#!/usr/bin/env python3
"""
Arranque unificado (sin Docker): colectores + bot + Mini App + túnel, en un solo proceso.

    python run_all.py                 # todo
    python run_all.py --no-tunnel     # sin cloudflared
    python run_all.py --only bot,miniapp,winamax   # solo algunos
    python run_all.py --skip pokerstars,codere # todos menos estos (o SKIP_SERVICES=... en .env)
    python run_all.py --verbose       # todo el log en consola (por defecto solo avisos; el log completo va a data/logs/)

Lee la configuración de `.env` (junto a este archivo; copia .env.example y rellena BOT_TOKEN y
ADMIN_ID). Las rutas /app/data/... del .env se traducen automáticamente a ./data/ cuando se
ejecuta fuera de Docker. Cada servicio se reinicia solo si muere, y Ctrl+C los para todos.

Túnel: si existe `cloudflared` (en PATH o ./cloudflared.exe) se abre un quick tunnel hacia la
Mini App y la URL https://xxx.trycloudflare.com se escribe en data/miniapp_url.txt, de donde el
bot la lee en caliente: no hace falta /setminiapp.
"""
from __future__ import annotations

import os
import re
import shutil
import signal
import subprocess
import sys
import threading
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
PY = sys.executable

SERVICES = {               # nombre: (cwd, comando)
    "winamax":     ("scraper", [PY, "-u", "winamax.py"]),
    "paston":      ("scraper", [PY, "-u", "paston.py"]),
    "betsson":     ("scraper", [PY, "-u", "betsson.py"]),
    "leovegas":    ("scraper", [PY, "-u", "kambi.py", "--cfg", "leovegas.json"]),
    "casumo":      ("scraper", [PY, "-u", "kambi.py", "--cfg", "casumo.json"]),
    "speedybet":   ("scraper", [PY, "-u", "kambi.py", "--cfg", "speedybet.json"]),
    "paf":         ("scraper", [PY, "-u", "kambi.py", "--cfg", "paf.json"]),
    "bwin":        ("scraper", [PY, "-u", "bwin.py"]),
    "888sport":    ("scraper", [PY, "-u", "spectate888.py"]),
    "pokerstars":  ("scraper", [PY, "-u", "pokerstars.py"]),
    "jokerbet":    ("scraper", [PY, "-u", "paston.py", "--cfg", "jokerbet.json"]),
    "betway":      ("scraper", [PY, "-u", "betway.py"]),
    "sportium":    ("scraper", [PY, "-u", "sportium.py"]),
    "marca":       ("scraper", [PY, "-u", "sportium.py", "--cfg", "marca.json"]),
    "versus":      ("scraper", [PY, "-u", "sportium.py", "--cfg", "versus.json"]),
    "codere":      ("scraper", [PY, "-u", "codere.py"]),
    "tonybet":     ("scraper", [PY, "-u", "tonybet.py"]),
    "betinia":     ("scraper", [PY, "-u", "paston.py", "--cfg", "betinia.json"]),
    "admiralbet":  ("scraper", [PY, "-u", "paston.py", "--cfg", "admiralbet.json"]),
    "solcasino":   ("scraper", [PY, "-u", "paston.py", "--cfg", "solcasino.json"]),
    "yaass":       ("scraper", [PY, "-u", "yaass.py"]),
    "dafabet":     ("scraper", [PY, "-u", "dafabet.py"]),
    "interwetten": ("scraper", [PY, "-u", "interwetten.py"]),
    "daznbet":     ("scraper", [PY, "-u", "daznbet.py"]),
    "bet777":      ("scraper", [PY, "-u", "bet777.py"]),
    "goldenpark":  ("scraper", [PY, "-u", "goldenpark.py"]),
    "limpieza":    ("scraper", [PY, "-u", "housekeeping.py"]),
    "bot":         ("bot",     [PY, "-u", "main.py"]),
    "miniapp":     ("bot",     [PY, "-u", "-m", "miniapp.app"]),
}
DEFAULT_SKIP = ""   # casas desactivadas por defecto (SKIP_SERVICES= en .env o --skip a,b)
COLORS = {"winamax": 35, "paston": 36, "betsson": 32, "leovegas": 93, "casumo": 95, "bwin": 94, "888sport": 96, "pokerstars": 91, "jokerbet": 92, "betway": 97, "sportium": 38, "marca": 39, "versus": 33, "codere": 33, "tonybet": 34, "betinia": 36, "admiralbet": 37, "yaass": 38, "dafabet": 39, "interwetten": 32, "speedybet": 40, "solcasino": 41, "paf": 42, "daznbet": 44, "bet777": 45, "goldenpark": 46, "limpieza": 90, "bot": 31, "miniapp": 95, "tunnel": 90}
_stop = threading.Event()


def load_env() -> dict:
    env = dict(os.environ)
    f = ROOT / ".env"
    if not f.exists() and (ROOT / ".env.txt").exists():      # el Bloc de notas añade .txt
        f = ROOT / ".env.txt"
        print(f"aviso: usando {f.name} (renómbralo a .env)")
    if f.exists():
        for line in f.read_text(encoding="utf-8-sig").splitlines():   # -sig: tolera el BOM del Bloc de notas
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            v = v.split(" #")[0].strip().strip('"').strip("'")
            env.setdefault(k.strip(), v)
    # rutas de Docker → locales
    for k in ("DB_PATH", "ODDS_DB", "MINIAPP_URL_FILE"):
        v = env.get(k, "")
        if v.startswith("/app/"):
            env[k] = str(ROOT / v[5:])
    env.setdefault("DB_PATH", str(DATA / "bot_v2.db"))
    env.setdefault("ODDS_DB", str(DATA / "odds.db"))
    env.setdefault("MINIAPP_URL_FILE", str(DATA / "miniapp_url.txt"))
    env.setdefault("MINIAPP_ENABLED", "true")
    env.setdefault("MINIAPP_PORT", "8080")
    env.setdefault("PYTHONIOENCODING", "utf-8")
    env.setdefault("PYTHONUTF8", "1")
    return env


# ── Logs: a fichero siempre (data/logs/<servicio>.log, rotación 5 MB × 3), a la consola solo lo importante ──
# Pintar 25 procesos de log con colores en la consola de Windows cuesta más CPU que el propio sistema (con la
# ventana abierta el equipo iba al 90 %; minimizada, al 30-40 %). CONSOLE_LOG en .env:
#   warn (por defecto) = solo WARNING/ERROR y arranques/caídas · all = todo como antes · none = nada
CONSOLE_LOG = "warn"
_LOG_DIR = DATA / "logs"
_files: dict[str, object] = {}
_files_lock = threading.Lock()
_LEVEL_RX = re.compile(r"\b(WARNING|ERROR|CRITICAL)\b")


def _logfile(name: str):
    import logging
    from logging.handlers import RotatingFileHandler
    with _files_lock:
        lg = _files.get(name)
        if lg is None:
            _LOG_DIR.mkdir(parents=True, exist_ok=True)
            lg = logging.getLogger(f"svc.{name}")
            lg.propagate = False
            lg.setLevel(logging.INFO)
            h = RotatingFileHandler(_LOG_DIR / f"{name}.log", maxBytes=5_000_000, backupCount=3, encoding="utf-8")
            h.setFormatter(logging.Formatter("%(message)s"))
            lg.addHandler(h)
            _files[name] = lg
        return lg


def say(name: str, line: str, force: bool = False):
    line = line.rstrip()
    _logfile(name).info(line)
    if CONSOLE_LOG == "none" and not force:
        return
    if CONSOLE_LOG == "warn" and not force and not _LEVEL_RX.search(line):
        return
    c = COLORS.get(name, 0)
    sys.stdout.write(f"\x1b[{c}m[{name:<11}]\x1b[0m {line}\n")
    sys.stdout.flush()


def pump(name: str, proc: subprocess.Popen, on_line=None):
    for raw in iter(proc.stdout.readline, b""):
        line = raw.decode("utf-8", "replace")
        say(name, line)
        if on_line:
            on_line(line)


def supervise(name: str, cwd: Path, cmd: list[str], env: dict, on_line=None):
    backoff = 2
    while not _stop.is_set():
        t0 = time.time()
        try:
            proc = subprocess.Popen(cmd, cwd=str(cwd), env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                    creationflags=getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0))
        except FileNotFoundError as e:
            say(name, f"no se pudo arrancar: {e}", force=True)
            return
        _procs[name] = proc
        pump(name, proc, on_line)
        code = proc.wait()
        if _stop.is_set():
            return
        backoff = 2 if time.time() - t0 > 120 else min(backoff * 2, 60)
        say(name, f"terminó con código {code}; reinicio en {backoff}s", force=True)
        _stop.wait(backoff)


_procs: dict[str, subprocess.Popen] = {}


def find_cloudflared() -> str | None:
    for cand in (ROOT / "cloudflared.exe", ROOT / "cloudflared", ROOT / "scraper" / "cloudflared.exe"):
        if cand.exists():
            return str(cand)
    return shutil.which("cloudflared")


def main():
    args = sys.argv[1:]
    only = None
    if "--only" in args:
        only = set(args[args.index("--only") + 1].split(","))
    no_tunnel = "--no-tunnel" in args
    env = load_env()
    global CONSOLE_LOG
    CONSOLE_LOG = (env.get("CONSOLE_LOG", "warn") or "warn").strip().lower()
    if "--verbose" in args:
        CONSOLE_LOG = "all"
    # Casas desactivadas: SKIP_SERVICES en .env (lista separada por comas) o --skip a,b. Por defecto ninguna.
    skip = set(x.strip() for x in env.get("SKIP_SERVICES", DEFAULT_SKIP).split(",") if x.strip())
    if "--skip" in args:
        skip |= set(args[args.index("--skip") + 1].split(","))
    if skip:
        print("Servicios desactivados (SKIP_SERVICES):", ", ".join(sorted(skip)))
    DATA.mkdir(exist_ok=True)
    if not env.get("BOT_TOKEN") or not env.get("ADMIN_ID"):
        f = ROOT / ".env"
        print("Falta BOT_TOKEN o ADMIN_ID.")
        print(f"  Archivo esperado: {f}  → {'existe' if f.exists() else 'NO EXISTE'}")
        print("  Archivos .env* en la carpeta:", [p.name for p in ROOT.glob(".env*")])
        if f.exists():
            keys = [l.split('=', 1)[0].strip() for l in f.read_text(encoding='utf-8-sig').splitlines()
                    if '=' in l and not l.strip().startswith('#')]
            print("  Claves leídas:", keys)
        sys.exit(1)
    if os.name == "nt":
        os.system("")   # habilita colores ANSI en la consola de Windows

    threads = []
    for name, (sub, cmd) in SERVICES.items():
        if only and name not in only:
            continue
        if name in skip and not (only and name in only):
            continue
        th = threading.Thread(target=supervise, args=(name, ROOT / sub, cmd, env), daemon=True)
        th.start()
        threads.append(th)
        time.sleep(0.5)

    if not no_tunnel and (only is None or "tunnel" in only or "miniapp" in only):
        cf = find_cloudflared()
        if cf:
            url_file = Path(env["MINIAPP_URL_FILE"])

            def on_line(line: str):
                m = re.search(r"https://[a-z0-9-]+\.trycloudflare\.com", line)
                if m:
                    url_file.write_text(m.group(0) + "\n", encoding="utf-8")
                    say("tunnel", f"✅ Mini App pública en {m.group(0)} (guardada en {url_file.name}; el bot la usa ya)", force=True)

            cmd = [cf, "tunnel", "--no-autoupdate", "--url", f"http://localhost:{env['MINIAPP_PORT']}"]
            th = threading.Thread(target=supervise, args=("tunnel", ROOT, cmd, env, on_line), daemon=True)
            th.start()
            threads.append(th)
        else:
            say("tunnel", "cloudflared no encontrado: la Mini App solo será accesible con /setminiapp <url> y un túnel manual", force=True)

    say("run_all", f"{len(threads)} servicios arrancados. Ctrl+C para parar todo.", force=True)
    if CONSOLE_LOG != "all":
        say("run_all", f"en consola solo avisos y errores (CONSOLE_LOG={CONSOLE_LOG}); log completo por servicio en {_LOG_DIR}", force=True)
    try:
        while any(t.is_alive() for t in threads):
            time.sleep(1)
    except KeyboardInterrupt:
        pass
    _stop.set()
    say("run_all", "parando…", force=True)
    for name, p in list(_procs.items()):
        if p.poll() is None:
            try:
                if os.name == "nt":
                    p.send_signal(signal.CTRL_BREAK_EVENT)
                else:
                    p.terminate()
            except Exception:   # noqa: BLE001
                pass
    time.sleep(3)
    for p in _procs.values():
        if os.name == "nt":                  # árbol completo: python -> driver de Playwright -> msedge/chrome (todas sus pestañas)
            try:
                subprocess.run(["taskkill", "/PID", str(p.pid), "/T", "/F"], capture_output=True, timeout=20)
            except Exception:   # noqa: BLE001
                pass
        if p.poll() is None:
            p.kill()
    try:                                     # ventanas de Edge/Chrome que hayan quedado vivas (perfiles chrome_profile*)
        sys.path.insert(0, str(ROOT / "scraper"))
        from transport import kill_browsers
        n = kill_browsers(str(ROOT / "scraper" / "chrome_profile"))
        time.sleep(2)
        n += kill_browsers(str(ROOT / "scraper" / "chrome_profile"))      # segunda pasada: procesos que estaban cerrándose
        say("run_all", f"{n} procesos de navegador huérfanos cerrados" if n else "sin navegadores huérfanos", force=True)
    except Exception as e:   # noqa: BLE001
        say("run_all", f"no pude barrer navegadores huérfanos: {e}", force=True)


if __name__ == "__main__":
    main()
