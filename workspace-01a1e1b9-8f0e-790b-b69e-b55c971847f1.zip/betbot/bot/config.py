"""
Configuración central del bot.

Se puede editar directamente `RuntimeConfig` o dejar valores por defecto
y pasarlos por *variables de entorno* (recomendado para Docker).

Nombres de las env vars:
    BOT_TOKEN, ADMIN_ID, ADMIN_IDS (coma-separado),
    STRIPE_SECRET_KEY,
    STRIPE_SUCCESS_URL, STRIPE_CANCEL_URL, STRIPE_PORTAL_URL,
    DB_PATH, FREE_TRIAL_DAYS, EXAMPLE_STAKE, STAKE_CURRENCY,
    ODDS_DB, ODDS_POLL_SECONDS (fuente de cuotas: scraper),
    PLAN_WEEKLY_PRICE_ID, PLAN_MONTHLY_PRICE_ID,
    PLAN_QUARTERLY_PRICE_ID, PLAN_YEARLY_PRICE_ID
"""
from __future__ import annotations
import os
from dataclasses import dataclass, field


# ──────────────────────────────────────────────────────────
# HELPERS PARA ENV VARS
# ──────────────────────────────────────────────────────────

def _env(key: str, default: str = "") -> str:
    return os.getenv(key, default) or default

def _env_float(key: str, default: float = 0.0) -> float:
    try:
        return float(_env(key, str(default)))
    except ValueError:
        return default


def _env_int(key: str, default: int = 0) -> int:
    try:
        return int(os.getenv(key) or default)
    except ValueError:
        return default

def _env_bool(key: str, default: bool = False) -> bool:
    v = (os.getenv(key) or "").strip().lower()
    if v in ("1", "true", "yes", "on"):  return True
    if v in ("0", "false", "no", "off"): return False
    return default

def _env_tuple(key: str) -> tuple:
    raw = os.getenv(key) or ""
    items = [x.strip() for x in raw.split(",") if x.strip()]
    # Intentar convertir a int si son ids numéricos
    out = []
    for it in items:
        try:
            out.append(int(it))
        except ValueError:
            out.append(it)
    return tuple(out)


# ──────────────────────────────────────────────────────────
# CONFIG DE RUNTIME (editable / env vars)
# ──────────────────────────────────────────────────────────

@dataclass(frozen=True)
class RuntimeConfig:
    # Telegram
    bot_token: str = field(default_factory=lambda: _env("BOT_TOKEN"))
    admin_id:  int = field(default_factory=lambda: _env_int("ADMIN_ID"))
    admin_ids: tuple = field(default_factory=lambda: _env_tuple("ADMIN_IDS"))

    # Stripe
    stripe_secret_key:     str = field(default_factory=lambda: _env("STRIPE_SECRET_KEY"))
    stripe_success_url:    str = field(default_factory=lambda: _env("STRIPE_SUCCESS_URL"))
    stripe_cancel_url:     str = field(default_factory=lambda: _env("STRIPE_CANCEL_URL"))
    stripe_portal_url:     str = field(default_factory=lambda: _env("STRIPE_PORTAL_URL"))

    # ── MODO DE SINCRONIZACIÓN CON STRIPE ────────────────
    # "webhook"  → Stripe llama a tu servidor (necesita HTTPS/dominio)
    # "polling"  → el bot consulta Stripe cada N minutos (sin dominio)
    stripe_mode:          str = field(default_factory=lambda: _env("STRIPE_MODE", "polling"))
    stripe_poll_interval: int = field(default_factory=lambda: _env_int("STRIPE_POLL_INTERVAL", 300))  # segundos

    # Planes de suscripción — price_ids desde env
    plans: dict = field(default_factory=lambda: {
        "weekly":    {"price_id": _env("PLAN_WEEKLY_PRICE_ID"),
                      "label": "Semanal",    "display": "15 €/sem",     "days": 7},
        "monthly":   {"price_id": _env("PLAN_MONTHLY_PRICE_ID"),
                      "label": "Mensual",    "display": "60 €/mes",     "days": 30},
        "quarterly": {"price_id": _env("PLAN_QUARTERLY_PRICE_ID"),
                      "label": "Trimestral", "display": "150 €/3 meses","days": 90},
        "yearly":    {"price_id": _env("PLAN_YEARLY_PRICE_ID"),
                      "label": "Anual",      "display": "480 €/año",    "days": 365},
    })

    # Prueba gratuita (sin tarjeta) al hacer /start la primera vez
    free_trial_days: int = field(default_factory=lambda: _env_int("FREE_TRIAL_DAYS", 3))
    # Tope de seguridad (aprox. 3 años): una sincronización automática
    # nunca dejará la suscripción más allá de aquí. Es el freno que
    # impide que un fallo la infle sin límite. Las compras reales y
    # las acciones de un admin no están limitadas por esto.
    max_subscription_days: int = field(
        default_factory=lambda: _env_int("MAX_SUBSCRIPTION_DAYS", 1100))

    # Base de datos
    db_path: str = field(default_factory=lambda: _env("DB_PATH", "/app/data/bot_v2.db"))

    # ── APUESTAS: ejemplo de reparto ─────────────────────
    # Banco con el que se calcula el stake de ejemplo del mensaje.
    example_stake: int = field(default_factory=lambda: _env_int("EXAMPLE_STAKE", 100))
    # Divisa en la que se muestran los importes (BetBurger ya manda euros).
    stake_currency: str = field(default_factory=lambda: _env("STAKE_CURRENCY", "€"))


    # ── MINI APP (WebApp de Telegram) ───────────────────
    # Telegram exige una URL pública HTTPS: no vale localhost ni una IP.
    # Sácala con Cloudflare Tunnel (sobre tu dominio) o Tailscale Funnel.
    miniapp_enabled: bool = field(default_factory=lambda: _env_bool("MINIAPP_ENABLED", False))
    miniapp_url: str = field(default_factory=lambda: _env("MINIAPP_URL").rstrip("/"))
    miniapp_host: str = field(default_factory=lambda: _env("MINIAPP_HOST", "0.0.0.0"))
    miniapp_port: int = field(default_factory=lambda: _env_int("MINIAPP_PORT", 8080))
    # Override en caliente: si este fichero existe y tiene una URL, gana.
    # Pensado para los túneles rápidos, cuya URL cambia en cada reinicio:
    # así cambias la URL sin reiniciar el bot (ver /setminiapp).
    miniapp_url_file: str = field(
        default_factory=lambda: _env("MINIAPP_URL_FILE") or os.path.join(
            os.path.dirname(_env("DB_PATH", "/app/data/bot_v2.db")) or ".", "miniapp_url.txt"))
    # Antigüedad máxima aceptada del initData firmado por Telegram (segundos)
    miniapp_initdata_max_age: int = field(
        default_factory=lambda: _env_int("MINIAPP_INITDATA_MAX_AGE", 3600))

    # ── ENVÍO / LATENCIA ────────────────────────────────
    # Cuántos sendMessage se lanzan EN PARALELO.
    # Si es 1, los envíos son secuenciales: con 100 usuarios el último
    # recibe la apuesta ~3-5 s después que el primero (mata las LIVE).
    max_parallel_sends: int = field(
        default_factory=lambda: _env_int("MAX_PARALLEL_SENDS", 30))

    # ── FUENTE DE CUOTAS: scraper (odds.db) ─────────────
    odds_db_path:    str   = field(default_factory=lambda: _env("ODDS_DB", "/app/data/odds.db"))
    odds_poll_seconds: int = field(default_factory=lambda: _env_int("ODDS_POLL_SECONDS", 3))
    surebet_detector_enabled: bool = field(default_factory=lambda: _env_bool("SUREBET_DETECTOR_ENABLED", True))
    surebet_detector_min_profit: float = field(default_factory=lambda: _env_float("SUREBET_DETECTOR_MIN_PROFIT", 0.5))
    # Filtros de calidad antes de enviar: beneficio máximo (0 = sin límite; si se fija, por encima se descarta y se loguea),
    # espera de confirmación (la cuota debe seguir igual N s después) y antigüedad máxima del dato de cada casa.
    surebet_max_profit:      float = field(default_factory=lambda: _env_float("SUREBET_MAX_PROFIT", 0.0))
    # coherencia: las probabilidades (sin margen) que cada casa da a su pata deben sumar ~1; si se alejan más que esto
    # es que no es el mismo mercado (periodo/línea distinta) o una casa tiene la cuota suspendida/vieja
    surebet_max_prob_gap:    float = field(default_factory=lambda: _env_float("SUREBET_MAX_PROB_GAP", 0.0))
    signal_confirm_seconds:  float = field(default_factory=lambda: _env_float("SIGNAL_CONFIRM_SECONDS", 3.0))
    odds_max_age_live:       float = field(default_factory=lambda: _env_float("ODDS_MAX_AGE_LIVE", 45.0))
    # live estricto: cada pata tiene que haberse VISTO (seen_at/changed_at de la propia cuota) hace <= N s; 0 = desactivado
    surebet_live_max_leg_age: float = field(default_factory=lambda: _env_float("SUREBET_LIVE_MAX_LEG_AGE", 3.0))
    # live: una cuota que lleva más de X s sin cambiar de precio está congelada (la casa no recibe actualizaciones de ese
    # partido: p. ej. Playtech con precios pre-partido tras el inicio); 0 = desactivado
    surebet_live_max_frozen: float = field(default_factory=lambda: _env_float("SUREBET_LIVE_MAX_FROZEN", 300.0))
    odds_max_age_prematch:   float = field(default_factory=lambda: _env_float("ODDS_MAX_AGE_PREMATCH", 150.0))
    # Detector de middlebets (Más de L1 en una casa + Menos de L2 > L1 en otra; hándicaps con hueco)
    middle_enabled:      bool  = field(default_factory=lambda: _env_bool("MIDDLE_ENABLED", True))
    middle_max_worst_profit: float = field(default_factory=lambda: _env_float("MIDDLE_MAX_WORST_PROFIT", 8.0))  # un middle con peor caso > X% es matemáticamente imposible (línea mal leída); 0 = sin límite
    middle_max_loss_pct: float = field(default_factory=lambda: _env_float("MIDDLE_MAX_LOSS_PCT", 0.0))   # pérdida máx. si no entra en el hueco (0 = solo middles sin pérdida)
    middle_min_gap:      float = field(default_factory=lambda: _env_float("MIDDLE_MIN_GAP", 1.0))        # tamaño mínimo del hueco

    # Idiomas soportados
    default_language: str = field(default_factory=lambda: _env("DEFAULT_LANGUAGE", "es"))

    def is_admin(self, user_id: int) -> bool:
        return user_id == self.admin_id or user_id in self.admin_ids


CONFIG = RuntimeConfig()


def get_miniapp_url() -> str:
    """
    URL efectiva de la Mini App.

    Prioridad:
      1. El fichero de override (se cambia en caliente con /setminiapp).
      2. La variable MINIAPP_URL del .env.

    Esto existe porque el túnel rápido de Cloudflare
    (`cloudflared tunnel --url`) genera una URL DISTINTA en cada arranque,
    y sin esto habría que reiniciar el bot cada vez.
    """
    path = CONFIG.miniapp_url_file
    if path:
        try:
            with open(path, "r", encoding="utf-8") as fh:
                url = fh.read().strip().splitlines()[0].strip() if fh.readable() else ""
            if url:
                return url.rstrip("/")
        except (OSError, IndexError):
            pass
    return CONFIG.miniapp_url



def set_miniapp_url(url: str) -> bool:
    """Escribe el override en caliente. Pasa '' para volver al .env."""
    path = CONFIG.miniapp_url_file
    if not path:
        return False
    try:
        url = (url or "").strip()
        if not url:
            try:
                os.remove(path)
            except FileNotFoundError:
                pass
            return True
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(url.rstrip("/") + "\n")
        return True
    except OSError:
        return False
