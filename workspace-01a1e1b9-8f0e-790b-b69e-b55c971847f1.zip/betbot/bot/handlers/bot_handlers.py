"""
BotHandlers: registra todos los handlers de python-telegram-bot y los conecta
con los servicios y las vistas.
"""
from __future__ import annotations
import asyncio
import logging

from telegram import Update
from telegram.ext import (
    Application, CommandHandler, CallbackQueryHandler,
    ContextTypes,
)

from config import (CONFIG, get_miniapp_url, set_miniapp_url)
from i18n import t
from domain.bookmakers import CATALOG as BOOKMAKERS
from data.repository import (
    UserRepository, StatsRepository, FreebetRepository, Database,
)
from services.distribution import DistributionService
from services.subscription import SubscriptionService
from services.stripe_gateway import StripeGateway

log = logging.getLogger(__name__)


class BotHandlers:

    def __init__(self,
                 users: UserRepository,
                 stats: StatsRepository,
                 distribution: DistributionService,
                 subscription: SubscriptionService,
                 stripe_gw: StripeGateway,
                 freebets: FreebetRepository = None,
                 admins=None):
        self.users = users
        self.admins = admins
        self.stats = stats
        # Se inyecta desde main.py; si no llega, abrimos nuestra propia
        # conexión (mismo fichero, gracias al modo WAL).
        self.freebets = freebets or FreebetRepository(Database(CONFIG.db_path))
        self.distribution = distribution
        self.subscription = subscription
        self.stripe = stripe_gw

    # ═════════════════════════════════════════════════════
    #  REGISTRO
    # ═════════════════════════════════════════════════════
    def register(self, app: Application):
        # Traza de todo lo que llega (grupo -1 no consume el update)
        from telegram.ext import TypeHandler

        async def _trace(update, ctx):
            u = update.effective_user
            m = update.effective_message
            c = update.effective_chat
            log.info("⬅️ update de %s (%s) chat=%s/%s edited=%s entities=%s: %r",
                     u.id if u else None, u.username if u else None,
                     c.id if c else None, c.type if c else None,
                     update.edited_message is not None,
                     [e.type for e in (m.entities if m else [])], (m.text if m else None))
        app.add_handler(TypeHandler(Update, _trace), group=-1)

        # Comandos
        app.add_handler(CommandHandler("start", self.cmd_start))
        app.add_handler(CommandHandler("panel", self.cmd_panel))
        app.add_handler(CommandHandler("setminiapp", self.cmd_setminiapp))
        app.add_handler(CommandHandler("freebet", self.cmd_freebet))
        app.add_handler(CommandHandler("freebets", self.cmd_freebets))
        app.add_handler(CommandHandler("freebetdel", self.cmd_freebetdel))
        app.add_handler(CommandHandler("eventsclear", self.cmd_eventsclear))
        app.add_handler(CommandHandler("miniapp", self.cmd_miniapp))
        app.add_handler(CommandHandler("filtros", self.cmd_filtros))
        app.add_handler(CommandHandler("filters", self.cmd_filtros))

        # Callbacks
        app.add_handler(CallbackQueryHandler(self.on_callback))


    # ═════════════════════════════════════════════════════
    #  COMANDOS
    # ═════════════════════════════════════════════════════
    async def cmd_start(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        tg = update.effective_user
        log.info("cmd_start de %s", tg.id)
        user = self.users.get_or_create(
            tg.id, tg.username or "", tg.first_name or ""
        )
        # Refrescamos el perfil (nombre y usuario pueden cambiar en Telegram).
        # IMPORTANTE: hay que guardarlo aquí, porque si el trial no se activa
        # no hay ningún save() después y los cambios se perdían.
        cambiado = False
        if tg.username and tg.username != (user.username or ""):
            user.username = tg.username
            cambiado = True
        if tg.first_name and tg.first_name != (user.first_name or ""):
            user.first_name = tg.first_name
            cambiado = True
        if cambiado:
            self.users.save(user)

        # Activar trial la primera vez
        trial_activated = self.subscription.start_free_trial(user)

        user = self.users.find(tg.id)   # recarga tras trial
        await self._show_home(update, user, trial_activated)

    async def _send_app_launcher(self, update, user, trial_activated=False, is_admin=False):
        """
        Mensaje mínimo de bienvenida con un único botón que abre la Mini App.
        Toda la configuración vive dentro de la app.
        """
        from telegram import InlineKeyboardButton, InlineKeyboardMarkup, WebAppInfo

        lang = user.filters.language
        s = user.subscription

        # Los administradores no necesitan suscripción: acceso total.
        if is_admin:
            estado = t("launch.admin", lang)
            extra = ""
            text = (
                f"{t('launch.greet', lang, name=user.first_name or '')}\n"
                f"{estado}{extra}\n\n"
                f"{t('launch.help', lang)}"
            )
            if not get_miniapp_url():
                await update.effective_message.reply_text(
                    text + "\n\n⚠️ Mini App sin URL: arranca `python -m miniapp.app` + túnel https y envía "
                    "`/setminiapp https://...`", parse_mode="Markdown")
                return
            kb = InlineKeyboardMarkup([[
                InlineKeyboardButton(
                    t("launch.open", lang),
                    web_app=WebAppInfo(url=get_miniapp_url()),
                )
            ]])
            await update.effective_message.reply_text(
                text, reply_markup=kb, parse_mode="Markdown")
            return

        if s.is_active:
            plan_name = s.plan.value.capitalize() if s.plan else "—"
            if s.is_trial:
                plan_name = t("home.trial_name", lang)
            estado = t("launch.active", lang, plan=plan_name, days=s.days_left)
        else:
            estado = t("launch.no_sub", lang)

        extra = ""
        if trial_activated:
            extra = "\n" + t("launch.trial", lang, days=CONFIG.free_trial_days)

        text = (
            f"{t('launch.greet', lang, name=user.first_name or '')}\n"
            f"{estado}{extra}\n\n"
            f"{t('launch.help', lang)}"
        )
        kb = InlineKeyboardMarkup([[
            InlineKeyboardButton(
                t("launch.open", lang),
                web_app=WebAppInfo(url=get_miniapp_url()),
            )
        ]])
        await update.effective_message.reply_text(
            text, reply_markup=kb, parse_mode="Markdown"
        )

    async def cmd_panel(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """/panel hace lo mismo que /start: abre la Mini App."""
        tg = update.effective_user
        user = self.users.get_or_create(tg.id, tg.username or "", tg.first_name or "")
        await self._show_home(update, user)

    async def _show_home(self, update, user, trial_activated=False):
        """
        Pantalla de inicio: abre la Mini App.

        No hay panel de botones: filtros, suscripción, estadísticas, promos y
        administración viven dentro de la app.
        """
        es_admin = bool(
            self.admins and self.admins.is_admin(user.telegram_id)
        )
        miniapp_url = get_miniapp_url()
        # activa si MINIAPP_ENABLED=true o si se fijó una URL en caliente con /setminiapp
        if miniapp_url and (CONFIG.miniapp_enabled or miniapp_url != CONFIG.miniapp_url):
            await self._send_app_launcher(
                update, user, trial_activated, is_admin=es_admin)
            return

        lang = user.filters.language
        estado = (t("launch.admin", lang) if es_admin else t("launch.no_sub", lang))
        await update.effective_message.reply_text(
            f"{t('launch.greet', lang, name=user.first_name or '')}\n"
            f"{estado}\n\n"
            f"{t('launch.help', lang)}\n\n"
            f"{t('launch.nodispo', lang)}",
            parse_mode="Markdown",
        )

    # ═════════════════════════════════════════════════════
    #  HISTORIAL DE SUSCRIPCIONES
    # ═════════════════════════════════════════════════════
    async def cmd_eventsclear(self, update, ctx):
        """
        /eventsclear — vacía el historial de cambios de suscripción.

        Útil cuando se acumula mucho. La función sigue activa: desde la
        Mini App (botón "Vaciar historial" en Admin) o con este comando.
        """
        if not CONFIG.is_admin(update.effective_user.id):
            return
        try:
            n = self.users.clear_sub_events()
            await update.effective_message.reply_text(
                f"🧹 Historial de suscripciones vaciado.\n"
                f"Se borraron *{n}* registros.\n\n"
                f"La auditoría sigue activa y volverá a registrar los cambios "
                f"a partir de ahora.",
                parse_mode="Markdown",
            )
        except Exception as e:                              # noqa: BLE001
            log.error("No pude vaciar el historial: %s", e)
            await update.effective_message.reply_text(f"❌ No pude vaciar el historial: {e}")

    # ═════════════════════════════════════════════════════
    #  MINI APP — gestión de la URL en caliente
    # ═════════════════════════════════════════════════════
    async def cmd_setminiapp(self, update, ctx):
        """
        /setminiapp <url>   → cambia la URL de la Mini App SIN reiniciar el bot.
        /setminiapp off     → vuelve a la URL del .env
        Útil con los túneles rápidos, que cambian de URL en cada arranque.
        """
        log.info("cmd_setminiapp de %s", update.effective_user.id)
        if not CONFIG.is_admin(update.effective_user.id):
            await update.effective_message.reply_text(
                f"⛔ Solo admins. Tu ID es {update.effective_user.id}; "
                f"ADMIN_ID configurado: {CONFIG.admin_id or '(vacío)'}")
            return

        arg = " ".join(ctx.args or []).strip()
        if not arg:
            await update.effective_message.reply_text(
                "Uso:\n"
                "`/setminiapp https://xxx.trycloudflare.com`\n"
                "`/setminiapp off`  ← volver a la URL del .env",
                parse_mode="Markdown",
            )
            return

        if arg.lower() in ("off", "reset", "clear", "no"):
            set_miniapp_url("")
            url = get_miniapp_url()
        else:
            if not arg.startswith("https://"):
                await update.effective_message.reply_text("❌ La URL debe empezar por https://")
                return
            set_miniapp_url(arg)
            url = arg.rstrip("/")

        # ¿Responde la Mini App en esa URL? Si no, el botón ⚙️ Panel abrirá
        # una página en blanco, así que mejor avisar ahora.
        reachable, ping = await self._ping_miniapp(url)

        # Re-registrar el botón del menú con la nueva URL
        try:
            from telegram import MenuButtonWebApp, WebAppInfo
            await ctx.bot.set_chat_menu_button(
                menu_button=MenuButtonWebApp(text="⚙️ Panel",
                                             web_app=WebAppInfo(url=url))
            )
            menu = "✅ Botón del menú actualizado"
        except Exception as e:
            menu = f"⚠️ No pude actualizar el menú: {e}"

        aviso = ""
        if not reachable:
            aviso = (
                "\n\n⚠️ **Pero no respondió**: `ping` → " + ping + "\n"
                "El botón ⚙️ Panel abrirá una página vacía.\n"
                "Comprueba que el contenedor de la Mini App está arriba\n"
                "`docker compose ps`"
            )

        await update.effective_message.reply_text(
            f"🧩 URL de la Mini App:\n`{url}`\n\n"
            f"{menu}{aviso}\n\n"
            f"Abre /start y pulsa **⚙️ Panel**.",
            parse_mode="Markdown",
        )

    async def _ping_miniapp(self, url: str):
        """Comprueba que la Mini App responde en esa URL. (ok, detalle)"""
        import urllib.request
        import urllib.error
        try:
            req = urllib.request.Request(
                url.rstrip("/") + "/healthz",
                headers={"User-Agent": "bot-ping"},
            )
            with urllib.request.urlopen(req, timeout=6) as r:
                return True, f"HTTP {r.status}"
        except urllib.error.HTTPError as e:
            # Responde, aunque no con 200: la app está viva
            return True, f"HTTP {e.code}"
        except Exception as e:
            return False, f"{type(e).__name__}: {e}"

    # ═════════════════════════════════════════════════════
    #  PROMOCIONES / FREEBETS (solo admin)
    # ═════════════════════════════════════════════════════
    async def cmd_freebet(self, update, ctx):
        """
        /freebet <casa> | <título> | <valor €> | <url> [| condiciones]

        Ejemplo:
            /freebet codere | Apuesta gratis 10 € sin depósito | 10 | https://codere.es/promo
        """
        if not CONFIG.is_admin(update.effective_user.id):
            return

        raw = " ".join(ctx.args or []).strip()
        if not raw or raw.lower() in ("help", "ayuda"):
            await update.effective_message.reply_text(
                "*Publicar una promoción*\n\n"
                "`/freebet <casa> | <título> | <valor €> | <url>`\n"
                "opcional: `| <condiciones>`\n\n"
                "*Ejemplo*\n"
                "`/freebet codere | Apuesta gratis 10 € | 10 | https://… | Solo nuevos clientes`\n\n"
                "*Otros comandos*\n"
                "`/freebets` — listar activas\n"
                "`/freebetdel <id>` — retirar una",
                parse_mode="Markdown",
            )
            return

        parts = [p.strip() for p in raw.split("|")]
        if len(parts) < 3:
            await update.effective_message.reply_text(
                "❌ Faltan campos. Formato:\n"
                "`<casa> | <título> | <valor €> | <url>`",
                parse_mode="Markdown",
            )
            return

        casa   = parts[0].lower()
        titulo = parts[1]
        try:
            valor = float(str(parts[2]).replace(",", ".").replace("€", "").strip() or 0)
        except ValueError:
            valor = 0.0
        url         = parts[3] if len(parts) > 3 else ""
        condiciones = parts[4] if len(parts) > 4 else ""

        # Si la casa existe en el catálogo, guardamos su clave
        bk = BOOKMAKERS.get(casa) or BOOKMAKERS.find_by_text(casa)
        if bk:
            casa = bk[0].key if isinstance(bk, list) else bk.key

        fb_id = self.freebets.add(
            bookmaker=casa, title=titulo, value_eur=valor,
            url=url, description=condiciones, kind="freebet",
        )
        await update.effective_message.reply_text(
            f"✅ *Promoción publicada* (id `{fb_id}`)\n\n"
            f"🏦 {casa}\n📰 {titulo}\n💶 {valor:g} €\n🔗 {url or '—'}",
            parse_mode="Markdown",
        )

    async def cmd_freebets(self, update, ctx):
        """/freebets — lista las promociones activas (solo admin)."""
        if not CONFIG.is_admin(update.effective_user.id):
            return
        items = self.freebets.list_active()
        if not items:
            await update.effective_message.reply_text("No hay promociones activas.")
            return
        lineas = []
        for f in items:
            lineas.append(
                f"🆔 `{f['id']}` · *{f['bookmaker']}*\n"
                f"   {f['title']} — {f['value_eur']:g} €"
            )
        await update.effective_message.reply_text(
            "*Promociones activas:*\n\n" + "\n".join(lineas)
            + "\n\n`/freebetdel <id>` para retirar una.",
            parse_mode="Markdown",
        )

    async def cmd_freebetdel(self, update, ctx):
        """/freebetdel <id> — retira una promoción (solo admin)."""
        if not CONFIG.is_admin(update.effective_user.id):
            return
        arg = (ctx.args or [""])[0].strip()
        try:
            fb_id = int(arg)
        except ValueError:
            await update.effective_message.reply_text("Uso: `/freebetdel <id>`", parse_mode="Markdown")
            return
        if self.freebets.deactivate(fb_id):
            await update.effective_message.reply_text(f"🗑 Promoción `{fb_id}` retirada.",
                                            parse_mode="Markdown")
        else:
            await update.effective_message.reply_text(f"⚠️ No encontré la promoción `{fb_id}`.",
                                            parse_mode="Markdown")

    async def cmd_miniapp(self, update, ctx):
        """/miniapp — abre la Mini App al instante (para no tener que ir al panel)."""
        url = get_miniapp_url()
        if not url or not (CONFIG.miniapp_enabled or url != CONFIG.miniapp_url):
            await update.effective_message.reply_text(
                "La Mini App no está activa.\n"
                "Pon `MINIAPP_ENABLED=true` y una `MINIAPP_URL` en el .env."
            )
            return
        from telegram import InlineKeyboardButton, InlineKeyboardMarkup, WebAppInfo
        await update.effective_message.reply_text(
            "🧩 Abrir configuración:",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("⚙️ Configurar filtros",
                                     web_app=WebAppInfo(url=url))
            ]]),
        )

    async def cmd_filtros(self, update, ctx):
        """/filtros — abre la Mini App directamente en la pestaña de filtros."""
        url = get_miniapp_url()
        if not url:
            await update.effective_message.reply_text("⚠️ La Mini App no está activa ahora mismo. Prueba en un momento.")
            return
        from telegram import InlineKeyboardButton, InlineKeyboardMarkup, WebAppInfo
        lang = "es"
        try:
            tg = update.effective_user
            u = self.users.get_or_create(tg.id, tg.username or "", tg.first_name or "")
            lang = u.filters.language or "es"
        except Exception:                                     # noqa: BLE001
            pass
        es = (lang == "es")
        sep = "&" if "?" in url else "?"
        await update.effective_message.reply_text(
            "🎛 Filtros de señales: deportes, casas, beneficio mínimo, directo/pre-partido, surebets y middles."
            if es else "🎛 Signal filters: sports, bookmakers, minimum profit, live/pre-match, surebets and middles.",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(
                "⚙️ Abrir filtros" if es else "⚙️ Open filters", web_app=WebAppInfo(url=f"{url}{sep}tab=filters"))]]),
        )

    # ═════════════════════════════════════════════════════
    #  CALLBACKS ROUTER
    # ═════════════════════════════════════════════════════
    async def on_callback(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        Único callback que el bot sigue emitiendo: 🔓 Desbloquear.

        Toda la configuración (filtros, suscripción, estadísticas, promos y
        administración) vive en la Mini App, así que ya no hay callbacks de
        panel, asistente ni administración por botones.
        """
        query = update.callback_query
        data = query.data
        try:
            await query.answer()
        except Exception as e:                       # "Query is too old": el usuario pulsó hace rato; seguimos igualmente
            log.debug("answer_callback_query: %s", e)

        if data == "unlock":
            await self._handle_unlock(query)
            return

        log.debug("Callback desconocido: %s", data)


    async def _handle_unlock(self, query):
        user_id = query.from_user.id
        msg_id  = query.message.message_id
        full = self.distribution.get_locked_text(user_id, msg_id)
        if not full:
            # Mensaje viejo (bot reiniciado) — el cache en memoria se perdió. Editar el mensaje funciona aunque la
            # pulsación sea antigua (answer() falla con "Query is too old" pasados ~30 s).
            try:
                await query.answer("⏳ Este aviso ya no está disponible", show_alert=True)
            except Exception:
                try:
                    await query.edit_message_reply_markup(reply_markup=None)
                except Exception:
                    pass
            return
        last = None
        for attempt in range(4):                     # reintentos: pool saturado / red / flood control momentáneos
            try:
                await query.edit_message_text(
                    full,
                    parse_mode="Markdown",
                    disable_web_page_preview=True,
                )
                self.distribution.clear_locked(user_id, msg_id)
                return
            except Exception as e:
                last = e
                wait = getattr(e, "retry_after", None)
                if "not modified" in str(e).lower():  # ya estaba desbloqueado
                    self.distribution.clear_locked(user_id, msg_id)
                    return
                await asyncio.sleep(float(wait) if wait else 0.5 * (attempt + 1))
        log.warning("No pude desbloquear mensaje %s/%s tras 4 intentos: %s", user_id, msg_id, last)

    # ═════════════════════════════════════════════════════

