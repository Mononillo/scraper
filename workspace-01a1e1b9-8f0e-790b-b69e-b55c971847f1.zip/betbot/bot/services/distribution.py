"""
DistributionService: orquesta el flujo completo.
    señal (odds.db) → matcher (por usuario) → formatter → envío

Los mensajes se envían "bloqueados": el usuario ve un teaser con el tipo,
deporte, ROI/EV y un botón 🔓 para desbloquear el detalle completo.
"""
from __future__ import annotations
import asyncio
import logging
import time

from telegram import Bot, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.constants import ParseMode

from config import CONFIG

from domain.models import Bet
from domain.sports import CATALOG as SPORTS
from services.matching import MatchingService
from services.formatter import BetFormatter, esc
from data.repository import UserRepository, StatsRepository

log = logging.getLogger(__name__)


class DistributionService:

    def __init__(
        self,
        bot: Bot,
        users: UserRepository,
        stats: StatsRepository,
        admins=None,
        matcher: MatchingService = None,
        formatter: BetFormatter = None,
        max_parallel_sends: int = None,
    ):
        self.bot = bot
        self.users = users
        self.stats = stats
        # Los administradores reciben las apuestas sin necesidad de
        # suscripción (útil para revisar que todo funciona).
        self.admins = admins
        self.matcher = matcher or MatchingService()
        # Acorta los enlaces "Place Bet" para que en el mensaje solo aparezca
        self.formatter = formatter or BetFormatter()

        # Cache de mensajes bloqueados: (user_id, message_id) → texto formateado
        # Se llena al enviar y se consume al desbloquear.
        self._locked_bets: dict[tuple[int, int], str] = {}

        # Envíos en paralelo (latencia). El semáforo se crea dentro del loop.
        self.max_parallel_sends = max(
            1,
            int(max_parallel_sends if max_parallel_sends is not None
                else getattr(CONFIG, "max_parallel_sends", 30)),
        )
        self._send_sem: asyncio.Semaphore | None = None

    # ══════════════════════════════════════════════════════
    #  API PÚBLICA — Entrada desde grupo / forwarder
    # ══════════════════════════════════════════════════════
    async def handle_bet(self, bet: Bet) -> int:
        """Entrada para Bets ya construidas (motor de señales del scraper): sin parser."""
        t0 = time.perf_counter()
        users = self.users.all_active()
        # Los admins reciben todas las señales aunque no tengan suscripción activa.
        if self.admins is not None:
            have = {u.telegram_id for u in users}
            for aid in list(self.admins.owners()) + list(self.admins.extra()):
                if aid not in have:
                    u = self.users.find(aid)
                    if u:
                        users.append(u)
                        have.add(aid)
        sent = await self._distribute(bet, users)
        log.info("📊 %s %s %.2f%% → %d usuarios (%.0f ms)", bet.kind.value, bet.game,
                 bet.profit_pct, sent, (time.perf_counter() - t0) * 1000)
        if sent:
            # detalle de las patas en el log (diagnóstico de señales dudosas sin tener que abrir el 🔓)
            legs = " | ".join(f"{l.bookmaker_key} {l.market_code or l.selection} @{l.odds:.2f}" for l in bet.lines)
            log.info("   ↳ %s%s%s: %s", bet.market, " · LIVE" if bet.period == "LIVE" else "",
                     f" · {getattr(bet, '_scores', '')}" if getattr(bet, "_scores", "") else "", legs)
        return sent


    # ══════════════════════════════════════════════════════
    #  API PÚBLICA — Desbloqueo (llamado desde el callback)
    # ══════════════════════════════════════════════════════
    def get_locked_text(self, user_id: int, message_id: int) -> str | None:
        return self._locked_bets.get((user_id, message_id))

    def clear_locked(self, user_id: int, message_id: int):
        self._locked_bets.pop((user_id, message_id), None)

    # ══════════════════════════════════════════════════════
    #  INTERNO
    # ══════════════════════════════════════════════════════
    async def _distribute(self, bet: Bet, active_users: list) -> int:
        """Envía la apuesta a todos los usuarios que la aceptan, EN PARALELO.

        El envío secuencial añadía ~30-50 ms por usuario: con 100 usuarios
        el último recibía la apuesta 3-5 s más tarde, lo que mata las LIVE.
        """
        # El semáforo se crea dentro del loop en ejecución (Python >= 3.10 ok,
        # pero así evitamos sorpresas si el servicio se instancia fuera).
        if self._send_sem is None:
            self._send_sem = asyncio.Semaphore(self.max_parallel_sends)

        targets = [
            u for u in active_users
            if (u.has_access or self._is_admin(u.telegram_id))
            and not self.matcher.is_muted(u)
            and self.matcher.matches(bet, u)
        ]
        if not targets:
            for u in active_users[:3]:
                f = u.filters
                log.info("   ↳ %s descartada: acceso=%s muted=%s sure=%s middles=%s roi_min=%s deportes=%s casas=%s (bet %.2f%% %s %s)",
                         u.telegram_id, u.has_access or self._is_admin(u.telegram_id), self.matcher.is_muted(u),
                         f.surebets_enabled, f.middlebets_marked, f.surebet_min_profit, f.sports or "todos",
                         f.surebet_bookmakers or "todas", bet.profit_pct, bet.sport_key, bet.bookmaker_keys())
            return 0

        # Cache de textos por idioma. Antes se formateaba el MISMO mensaje
        # una vez por usuario; con 100 usuarios en español eran 100 formatos
        # idénticos. Ahora se calcula una vez por idioma.
        # Cache de textos por idioma Y por tipo de enlace (los admins reciben
        # el enlace directo del proveedor; el resto, la web de la casa).
        texts_cache: dict[tuple[str, bool], tuple[str, str]] = {}

        def texts_for(lang: str, is_admin: bool) -> tuple[str, str]:
            key = (lang, is_admin)
            if key not in texts_cache:
                texts_cache[key] = (
                    self.formatter.format(bet, lang=lang,
                                          deep_links=True),
                    self._render_teaser(bet, lang),
                )
            return texts_cache[key]

        t0 = time.perf_counter()
        results = await asyncio.gather(
            *(self._send_locked(
                u, bet,
                texts_for(u.filters.language, self._is_admin(u.telegram_id)))
              for u in targets),
            return_exceptions=True,
        )
        elapsed_ms = (time.perf_counter() - t0) * 1000

        ok = [u for u, r in zip(targets, results) if r is True]
        sent = len(ok)

        for u, r in zip(targets, results):
            if r is not True and isinstance(r, Exception):
                log.warning("Envío a %s falló: %s", u.telegram_id, r)

        # Un solo INSERT para todos, en vez de uno por usuario
        if ok:
            self.stats.log_bet_many([
                {
                    "user_id": u.telegram_id, "kind": bet.kind,
                    "is_middle": bet.is_middle, "sport": bet.sport_key,
                    "profit": bet.profit_pct, "bookmakers": bet.bookmaker_keys(),
                    "game": bet.game, "market": bet.market,
                }
                for u in ok
            ])

        if sent:
            log.info("→ enviado a %d/%d usuarios en %.0f ms (paralelo=%d)",
                     sent, len(targets), elapsed_ms, self.max_parallel_sends)
        return sent

    def _is_admin(self, user_id: int) -> bool:
        """True si es admin (dueño del .env o de la BD)."""
        if self.admins is None:
            return False
        return self.admins.is_admin(user_id)

    async def _send_locked(self, user, bet: Bet,
                           texts: tuple[str, str] | None = None) -> bool:
        """Envía 1 mensaje bloqueado a 1 usuario. Devuelve True si OK."""
        async with self._send_sem:
            try:
                # (texto completo, teaser) ya calculados por idioma
                if texts is None:
                    texts = (
                        self.formatter.format(
                            bet, lang=user.filters.language,
                            deep_links=True),
                        self._render_teaser(bet, user.filters.language))
                full_text, teaser = texts

                kb = InlineKeyboardMarkup([[
                    InlineKeyboardButton("🔓 Desbloquear", callback_data="unlock")
                ]])

                sent_msg = await self.bot.send_message(
                    chat_id=user.telegram_id,
                    text=teaser,
                    parse_mode=ParseMode.MARKDOWN,
                    reply_markup=kb,
                    disable_web_page_preview=True,
                )

                # Guardar el texto completo para desbloquear luego
                self._locked_bets[(user.telegram_id, sent_msg.message_id)] = full_text
                return True
            except Exception as e:
                log.warning("Envío a %s falló: %s", user.telegram_id, e)
                return False

    # ── Teaser: información justa para decidir si desbloquear ─
    def _render_teaser(self, bet: Bet, lang: str) -> str:
        sport = SPORTS.get(bet.sport_key)
        sport_txt = (f"{sport.emoji} {(sport.name_es if lang=='es' else sport.name_en)}"
                     if sport else bet.sport_key)

        if bet.is_middle:
            kind_txt = "🎯 MIDDLEBET"
            metric_label = "ROI"
        else:
            kind_txt = "🔒 SUREBET"
            metric_label = "ROI"

        # Primera línea = lo que aparece en la notificación del móvil.
        # Metemos el tipo + profit para que se vea antes de abrir el chat.
        headline = f"*{kind_txt}* · 💰 {metric_label} `{bet.profit_pct:.2f}%`"

        lines = [
            headline,
            sport_txt,
        ]
        if bet.game:
            lines.append(f"⚔️ {esc(bet.game)}")
        if lang == "es":
            lines.append("\n_Pulsa 🔓 para ver el detalle_")
        else:
            lines.append("\n_Tap 🔓 to see details_")
        return "\n".join(lines)
