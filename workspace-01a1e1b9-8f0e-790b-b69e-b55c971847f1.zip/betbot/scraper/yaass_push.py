"""
yaass_push.py — canal push (GraphQL subscriptions por websocket) del sportsbook de Orenes (Yaass).

El front de yaasscasino.es no sondea: abre un websocket graphql-transport-ws contra
    wss://online-sportsbook.orenes.tech/offermanager/graphql
y se suscribe a `eventsChanged(filter:{…})`. Cada vez que cambia algo de un evento (cuota, suspensión, marcador,
minuto) el servidor manda el evento COMPLETO (misma forma que `currentOffer`/`eventsById`), así que `Collector._row`
lo procesa sin cambios. Con `useEventsByFilter:true` + `status:"Live"` llegan todos los eventos en directo de los
deportes indicados sin tener que listar ids.

Protocolo (graphql-transport-ws):
    → {"type":"connection_init","payload":{"X-API-KEY":…,"Accept-Language":"es"}}     ← {"type":"connection_ack"}
    → {"id":…,"type":"subscribe","payload":{"variables":…,"query":…}}
    ← {"id":…,"type":"next","payload":{"data":{"eventsChanged":{…evento…}}}}      (uno por cambio)
    ← {"type":"ping"}  → {"type":"pong"}

Uso desde yaass.py: `Push(cfg, fields)`; `push.drain()` devuelve los eventos cambiados desde la última llamada;
`push.alive()` dice si el socket está conectado. El colector sigue haciendo un `currentOffer` Live cada
`push_refresh` s para sembrar/limpiar (eventos que terminan no siempre llegan por el socket).
"""
from __future__ import annotations

import fastjson as json
import logging
import threading
import time
import uuid

log = logging.getLogger("yaass.push")

SUB = """subscription eventsChanged($eventsId:[Uuid!],$types:[EventTypeEnum!],$sportKeys:[Short!],$status:EventFilterEnum,$useEventsToMonitor:Boolean!,$useEventsByFilter:Boolean!){
 eventsChanged(filter:{tenantId:"{T}",eventsToMonitor:$eventsId,useEventsToMonitor:$useEventsToMonitor,useEventsByFilter:$useEventsByFilter,eventsByFilter:{types:$types,sportKeys:$sportKeys,status:$status,excludeInactives:true,onlyMainMarkets:false}}){
  {FIELDS}}}"""


class Push:
    def __init__(self, cfg: dict, fields: str, sport_keys: list[int]):
        self.cfg = cfg
        self.query = SUB.replace("{T}", cfg["tenant"]).replace("{FIELDS}", fields)
        self.sport_keys = sport_keys
        self.url = cfg.get("ws", cfg["api"].replace("https://", "wss://"))
        self.origin = cfg.get("ws_origin", "https://www.yaasscasino.es")
        self._lock = threading.Lock()
        self._changed: dict[str, dict] = {}        # eventId -> último snapshot pendiente de procesar
        self._stop = False
        self.connected = False
        self.connected_at = 0.0
        self.last_msg = 0.0
        self.msgs = 0
        self.bytes = 0
        self.reconnects = 0
        self.generation = 0                         # +1 en cada conexión (el colector resiembra al cambiar)
        self._th = threading.Thread(target=self._loop, name="yaass-push", daemon=True)
        self._th.start()

    # ── API para el colector ──
    def alive(self, max_silence: float = 120.0) -> bool:
        return self.connected and (time.time() - max(self.last_msg, self.connected_at)) < max_silence

    def drain(self) -> list[dict]:
        with self._lock:
            evs = list(self._changed.values())
            self._changed.clear()
        return evs

    def stop(self):
        self._stop = True

    # ── hilo ──
    def _loop(self):
        try:
            from websockets.sync.client import connect
        except ImportError:
            log.warning("falta el paquete 'websockets': push desactivado (pip install websockets)")
            return
        backoff = 2
        while not self._stop:
            try:
                with connect(self.url, subprotocols=["graphql-transport-ws"], additional_headers={"Origin": self.origin},
                             max_size=None, open_timeout=20, close_timeout=5) as ws:
                    ws.send(json.dumps({"type": "connection_init",
                                        "payload": {"X-API-KEY": self.cfg["api_key"], "Accept-Language": "es"}}))
                    ack = json.loads(ws.recv(timeout=20))
                    if ack.get("type") != "connection_ack":
                        raise RuntimeError(f"sin connection_ack: {str(ack)[:120]}")
                    ws.send(json.dumps({"id": str(uuid.uuid4()), "type": "subscribe", "payload": {
                        "operationName": "eventsChanged",
                        "variables": {"eventsId": [], "types": ["Fixture"], "sportKeys": self.sport_keys, "status": "Live",
                                      "useEventsToMonitor": False, "useEventsByFilter": True},
                        "query": self.query}}))
                    self.connected = True
                    self.connected_at = time.time()
                    self.generation += 1
                    log.info("push Orenes conectado (%s deportes)", len(self.sport_keys))
                    backoff = 2
                    while not self._stop:
                        try:
                            raw = ws.recv(timeout=30)
                        except TimeoutError:
                            if time.time() - max(self.last_msg, self.connected_at) > 180:
                                raise RuntimeError("socket mudo 180s")
                            continue
                        self._on_msg(ws, raw)
            except Exception as e:  # noqa: BLE001
                if self._stop:
                    break
                log.warning("push Orenes caído: %s — reconexión en %ss", str(e)[:160], backoff)
                self.reconnects += 1
                time.sleep(backoff)
                backoff = min(backoff * 2, 60)
            finally:
                self.connected = False

    def _on_msg(self, ws, raw):
        d = json.loads(raw)
        t = d.get("type")
        if t == "ping":
            ws.send(json.dumps({"type": "pong"}))
            return
        if t == "next":
            self.msgs += 1
            self.bytes += len(raw)
            self.last_msg = time.time()
            ev = ((d.get("payload") or {}).get("data") or {}).get("eventsChanged")
            if isinstance(ev, dict) and ev.get("eventId"):
                with self._lock:
                    self._changed[ev["eventId"]] = ev
            return
        if t == "error":
            raise RuntimeError(f"error de suscripción: {str(d.get('payload'))[:200]}")
        if t == "complete":
            raise RuntimeError("el servidor cerró la suscripción")
        if t == "pong":
            return
        log.debug("mensaje desconocido: %s", raw[:120])
