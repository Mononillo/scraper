"""Push de Kambi (socket.io) — cuotas en directo sin sondear fichas.

Kambi publica por websocket TODOS los cambios del offering (cuotas, altas/bajas/suspensiones de mercados, marcador y
reloj) en un solo canal:  wss://push-eu.offering-api.kambicdn.com/socket.io/?EIO=4&transport=websocket
    -> "0{...}"  handshake      -> enviamos "40"  -> "40{sid}"
    -> enviamos 42["subscribe",{"topic":"v2018.<offering>.ev.json"}]
    -> mensajes 42["message","<json array>"] con objetos {"t": ms, "mt": tipo, <clave>: {...}}
       mt 11 boou  cuotas (outcomes[{id, odds, betOfferId}])         mt 6  boa   betOffer nuevo/actualizado
       mt 7  bor   betOffer eliminado                                mt 8  bosu  betOffer suspendido/visible
       mt 15 mcu   reloj (matchClock)                                mt 16 score marcador
       mt 17 stats estadísticas (sets de tenis…)                     mt 18 er    evento eliminado
    -> "2" ping del servidor cada 55 s: respondemos "3".
(Verificado con HAR de paf.es y en pruebas directas con leoes/pafes: ~15-40 mensajes/s en hora punta.)

Uso: la ficha completa (`betoffer/event/<id>.json`) se descarga UNA vez por evento en directo y se guarda aquí; el push
la mantiene al día (cuotas, suspensiones, mercados nuevos). Cada ciclo el colector construye las filas desde la caché
sin peticiones HTTP; solo pide fichas para eventos nuevos y un pequeño refresco rotatorio por si se perdió algo.
Si el socket cae, `fresh()` devuelve False y el colector vuelve al sondeo clásico hasta que reconecte.
"""
from __future__ import annotations

import logging
import threading
import time

import fastjson as json

log = logging.getLogger("kambi.push")

PUSH_URL = "wss://push-eu.offering-api.kambicdn.com/socket.io/?EIO=4&transport=websocket"


class KambiPush:
    def __init__(self, offering: str, origin: str = "https://www.kambi.com", url: str = PUSH_URL):
        self.offering, self.origin, self.url = offering, origin, url
        self.lock = threading.Lock()
        self.fichas: dict[int, dict] = {}       # eventId -> {"bos": {betOfferId: betOffer}, "at": epoch descarga}
        self.live: dict[int, dict] = {}         # eventId -> {"score": {...}, "matchClock": {...}}
        self.touched: set[int] = set()          # eventos con cambios desde la última construcción de filas
        self.connected = False
        self.last_rx = 0.0
        self.msgs = 0
        self.unknown: dict[int, int] = {}
        self._stop = False
        self._thread = threading.Thread(target=self._run, name=f"kambi-push-{offering}", daemon=True)

    # ── ciclo de vida ──
    def start(self) -> "KambiPush":
        self._thread.start()
        return self

    def stop(self) -> None:
        self._stop = True

    def fresh(self, max_silence: float = 90.0) -> bool:
        """Conectado y con tráfico (o ping) reciente: los datos de la caché se pueden considerar actuales."""
        return self.connected and time.time() - self.last_rx < max_silence

    # ── caché de fichas ──
    def put(self, event_id: int, js: dict) -> None:
        bos = {bo["id"]: bo for bo in js.get("betOffers") or [] if bo.get("id") is not None}
        with self.lock:
            self.fichas[event_id] = {"bos": bos, "at": time.time()}
            self.touched.add(event_id)

    def drop(self, keep: set[int]) -> None:
        with self.lock:
            for eid in [e for e in self.fichas if e not in keep]:
                self.fichas.pop(eid, None)
                self.live.pop(eid, None)

    def cached(self) -> set[int]:
        with self.lock:
            return set(self.fichas)

    def expired(self) -> int:
        """Fichas marcadas como caducadas (reconexión): se refrescan a ritmo máximo hasta que no quede ninguna."""
        with self.lock:
            return sum(1 for f in self.fichas.values() if f["at"] <= 0)

    def oldest(self, n: int, min_age: float = 0.0) -> list[int]:
        """Los n eventos cuya ficha lleva más tiempo sin descargar (al menos `min_age` s): refresco rotatorio."""
        lim = time.time() - min_age
        with self.lock:
            return [eid for eid, f in sorted(self.fichas.items(), key=lambda kv: kv[1]["at"])[:n] if f["at"] <= lim]

    def betoffers(self, event_id: int) -> list[dict] | None:
        with self.lock:
            f = self.fichas.get(event_id)
            return None if f is None else list(f["bos"].values())

    def live_data(self, event_id: int) -> dict:
        with self.lock:
            return dict(self.live.get(event_id) or {})

    def pop_touched(self) -> set[int]:
        with self.lock:
            t, self.touched = self.touched, set()
            return t

    # ── aplicación de mensajes ──
    def _apply(self, it: dict) -> None:
        mt = it.get("mt")
        if mt == 11:
            u = it.get("boou") or {}
            f = self.fichas.get(u.get("eventId"))
            if not f:
                return
            for o in u.get("outcomes") or []:
                bo = f["bos"].get(o.get("betOfferId"))
                if not bo:
                    continue
                for oc in bo.get("outcomes") or []:
                    if oc.get("id") == o.get("id"):
                        oc["odds"] = o.get("odds")
                        if "status" in o:
                            oc["status"] = o["status"]
                        break
            self.touched.add(u["eventId"])
        elif mt == 6:
            bo = (it.get("boa") or {}).get("betOffer") or {}
            f = self.fichas.get(bo.get("eventId"))
            if f and bo.get("id") is not None:
                f["bos"][bo["id"]] = bo
                self.touched.add(bo["eventId"])
        elif mt == 7:
            r = it.get("bor") or {}
            f = self.fichas.get(r.get("eventId"))
            if f and f["bos"].pop(r.get("betOfferId"), None) is not None:
                self.touched.add(r["eventId"])
        elif mt == 8:
            s = it.get("bosu") or {}
            f = self.fichas.get(s.get("eventId"))
            bo = f["bos"].get(s.get("betOfferId")) if f else None
            if bo is not None:
                bo["suspended"] = bool(s.get("suspended"))
                if s.get("visible") is False:
                    bo["suspended"] = True
                self.touched.add(s["eventId"])
        elif mt == 16:
            s = it.get("score") or {}
            if s.get("eventId") is not None:
                self.live.setdefault(s["eventId"], {})["score"] = s.get("score") or {}
                self.touched.add(s["eventId"])
        elif mt == 15:
            m = it.get("mcu") or {}
            if m.get("eventId") is not None:
                self.live.setdefault(m["eventId"], {})["matchClock"] = m.get("matchClock") or {}
        elif mt == 18:
            eid = (it.get("er") or {}).get("eventId")
            if eid in self.fichas:
                self.fichas.pop(eid, None)
                self.live.pop(eid, None)
                self.touched.add(eid)
        elif mt == 17:
            s = it.get("stats") or {}
            if s.get("eventId") is not None and s.get("statistics") is not None:
                self.live.setdefault(s["eventId"], {})["statistics"] = s.get("statistics") or {}
                self.touched.add(s["eventId"])
        else:
            self.unknown[mt] = self.unknown.get(mt, 0) + 1

    def _run(self) -> None:
        from websockets.sync.client import connect
        backoff = 2.0
        while not self._stop:
            try:
                with connect(self.url, additional_headers={"Origin": self.origin}, max_size=None,
                             open_timeout=15, close_timeout=3, ping_interval=None) as ws:   # el ping lo hace socket.io ("2"/"3")
                    hello = ws.recv(timeout=15)
                    if not str(hello).startswith("0"):
                        raise RuntimeError(f"handshake inesperado: {str(hello)[:60]}")
                    ws.send("40")
                    ws.recv(timeout=15)
                    ws.send("42" + json.dumps(["subscribe", {"topic": f"v2018.{self.offering}.ev.json"}]))
                    with self.lock:                                   # tras una reconexión pudimos perder cambios:
                        for f in self.fichas.values():                # todas las fichas pasan a «caducadas» y el
                            f["at"] = 0.0                             # colector las vuelve a descargar por turnos
                    self.connected = True
                    self.last_rx = time.time()
                    backoff = 2.0
                    log.info("push Kambi conectado (%s)", self.offering)
                    while not self._stop:
                        try:
                            m = ws.recv(timeout=70)
                        except TimeoutError:
                            raise RuntimeError("sin ping del servidor en 70 s")
                        self.last_rx = time.time()
                        if m == "2":
                            ws.send("3")
                            continue
                        if not isinstance(m, str) or not m.startswith("42"):
                            continue
                        try:
                            arr = json.loads(m[2:])
                            items = json.loads(arr[1]) if arr and arr[0] == "message" else []
                        except Exception:                                 # noqa: BLE001
                            continue
                        with self.lock:
                            for it in items:
                                if isinstance(it, dict):
                                    self._apply(it)
                        self.msgs += len(items)
            except Exception as e:                                        # noqa: BLE001
                if self._stop:
                    break
                log.warning("push Kambi (%s) caído: %s — reconecto en %.0fs", self.offering, e, backoff)
                time.sleep(backoff)
                backoff = min(backoff * 2, 60)
            finally:
                self.connected = False
