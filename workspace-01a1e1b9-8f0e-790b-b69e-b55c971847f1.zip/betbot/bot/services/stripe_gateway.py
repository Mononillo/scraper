"""
StripeGateway: encapsula todo el diálogo con Stripe (checkout + portal).
"""
from __future__ import annotations
import logging

import stripe

from typing import List

from config import CONFIG

log = logging.getLogger(__name__)


class StripeGateway:

    def __init__(self):
        stripe.api_key = CONFIG.stripe_secret_key

    def cancel_subscription(self, subscription_id: str,
                            at_period_end: bool = True) -> bool:
        """
        Cancela una suscripción de Stripe.

        Con at_period_end=True NO se le cobra el siguiente ciclo, pero
        conserva el acceso hasta que venza el periodo ya pagado. Es lo que
        queremos cuando alguien cambia de plan: que no le cobren dos veces.
        """
        try:
            if at_period_end:
                stripe.Subscription.modify(subscription_id,
                                           cancel_at_period_end=True)
            else:
                stripe.Subscription.delete(subscription_id)
            return True
        except Exception as e:                              # noqa: BLE001
            log.error("No pude cancelar la suscripción %s: %s",
                      subscription_id, e)
            return False

    def cancel_all_for_user(self, telegram_user_id, customer_id: str = "") -> List[str]:
        """
        Cancela TODAS las suscripciones activas de un usuario.

        Imprescindible cuando alguien tiene duplicados (compró dos veces):
        cancelar sólo la que teníamos guardada dejaba la otra viva y el poller
        resucitaba la cuenta en la siguiente vuelta, deshaciendo al admin y
        volviendo a mandar el aviso de "pago confirmado".
        """
        canceladas: List[str] = []
        objetivo = str(telegram_user_id)
        try:
            for sub in stripe.Subscription.list(status="active", limit=100).auto_paging_iter():
                uid = ""
                try:
                    md = getattr(sub, "metadata", None) or {}
                    uid = str(md.get("telegram_user_id") or "")
                except Exception:  # noqa: BLE001
                    uid = ""
                coincide = uid == objetivo
                if not coincide and customer_id:
                    cid = (sub.customer if isinstance(sub.customer, str)
                           else getattr(sub.customer, "id", None))
                    coincide = (cid == customer_id)
                if not coincide:
                    continue
                if self.cancel_subscription(sub.id, at_period_end=False):
                    canceladas.append(sub.id)
        except Exception as e:  # noqa: BLE001
            log.error("No pude listar/cancelar las suscripciones de %s: %s",
                      telegram_user_id, e)
        return canceladas

    def create_checkout_url(self, user_id: int, username: str, plan_key: str,
                            previous_subscription_id: str = "") -> str:
        """
        Crea la sesión de pago. Si el usuario ya tenía una suscripción
        anterior, la marca para que no se le vuelva a cobrar.

        Devolvemos el ID de la suscripción cancelada para poder registrarlo.
        """
        if previous_subscription_id:
            log.info("🔄 Cambio de plan: cancelando la suscripción %s "
                     "al final del periodo", previous_subscription_id)
            self.cancel_subscription(previous_subscription_id,
                                     at_period_end=True)

        plan = CONFIG.plans[plan_key]
        sub_data = {
            "metadata": {
                "telegram_user_id": str(user_id),
                "telegram_username": username or "",
                "plan": plan_key,
            }
        }
        session = stripe.checkout.Session.create(
            payment_method_types=["card"],
            mode="subscription",
            line_items=[{"price": plan["price_id"], "quantity": 1}],
            success_url=CONFIG.stripe_success_url or "https://t.me/",
            cancel_url=CONFIG.stripe_cancel_url or "https://t.me/",
            allow_promotion_codes=True,
            metadata={
                "telegram_user_id": str(user_id),
                "telegram_username": username or "",
                "plan": plan_key,
            },
            subscription_data=sub_data,
        )
        return session.url

    def create_portal_url(self, customer_id: str) -> str:
        if CONFIG.stripe_portal_url:
            return CONFIG.stripe_portal_url
        session = stripe.billing_portal.Session.create(
            customer=customer_id,
            return_url=CONFIG.stripe_success_url or "https://t.me/",
        )
        return session.url
