"""Salud de los colectores de cuotas a partir de `scraper_status` (odds.db).

Cada colector escribe `<casa>_last_ok` (epoch) al terminar bien un ciclo y
`<casa>_last_error` ("<epoch> <mensaje>") cuando algo falla.  Aquí se traduce
eso a un estado legible, compartido por el bot (aviso por Telegram) y la Mini
App (panel de administración):

  ok     -> último ciclo bueno hace < WARN_AFTER s
  warn   -> retraso (ciclo lento, pausa por 429/403...)  WARN_AFTER..DOWN_AFTER
  down   -> sin ciclo bueno desde hace >= DOWN_AFTER s  (casa caída)

Y una causa probable a partir del último error:
  structure -> KeyError/TypeError/JSON...: la casa ha cambiado su API/estructura
  blocked   -> 403/429/Banned/captcha: bloqueo temporal, se reanuda solo
  unknown   -> sin error registrado (proceso parado, red...)
"""
from __future__ import annotations

import os
import re
import time

WARN_AFTER = int(os.getenv("COLLECTOR_WARN_SECONDS", "120"))
DOWN_AFTER = int(os.getenv("COLLECTOR_DOWN_SECONDS", "600"))

# (prefijo en scraper_status, nombre visible)
COLLECTORS = (("winamax", "Winamax"), ("paston", "Pastón"), ("jokerbet", "JokerBet"), ("betsson", "Betsson"),
              ("leovegas", "LeoVegas"), ("casumo", "Casumo"), ("speedybet", "Speedybet"), ("paf", "Paf"), ("bwin", "bwin"), ("sp888", "888sport"),
              ("pokerstarses", "PokerStars"), ("betwayes", "Betway"), ("sportium", "Sportium"),
              ("marca", "Marca Apuestas"), ("versus", "Versus"), ("codere", "Codere"),
              ("tonybet", "TonyBet"), ("betinia", "Betinia"), ("admiralbet", "AdmiralBet"), ("solcasino", "Sol Casino"), ("yaass", "Yaass"), ("dafabet", "Dafabet"), ("interwetten", "Interwetten"), ("daznbet", "DAZN Bet"), ("bet777", "Bet777"), ("goldenpark", "GoldenPark"))

_STRUCT = re.compile(r"KeyError|TypeError|IndexError|AttributeError|ValueError|JSONDecodeError|Expecting value|"
                     r"NoneType|not subscriptable|estructura|structure", re.I)
_BLOCK = re.compile(r"\b(401|403|429|202)\b|Banned|bloque|captcha|Retry-After|cooldown|pausa", re.I)


def _ts(raw) -> float:
    try:
        return float(raw)
    except (TypeError, ValueError):
        pass
    try:
        from datetime import datetime
        return datetime.fromisoformat(str(raw)).timestamp()
    except Exception:
        return 0.0


def _error(raw) -> tuple[float, str]:
    """`<epoch> <mensaje>` -> (epoch, mensaje)."""
    s = str(raw or "").strip()
    m = re.match(r"(\d{9,11}(?:\.\d+)?)\s+(.*)", s, re.S)
    if m:
        return float(m.group(1)), m.group(2).strip()
    return 0.0, s


def cause_of(err: str) -> str:
    if not err:
        return "unknown"
    if _BLOCK.search(err):
        return "blocked"
    if _STRUCT.search(err):
        return "structure"
    return "unknown"


def evaluate(status: dict, now: float | None = None) -> list[dict]:
    """status = {clave: valor} de scraper_status -> lista por colector (solo los que han escrito alguna vez)."""
    now = now or time.time()
    out = []
    for prefix, name in COLLECTORS:
        raw = status.get(f"{prefix}_last_ok")
        if raw is None:
            continue
        ts = _ts(raw)
        age = now - ts if ts else None
        err_ts, err = _error(status.get(f"{prefix}_last_error"))
        err_recent = bool(err) and err_ts >= ts                       # error posterior al último ciclo bueno
        state = "ok" if age is not None and age < WARN_AFTER else ("warn" if age is not None and age < DOWN_AFTER else "down")
        cause = cause_of(err) if (err_recent and state != "ok") else ("" if state == "ok" else "unknown")
        if status.get(f"{prefix}_structure_changed"):
            cause = "structure"
        out.append({"key": prefix, "name": name, "state": state, "ok": state == "ok", "age_s": age,
                    "cause": cause, "error": (err[:200] if err_recent else ""),
                    "live": status.get(f"{prefix}_live_events"),
                    "transport": status.get(f"{prefix}_transport", "")})
    return out


CAUSE_TEXT = {
    "structure": "posible CAMBIO DE ESTRUCTURA de la web (hay que reparar el colector)",
    "blocked": "bloqueo temporal de la casa (se reanuda solo; si dura horas, baja el ritmo)",
    "unknown": "sin datos (¿proceso parado? revisa la ventana de run_all)",
}
