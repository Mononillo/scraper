"""
SignalEngine: convierte cambios de cuota (odds.db) en Bets para el pipeline del bot.

Diseñado multi-casa desde el principio: cada cuota lleva su `bookmaker`. Detectores:

  · SurebetDetector   — arbitraje entre casas en CUALQUIER mercado de la taxonomía de scraper/markets.py:
                        3 vías (1X2 fútbol), 2 vías (1X2 tenis/baloncesto, DNB*, BTTS*, HANDICAP*,
                        y todos los Más/Menos: TOTAL*, CORNERS*, CARDS*, …, PLAYER_* con jugador).
                        Necesita >= 2 casas con el MISMO evento (emparejamiento por nombres normalizados).

La lógica es pura (sin Telegram): recibe filas de odds_history y devuelve Bets.
"""
from __future__ import annotations

import difflib
import logging
import re
import time
import unicodedata
from collections import defaultdict
from bisect import bisect_left
from dataclasses import dataclass
from functools import lru_cache
from typing import Iterable

from config import CONFIG
from domain.models import Bet, BetKind, BetLine
from domain.sports import CATALOG as SPORTS

log = logging.getLogger(__name__)

SPORT_KEYS = {"futbol": "soccer", "baloncesto": "basketball", "tenis": "tennis"}
# Nombres legibles de la taxonomía de mercados (scraper/markets.py): METRICA[_HOME|_AWAY][_PERIODO]
METRIC_LABEL = {
    "1X2": "1X2", "DNB": "Sin empate", "BTTS": "Ambos marcan", "DC": "Doble oportunidad", "HANDICAP": "Hándicap",
    "TOTAL": "Total", "CORNERS": "Córners", "CARDS": "Tarjetas", "SHOTS": "Remates", "SHOTS_OT": "Remates a puerta",
    "FOULS": "Faltas", "FOULS_WON": "Faltas recibidas", "OFFSIDES": "Fueras de juego", "THREES": "Triples", "SETS": "Sets", "ASSISTS": "Asistencias",
    "REBOUNDS": "Rebotes", "PRA": "Pts+Reb+Ast", "PR": "Pts+Reb", "PA": "Pts+Ast", "RA": "Reb+Ast", "SAVES": "Paradas",
    "TACKLES": "Entradas", "PASSES": "Pases", "BLOCKS": "Tapones", "STEALS": "Robos", "GOALS": "Goles",
    "POINTS": "Puntos", "GAMES": "Juegos", "TTS": "Marca", "YELLOW": "Tarjetas amarillas",
}
PERIOD_LABEL = {"1H": "1ª parte", "2H": "2ª parte", "Q1": "1er cuarto", "Q2": "2º cuarto", "Q3": "3er cuarto",
                "Q4": "4º cuarto", "SET1": "1er set", "SET2": "2º set", "SET3": "3er set", "SET4": "4º set",
                "SET5": "5º set", "OT": "Prórroga", "REG": "Sin prórroga"}


def _is_live(cands) -> bool:
    """Una señal es LIVE si cualquiera de sus patas viene del feed en directo o si la hora de inicio ya ha pasado
    (las fichas pre-partido de una casa pueden seguir marcadas como prematch minutos después del inicio)."""
    now = time.time()
    for c in cands:
        if c.is_live:
            return True
        try:
            if c.start_date and c.start_time:
                import datetime as _dt
                t = _dt.datetime.strptime(f"{c.start_date} {c.start_time[:5]}", "%Y-%m-%d %H:%M").timestamp()
                if now >= t:
                    return True
        except ValueError:
            pass
    return False


def _when(date: str, time_: str) -> str:
    """'2026-10-25', '20:00' -> '25/10/2026 20:00' (formato español)."""
    d = (date or "").strip()
    m = re.match(r"^(\d{4})-(\d{2})-(\d{2})$", d)
    if m:
        d = f"{m.group(3)}/{m.group(2)}/{m.group(1)}"
    return " ".join(x for x in (d, (time_ or "").strip()) if x)


@lru_cache(maxsize=4096)
def split_market(market: str) -> tuple[str, str | None, str | None, bool]:
    """'PLAYER_SHOTS_OT_1H' -> ('SHOTS_OT', None, '1H', True) · 'TOTAL_HOME' -> ('TOTAL', 'HOME', None, False)."""
    parts = (market or "").split("_")
    player = False
    if parts and parts[0] == "PLAYER":
        player = True
        parts = parts[1:]
    period = parts.pop() if len(parts) > 1 and parts[-1] in PERIOD_LABEL and "_".join(parts) not in METRIC_LABEL else None
    team = parts.pop() if len(parts) > 1 and parts[-1] in ("HOME", "AWAY") else None
    return "_".join(parts), team, period, player


def market_label(market: str, home: str = "", away: str = "", sport: str = "") -> str:
    """'TOTAL_HOME_Q1' → 'Total de puntos · Lakers · 1er cuarto'."""
    base, team, period, _ = split_market(market)
    out = METRIC_LABEL.get(base, base.replace("_", " ").title())
    if base == "TOTAL" and sport:
        out = f"Total de {_total_unit('TOTAL', sport)}"
    if base.startswith("HANDICAP_"):
        out = f"Hándicap {METRIC_LABEL.get(base[9:], base[9:]).lower()}"
    if team:
        out += f" · {home if team == 'HOME' else away}" if (home or away) else f" · {'local' if team == 'HOME' else 'visitante'}"
    if period:
        out += f" · {PERIOD_LABEL[period]}"
    return out


@dataclass
class OddsChange:
    ts: float
    bookmaker: str
    event_id: str
    market_code: str
    market: str
    selection: str
    line: float | None
    price: float
    prev_price: float | None
    # datos del evento (join con events)
    sport: str = ""
    competition: str = ""
    home: str = ""
    away: str = ""
    start_date: str = ""
    start_time: str = ""
    url: str = ""
    is_live: bool = False
    score: str = ""
    period: str = ""
    player: str = ""


def sport_key(scraper_sport: str) -> str:
    k = SPORT_KEYS.get((scraper_sport or "").lower())
    if k:
        return k
    s = SPORTS.by_name(scraper_sport or "")
    return s.key if s else "other"


def selection_text(c: OddsChange) -> str:
    """Texto de la pata: 'Más de 2.5' · 'Lamine Yamal · Más de 1.5 remates a puerta' · 'Como (+0.75)' · 'X'."""
    base, team, period, is_player = split_market(c.market)
    sel = {"Over": "Más de", "Under": "Menos de", "Yes": "Sí", "No": "No"}.get(c.selection, c.selection)
    line = "" if c.line is None else f" {c.line:g}"
    if base.startswith("HANDICAP"):
        who = c.home if c.selection == "1" else c.away
        return f"{who} ({c.line:+g})" if c.line is not None else f"{who} hándicap"
    if base in ("1X2", "DNB"):
        who = {"1": c.home, "X": "Empate", "2": c.away}.get(c.selection, c.selection)
        return who or c.selection
    if is_player:
        return f"{c.player} · {sel}{line} {METRIC_LABEL.get(base, base).lower()}".strip()
    if base == "BTTS":
        return f"Ambos marcan: {sel}"
    if base == "TTS":
        who = c.home if team == "HOME" else c.away if team == "AWAY" else ""
        return f"{who} marca: {sel}".strip()
    # Totales: "Más de 18.5 córners · Real Madrid · 1ª parte"
    metric = _total_unit(base, c.sport)
    out = f"{sel}{line} {metric}".strip()
    if team:
        out += f" · {c.home if team == 'HOME' else c.away}"
    if period:
        out += f" · {PERIOD_LABEL[period]}"
    return out


_TOTAL_UNIT = {"futbol": "goles", "baloncesto": "puntos", "tenis": "juegos"}


def _total_unit(base: str, sport: str) -> str:
    """Unidad legible de un mercado de totales: TOTAL → goles/puntos/juegos según deporte."""
    if base == "TOTAL":
        return _TOTAL_UNIT.get((sport or "").lower(), "")
    return METRIC_LABEL.get(base, base.replace("_", " ").title()).lower()


_CYR = str.maketrans({
    "а": "a", "б": "b", "в": "v", "г": "g", "д": "d", "е": "e", "ё": "e", "ж": "zh", "з": "z", "и": "i", "й": "i", "к": "k",
    "л": "l", "м": "m", "н": "n", "о": "o", "п": "p", "р": "r", "с": "s", "т": "t", "у": "u", "ф": "f", "х": "h", "ц": "c",
    "ч": "ch", "ш": "sh", "щ": "sch", "ъ": "", "ы": "y", "ь": "", "э": "e", "ю": "yu", "я": "ya", "ї": "i", "є": "e", "ґ": "g",
    "ђ": "dj", "ј": "j", "љ": "lj", "њ": "nj", "ћ": "c", "џ": "dz", "ѕ": "dz", "ќ": "k", "ѓ": "g",
})


@lru_cache(maxsize=65536)
def _norm(s: str) -> str:
    s = (s or "").lower().translate(_CYR)                    # Pastón/Altenar a veces manda jugadores en cirílico
    s = unicodedata.normalize("NFKD", s).encode("ascii", "ignore").decode()
    s = re.sub(r"[^a-z0-9 ]", " ", s.lower())
    s = " ".join(w2 for w in s.split() if w not in {"fc", "cf", "club", "de", "the", "sc", "ud", "cd", "bk", "rc"}
                 for w2 in [_WORD_ALIASES.get(w, w)] if w2)
    return _NAME_ALIASES.get(s, s)


# Palabras que cambian de grafía/idioma entre casas y sobran o se traducen antes de comparar (ya en minúsculas y sin
# acentos). Nombres completos que no se parecen en nada entre casas van en _NAME_ALIASES (clave = nombre ya normalizado).
_WORD_ALIASES = {"azerbayan": "azerbaiyan", "azerbaijan": "azerbaiyan", "faroe": "feroe", "faroes": "feroe",
                 "ratiopharm": "", "spqr": "", "basketball": "", "baloncesto": "", "basket": ""}
_NAME_ALIASES = {"northern ireland": "irlanda del norte", "irlanda norte": "irlanda del norte", "n ireland": "irlanda del norte",
                 "rep of ireland": "irlanda", "republic of ireland": "irlanda", "republica irlanda": "irlanda", "rep irlanda": "irlanda",
                 "north macedonia": "macedonia del norte", "macedonia norte": "macedonia del norte",
                 "faroe islands": "islas feroe", "feroe islands": "islas feroe",
                 "czech republic": "republica checa", "czechia": "republica checa", "chequia": "republica checa",
                 "bosnia herzegovina": "bosnia", "bosnia and herzegovina": "bosnia", "bosnia y herzegovina": "bosnia",
                 "bc roma": "roma", "virtus roma": "roma", "ulm": "ulm"}


_ALIASES = {"utd": "united", "man": "manchester", "atl": "atletico", "ath": "athletic", "dep": "deportivo",
            "spo": "sporting", "int": "inter", "bor": "borussia", "olymp": "olympique", "st": "saint", "psg": "paris",
            "rb": "red bull", "nyk": "knicks", "lal": "lakers", "gsw": "warriors", "okc": "thunder", "bkn": "nets",
            "atlanta": "atl hawks", "orlando": "orl magic"}
_GENERIC = {"real", "atletico", "athletic", "sporting", "deportivo", "racing", "union", "inter", "dinamo", "dynamo",
            "city", "united", "town", "b", "ii", "fk", "sk", "ac", "as", "ss", "us", "bc", "kk", "cska", "olympique",
            "paris", "saint", "red", "bull", "1907", "1899", "1909", "04", "05", "96"}


def _tokens(name: str) -> list[str]:
    out = []
    for t in name.split():
        out += _ALIASES.get(t, t).split()
    return out


def _sim(a: str, b: str) -> float:
    """Similitud entre nombres de equipo/jugador de distintas casas ('Man Utd' ~ 'Manchester United')."""
    if a == b:
        return 1.0
    ta, tb = _tokens(a), _tokens(b)
    if not ta or not tb:
        return 0.0

    def hit(x, y):
        return x == y or (len(x) >= 3 and len(y) >= 3 and (y.startswith(x) or x.startswith(y)))

    sa = [t for t in ta if t not in _GENERIC] or ta
    sb = [t for t in tb if t not in _GENERIC] or tb
    hits = sum(1 for x in sa if any(hit(x, y) for y in sb))
    tok = min(1.0, hits / min(len(sa), len(sb)))
    if hits == 0:
        return 0.0
    seq = difflib.SequenceMatcher(None, " ".join(ta), " ".join(tb)).ratio()
    return max(tok, seq)


def _sig(name: str) -> frozenset:
    """Firmas de un nombre para el índice del EventMatcher. _sim(a, b) > 0 exige que algún token significativo
    de a 'acierte' con uno de b (iguales, o uno prefijo del otro con >= 3 letras) → ambos comparten firma."""
    ta = _tokens(name)
    sa = [t for t in ta if t not in _GENERIC] or ta
    return frozenset(t[:3] if len(t) >= 3 else t for t in sa) or frozenset({""})


class EventMatcher:
    """Da la misma clave a un mismo partido visto en distintas casas (nombres distintos).
    Registro de eventos canónicos por (deporte, fecha); emparejamiento difuso de local y visitante."""

    def __init__(self, threshold: float = 0.6):
        self.threshold = threshold
        self._cache: dict[tuple[str, str], str] = {}
        self._cache_at: dict[tuple[str, str], float] = {}
        self._cache_names: dict[tuple[str, str], tuple[str, str]] = {}
        self._canon: dict[tuple[str, str], list[tuple[str, str, str]]] = defaultdict(list)   # (sport,date) -> [(key,h,a)]
        self._index: dict[tuple[str, str], dict[str, list[int]]] = defaultdict(lambda: defaultdict(list))  # firma local -> idx
        self._last_prune = 0.0

    def _candidates(self, bucket, sig_h):
        idx = self._index.get(bucket)
        if not idx:
            return ()
        seen: set[int] = set()
        for f in sig_h:
            seen.update(idx.get(f, ()))
        return sorted(seen)

    def key(self, c: OddsChange) -> str:
        sp, h, a = sport_key(c.sport), _norm(c.home), _norm(c.away)
        if not h or not a:
            # sin nombres (la fila de odds llegó antes que la de events, o la casa aún no los da): clave propia, sin
            # registrar canónico ni cachear. Antes todos los "sin nombre" caían en el mismo canónico "sp||" y la caché
            # por (casa, id) los dejaba emparejados para siempre (Israel-Polonia de TonyBet con Italia-Eslovenia de Versus).
            return f"{sp}|{c.bookmaker}|{c.event_id}|?"
        ck = (c.bookmaker, c.event_id)
        k = self._cache.get(ck)
        if k:
            if self._cache_names.get(ck) == (h, a):
                return k
            self._cache.pop(ck, None)          # la casa cambió los nombres del evento: se vuelve a emparejar
        sig_h = _sig(h)
        best, best_s = None, 0.0
        for date in (c.start_date or "", ""):
            bucket = (sp, date)
            canon = self._canon.get(bucket)
            if not canon:
                continue
            for i in self._candidates(bucket, sig_h):
                key, ch, ca = canon[i]
                if h == ch and a == ca:
                    s = 1.0
                else:
                    s = _sim(h, ch)
                    if s >= self.threshold and s > best_s:
                        s = min(s, _sim(a, ca))
                if s >= self.threshold and s > best_s:
                    best, best_s = key, s
                    if s >= 1.0:
                        break
            if best_s >= 1.0:
                break
        if best is None:
            best = f"{sp}|{h}|{a}"
            bucket = (sp, c.start_date or "")
            self._canon[bucket].append((best, h, a))
            pos = len(self._canon[bucket]) - 1
            for f in sig_h:
                self._index[bucket][f].append(pos)
        self._cache[ck] = best
        self._cache_names[ck] = (h, a)
        now = time.time()
        self._cache_at[ck] = now
        if len(self._cache) > 50000 and now - self._last_prune > 600:
            self._prune(now)
        return best

    def _prune(self, now: float) -> None:
        """Quita de la caché los eventos que no han mandado ningún cambio en 6 h y los registros canónicos de fechas
        pasadas. Antes se vaciaba todo de golpe y había que volver a emparejar decenas de miles de eventos."""
        self._last_prune = now
        old = [ck for ck, t in self._cache_at.items() if now - t > 6 * 3600]
        for ck in old:
            self._cache.pop(ck, None)
            self._cache_at.pop(ck, None)
            self._cache_names.pop(ck, None)
        today = time.strftime("%Y-%m-%d", time.localtime(now - 86400))
        for bucket in [b for b in self._canon if b[1] and b[1] < today]:
            self._canon.pop(bucket, None)
            self._index.pop(bucket, None)


_MATCHER = EventMatcher()


def event_key(c: OddsChange) -> str:
    return _MATCHER.key(c)


def _loose(a: str, b: str) -> bool:
    """Mismo equipo/jugador con tolerancia: 'Gauff, Cori' ~ 'Coco Gauff', 'Baskonia Vitoria' ~ 'Saski Baskonia'.
    Basta con compartir un token significativo de >= 4 letras (apellido, nombre del club) o pasar _sim."""
    if _sim(a, b) >= 0.6:
        return True
    ta = {t for t in _tokens(a) if t not in _GENERIC and len(t) >= 4}
    tb = {t for t in _tokens(b) if t not in _GENERIC and len(t) >= 4}
    return bool(ta & tb)


def _same_event(legs) -> bool:
    """Última barrera antes de emitir: todas las patas deben nombrar el mismo partido (local≈local y visitante≈visitante,
    o cruzados). Independiente de la caché del emparejador: si por lo que sea dos eventos distintos comparten clave,
    la señal se descarta y se registra en el log en vez de enviarse (Israel-Polonia con Italia-Eslovenia)."""
    legs = list(legs)
    ref = legs[0]
    rh, ra = _norm(ref.home), _norm(ref.away)
    for c in legs[1:]:
        if c.bookmaker == ref.bookmaker and c.event_id == ref.event_id:
            continue
        h, a = _norm(c.home), _norm(c.away)
        if not (rh and ra and h and a):
            log.warning("señal descartada: evento sin nombres %s|%s %r-%r vs %s|%s %r-%r", ref.bookmaker, ref.event_id,
                        ref.home, ref.away, c.bookmaker, c.event_id, c.home, c.away)
            return False
        ok = (_loose(rh, h) and _loose(ra, a)) or (_loose(rh, a) and _loose(ra, h))
        if not ok:
            log.warning("señal descartada: patas de partidos distintos %s %r-%r vs %s %r-%r", ref.bookmaker, ref.home,
                        ref.away, c.bookmaker, c.home, c.away)
            return False
    return True


_PLAYER_KEYS: dict[str, str] = {}
_PLAYER_RAW: dict[str, str] = {}                      # nombre tal cual llega -> clave (evita _norm en cada cambio)
_PLAYER_BY_SURNAME: dict[str, list[str]] = defaultdict(list)   # apellido[:5] (o entero si es corto) -> nombres


def _surname_bucket(n: str) -> str:
    # _same_surname: iguales, o uno prefijo del otro con >= 5 letras → ambos comparten las 5 primeras letras
    sx = n.split()[-1]
    return sx[:5] if len(sx) >= 5 else sx


def _player_key(name: str) -> str:
    """'Nicolas Paz Martinez' (Pastón) y 'Nico Paz' (Winamax) -> misma clave (apellido + inicial)."""
    if not name:
        return ""
    k = _PLAYER_RAW.get(name)
    if k is not None:
        return k
    n = _norm(name)
    if not n:
        _PLAYER_RAW[name] = ""
        return ""
    k = _PLAYER_KEYS.get(n)
    if k:
        _PLAYER_RAW[name] = k
        return k
    toks = n.split()
    # prefijo del nombre de pila: 3 letras si viene completo ('jaylin' -> 'jay', 'jalen' -> 'jal': NO son el mismo
    # jugador aunque compartan inicial y apellido), solo la inicial si viene abreviado ('j.' / 'j')
    first = toks[0].rstrip(".") if toks else ""
    pref = first[:3] if len(first) >= 3 else first[:1]
    cand = f"{pref}:{toks[1] if len(toks) > 1 else toks[0]}" if toks else n
    def _same_surname(x: str, y: str) -> bool:
        # 'tre jones' y 'tre johnson' NO son el mismo jugador: el apellido tiene que coincidir (o ser prefijo largo)
        sx, sy = x.split()[-1], y.split()[-1]
        return sx == sy or (min(len(sx), len(sy)) >= 5 and (sx.startswith(sy) or sy.startswith(sx)))
    def _same_first(x: str, y: str) -> bool:
        fx, fy = x.split()[0].rstrip("."), y.split()[0].rstrip(".")
        if len(fx) < 3 or len(fy) < 3:            # uno abreviado: basta la inicial
            return fx[:1] == fy[:1]
        return fx[:3] == fy[:3]
    bucket = _surname_bucket(n)
    for other in _PLAYER_BY_SURNAME.get(bucket, ()):
        if _same_first(n, other) and _same_surname(n, other) and _sim(n, other) >= 0.75:
            cand = _PLAYER_KEYS[other]
            break
    _PLAYER_KEYS[n] = cand
    _PLAYER_BY_SURNAME[bucket].append(n)
    _PLAYER_RAW[name] = cand
    if len(_PLAYER_RAW) > 200000:
        _PLAYER_RAW.clear()
    return cand


def bookmaker_url(c: OddsChange, base_urls: dict[str, str]) -> str:
    base = base_urls.get(c.bookmaker, "")
    if c.url and c.url.startswith("/"):
        return base.rstrip("/") + c.url if base else ""
    return c.url or base


_PRUNE_EVERY_S = 300.0        # cada cuánto se limpian los libros de los detectores
_BOOK_MAX_AGE_S = 6 * 3600    # cuota sin novedades en 6 h = evento terminado/retirado: fuera del libro
_prune_last: dict[int, float] = {}


def _prune_book(book: dict, last_alert: dict) -> None:
    """Quita de un libro (clave -> selección -> casa/(línea, casa) -> OddsChange) las cuotas viejas y las claves
    vacías, y olvida los avisos de más de un día. Sin esto el libro crece sin límite con eventos ya terminados."""
    now = time.time()
    if now - _prune_last.get(id(book), 0.0) < _PRUNE_EVERY_S:
        return
    _prune_last[id(book)] = now
    cutoff = now - _BOOK_MAX_AGE_S
    for mk in list(book.keys()):
        sels = book[mk]
        for sel in list(sels.keys()):
            d = sels[sel]
            for k in [k for k, c in d.items() if getattr(c, "ts", now) < cutoff]:
                d.pop(k, None)
            if not d:
                sels.pop(sel, None)
        if not sels:
            book.pop(mk, None)
    for k in [k for k, t in last_alert.items() if now - t > 86400]:
        last_alert.pop(k, None)


# ────────────────────────────────────────────────────────────────────────────
class SurebetDetector:
    """Arbitraje entre casas. Mantiene la mejor cuota por (evento normalizado, mercado, línea, selección, casa)."""

    @staticmethod
    def outcomes_for(market: str, sport_k: str) -> tuple[str, ...] | None:
        base, _, _, _ = split_market(market)
        if base == "1X2":
            return ("1", "X", "2") if sport_k == "soccer" else ("1", "2")
        if base in ("DNB", "ML") or base.startswith("HANDICAP"):
            return ("1", "2")
        if base in ("BTTS", "TTS"):
            return ("Yes", "No")
        if base == "DC":
            return None
        return ("Over", "Under")         # TOTAL*, CORNERS*, CARDS*, …, props de jugador

    def __init__(self, min_profit: float = 0.5, cooldown_min: int = 20, base_urls: dict | None = None):
        self.min_profit, self.cooldown = min_profit, cooldown_min * 60
        self.base_urls = base_urls or {}
        self._book: dict[tuple, dict[str, dict[str, OddsChange]]] = defaultdict(lambda: defaultdict(dict))
        self._last_alert: dict[tuple, float] = {}
        self._threeway: set[tuple] = set()

    def feed(self, changes: Iterable[OddsChange]) -> list[Bet]:
        out = []
        touched = set()
        _prune_book(self._book, self._last_alert)
        if len(self._threeway) > 20000:
            self._threeway.clear()
        for c in changes:
            if c.line is None:
                line = ""
            elif c.market.startswith("HANDICAP"):
                # clave desde el punto de vista del local: local -0.5 empareja con visitante +0.5
                line = f"{(c.line if c.selection == '1' else -c.line) + 0.0:g}"
            else:
                line = f"{c.line:g}"
            pk = _player_key(c.player)
            if c.market.startswith("PLAYER") and not pk:
                continue                                     # prop sin jugador identificable: no se cruza con nada
            mk = (event_key(c), c.market, line, pk)
            if c.selection == "X" and not mk[0].startswith("soccer"):
                # baloncesto/tenis: una casa con empate ("1X2" a 3 vías, tiempo reglamentario) no es comparable con el
                # ganador a 2 vías (incluye prórroga) de las demás → sus patas 1/2 se excluyen de esta clave
                self._threeway.add((mk, c.bookmaker))
                for o in ("1", "2"):
                    self._book[mk][o].pop(c.bookmaker, None)
                continue
            if (mk, c.bookmaker) in self._threeway:
                continue
            if c.price is None:                      # selección retirada/suspendida en la casa
                self._book[mk][c.selection].pop(c.bookmaker, None)
                continue
            self._book[mk][c.selection][c.bookmaker] = c
            touched.add(mk)
        for mk in touched:
            bet = self._check(mk)
            if bet:
                out.append(bet)
        return out

    def _check(self, mk) -> Bet | None:
        sels = self._book[mk]
        market = mk[1]
        outcomes = self.outcomes_for(market, mk[0].split("|")[0])
        if not outcomes or any(not sels.get(o) for o in outcomes):   # falta alguna pata (o se retiró en todas las casas)
            return None
        best = []
        for o in outcomes:
            c = max(sels[o].values(), key=lambda x: x.price)
            best.append(c)
        if len({c.bookmaker for c in best}) < 2:         # misma casa en todas las patas: no es arbitraje
            return None
        if not _same_event(best):
            return None
        inv = sum(1.0 / c.price for c in best)
        if inv >= 1.0:
            return None
        profit = (1.0 / inv - 1.0) * 100.0
        if profit < self.min_profit:
            return None
        now = time.time()
        if now - self._last_alert.get(mk, 0) < self.cooldown:
            return None
        self._last_alert[mk] = now
        ref = best[0]
        lines = []
        for c in best:
            stake = float(round(100.0 / (c.price * inv)))      # stake redondeado a euros enteros (reparto para ganancia igual con banco 100)
            lines.append(BetLine(selection=selection_text(c), odds=c.price, bookmaker_key=c.bookmaker, event_id=c.event_id, market_code=c.market_code,
                                 url=bookmaker_url(c, self.base_urls), provider_stake=stake, line_value=c.line))
        label = market_label(market, ref.home, ref.away, ref.sport)
        if ref.player:
            label = f"{ref.player} · {label}"
        return Bet(kind=BetKind.SUREBET, sport_key=sport_key(ref.sport), game=f"{ref.home} - {ref.away}",
                   market=label, lines=lines, profit_pct=round(profit, 2), league=ref.competition or "",
                   period="LIVE" if _is_live(best) else "", starts_at=_when(ref.start_date, ref.start_time),
                   raw_text=f"surebet {mk}")


def _max_gap(sport: str, market: str) -> float:
    """Hueco máximo creíble entre las líneas de dos casas para el mismo mercado."""
    sp = (sport or "").lower()
    base = split_market(market)[0]
    hcp = base.startswith("HANDICAP")
    if "balonc" in sp or "basket" in sp:
        return 4.0 if hcp else 8.0
    if "tenis" in sp or "tennis" in sp:
        return 2.5 if hcp else 3.0
    if "CORNERS" in market or "CARDS" in market or "YELLOW" in market or "SHOTS" in market:
        return 2.5 if hcp else 3.0
    return 1.0 if hcp else 1.5          # fútbol: goles


class MiddleDetector:
    """Middlebets entre casas: Más de L1 (casa A) + Menos de L2 (casa B) con L2 > L1 (totales, córners, props…)
    o hándicap local h1 (casa A) + visitante h2 (casa B) con hueco entre ambas líneas. Si el resultado cae en el
    hueco se cobran las dos apuestas; fuera del hueco se pierde como mucho `max_loss_pct` % del banco
    (si el hueco además es arbitraje, el peor caso es ganancia)."""

    def __init__(self, max_loss_pct: float = 2.0, min_gap: float = 1.0, cooldown_min: int = 20,
                 base_urls: dict | None = None):
        self.max_loss, self.min_gap, self.cooldown = max_loss_pct, min_gap, cooldown_min * 60
        self._last_warn: dict = {}
        self.base_urls = base_urls or {}
        # (evento, mercado, jugador) -> selección -> (línea, casa) -> cambio
        self._book: dict[tuple, dict[str, dict[tuple, OddsChange]]] = defaultdict(lambda: defaultdict(dict))
        self._last_alert: dict[tuple, float] = {}

    @staticmethod
    def _pair(market: str) -> tuple[str, str] | None:
        base, _, _, _ = split_market(market)
        if base.startswith("HANDICAP"):
            return ("1", "2")
        if base in ("1X2", "DNB", "ML", "BTTS", "TTS", "DC"):
            return None
        return ("Over", "Under")

    def feed(self, changes: Iterable[OddsChange]) -> list[Bet]:
        out, touched = [], set()
        _prune_book(self._book, self._last_alert)
        for c in changes:
            if c.line is None or not self._pair(c.market):
                continue
            pk = _player_key(c.player)
            if c.market.startswith("PLAYER") and not pk:
                continue
            mk = (event_key(c), c.market, pk)
            if c.price is None:
                self._book[mk][c.selection].pop((float(c.line), c.bookmaker), None)
                continue
            self._book[mk][c.selection][(float(c.line), c.bookmaker)] = c
            touched.add(mk)
        for mk in touched:
            bet = self._check(mk)
            if bet:
                out.append(bet)
        return out

    def _check(self, mk) -> Bet | None:
        a_sel, b_sel = self._pair(mk[1])
        A, B = self._book[mk].get(a_sel) or {}, self._book[mk].get(b_sel) or {}
        if not A or not B:
            return None
        # Índice por línea: para cada línea, las cuotas ordenadas de mayor a menor. Solo hace falta comparar la mejor
        # cuota de cada línea (o la segunda si la mejor es de la misma casa): O(líneas²) en vez de O(cuotas²).
        by_a: dict[float, list[OddsChange]] = defaultdict(list)
        by_b: dict[float, list[OddsChange]] = defaultdict(list)
        for (la, _), ca in A.items():
            by_a[la].append(ca)
        for (lb, _), cb in B.items():
            by_b[lb].append(cb)
        for lst in by_a.values():
            lst.sort(key=lambda x: -x.price)
        for lst in by_b.values():
            lst.sort(key=lambda x: -x.price)
        lines_b = sorted(by_b)
        any_a = next(iter(A.values()))
        max_gap = _max_gap(any_a.sport, mk[1])
        max_worst = CONFIG.middle_max_worst_profit
        best, best_score = None, None
        now = time.time()
        for la, cand_a in by_a.items():
            # líneas de B ordenadas: el hueco crece con lb, así que se salta de golpe a la primera con hueco >= min_gap
            lo = (la + self.min_gap) if a_sel == "Over" else (self.min_gap - la)
            for lb in lines_b[bisect_left(lines_b, lo - 1e-9):]:
                gap = (lb - la) if a_sel == "Over" else (la + lb)
                if gap < self.min_gap - 1e-9:
                    continue
                cand_b = by_b[lb]
                ca, cb = cand_a[0], cand_b[0]
                if ca.bookmaker == cb.bookmaker:                 # misma casa: prueba la segunda mejor de un lado
                    alt_a = cand_a[1] if len(cand_a) > 1 else None
                    alt_b = cand_b[1] if len(cand_b) > 1 else None
                    inv_a = (1.0 / alt_a.price + 1.0 / cb.price) if alt_a else None
                    inv_b = (1.0 / ca.price + 1.0 / alt_b.price) if alt_b else None
                    if inv_a is None and inv_b is None:
                        continue
                    if inv_b is None or (inv_a is not None and inv_a <= inv_b):
                        ca = alt_a
                    else:
                        cb = alt_b
                inv = 1.0 / ca.price + 1.0 / cb.price
                worst = (1.0 / inv - 1.0) * 100.0          # % sobre el banco si solo gana una pata
                if worst < -self.max_loss:
                    continue                               # (líneas alternativas lejanas caen aquí: hueco grande pero sin valor)
                # Solo para candidatos que SE ENVIARÍAN: dos casas no pueden distar más de unos puntos en la misma
                # línea, y las dos patas de un middle cubren todos los resultados (suma de probabilidades >= 1).
                # Si falla cualquiera de las dos, alguna línea/selección viene mal leída (signo, lado, mercado).
                bad = None
                if gap > max_gap:
                    bad = f"hueco inverosímil ({gap:.1f})"
                elif max_worst > 0 and worst > max_worst:
                    bad = f"probabilidades incoherentes (peor caso {worst:.1f}%)"
                if bad:
                    wk = (mk, ca.bookmaker, cb.bookmaker)
                    if now - self._last_warn.get(wk, 0) > 600:   # un aviso por mercado y pareja de casas cada 10 min
                        self._last_warn[wk] = now
                        log.warning("middle descartado por %s en %s - %s %s: %s %s %s @%.2f | %s %s %s @%.2f",
                                    bad, ca.home, ca.away, mk[1], ca.bookmaker, a_sel, la, ca.price, cb.bookmaker, b_sel, lb, cb.price)
                    continue
                score = (gap, worst)
                if best_score is None or score > best_score:
                    best, best_score = (ca, cb, inv, worst, gap), score
        if not best:
            return None
        ca, cb, inv, worst, gap = best
        if not _same_event((ca, cb)):
            return None
        key = mk + (ca.line, cb.line)
        now = time.time()
        if now - self._last_alert.get(key, 0) < self.cooldown:
            return None
        self._last_alert[key] = now
        lines = []
        for c in (ca, cb):
            stake = float(round(100.0 / (c.price * inv)))      # stake redondeado a euros enteros
            lines.append(BetLine(selection=selection_text(c), odds=c.price, bookmaker_key=c.bookmaker, event_id=c.event_id, market_code=c.market_code,
                                 url=bookmaker_url(c, self.base_urls), provider_stake=stake, line_value=c.line))
        ref = ca
        label = market_label(mk[1], ref.home, ref.away, ref.sport)
        if ref.player:
            label = f"{ref.player} · {label}"
        return Bet(kind=BetKind.SUREBET, is_middle=True, sport_key=sport_key(ref.sport), game=f"{ref.home} - {ref.away}",
                   market=label, lines=lines, profit_pct=round(worst, 2), league=ref.competition or "",
                   period="LIVE" if _is_live((ca, cb)) else "", starts_at=_when(ref.start_date, ref.start_time),
                   raw_text=f"middle {key}")




# ────────────────────────────────────────────────────────────────────────────
class SignalEngine:
    def __init__(self, detectors: list):
        self.detectors = detectors

    def process(self, changes: list[OddsChange]) -> list[Bet]:
        bets = []
        for d in self.detectors:
            try:
                bets += d.feed(changes)
            except Exception as e:                                   # noqa: BLE001
                log.exception("detector %s falló: %s", type(d).__name__, e)
        return bets
