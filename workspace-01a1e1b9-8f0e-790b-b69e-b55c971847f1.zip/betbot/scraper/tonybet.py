"""
tonybet.py — colector de cuotas de TonyBet (tonybet.es). Plataforma propia con feed de Sportradar.

API JSON pública (sin cookies, sin WAF; Cloudflare la sirve a cualquier cliente con requests):
    GET {api}/v4/menu/line/es?period=0&withOutrightMarkets=1   -> ligas pre-partido (id, nombre, categoría)
    GET {api}/v4/menu/live/es                                   -> ligas con eventos en directo
    GET {api}/event/list?lang=es&relations=odds&relations=result&relations=league&relations=competitors
            &relations=players&oddsExists_eq=1&main=0&limit=N
            &status_in=2&status_in=1&isLive=true&sportId_eq=S                    -> todos los directos de un deporte
            &period=0&status_in=0&isLive=false&leagueId_in=L&time_lte=YYYY-MM-DD HH:MM:SS  -> pre-partido de una liga
    (main=0 = TODOS los mercados del evento; main=1 = solo los principales)

Los mercados vienen sin nombre: `vendorMarketId` es el id de mercado de Sportradar (UOF), `specifiers` la línea
("total=2.5", "hcp=-1", "setnr=2|total=9.5") y `vendorOutcomeId` el id de resultado UOF (1/2/3 = 1/X/2, 12/13 =
más/menos, 1714/1715 = local/visitante en hándicap, 74/76 = sí/no…). Se normalizan con la tabla UOF de abajo
(determinista, sin depender de textos). Marcador en directo: relations.result (matchStatusId de Sportradar).

Uso:  python tonybet.py            (bucle)     --once     --list (competiciones)     --dump <eventId>
"""
from __future__ import annotations

import fastjson as json
import logging
import os
import re
import sys
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path
from urllib.parse import quote, urlencode

from competitions import Competitions
from storage import OddsStore
from transport import Http
import pace

log = logging.getLogger("tonybet")
CFG_PATH = Path(os.getenv("TONYBET_CFG", Path(__file__).parent / "tonybet.json"))

SPORTS = {1: "futbol", 2: "baloncesto", 3: "tenis"}
SPORT_ALIAS = {1: "football", 2: "basketball", 3: "tennis"}

# ── Sportradar UOF → taxonomía propia ─────────────────────────────────────────────────────────────────────────
# (market, tipo, selecciones).  tipo: "result" (ids de outcome -> 1/X/2/1X/12/X2), "total" (12 más / 13 menos,
# línea en specifier total=), "hcp" (1714 local / 1715 visitante, línea hcp= desde el local), "yesno" (74/76),
# "scorer" (goleador en cualquier momento: jugador -> PLAYER_GOALS Over 0.5).  {n} = nº de periodo del specifier.
_R3 = {"1": "1", "2": "X", "3": "2"}
_R2 = {"4": "1", "5": "2"}
_DC = {"9": "1X", "10": "12", "11": "X2"}
UOF: dict[str, dict[int, tuple]] = {
    "futbol": {
        1: ("1X2", "result", _R3), 10: ("DC", "result", _DC), 11: ("DNB", "result", _R2),
        16: ("HANDICAP", "hcp", None), 18: ("TOTAL", "total", None), 19: ("TOTAL_HOME", "total", None),
        20: ("TOTAL_AWAY", "total", None), 29: ("BTTS", "yesno", None),
        60: ("1X2_1H", "result", _R3), 63: ("DC_1H", "result", _DC), 64: ("DNB_1H", "result", _R2),
        66: ("HANDICAP_1H", "hcp", None), 68: ("TOTAL_1H", "total", None), 69: ("TOTAL_HOME_1H", "total", None),
        70: ("TOTAL_AWAY_1H", "total", None), 75: ("BTTS_1H", "yesno", None),
        83: ("1X2_2H", "result", _R3), 88: ("HANDICAP_2H", "hcp", None), 90: ("TOTAL_2H", "total", None),
        162: ("CORNERS", "total", None), 165: ("HANDICAP_CORNERS", "hcp", None), 139: ("CARDS", "total", None),
        38: ("PLAYER_GOALS", "scorer", None),
    },
    "baloncesto": {
        219: ("1X2", "result", _R2), 223: ("HANDICAP", "hcp", None), 225: ("TOTAL", "total", None),
        227: ("TOTAL_HOME", "total", None), 228: ("TOTAL_AWAY", "total", None),
        # UOF 64 = "1st half - draw no bet", 302 = "{quarter} - draw no bet": a 2 vías con reembolso si hay empate →
        # DNB_*, no 1X2_* (el "1X2 · 1er cuarto" de las demás casas es a 3 vías y la X pierde)
        64: ("DNB_1H", "result", _R2), 66: ("HANDICAP_1H", "hcp", None), 68: ("TOTAL_1H", "total", None),
        302: ("DNB_Q{n}", "result", _R2), 303: ("HANDICAP_Q{n}", "hcp", None), 236: ("TOTAL_Q{n}", "total", None),
    },
    "tenis": {
        186: ("1X2", "result", _R2), 187: ("HANDICAP", "hcp", None), 189: ("TOTAL", "total", None),
        314: ("SETS", "total", None), 202: ("1X2_SET{n}", "result", _R2), 204: ("TOTAL_SET{n}", "total", None),
    },
}
# matchStatusId de Sportradar -> texto de periodo (lo que entiende el bot) y si el partido está en juego
_STATUS = {0: None, 1: None, 6: "1ª parte", 7: "2ª parte", 31: "Descanso", 32: "Esperando prórroga", 40: "Prórroga",
           41: "Prórroga 1", 42: "Prórroga 2", 50: "Penaltis", 8: "Set 1", 9: "Set 2", 10: "Set 3", 11: "Set 4",
           12: "Set 5", 13: "Q1", 14: "Q2", 15: "Q3", 16: "Q4", 110: "Prórroga", 301: "Fin Q1", 302: "Descanso",
           303: "Fin Q3", 100: "Finalizado", 80: "Interrumpido", 90: "Suspendido"}
_ENDED = {100, 80, 90, 93, 94, 95, 96, 97, 98, 99}


def _spec(s: str | None) -> dict[str, str]:
    out = {}
    for part in (s or "").split("|"):
        k, _, v = part.partition("=")
        if k:
            out[k.strip()] = v.strip()
    return out


def _num(v: str | None) -> float | None:
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def _half(v: float | None) -> bool:
    """True solo para líneas x.5 (las únicas comparables entre casas sin reembolso/asiáticas)."""
    return v is not None and abs(abs(v) % 1 - 0.5) < 1e-9


def uof_selections(m: dict, sport: str, players: dict[int, str]) -> list[dict]:
    """Un mercado del feed -> selecciones normalizadas (market, selection, line, player, price)."""
    rule = UOF.get(sport, {}).get(m.get("vendorMarketId") or -1)
    if not rule or m.get("status") not in (1, None) or m.get("isVariant"):
        return []
    market, typ, sels = rule
    sp = _spec(m.get("specifiers"))
    n = sp.get("quarternr") or sp.get("setnr") or sp.get("periodnr")
    if "{n}" in market:
        if not n or not n.isdigit():
            return []
        market = market.replace("{n}", n)
    outs = [o for o in m.get("outcomes") or [] if o.get("active") == 1 and o.get("odds")]
    out: list[dict] = []
    if typ == "total":
        line = _num(sp.get("total"))
        if not _half(line):
            return []                                          # solo líneas x.5 (ni enteras ni asiáticas x.25/x.75)
        for o in outs:
            sel = {"12": "Over", "13": "Under"}.get(str(o.get("vendorOutcomeId")))
            if sel:
                out.append({"market": market, "selection": sel, "line": line, "price": o["odds"]})
    elif typ == "hcp":
        h = _num(sp.get("hcp"))
        if not _half(h):
            return []
        for o in outs:
            vid = str(o.get("vendorOutcomeId"))
            if vid == "1714":
                out.append({"market": market, "selection": "1", "line": h, "price": o["odds"]})
            elif vid == "1715":
                out.append({"market": market, "selection": "2", "line": -h, "price": o["odds"]})
    elif typ == "yesno":
        for o in outs:
            sel = {"74": "Yes", "76": "No"}.get(str(o.get("vendorOutcomeId")))
            if sel:
                out.append({"market": market, "selection": sel, "line": None, "price": o["odds"]})
    elif typ == "scorer":
        # goalnr=1 es "PRIMER goleador" (cuotas x3 respecto al "en cualquier momento" del resto de casas: Bernardo
        # Silva 13.0 frente a 3.95). Solo vale el mercado sin goalnr (goleador en cualquier momento).
        if sp.get("goalnr") not in (None, ""):
            return []
        for o in outs:
            pid = o.get("playerVendorId") or str(o.get("vendorOutcomeId") or "").rsplit(":", 1)[-1]
            name = players.get(int(pid)) if pid and str(pid).isdigit() else None
            if name:
                out.append({"market": market, "selection": "Over", "line": 0.5, "player": name, "price": o["odds"]})
    else:                                                      # result
        for o in outs:
            sel = sels.get(str(o.get("vendorOutcomeId")))
            if sel:
                out.append({"market": market, "selection": sel, "line": None, "price": o["odds"]})
    return out


def _player_name(raw: str) -> str:
    """'Moreno, Gerard' -> 'Gerard Moreno' (como el resto de casas)."""
    if "," in raw:
        a, b = raw.split(",", 1)
        return f"{b.strip()} {a.strip()}".strip()
    return raw.strip()


# ──────────────────────────────────────────────────────────────────────────────
class Collector:
    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.bk = cfg["bookmaker"]
        self.api = cfg.get("api", "https://platform.tonybet.es/api").rstrip("/")
        self.origin = cfg.get("origin", "https://tonybet.es")
        self.http = Http(self.api, cfg.get("transport", "requests"),
                         headers={"Accept": "application/json", "Origin": self.origin, "Referer": self.origin + "/",
                                  **(cfg.get("headers") or {})}, api_hint="/api/")
        self.catalog = Competitions()
        self.store = OddsStore(bookmaker=self.bk)
        self.leagues: dict[int, tuple[str, str, str]] = {}       # leagueId -> (sport, competición canónica, slug)
        self._menu_at = 0.0
        self._last_prematch = 0.0
        self._pm_queue: list[int] = []
        self._cfg_mtime = CFG_PATH.stat().st_mtime
        self._bg = pace.Background(f"{self.bk}-prematch")

    # ── HTTP ──
    def get(self, path: str, params: list[tuple[str, str]] | dict | None = None) -> dict:
        url = f"{self.api}/{path.lstrip('/')}"
        if params:
            url += ("&" if "?" in url else "?") + urlencode(params, doseq=True, quote_via=quote)
        st, data = self.http.get(url)
        if st != 200 or not isinstance(data, dict):
            raise RuntimeError(f"{path} -> HTTP {st}")
        if data.get("status") != "ok":
            raise RuntimeError(f"{path} -> {data.get('code')} {data.get('messages')}")
        return data.get("data") or {}

    def _reload_if_changed(self):
        mt = CFG_PATH.stat().st_mtime
        if mt != self._cfg_mtime:
            self._cfg_mtime = mt
            self.cfg = pace.apply(json.loads(CFG_PATH.read_text(encoding="utf-8")))
            log.info("tonybet.json recargado")
        self.catalog.reload()

    # ── catálogo ──
    def refresh_menu(self, force: bool = False):
        if not force and time.time() - self._menu_at < self.cfg.get("menu_ttl", 900):
            return
        found: dict[int, tuple[str, str, str]] = {}
        self._all_leagues: list[tuple[str, int, str]] = []
        for path in ("v4/menu/line/es?period=0&withOutrightMarkets=1", "v4/menu/live/es"):
            try:
                d = self.get(path)
            except Exception as e:  # noqa: BLE001
                log.warning("menú %s: %s", path, e)
                continue
            cats = {c["id"]: c for c in d.get("sportCategories") or []}
            for lg in d.get("leagues") or []:
                cat = cats.get(lg.get("sportCategoryId")) or {}
                sport = SPORTS.get(cat.get("sportId") or lg.get("sportId") or lg.get("sport_id"))
                if not sport or lg.get("isOutright"):
                    continue
                label = re.sub(r"\s+", " ", f"{cat.get('name') or ''} - {lg.get('name') or ''}").strip(" -")
                self._all_leagues.append((sport, lg["id"], label))
                comp = self.catalog.match(self.bk, sport, label)
                if comp:
                    found[lg["id"]] = (sport, comp, lg.get("translationSlug") or lg.get("defaultSlug") or "")
        if found or force:
            self.leagues = found
        self._menu_at = time.time()
        log.info("%d competiciones mapeadas en TonyBet", len(self.leagues))

    # ── eventos ──
    @staticmethod
    def _score(res: dict | None, sport: str) -> tuple[str | None, str | None, str | None, bool]:
        """(score, period, timer, en_juego) a partir de relations.result."""
        if not res:
            return None, None, None, False
        st = res.get("matchStatusId") or 0
        if st in _ENDED:
            return None, _STATUS.get(st), None, False
        playing = st not in (0, None)
        period = _STATUS.get(st) or (f"Periodo {st}" if playing else None)
        pers = sorted((p for p in res.get("periods") or [] if p.get("number")), key=lambda p: p["number"])
        if sport == "tenis":
            # juegos por set; con un solo set se añade " -:-" para que "2:1" no se lea como sets ganados
            score = " ".join(f"{p.get('team1Score', 0)}:{p.get('team2Score', 0)}" for p in pers) or "0:0"
            if len(pers) == 1:
                score += " -:-"
        else:
            score = f"{res.get('team1Score', 0)}:{res.get('team2Score', 0)}"
        clk = res.get("clock") or {}
        timer = clk.get("matchTime")
        return score, period, timer, playing

    def _rows(self, data: dict, kind: str) -> dict[str, list[dict]]:
        rel = data.get("relations") or {}
        odds = rel.get("odds") or {}
        results = rel.get("result") or {}
        comps = {c["id"]: c.get("name") or "" for c in rel.get("competitors") or []}
        players = {p["id"]: _player_name(p.get("name") or "") for p in rel.get("players") or []}
        leagues = {lg["id"]: lg for lg in rel.get("league") or []}
        by_sport: dict[str, list[dict]] = {}
        for ev in data.get("items") or []:
            lg = self.leagues.get(ev.get("leagueId"))
            if not lg:
                continue
            sport, comp, lslug = lg
            home, away = comps.get(ev.get("competitor1Id"), ev.get("team1") or ""), comps.get(ev.get("competitor2Id"), ev.get("team2") or "")
            if ev.get("isHomeAwayReversed"):
                home, away = away, home
            if sport == "tenis":
                home, away = _player_name(home), _player_name(away)
            if not home or not away:
                continue
            score, period, timer, playing = self._score(results.get(str(ev["id"])), sport)
            if kind == "live" and not playing:
                continue                                       # listado live incluye "a punto de empezar": va por pre-partido
            dt = None
            try:
                dt = datetime.strptime(ev["time"], "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc).astimezone()
            except Exception:  # noqa: BLE001
                pass
            if kind != "live" and dt and dt - datetime.now(dt.tzinfo) > timedelta(hours=self.cfg.get("prematch_hours", 48)):
                continue                                       # fuera de la ventana (red de seguridad)
            lgname = (leagues.get(ev.get("leagueId")) or {}).get("translationSlug") or lslug
            url = self.cfg.get("event_url", "").format(kind="live" if kind == "live" else "prematch",
                                                       sport=SPORT_ALIAS.get(ev.get("sportId"), "football"),
                                                       league=f"{ev.get('leagueId')}-{lgname}",
                                                       event=f"{ev['id']}-{ev.get('translationSlug') or ev.get('defaultSlug') or ''}")
            sels: list[dict] = []
            for m in odds.get(str(ev["id"])) or []:
                sels.extend(uof_selections(m, sport, players))
            if not sels:
                continue
            row = {"event_id": str(ev["id"]), "home": home, "away": away, "competition": comp,
                   "date": dt.strftime("%Y-%m-%d") if dt else None, "start_time": dt.strftime("%H:%M") if dt else None,
                   "url": url, "selections": sels}
            if kind == "live":
                row.update(score=score, period=period, timer=timer)
            by_sport.setdefault(sport, []).append(row)
        return by_sport

    _REL = [("relations", "odds"), ("relations", "result"), ("relations", "league"), ("relations", "competitors"),
            ("relations", "players")]

    def live_cycle(self) -> tuple[int, int]:
        # timeout corto en directo: una API colgada no debe dejar la casa ciega 60-100 s (ver Http.timeout_scope)
        with self.http.timeout_scope(self.cfg.get("timeout_live", 8)):
            return self._live_cycle()

    def _live_cycle(self) -> tuple[int, int]:
        rows = changed = 0
        present: set[str] = set()
        for sid, sport in SPORTS.items():
            if not any(s == sport for s, _c, _l in self.leagues.values()):
                continue
            params = [("lang", "es"), *self._REL, ("oddsExists_eq", "1"), ("main", "0"),
                      ("limit", str(self.cfg.get("live_limit", 150))), ("status_in", "2"), ("status_in", "1"),
                      ("isLive", "true"), ("sportId_eq", str(sid))]
            data = self.get("event/list", params)
            by_sport = self._rows(data, "live")
            for sp, rs in by_sport.items():
                present |= {r["event_id"] for r in rs}
                changed += self.store.save_rows(sp, "live", rs)
                rows += len(rs)
        self.store.sweep(present, "live")
        return rows, changed

    def prematch_league(self, league_id: int) -> tuple[int, int]:
        until = (datetime.now(timezone.utc) + timedelta(hours=self.cfg.get("prematch_hours", 48))).strftime("%Y-%m-%d %H:%M:%S")
        params = [("lang", "es"), *self._REL, ("oddsExists_eq", "1"), ("main", "0"), ("period", "0"),
                  ("limit", str(self.cfg.get("prematch_limit", 100))), ("status_in", "0"), ("isLive", "false"),
                  ("leagueId_in", str(league_id)), ("time_lte", until)]
        data = self.get("event/list", params)
        rows = changed = 0
        for sp, rs in self._rows(data, "prematch").items():
            self._pm_present |= {r["event_id"] for r in rs}
            changed += self.store.save_rows(sp, "prematch", rs)
            rows += len(rs)
        return rows, changed

    def _pm_job(self, t0: float, once: bool):
        if not self._pm_queue and t0 - self._last_prematch >= self.cfg.get("interval_prematch", 300):
            self._pm_queue = list(self.leagues)
            self._pm_present: set[str] = set()
            self._pm_rows = self._pm_changed = 0
            self._last_prematch = t0
        if not self._pm_queue:
            return None
        batch = len(self._pm_queue) if once else max(1, self.cfg.get("prematch_batch", 3))
        chunk, self._pm_queue = self._pm_queue[:batch], self._pm_queue[batch:]

        def _run():
            gap = self.cfg.get("request_gap", 0.3)
            for lid in chunk:
                try:
                    r, c = self.prematch_league(lid)
                    self._pm_rows += r
                    self._pm_changed += c
                except Exception as e:  # noqa: BLE001
                    log.warning("prematch liga %s: %s", lid, e)
                time.sleep(gap)
            if not self._pm_queue:
                self.store.sweep(self._pm_present, "prematch")
                return f"prematch {self._pm_rows} ev / {self._pm_changed} cambios (pasada completa)"
            return f"prematch {self._pm_rows} ev / {self._pm_changed} cambios ({len(self._pm_queue)} ligas pendientes)"
        return _run

    def run(self, once: bool = False):
        backoff = 2
        while True:
            t0 = time.time()
            try:
                self._reload_if_changed()
                self.refresh_menu()
                rows, changed = self.live_cycle()
                msg = f"live {rows} ev / {changed} cambios"
                if not self._bg.busy():
                    job = self._pm_job(t0, once)
                    if job is not None:
                        r = self._bg.run(job, inline=once)
                        if r:
                            msg += " | " + r
                note = self._bg.note()
                if note:
                    msg += " | " + note
                self.store.set_status(**{f"{self.bk}_last_ok": time.time(), f"{self.bk}_live_events": rows,
                                         f"{self.bk}_transport": self.http.name})
                log.info("%s [%s] (%.1fs)", msg, self.http.name, time.time() - t0)
                backoff = 2
                if once:
                    return
            except Exception as e:  # noqa: BLE001
                log.warning("error de ciclo: %s — reintento en %ss", e, backoff, exc_info=log.isEnabledFor(logging.DEBUG))
                self.store.set_status(**{f"{self.bk}_last_error": f"{time.time():.0f} {e}"})
                time.sleep(backoff)
                backoff = min(backoff * 2, 60)
                continue
            time.sleep(max(0.5, self.cfg.get("interval_live", 3) - (time.time() - t0)))


def list_catalog(c: Collector):
    c.refresh_menu(force=True)
    by: dict[str, list] = {}
    for sport, lid, label in sorted(set(c._all_leagues), key=lambda x: (x[0], x[2])):
        by.setdefault(sport, []).append((lid, label))
    for sport, items in by.items():
        print(f"\n=== {sport}")
        for lid, label in items:
            comp = c.leagues.get(lid)
            mark = f" ✔ -> {comp[1]}" if comp else ""
            print(f" {'✔' if comp else ' '} {label}   [{lid}]{mark}")


def dump_event(c: Collector, eid: str):
    c.refresh_menu(force=True)
    params = [("lang", "es"), *Collector._REL, ("main", "0"), ("eventId_eq", eid)]
    data = c.get("event/list", params)
    items = data.get("items") or []
    if not items:
        print("evento no encontrado")
        return
    ev = items[0]
    c.leagues.setdefault(ev["leagueId"], (SPORTS.get(ev["sportId"], "futbol"), "?", ""))
    rel = data.get("relations") or {}
    players = {p["id"]: _player_name(p.get("name") or "") for p in rel.get("players") or []}
    sport = SPORTS.get(ev["sportId"], "futbol")
    for m in rel.get("odds", {}).get(str(ev["id"])) or []:
        sels = uof_selections(m, sport, players)
        print(f"UOF {m.get('vendorMarketId')!s:>5} {m.get('specifiers') or '':<30} -> "
              + (", ".join(f"{s['market']} {s.get('player') or ''} {s['selection']} {s.get('line') if s.get('line') is not None else ''} @{s['price']}" for s in sels) or "(sin mapear)"))
    for sp, rs in c._rows(data, "prematch").items():
        print(f"\n{sp}: {len(rs)} evento(s), {sum(len(r['selections']) for r in rs)} selecciones")


def main():
    logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"), format="%(asctime)s %(levelname)s %(name)s: %(message)s", datefmt="%H:%M:%S")
    cfg = pace.apply(json.loads(CFG_PATH.read_text(encoding="utf-8")))
    c = Collector(cfg)
    if "--list" in sys.argv:
        list_catalog(c)
        return
    if "--dump" in sys.argv:
        dump_event(c, sys.argv[sys.argv.index("--dump") + 1])
        return
    c.run(once="--once" in sys.argv)


if __name__ == "__main__":
    main()
