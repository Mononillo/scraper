"""JSON rápido: `orjson` si está instalado (3-6× más rápido descodificando las respuestas de 1-10 MB de las casas),
y el `json` de la biblioteca estándar si no. Mismo interfaz que `json` para lo que usa el proyecto:
loads / dumps / dump / JSONDecoder. `dumps` se queda en la estándar (no es un punto caliente y así se conservan
`ensure_ascii`, `indent`, etc.)."""
import json as _json

dumps = _json.dumps
dump = _json.dump
JSONDecoder = _json.JSONDecoder
JSONDecodeError = _json.JSONDecodeError

try:
    import orjson as _orjson

    def loads(s):
        try:
            return _orjson.loads(s)
        except _orjson.JSONDecodeError as e:
            raise _json.JSONDecodeError(str(e), s if isinstance(s, str) else "", 0) from None

    LIB = "orjson"
except ImportError:          # sin orjson: comportamiento idéntico al de siempre
    loads = _json.loads
    LIB = "json"
