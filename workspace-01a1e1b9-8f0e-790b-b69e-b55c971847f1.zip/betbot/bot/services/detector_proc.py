"""Detectores en un PROCESO aparte.

Los detectores (surebets/middles) son Python puro y CPU: con 15-20k cambios por lote tardan 2-6 s. En un hilo
(`asyncio.to_thread`) siguen compitiendo por el GIL con el bucle de eventos de Telegram y, en Windows sobre todo, el
bucle se queda sin turno varios segundos («bucle de eventos bloqueado 5s») → el botón 🔓 y los envíos se retrasan.
En un proceso hijo el GIL es otro: el bot queda libre para Telegram y los detectores corren a su ritmo.

Protocolo (multiprocessing.Pipe): el padre envía "tick"; el hijo lee odds.db (su propio `last_id`), pasa los cambios
por los detectores (primero directo, después pre-partido) y devuelve
    {"status": dict, "n": nº cambios, "parts": [(is_live, bets, dt_detectores), ...]}
Las Bet viajan en pickle (dataclasses normales). La verificación final (`_verify`) y el envío siguen en el padre.
"""
from __future__ import annotations

import logging
import multiprocessing as mp
import os
import sys
import time

log = logging.getLogger("services.detector_proc")


def _worker(conn, db_path: str, log_level: int, cwd: str) -> None:
    os.chdir(cwd)
    if cwd not in sys.path:
        sys.path.insert(0, cwd)
    logging.basicConfig(level=log_level, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s", stream=sys.stdout)
    from services.odds_source import OddsSource
    src = OddsSource(None, db_path)
    logging.getLogger("services.detector_proc").info("detectores en proceso aparte (pid %s)", os.getpid())
    while True:
        try:
            cmd = conn.recv()
        except (EOFError, OSError):
            return
        if cmd == "stop":
            return
        try:
            changes, status = src._read(True)
            parts = []
            if changes:
                live = [c for c in changes if c.is_live]
                pre = [c for c in changes if not c.is_live]
                for part in (live, pre):
                    if not part:
                        continue
                    t0 = time.time()
                    bets = src.engine.process(part)
                    parts.append((part is live, bets, time.time() - t0))
            conn.send({"status": status, "n": len(changes), "parts": parts})
        except Exception as e:                                           # noqa: BLE001
            logging.getLogger("services.detector_proc").exception("detector worker: %s", e)
            try:
                conn.send({"status": {}, "n": 0, "parts": [], "error": str(e)})
            except Exception:                                            # noqa: BLE001
                return


class DetectorProcess:
    """Lanza/relanza el proceso hijo y ofrece `request()` (bloqueante: llamar desde `asyncio.to_thread`)."""

    def __init__(self, db_path: str):
        self.db_path = db_path
        self._ctx = mp.get_context("spawn")
        self._proc = None
        self._conn = None

    def _start(self) -> None:
        parent, child = self._ctx.Pipe()
        self._proc = self._ctx.Process(
            target=_worker, args=(child, self.db_path, logging.getLogger().level, os.getcwd()),
            name="detectores", daemon=True)
        self._proc.start()
        child.close()
        self._conn = parent
        log.info("proceso de detectores lanzado (pid %s)", self._proc.pid)

    def alive(self) -> bool:
        return self._proc is not None and self._proc.is_alive()

    def request(self, timeout: float = 120.0) -> dict:
        if not self.alive():
            self._start()
        try:
            self._conn.send("tick")
            if not self._conn.poll(timeout):
                raise TimeoutError(f"detectores sin respuesta en {timeout:.0f}s")
            return self._conn.recv()
        except Exception as e:                                           # noqa: BLE001
            log.warning("proceso de detectores caído (%s): lo relanzo", e)
            self.stop()
            return {"status": {}, "n": 0, "parts": [], "error": str(e)}

    def stop(self) -> None:
        try:
            if self._conn is not None:
                try:
                    self._conn.send("stop")
                except Exception:                                        # noqa: BLE001
                    pass
                self._conn.close()
        finally:
            self._conn = None
            if self._proc is not None:
                self._proc.join(2)
                if self._proc.is_alive():
                    self._proc.kill()
            self._proc = None
