r"""
spectate888.py — colector de 888sport.es (plataforma Spectate, host spectate-web.888sport.es).

Uso (desde betbot\scraper\ o con `-m scraper.spectate888` desde betbot\):
    python spectate888.py            # bucle: live cada 5 s, prematch cada `interval_prematch` s
    python spectate888.py --once     # una pasada completa
    python spectate888.py --list     # torneos que ofrece hoy/mañana y cuáles se mapean a competiciones principales
    python spectate888.py --dump     # vuelca JSON crudo + selecciones mapeadas de 2 partidos por deporte (snapshots/)

API (sin token; solo requiere la cookie de sesión anónima `spectate_session`/`bbsess`):
  GET  inplay-req/getInplayEvents/all                       -> todos los directos (todos los deportes) + marcador
  GET  inplay-req/event/<id>                                -> todos los mercados de un directo (~50 KB)
  POST sportsbook-req/getUpcomingEvents/<sport>/<today|tomorrow|YYYY-MM-DD>  -> prematch por día (mercado principal)
  GET  sportsbook/getEventData/<sport>/<cat>/<torneo>/<slug>/<id>  -> todos los mercados prematch (¡~1,8 MB!)
Sesión: la web la crea con JS; aquí se intenta con requests, luego con la cookie de `SPECTATE_COOKIE`/cfg y,
si no, se abre Chrome (transport.BrowserTransport) solo para obtener las cookies y se cierra.
"""
from __future__ import annotations

import fastjson as json
import contextlib
import logging
import os
import re
import sys
import time
import unicodedata
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone, timedelta
from pathlib import Path

import requests

sys.path.insert(0, str(Path(__file__).resolve().parent))

from competitions import Competitions
from markets import classify, parse_ou_label
from storage import OddsStore
from demand import Demand
from transport import BrowserTransport, UA, _pace, set_request_gap

log = logging.getLogger("888sport")
CFG_PATH = Path(os.getenv("SPECTATE888_CFG", Path(__file__).parent / "spectate888.json"))


def load_cfg() -> dict:
    import pace
    return pace.apply(json.loads(CFG_PATH.read_text(encoding="utf-8")))


def _fold(s: str) -> str:
    s = unicodedata.normalize("NFKD", s or "").encode("ascii", "ignore").decode()
    return re.sub(r"\s+", " ", s.lower()).strip()


def _num(s) -> float | None:
    try:
        return float(str(s).replace(",", ".").replace("+", "")) if s not in (None, "") else None
    except ValueError:
        return None


def _d(x) -> dict:
    """Spectate devuelve a veces [] donde normalmente hay un objeto: tratar cualquier no-dict como vacío."""
    return x if isinstance(x, dict) else {}


# ──────────────────────────────────────────────────────────────────────────────
# Sesión HTTP con cookies de Spectate
class Session888:
    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.api = cfg["api_base"].rstrip("/")
        self.origin = cfg["origin"]
        self.s = requests.Session()
        if os.getenv("PROXY"):
            self.s.proxies = {"http": os.getenv("PROXY"), "https": os.getenv("PROXY")}
        # Cabeceras calcadas del HAR del navegador (29-10-2026): el navegador NO envía cookies a spectate-web.
        self.s.headers.update({"User-Agent": UA, "Accept": "*/*", "Accept-Language": "es-ES,es;q=0.9,en;q=0.8",
                               "Origin": self.origin, "Referer": self.origin + "/", "Priority": "u=1, i",
                               "sec-ch-ua": '"Chromium";v="130", "Google Chrome";v="130", "Not?A_Brand";v="99"',
                               "sec-ch-ua-mobile": "?0", "sec-ch-ua-platform": '"Windows"',
                               "sec-fetch-dest": "empty", "sec-fetch-mode": "cors", "sec-fetch-site": "same-site"})
        self.pool = ThreadPoolExecutor(max_workers=cfg.get("workers", 3))
        self._minted = 0.0
        self.mode = "requests"
        self.cache = Path(os.getenv("SESSION_CACHE", Path(__file__).parent.parent / "data" / "888_session.json"))
        try:                                             # cookies de una ejecución anterior (evita abrir Chrome cada arranque)
            for k, v in json.loads(self.cache.read_text(encoding="utf-8")).items():
                self.s.cookies.set(k, v, domain=".888sport.es")
            if self.has_session():
                log.info("sesión Spectate recuperada de %s", self.cache.name)
        except (OSError, ValueError):
            pass

    # ── sesión ──
    def has_session(self) -> bool:
        return bool(self.s.cookies.get("spectate_session"))

    def _set_cookie_str(self, raw: str):
        for kv in (raw or "").split(";"):
            if "=" in kv:
                k, v = kv.strip().split("=", 1)
                self.s.cookies.set(k, v, domain=".888sport.es")

    def ensure(self, force: bool = False):
        if self.has_session() and not force:
            return
        if force:
            self.s.cookies.clear()
            try:
                self.cache.unlink()
            except OSError:
                pass
        if time.time() - self._minted < 30:
            return
        self._minted = time.time()
        # 1) requests: portada + una llamada barata (por si el backend crea la sesión él mismo)
        for u in (self.origin + "/", f"{self.api}/sportsbook-req/getVirtualGamesList"):
            try:
                self.s.get(u, timeout=20)
            except requests.RequestException:
                pass
            if self.has_session():
                log.info("sesión Spectate creada con requests")
                return
        # 2) cookie facilitada por el usuario
        raw = os.getenv("SPECTATE_COOKIE") or self.cfg.get("cookie") or ""
        if raw:
            self._set_cookie_str(raw)
            st, _ = self.get("inplay-req/featured")
            if st == 200:
                log.info("sesión Spectate: usando cookie de configuración")
                return
            log.warning("la cookie de configuración no sirve (HTTP %s): intento con navegador", st)
            self.s.cookies.clear()
        # 3) Chrome real solo para obtener las cookies
        try:
            b = BrowserTransport(self.origin, start_url=self.cfg.get("start_url"), api_hint="/spectate/")
            b.page()
            from transport import LEARNED
            for i in range(60):                      # hasta 30 s: sesión creada Y la web ya ha llamado a su API
                ck = {c["name"]: c["value"] for c in b._ctx.cookies() if "888sport" in c.get("domain", "")}
                if ck.get("spectate_session") and (LEARNED or i >= 40):   # con la máquina cargada la web tarda en arrancar
                    break
                b._page.wait_for_timeout(500)
            b._page.wait_for_timeout(1500)           # últimas cookies que ponga el JS tras la primera llamada
            ck = {c["name"]: c["value"] for c in b._ctx.cookies() if "888sport" in c.get("domain", "")}
            b.close()
            for k, v in ck.items():
                self.s.cookies.set(k, v, domain=".888sport.es")
            if self.has_session():
                self.mode = "requests+chrome"
                log.info("sesión Spectate obtenida con Chrome (%s cookies)", len(ck))
                try:
                    self.cache.parent.mkdir(parents=True, exist_ok=True)
                    self.cache.write_text(json.dumps(ck), encoding="utf-8")
                except OSError:
                    pass
                return
            log.warning("Chrome no obtuvo spectate_session")
        except Exception as e:  # noqa: BLE001
            log.warning("no pude abrir Chrome para la sesión: %s", e)

    # ── peticiones ──
    timeout = 25.0          # se acorta durante el ciclo en directo (ver Collector.live_cycle)

    @contextlib.contextmanager
    def timeout_scope(self, seconds: float):
        old, self.timeout = self.timeout, seconds
        try:
            yield
        finally:
            self.timeout = old

    def _req(self, method: str, path: str, data=None):
        url = f"{self.api}/{path}"
        for attempt in (0, 1):
            if "inplay" in path and time.time() < getattr(self, "_ban_until", 0.0):
                return 403, None                                  # enfriamiento tras 403: ni una petición al live
            try:
                _pace()
                if method == "POST":
                    r = self.s.post(url, files={"_": (None, "")} if not data else None, data=data, timeout=self.timeout)
                else:
                    r = self.s.get(url, timeout=self.timeout)
            except requests.RequestException as e:
                log.debug("%s %s: %s", method, path, e)
                return 0, None
            if r.status_code in (400, 403, 406) and attempt == 0 and "getEventData" not in path:
                # 406 = sesión caducada/inexistente; 400/403 en listados = sesión incompleta (cookies cogidas demasiado pronto)
                now = time.time()
                if now < getattr(self, "_ban_until", 0.0):
                    return r.status_code, None                   # en pausa por baneo: no abrimos Chrome otra vez
                if r.status_code == 403:
                    # 403 = límite temporal del WAF sobre la IP, NO sesión caducada: en la práctica la misma sesión
                    # vuelve a funcionar sola a los pocos minutos, y renovar con Chrome solo empeora el baneo.
                    # → enfriamiento sin peticiones (60 s, luego 120 s, 240 s… hasta 15 min) y sin renovar sesión.
                    self._ban_streak = getattr(self, "_ban_streak", 0) + 1
                    wait = min(900, 60 * 2 ** (self._ban_streak - 1))
                    self._ban_until = now + wait
                    log.warning("HTTP 403 en %s: enfriamiento %ds sin renovar sesión (racha %d)",
                                path.split("?")[0][:60], wait, self._ban_streak)
                    return r.status_code, None
                log.warning("HTTP %s en %s: renuevo sesión", r.status_code, path.split("?")[0][:60])
                self.ensure(force=True)
                continue
            if r.status_code == 200:
                self._ban_streak = 0
            try:
                return r.status_code, json.loads(r.content)
            except ValueError:
                return r.status_code, None
        return 406, None

    def get(self, path: str):
        return self._req("GET", path)

    def post(self, path: str, data=None):
        return self._req("POST", path, data)

    def get_many(self, paths: list[str]):
        return list(self.pool.map(self.get, paths))

    def close(self):
        self.pool.shutdown(wait=False)


# ──────────────────────────────────────────────────────────────────────────────
# Mapeo de mercados
_SKIP = re.compile(r"\d+ minutos|tras \d+|despu[eé]s de \d+|2 arriba|y hay \d|marcar[aá] o asistir|o asistir[aá]|ambas partes|"
                   r"ambos tiempos|primero|[uú]ltimo|expulsad|hat-?trick|fuera del [aá]rea|de cabeza|pie (izquierdo|derecho)|"
                   r"combipartido|s[uú]per suplente|x |scorecast|margen de victoria|par o impar|pares o impares|qu[eé] equipo|"
                   r"tiempo con mayor|se pitar[aá]|m[eé]todo|^\d+\.?[ºª]?(er|o|º)? gol|primer gol|mayor n[uú]mero|mayor[ií]a|"
                   r"marcador correcto|varios goles|^goles totales$|anotar[aá] en|marcar[aá] en|equipo que ganar|y resultado|y ambos|"
                   r"robos \+ bloqueos|bloqueos \+ robos|p[eé]rdidas|doble doble|triple doble|tiempo a[ñn]adido|ganar un set|tie ?break", re.I)
_WORDNUM = {"un": 1, "uno": 1, "una": 1, "dos": 2, "tres": 3, "cuatro": 4, "cinco": 5, "seis": 6}


def _norm_title(name: str, home: str, away: str) -> str:
    t = name.replace("Home Team", home).replace("Away Team", away)
    t = re.sub(r"\{Competitor 1\}|Player 1", home, t)
    t = re.sub(r"\{Competitor 2\}|Player 2", away, t)
    t = re.sub(r"margen de puntos\s*/\s*spread(\s*/\s*spread)?(\s*\(spread\))?|distribuci[oó]n de puntos|\bspread\b", "Hándicap", t, flags=re.I)
    t = re.sub(r"1\.er cuatro", "1.er cuarto", t, flags=re.I)
    t = re.sub(r"ganador del set \(set (\d)\)", r"Ganador set \1", t, flags=re.I)
    t = re.sub(r"\(set (\d)\)", r"set \1", t, flags=re.I)
    t = re.sub(r"tiros de tres|triples anotados", "triples", t, flags=re.I)
    t = re.sub(r"bloqueos", "tapones", t, flags=re.I)
    t = re.sub(r"entre los 3 palos|lanzamientos? a puerta|tiros? a porter[ií]a", "tiros a puerta", t, flags=re.I)
    t = re.sub(r"\btiro\b", "tiros", t, flags=re.I)
    t = re.sub(r"c[oó]rneres", "córners", t, flags=re.I)
    t = re.sub(r"\(por encima/debajo\)|por encima/debajo|m[aá]s/menos", "más/menos", t, flags=re.I)
    return t


def _implied(name: str) -> float | None:
    """Línea implícita en el nombre del mercado/selección de Spectate.
    'Jugador que tendrá más de 2 tiros' -> 2.5 · 'realizará 1 o más tiros' -> 0.5 · 'Por encima de 17' -> 17.5 ·
    'El jugador realizará dos o más asistencias' -> 1.5 · 'Al menos un tiro' -> 0.5 · 'que asistirá' -> 0.5"""
    t = _fold(name)
    t = re.sub(r"\b(" + "|".join(_WORDNUM) + r")\b", lambda m: str(_WORDNUM[m.group(1)]), t)
    m = re.search(r"(\d+(?:[.,]\d+)?)", t)
    n = float(m.group(1).replace(",", ".")) if m else None
    if n is not None:
        if re.search(r"o mas|al menos|como minimo|\+", t):
            return n - 0.5
        if re.search(r"mas de|por encima de|over|menos de|por debajo de|under", t):
            return n if n != int(n) else n + 0.5
        return None
    if re.search(r"al menos 1|que asistir|que va a marcar|que marcar|recibe tarjeta|recibir|anotador|goleador|realizara 1 ", t):
        return 0.5
    return None


_METRIC_WORDS = [(r"a puerta|entre los 3 palos|lanzamiento", "tiros a puerta"), (r"\btiros?\b|remate|disparo", "tiros"),
                 (r"asist", "asistencias"), (r"tarjeta|amonest", "tarjetas"), (r"c[oó]rner", "córners"), (r"falta", "faltas"),
                 (r"fuera de juego", "fueras de juego"), (r"entrada", "entradas"), (r"parada", "paradas"), (r"rebote", "rebotes"),
                 (r"triple", "triples"), (r"tap[oó]n", "tapones"), (r"robo", "robos"), (r"punto", "puntos"), (r"marcar|anotar|gol", "goles")]


def _player_title(name: str) -> str | None:
    """'Jugador que tendrá más de 2 tiros' -> 'Total de tiros jugador' (título que entiende markets.classify)."""
    t = _fold(name)
    for rx, phrase in _METRIC_WORDS:
        if re.search(rx, t):
            return f"Total de {phrase} jugador"
    return None


def _flatten(x) -> list[dict]:
    """Las selecciones de Spectate vienen como lista, dict id->sel, o dict línea->dict orden->sel."""
    out: list[dict] = []
    if isinstance(x, dict):
        if "decimal_price" in x:
            return [x]
        for v in x.values():
            out += _flatten(v)
    elif isinstance(x, list):
        for v in x:
            out += _flatten(v)
    return out


def map_market(name: str, sels: list[dict], sport: str, home: str, away: str) -> list[dict]:
    """Un mercado Spectate (nombre + selecciones crudas) -> filas normalizadas."""
    if not name or _SKIP.search(name):
        return []
    title = _norm_title(name, home, away)
    live = [s for s in sels if s.get("decimal_price") and s.get("active", True) and s.get("tradable", True)
            and not s.get("suspended") and str(s.get("visible", "1")) != "0"]
    if not live:
        return []
    types = {str(s.get("type") or "") for s in live}
    out: list[dict] = []

    def price(s):
        return _num(s.get("decimal_price"))

    # ── más/menos (Over/Under) ──
    if types & {"Over", "Under"}:
        pm = re.match(r"^(.+?);\s*[A-Z]{2,4};\s*(Over|Under)", live[0].get("name") or "")   # NBA: "Luka Doncic; LAL; Over (32.5)"
        info = classify(f"Total de {_fold(title)} jugador" if pm else title, sport, home, away, kind="total",
                        player="x" if pm else None)
        if not info:
            return []
        for s in live:
            if s.get("type") not in ("Over", "Under"):
                continue
            ln = _num(s.get("special_odds_value") or s.get("specialoddsvalue"))
            if ln is None:
                ln = parse_ou_label(s.get("name") or "")[1]
            player = None
            if pm:
                m = re.match(r"^(.+?);", s.get("name") or "")
                player = m.group(1).strip() if m else None
                if not player:
                    continue
            if ln is not None:
                out.append({"market": info.market, "selection": s["type"], "line": ln, "player": player, "price": price(s)})
        return out
    # ── ambos marcan ──
    if types & {"Yes", "No"}:
        info = classify(title, sport, home, away)
        if not info or not info.market.startswith("BTTS"):
            return []
        for s in live:
            if s.get("type") in ("Yes", "No"):
                out.append({"market": info.market, "selection": s["type"], "line": None, "price": price(s)})
        return out
    # ── doble oportunidad ──
    if types & {"1/X", "X/2", "2/X", "1/2"}:
        info = classify(title, sport, home, away, kind="dc")
        if not info:
            return []
        for s in live:
            sel = {"1/X": "1X", "X/2": "X2", "2/X": "X2", "1/2": "12"}.get(s.get("type"))
            if sel:
                out.append({"market": info.market, "selection": sel, "line": None, "price": price(s)})
        return out
    # ── 1X2 / sin empate / hándicap ──
    if types & {"1", "2"}:
        sov = [_num(s.get("special_odds_value") or s.get("specialoddsvalue")) for s in live]
        has_line = any(v is not None for v in sov)
        names_have_player = not has_line and len(live) > 3 and all(
            re.search(r"[A-Za-z]", s.get("name") or "") and _fold(s.get("name") or "") not in (_fold(home), _fold(away), "empate") for s in live)
        if names_have_player:                                   # lista de jugadores (tipo = equipo del jugador)
            ln = _implied(title)
            pt = _player_title(title)
            info = classify(pt, sport, home, away, kind="total", player="x") if (ln is not None and pt) else None
            if not info:
                return []
            for s in live:
                out.append({"market": info.market, "selection": "Over", "line": ln, "player": s.get("name"), "price": price(s)})
            return out
        if has_line or re.search(r"h[aá]ndicap", title, re.I):
            if "X" in types:
                return []                                       # hándicap a 3 vías: no comparable
            info = classify(title, sport, home, away, kind="handicap")
            if not info:
                return []
            for s, v in zip(live, sov):
                if s.get("type") in ("1", "2") and v is not None:
                    out.append({"market": info.market, "selection": s["type"], "line": v, "price": price(s)})
            return out
        if sport == "baloncesto" and "X" in types:
            return []                                           # 3 vías en baloncesto: no comparable con el 2 vías de otras casas
        info = classify(title, sport, home, away, kind="dnb" if re.search(r"sin empate", title, re.I) else "result")
        if not info or not info.market.startswith(("1X2", "DNB")):
            return []
        for s in live:
            if s.get("type") in ("1", "X", "2"):
                out.append({"market": info.market, "selection": s["type"], "line": None, "price": price(s)})
        return out
    # ── sin tipo: totales de equipo/partido en texto ("Por encima de 17"), hándicap de córners por nombre ──
    if all(re.search(r"por encima de|por debajo de|m[aá]s de|menos de", s.get("name") or "", re.I) for s in live):
        info = classify(title, sport, home, away, kind="total")
        if not info:
            return []
        for s in live:
            sel = "Over" if re.search(r"encima|m[aá]s de", s["name"], re.I) else "Under"
            ln = _implied(s["name"])
            if ln is not None:
                out.append({"market": info.market, "selection": sel, "line": ln, "player": info.player, "price": price(s)})
        return out
    if re.search(r"h[aá]ndicap", title, re.I):
        if any(re.match(r"\s*empate", s.get("name") or "", re.I) for s in live):
            return []                                           # hándicap a 3 vías
        info = classify(title, sport, home, away, kind="handicap")
        if not info:
            return []
        for s in live:
            m = re.match(r"(.+?)\s*([+-]\d+(?:[.,]\d+)?)", s.get("name") or "")
            if not m:
                continue
            team = _fold(m.group(1))
            sel = "1" if team and (team in _fold(home) or _fold(home) in team) else "2" if team and (team in _fold(away) or _fold(away) in team) else None
            if sel:
                out.append({"market": info.market, "selection": sel, "line": _num(m.group(2)), "price": price(s)})
        return out
    return []


def event_selections(markets: dict, selections, sport: str, home: str, away: str) -> list[dict]:
    """markets: id -> {name, selection_schema}; selections: dict id->sel | dict market_id->(lista|dict) | lista."""
    by_m: dict[str, list[dict]] = {}
    if isinstance(selections, dict):
        for key, v in selections.items():
            for s in _flatten(v):                           # vale para los tres formatos (plano, por mercado, mixto)
                by_m.setdefault(str(s.get("market_id") or key), []).append(s)
    elif isinstance(selections, list):
        for s in _flatten(selections):
            by_m.setdefault(str(s.get("market_id")), []).append(s)
    out: list[dict] = []
    for mid, m in (markets or {}).items():
        if not isinstance(m, dict):
            continue
        sels = by_m.get(str(mid)) or _flatten(m.get("selections"))
        out += map_market(m.get("name") or "", sels, sport, home, away)
    return out


# ──────────────────────────────────────────────────────────────────────────────
class Collector:
    def __init__(self, cfg: dict):
        self.cfg = cfg
        self._cfg_mtime = CFG_PATH.stat().st_mtime
        self.bk = cfg.get("bookmaker", "888sportes")
        set_request_gap(cfg.get("request_gap", 0.2))
        self.http = Session888(cfg)
        self.store = OddsStore(bookmaker=self.bk)
        self.catalog = Competitions()
        self.demand = Demand(self.bk)
        self.sports: dict[str, str] = cfg["sports"]                # slug spectate -> deporte
        self._last_prematch = 0.0
        self._pm_queue: list = []
        self._live_off = 0
        self._skipped = 0
        self._comp_cache: dict[str, str | None] = {}
        self._detail_mode = cfg.get("prematch_detail", "auto")  # auto | inplay | full

    def _reload_if_changed(self):
        mt = CFG_PATH.stat().st_mtime
        if mt != self._cfg_mtime:
            self.cfg = load_cfg()
            self._cfg_mtime = mt
            log.info("config recargada")

    # ── competiciones ──
    def comp_of(self, sport: str, tournament: str, category: str) -> str | None:
        key = f"{sport}|{category}|{tournament}"
        if key not in self._comp_cache:
            comp = self.catalog.match(self.bk, sport, tournament) or self.catalog.match(self.bk, sport, f"{category} - {tournament}")
            self._comp_cache[key] = comp
        return self._comp_cache[key]

    # ── filas ──
    @staticmethod
    def _url(cfg: dict, ev: dict, live: bool | None = None) -> str:
        from urllib.parse import quote
        return quote(Collector._url_raw(cfg, ev, live), safe=":/?=&#%-_.")   # tildes (fútbol, españa) -> %C3%BA… para Telegram

    @staticmethod
    def _url_raw(cfg: dict, ev: dict, live: bool | None = None) -> str:
        """URLs reales de 888sport.es (comprobadas 2026-10-24):
           en directo : https://www.888sport.es/en-vivo/mercados_partido/<id>-ipe-<id>/
           prematch   : https://www.888sport.es/fútbol/españa/españa-laliga-ea-sports/rayo-vallecano-contra-elche-e-8386703/
                        https://www.888sport.es/tenis/kazajistán/atp-almaty/nikoloz-basilashvili-contra-stefanos-tsitsipas-e-8453048/
           Los tramos van en español y conservan tildes/ñ: se construyen a partir de category_name / tournament_name
           (en español en la API) y "<local>-contra-<visitante>"."""
        if live is None:
            live = bool(ev.get("inplay") or ev.get("is_live") or ev.get("live"))
        if live:
            return f"https://www.888sport.es/en-vivo/mercados_partido/{ev['id']}-ipe-{ev['id']}/"

        def _sl(x):
            x = unicodedata.normalize("NFC", str(x or "")).lower()
            return re.sub(r"[^0-9a-zà-ÿ]+", "-", x).strip("-")
        sport_es = {"football": "fútbol", "basketball": "baloncesto", "tennis": "tenis"}.get(ev.get("sport_slug") or "")
        cat = ev.get("category_name") or ev.get("categoryName")
        tour = ev.get("tournament_name") or ev.get("tournamentName")
        if sport_es and cat and tour and ev.get("home") and ev.get("away"):
            return f"https://www.888sport.es/{sport_es}/{_sl(cat)}/{_sl(tour)}/{_sl(ev['home'])}-contra-{_sl(ev['away'])}-e-{ev['id']}/"
        slug = ev.get("slug_api") or (f"{_sl(ev.get('home'))}-vs-{_sl(ev.get('away'))}" if ev.get("home") and ev.get("away") else None) or ev.get("slug") or ""
        return cfg["event_url"].format(sport=ev.get("sport_slug") or "", cat=ev.get("category_slug") or "",
                                       tour=ev.get("tournament_slug") or "", slug=slug, id=ev["id"])

    def _row(self, ev: dict, sport: str, comp: str, home: str, away: str, sels: list[dict], live: bool) -> dict:
        dt = None
        try:
            dt = datetime.fromisoformat((ev.get("start_time") or ev.get("scheduled_start")).replace("Z", "+00:00")).astimezone()
        except Exception:  # noqa: BLE001
            pass
        row = {"event_id": str(ev["id"]), "home": home, "away": away, "competition": comp,
               "date": dt.strftime("%Y-%m-%d") if dt else None, "start_time": dt.strftime("%H:%M") if dt else None,
               "url": self._url(self.cfg, ev, live), "selections": sels}
        if live:
            # Pestaña de la ficha en directo (URL real comprobada 2026-11-15: …/mercados_partido/<id>-ipe-<id>/#quarters)
            for sl in sels:
                if re.search(r"_Q[1-4]$", sl.get("market") or "") and not sl.get("url"):
                    sl["url"] = row["url"] + "#quarters"
        if live:
            xi = ev.get("extra_info") or {}
            if isinstance(xi, dict):
                row.update({"score": xi.get("score"), "timer": xi.get("time"), "period": ev.get("match_status")})
        return row

    # ── live ──
    def live_events(self) -> list[tuple[dict, str, str]]:
        st, js = self.http.get("inplay-req/getInplayEvents/all")
        if st != 200 or not isinstance(js, dict):
            raise RuntimeError(f"getInplayEvents HTTP {st}")
        out = []
        for sp in js.get("sports") or []:
            sport = self.sports.get(sp.get("slug"))
            if not sport:
                continue
            for t in sp.get("tournaments") or []:
                comp = self.comp_of(sport, t.get("name") or "", t.get("categorySlug") or "")
                if not comp:
                    continue
                for ev in t.get("events") or []:
                    cs = ev.get("competitors") or []
                    if len(cs) != 2:
                        continue
                    ev = dict(ev, sport_slug=sp.get("slug"), category_slug=t.get("categorySlug"), tournament_slug=t.get("slug"),
                              home=cs[0]["name"], away=cs[1]["name"], slug_api=ev.get("slug"),
                              slug=re.sub(r"[^a-z0-9]+", "-", _fold(ev.get("name") or "")).strip("-"))
                    out.append((ev, sport, comp))
        return out

    def live_details(self, evs: list) -> dict[str, list[dict]]:
        res = self.http.get_many([f"inplay-req/event/{ev['id']}" for ev, *_ in evs])
        by_sport: dict[str, list[dict]] = {}
        for (ev, sport, comp), (st, js) in zip(evs, res):
            sels: list[dict] = []
            if st == 200 and isinstance(js, dict):
                sels = event_selections(_d(js.get("markets")), js.get("selections") or {}, sport, ev["home"], ev["away"])
            by_sport.setdefault(sport, []).append(self._row(ev, sport, comp, ev["home"], ev["away"], sels, True))
        return by_sport

    # ── prematch ──
    def _days(self) -> list[str]:
        hours = self.cfg.get("prematch_hours", 48)
        days = ["today", "tomorrow"]
        d = datetime.now().date()
        for i in range(2, max(2, -(-hours // 24))):
            days.append((d + timedelta(days=i)).isoformat())
        return days

    def prematch_events(self) -> list[tuple[dict, str, str]]:
        horizon = datetime.now(timezone.utc) + timedelta(hours=self.cfg.get("prematch_hours", 48))
        out, seen = [], set()
        for slug, sport in self.sports.items():
            for day in self._days():
                st, js = self.http.post(f"sportsbook-req/getUpcomingEvents/{slug}/{day}")
                if st != 200 or not isinstance(js, dict):
                    log.debug("getUpcomingEvents %s/%s HTTP %s", slug, day, st)
                    continue
                for ev in _d(js.get("events")).values():
                    if ev.get("inplay") or ev["id"] in seen or ev.get("event_type") not in (None, "NORMAL"):
                        continue
                    comp = self.comp_of(sport, ev.get("tournament_name") or "", ev.get("category_name") or "")
                    if not comp:
                        continue
                    try:
                        if datetime.fromisoformat(ev["start_time"].replace("Z", "+00:00")) > horizon:
                            continue
                    except Exception:  # noqa: BLE001
                        pass
                    cs = sorted((ev.get("competitors") or {}).values(), key=lambda c: (not c.get("is_home_team"), c.get("order", 0)))
                    if len(cs) != 2:
                        continue
                    ev = dict(ev, home=cs[0]["name"], away=cs[1]["name"], slug_api=ev.get("slug"))
                    seen.add(ev["id"])
                    out.append((ev, sport, comp))
        return out

    def prematch_details(self, evs: list) -> dict[str, list[dict]]:
        by_sport: dict[str, list[dict]] = {}
        if self._detail_mode in ("auto", "inplay"):
            res = self.http.get_many([f"inplay-req/event/{ev['id']}" for ev, *_ in evs])
            ok = [(st == 200 and isinstance(js, dict) and len(js.get("markets") or {}) > 3) for st, js in res]
            if self._detail_mode == "auto":
                if any(ok):
                    self._detail_mode = "inplay"
                    log.info("detalle prematch: inplay-req/event sirve también para prematch (ligero) ✔")
                else:
                    self._detail_mode = "full"
                    log.info("detalle prematch: inplay-req/event no sirve en prematch; uso sportsbook/getEventData (pesado)")
            if self._detail_mode == "inplay":
                for (ev, sport, comp), (st, js), good in zip(evs, res, ok):
                    sels = event_selections(_d(js.get("markets")), js.get("selections") or {}, sport, ev["home"], ev["away"]) if good else \
                        event_selections(ev.get("markets") or {}, None, sport, ev["home"], ev["away"])
                    by_sport.setdefault(sport, []).append(self._row(ev, sport, comp, ev["home"], ev["away"], sels, False))
                return by_sport
        paths = [f"sportsbook/getEventData/{ev.get('sport_slug')}/{ev.get('category_slug')}/{ev.get('tournament_slug')}/{ev.get('slug')}/{ev['id']}"
                 for ev, *_ in evs]
        for (ev, sport, comp), (st, js) in zip(evs, self.http.get_many(paths)):
            sels = []
            if st == 200 and isinstance(js, dict):
                mk = _d(_d(js.get("event")).get("markets"))
                sels = event_selections(_d(mk.get("markets_details")), mk.get("markets_selections") or {}, sport, ev["home"], ev["away"])
            if not sels:
                sels = event_selections(_d(ev.get("markets")), None, sport, ev["home"], ev["away"])
            by_sport.setdefault(sport, []).append(self._row(ev, sport, comp, ev["home"], ev["away"], sels, False))
        return by_sport

    # ── ciclos ──
    def _demand(self, evs: list) -> list:
        if not self.cfg.get("demand_only", True):
            return evs
        out = self.demand.filter(evs, lambda it: (it[1], it[0]["home"], it[0]["away"]))
        self._skipped = len(evs) - len(out)
        return out

    def _save(self, by_sport: dict[str, list[dict]], kind: str) -> tuple[int, int]:
        rows = changed = 0
        for sport, rs in by_sport.items():
            changed += self.store.save_rows(sport, kind, rs)
            rows += len(rs)
        return rows, changed

    def live_cycle(self) -> tuple[int, int]:
        # timeout corto en directo: una API colgada no debe dejar la casa ciega 60-100 s (ver Http.timeout_scope)
        with self.http.timeout_scope(self.cfg.get("timeout_live", 8)):
            return self._live_cycle()

    def _live_cycle(self) -> tuple[int, int]:
        # El navegador real pide getInplayEvents UNA vez por página y luego solo las fichas; pedir el listado en cada
        # ciclo (cada 5 s) es lo que dispara el 403 del WAF a los ~7 min → listado cada `interval_live_list` s (15).
        now = time.time()
        cached = getattr(self, "_live_list", None)
        if cached is None or now - getattr(self, "_live_list_at", 0.0) >= self.cfg.get("interval_live_list", 15):
            evs = self.live_events()
            self._live_list, self._live_list_at = evs, now
            self.store.sweep({str(ev["id"]) for ev, *_ in evs}, "live")
        else:
            evs = cached
        evs = self._demand(evs)
        n = self.cfg.get("max_detail_per_cycle", 30)
        if len(evs) > n:
            off = self._live_off % len(evs)
            evs = (evs + evs)[off: off + n]
            self._live_off = off + n
        return self._save(self.live_details(evs), "live")

    # ── pre-partido en segundo plano (pace.Background): el bucle live no espera por listas ni fichas pre-partido ──
    def _pm_inline(self, once: bool) -> bool:
        http = getattr(self, "http", None) or getattr(getattr(self, "api", None), "http", None)
        name = getattr(http, "name", None) or getattr(http, "mode", "") or ""
        return once or "browser" in str(name) or "chrome" in str(name)   # el navegador no se comparte entre hilos

    def _pm_schedule(self, t0: float, once: bool, msg: str) -> str:
        bg = self.__dict__.setdefault("_bg", __import__("pace").Background(f"{getattr(self, 'bk', 'prematch')}-prematch"))
        if not bg.busy():
            job = self._pm_job(t0, once)
            if job is not None:
                r = bg.run(job, inline=self._pm_inline(once))
                if r:
                    msg += " | " + r
        note = bg.note()
        if note:
            msg += " | " + note
        return msg

    def _pm_job(self, t0: float, once: bool):
        if not self._pm_queue and t0 - self._last_prematch >= self.cfg.get("interval_prematch", 60):
            def _list():
                evs = self.prematch_events()
                out = ""
                if evs:
                    self.store.sweep({str(ev["id"]) for ev, *_ in evs}, "prematch")
                    by_sport: dict[str, list[dict]] = {}
                    for ev, sport, comp in evs:                       # mercado principal de la lista (barato)
                        r = self._row(ev, sport, comp, ev["home"], ev["away"],
                                      event_selections(ev.get("markets") or {}, None, sport, ev["home"], ev["away"]), False)
                        r["partial"] = True
                        by_sport.setdefault(sport, []).append(r)
                    prow, pchg = self._save(by_sport, "prematch")
                    out = f"prematch lista {prow} ev / {pchg} cambios"
                self._pm_queue = self._demand(evs)[: self.cfg.get("max_prematch_detail", 200)]
                self._last_prematch = time.time()
                if once and self._pm_queue:
                    out += " | " + self._pm_job(time.time(), once)()
                return out
            return _list
        if self._pm_queue:
            batch = len(self._pm_queue) if once else max(1, self.cfg.get("prematch_batch", 3))
            chunk, self._pm_queue = self._pm_queue[:batch], self._pm_queue[batch:]
            def _detail():
                prow, pchg = self._save(self.prematch_details(chunk), "prematch")
                return f"prematch detalle {prow} ev / {pchg} cambios ({len(self._pm_queue)} pendientes)"
            return _detail
        return None

    def run(self, once: bool = False):
        backoff = 2
        while True:
            t0 = time.time()
            try:
                self._reload_if_changed()
                self.http.ensure()
                if self.cfg.get("live_enabled", True):
                    rows, changed = self.live_cycle()
                    msg = f"live {rows} ev / {changed} cambios"
                else:
                    rows, changed = 0, 0                    # solo pre-partido (el live de 888 banea la IP con 403)
                    self._skipped = 0
                    msg = "solo pre-partido"
                if self._skipped:
                    msg += f" ({self._skipped} sin pareja en otras casas, no detallados)"
                msg = self._pm_schedule(t0, once, msg)
                self.store.set_status(sp888_last_ok=time.time(), sp888_live_events=rows, sp888_transport=self.http.mode)
                log.info("%s [%s] (%.1fs)", msg, self.http.mode, time.time() - t0)
                backoff = 2
                if once:
                    return
            except Exception as e:  # noqa: BLE001
                import traceback
                tb = traceback.extract_tb(e.__traceback__)[-1]
                log.warning("error de ciclo: %s (%s:%d en %s) — reintento en %ss", e, Path(tb.filename).name, tb.lineno, tb.name, backoff)
                self.store.set_status(sp888_last_error=f"{time.time():.0f} {e}")
                time.sleep(backoff)
                backoff = min(backoff * 2, 60)
                continue
            time.sleep(max(0.5, self.cfg.get("interval_live", 5) - (time.time() - t0)))


# ──────────────────────────────────────────────────────────────────────────────
def list_catalog(c: Collector):
    c.http.ensure()
    for slug, sport in c.sports.items():
        print(f"\n=== {sport}")
        seen: dict[str, int] = {}
        for day in ("today", "tomorrow"):
            st, js = c.http.post(f"sportsbook-req/getUpcomingEvents/{slug}/{day}")
            if st != 200 or not isinstance(js, dict):
                print(f"  getUpcomingEvents/{slug}/{day} -> HTTP {st}")
                continue
            for ev in _d(js.get("events")).values():
                k = f"{ev.get('category_name')} | {ev.get('tournament_name')}"
                seen[k] = seen.get(k, 0) + 1
        for k, n in sorted(seen.items()):
            cat, tour = k.split(" | ", 1)
            comp = c.comp_of(sport, tour, cat)
            print(f" {'✔' if comp else ' '} {k}  ({n} ev)" + (f"  -> {comp}" if comp else ""))


def dump(c: Collector, n: int = 2):
    c.http.ensure()
    out = []
    per: dict[str, int] = {}
    for ev, sport, comp in c.live_events():
        if per.get(sport, 0) >= n:
            continue
        per[sport] = per.get(sport, 0) + 1
        st, js = c.http.get(f"inplay-req/event/{ev['id']}")
        sels = event_selections((js or {}).get("markets") or {}, (js or {}).get("selections") or {}, sport, ev["home"], ev["away"]) if st == 200 else []
        out.append({"kind": "live", "sport": sport, "competition": comp, "event": ev, "raw": js, "parsed": sels})
        log.info("live %s %s - %s: %d mercados -> %d selecciones", sport, ev["home"], ev["away"], len((js or {}).get("markets") or {}), len(sels))
    per.clear()
    for ev, sport, comp in c.prematch_events():
        if per.get(sport, 0) >= n:
            continue
        per[sport] = per.get(sport, 0) + 1
        st1, js1 = c.http.get(f"inplay-req/event/{ev['id']}")
        st2, js2 = c.http.get(f"sportsbook/getEventData/{ev.get('sport_slug')}/{ev.get('category_slug')}/{ev.get('tournament_slug')}/{ev.get('slug')}/{ev['id']}")
        mk = ((js2 or {}).get("event") or {}).get("markets") or {}
        sels = event_selections(_d(mk.get("markets_details")), mk.get("markets_selections") or {}, sport, ev["home"], ev["away"]) if st2 == 200 else []
        out.append({"kind": "prematch", "sport": sport, "competition": comp, "event": ev, "inplay_req_status": st1,
                    "inplay_req_markets": len((js1 or {}).get("markets") or {}) if isinstance(js1, dict) else None,
                    "raw": js2, "parsed": sels})
        log.info("prematch %s %s - %s: getEventData HTTP %s, %d mercados -> %d selecciones | inplay-req HTTP %s (%s mercados)",
                 sport, ev["home"], ev["away"], st2, len(mk.get("markets_details") or {}), len(sels), st1, out[-1]["inplay_req_markets"])
    p = Path(os.getenv("SNAP_DIR", Path(__file__).parent / "snapshots")) / f"dump_888_{int(time.time())}.json"
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")
    log.info("volcado -> %s (%d KB)", p, p.stat().st_size // 1024)


def dump_links(c: Collector):
    """URLs candidatas de enlace directo a una selección (888sport/Spectate), para probarlas en el navegador."""
    c.http.ensure()
    evs = [(ev, sp, cp, True) for ev, sp, cp in c.live_events()[:5]] + [(ev, sp, cp, False) for ev, sp, cp in c.prematch_events()[:5]]
    for ev, sport, comp, live in evs:
        if live:
            st, js = c.http.get(f"inplay-req/event/{ev['id']}")
            markets, selections = _d((js or {}).get("markets")), (js or {}).get("selections") or {}
        else:
            st, js = c.http.get(f"sportsbook/getEventData/{ev.get('sport_slug')}/{ev.get('category_slug')}/{ev.get('tournament_slug')}/{ev.get('slug')}/{ev['id']}")
            mk = _d(_d((js or {}).get("event")).get("markets"))
            markets, selections = _d(mk.get("markets_details")), mk.get("markets_selections") or {}
        if st != 200 or not isinstance(js, dict):
            print(f"  {ev['id']}: HTTP {st}"); continue
        found = None
        allsels = _flatten(selections)
        for sel in allsels:
            if sel.get("decimal_price") and not sel.get("suspended"):
                m = _d(markets.get(str(sel.get("market_id"))))
                found = (m.get("name"), sel.get("name"), sel.get("decimal_price"), sel.get("market_id"), sel.get("id"))
                break
        if not found:
            ex = allsels[0] if allsels else None
            print(f"  {ev['home']} - {ev['away']}: {len(markets)} mercados, {len(allsels)} selecciones; tipo selections={type(selections).__name__}; "
                  f"ejemplo={json.dumps(ex, ensure_ascii=False)[:300] if ex else None}")
        if not found:
            print(f"  {ev['home']} - {ev['away']}: sin selecciones con precio"); continue
        title, oname, odds, mid, sid = found
        base = c._url(c.cfg, ev, live)
        # ── diagnóstico del enlace al partido: campos *slug* que devuelve la API ──
        evd = _d((js or {}).get("event")) if not live else _d(js)
        slugs = {k: v for k, v in {**ev, **evd}.items() if "slug" in k.lower() or k.lower().endswith("_name") or k in ("name", "url", "path")}
        print("Campos de enlace que da la API:", json.dumps(slugs, ensure_ascii=False)[:800])
        es_sport = {"football": "fútbol", "basketball": "baloncesto", "tennis": "tenis"}.get(ev.get("sport_slug"), ev.get("sport_slug"))
        print("\nPrimero comprueba cuál de estas URLs ABRE EL PARTIDO (sin selección):")
        for i, u in enumerate([
            base,
            f"https://www.888sport.es/{es_sport}/{ev.get('category_slug')}/{ev.get('tournament_slug')}/{ev.get('slug')}-e-{ev['id']}/",
            f"https://www.888sport.es/{es_sport}/x/x/x-e-{ev['id']}/",
            f"https://www.888sport.es/event/{ev['id']}/",
        ], 1):
            print(f"  B{i}. {u}")
        base = base if base.count("/") >= 6 else f"https://www.888sport.es/{es_sport}/{ev.get('category_slug')}/{ev.get('tournament_slug')}/{ev.get('slug')}-e-{ev['id']}/"
        print(f"\nPartido: {ev['home']} - {ev['away']}  eventId={ev['id']}")
        print(f"Apuesta: {title!r} -> selección {oname!r} @{odds}  marketId={mid} selectionId={sid}\n")
        print("Abre cada URL en incógnito y dime cuál deja la selección ya marcada en la cesta:")
        for i, u in enumerate([
            f"{base}?selection={sid}",
            f"{base}?selectionId={sid}",
            f"{base}?market={mid}&selection={sid}",
            f"{base}?betslip={sid}",
            f"{base}#selection-{sid}",
            f"https://www.888sport.es/?selection={sid}",
            f"https://www.888sport.es/betslip/add/{sid}",
            f"https://www.888sport.es/apuestas-en-vivo/?betslip={sid}",
        ], 1):
            print(f"  {i}. {u}")
        return
    print("sin eventos en directo con cuotas")


def main():
    logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"),
                        format="%(asctime)s %(levelname)s %(name)s: %(message)s", datefmt="%H:%M:%S")
    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    c = Collector(load_cfg())
    if "--list" in sys.argv:
        list_catalog(c)
    elif "--dump" in sys.argv:
        dump(c)
    elif "--links" in sys.argv:
        dump_links(c)
    else:
        c.run(once="--once" in sys.argv)
    c.http.close()


if __name__ == "__main__":
    main()
