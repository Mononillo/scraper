"""
Traducción de los mercados de BetBurger a español.

BetBurger escribe las selecciones en inglés y en clave:

    AH1(-0.5)          Team1 Win           TO(1.5)      TU(0.5)
    LAY AH1(+0.5)      1X / 12 / X2        Odd / Even
    Both to score      One scoreless       EH2(1.0)/DNB
    1st - yes (Autocrat)                   Player to Score (X)

Este módulo los convierte en algo que se entienda de un vistazo:

    Hándicap equipo 1 (-0.5)   Gana el equipo 1   Más de 1.5
    En contra · Hándicap equipo 1 (+0.5)
    Ambos marcan · Gana el equipo 1 o empate · Total impar/par
    Queda 1º (Autocrat) · Marca gol (MacKinnon)

Regla: lo que NO se reconoce se deja tal cual (mejor inglés raruno que
inventarse una traducción que lleve a apostar mal).
"""
from __future__ import annotations
import re

# ──────────────────────────────────────────────────────────
# EQUIPOS / RESULTADOS
# ──────────────────────────────────────────────────────────

_TEAM = {"1": "el equipo 1", "2": "el equipo 2", "X": "empate"}

_EXACT_RESULTS = {
    "1": "Gana el equipo 1",
    "2": "Gana el equipo 2",
    "X": "Empate",
    "1X": "Gana el equipo 1 o empate",
    "X2": "Empate o gana el equipo 2",
    "12": "Gana el equipo 1 o el 2 (sin empate)",
}

# ──────────────────────────────────────────────────────────
# PERIODOS
# ──────────────────────────────────────────────────────────

_PERIODS = {
    "regular time": "Tiempo reglamentario",
    "full time": "Final del partido",
    "full time with overtime": "Final con prórroga",
    "full time with overtimes": "Final con prórrogas",
    "1st half": "1ª parte",
    "2nd half": "2ª parte",
    "1st quarter": "1º cuarto",
    "2nd quarter": "2º cuarto",
    "3rd quarter": "3º cuarto",
    "4th quarter": "4º cuarto",
    "1st set": "1º set",
    "2nd set": "2º set",
    "3rd set": "3º set",
    "match": "Partido completo",
    "race": "Carrera",
    "fight": "Combate",
    "regular": "Tiempo reglamentario",
}

# ──────────────────────────────────────────────────────────
# COMPLEMENTOS  ("- Corners", "for Team2", "- Sets"...)
# ──────────────────────────────────────────────────────────

_MARKET_EXTRA = {
    "corners": "córners",
    "shots (all)": "tiros (total)",
    "shots on target": "tiros a puerta",
    "shots": "tiros",
    "sets": "sets",
    "games": "juegos",
    "goals": "goles",
    "points": "puntos",
    "rebounds": "rebotes",
    "assists": "asistencias",
    "cards": "tarjetas",
    "offsides": "fueras de juego",
    "fouls": "faltas",
    "aces": "aces",
    "penalties": "penaltis",
    "throws": "saques",
    "bookings": "amonestaciones",
}

_RE_FOR_TEAM = re.compile(r"\s*for\s*team\s*([12x])\b", re.IGNORECASE)
_RE_TAIL = re.compile(r"\s*[-–]\s*([^-–]+?)\s*$")
_RE_YESNO = re.compile(r"\s*[-–]\s*(yes|no)\b\s*$", re.IGNORECASE)
_RE_DNB = re.compile(r"/\s*dnb\b", re.IGNORECASE)
_RE_LAY = re.compile(r"^lay\b[\s:]*", re.IGNORECASE)

_RE_HANDICAP = re.compile(
    r"^(?P<kind>AH|EH|H)\s*(?P<team>[12X])\s*\(\s*(?P<val>[-+]?[0-9.]+)\s*\)",
    re.IGNORECASE)
_RE_TOTAL = re.compile(
    r"^(?P<kind>Over|Under|TO|TU|O|U)\s*\(\s*(?P<val>[0-9.]+)\s*\)",
    re.IGNORECASE)
_RE_EXACT = re.compile(r"^exact\s*\(\s*(?P<val>[-0-9.]+)\s*\)", re.IGNORECASE)
_RE_TEAM_WIN = re.compile(r"^team\s*(?P<team>[12])\s*win\b", re.IGNORECASE)
_RE_WIN_AND = re.compile(
    r"^win\s*(?P<team>[12X])\s*and\s*(?P<rest>.+)$", re.IGNORECASE)
_RE_BTS_W = re.compile(
    r"^both\s*to\s*score\s*and\s*w(?P<team>[12])$", re.IGNORECASE)
_RE_PLACE = re.compile(
    r"^(?P<pos>1st|2nd|3rd|1|2|3)\s*[-–]?\s*(?P<yn>yes|no)\s*\(\s*(?P<who>.+?)\s*\)\s*$",
    re.IGNORECASE)
_RE_PLAYER_PROP = re.compile(
    r"\s*[-–]?\s*Player\s+(?P<stat>[A-Za-z0-9 \-]+?)\s*\(\s*(?P<who>[^)]+?)\s*\)\s*$",
    re.IGNORECASE)

_RE_PLAYER_SCORE = re.compile(
    r"^player\s*to\s*score\s*(?P<neg>[-–]?\s*no)?\s*\(\s*(?P<who>.+?)\s*\)\s*$",
    re.IGNORECASE)
_RE_ORDINAL = re.compile(r"^([0-9]+)\s*(st|nd|rd|th)\b", re.IGNORECASE)

# Estadísticas de jugador: "Player Rebounds (X)" → "rebotes de X"
_PLAYER_STATS = {
    "points": "puntos", "rebounds": "rebotes", "assists": "asistencias",
    "threes": "triples", "3-pointers": "triples", "steals": "robos",
    "blocks": "tapones", "turnovers": "pérdidas", "goals": "goles",
    "shots": "tiros", "shots on target": "tiros a puerta", "aces": "aces",
    "fouls": "faltas", "double double": "doble-doble",
}

_HCAP_NAME = {"AH": "Hándicap asiático", "EH": "Hándicap europeo",
              "H": "Hándicap"}
_TOTAL_NAME = {"over": "Más de", "under": "Menos de",
               "to": "Más de", "tu": "Menos de",
               "o": "Más de", "u": "Menos de"}
_POS_NAME = {"1st": "1º", "2nd": "2º", "3rd": "3º", "1": "1º", "2": "2º",
             "3": "3º"}


# ══════════════════════════════════════════════════════════
#  API
# ══════════════════════════════════════════════════════════

def split_teams(game: str) -> tuple:
    """
    'Cerro Porteno - Rubio Nu' → ('Cerro Porteno', 'Rubio Nu')
    Si no hay separador, devuelve ('', '').
    """
    g = (game or "").strip()
    if " - " in g:
        a, b = g.split(" - ", 1)
        return a.strip(), b.strip()
    return "", ""


def translate_selection(selection: str, lang: str = "es",
                        team1: str = "", team2: str = "") -> str:
    """
    'LAY AH1(+0.5)' → 'En contra · Hándicap asiático equipo 1 (+0.5)'

    Si le pasas `team1` / `team2` (los nombres reales del evento), sustituye
    "equipo 1"/"equipo 2" por ellos:

        'Team1 Win'   →  'Gana Cerro Porteno'
    """
    s = (selection or "").strip()
    if not s or lang != "es":
        return s

    # 1) LAY  →  se ha apostado EN CONTRA (en un exchange)
    lay = False
    m = _RE_LAY.match(s)
    if m:
        lay = True
        s = s[m.end():]

    # 2) "for Team2"  →  "del equipo 2"
    team = None
    m = _RE_FOR_TEAM.search(s)
    if m:
        team = m.group(1).upper()
        s = (s[:m.start()] + s[m.end():]).strip()

    # 3) cola "- Corners" / "- Sets" / "- Yes" (se saca ANTES de traducir,
    #    porque el núcleo se queda solo con la primera parte)
    extra = yesno = None
    m = _RE_TAIL.search(s)
    if m:
        pieza = m.group(1).strip()
        low = pieza.lower()
        if low in ("yes", "no"):
            yesno, s = low, s[:m.start()].strip()
        elif low in _MARKET_EXTRA:
            extra, s = _MARKET_EXTRA[low], s[:m.start()].strip()
        # si no es ninguna conocida, se deja: el núcleo puede necesitarla
        #   p. ej. "Player to Score - No (MacKinnon, Nathan)"

    # 3b) prop de jugador: "Player Rebounds (Shepard, Jessica)"
    prop = None
    # OJO: "Player to Score (X)" lo traduce el núcleo ("Marca gol (X)"),
    # no lo tratamos como una estadística de jugador.
    m = None if _RE_PLAYER_SCORE.match(s) else _RE_PLAYER_PROP.search(s)
    if m:
        stat = m.group("stat").strip().lower()
        who = m.group("who").strip()
        prop = f"{_PLAYER_STATS.get(stat, stat)} de {who}"
        s = s[:m.start()].strip().rstrip("-–").strip()

    # 4) núcleo del mercado
    s = _translate_core(s)

    # 5) montar la frase (sin separadores colgando si algo queda vacío)
    piezas = []
    if s:
        piezas.append(s)
    if prop:
        piezas.append(prop)
    if extra:
        piezas.append(extra)
    if team:
        piezas.append(f"del equipo {team}")
    if yesno:
        piezas.append("Sí" if yesno == "yes" else "No")
    s = " · ".join(piezas)

    if lay:
        # Un LAY es apostar a que algo NO pasa. Si es un mercado de
        # ganador, se dice tal cual: "Pierde Rubio Nu".
        if re.fullmatch(r"Gana el equipo [12]", s):
            s = s.replace("Gana el equipo", "Pierde el equipo", 1)
        elif s == "Empate":
            s = "No hay empate"
        else:
            s = f"En contra · {s}"

    # 6) "equipo 1" / "equipo 2" → los nombres de verdad
    s = _with_team_names(s, team1, team2)
    return s


def _with_team_names(text: str, team1: str, team2: str) -> str:
    """'Gana el equipo 1' → 'Gana Cerro Porteno'."""
    if not text:
        return text
    if team1:
        text = (text.replace("del equipo 1", f"de {team1}")
                    .replace("el equipo 1", team1)
                    .replace("equipo 1", team1))
    if team2:
        text = (text.replace("del equipo 2", f"de {team2}")
                    .replace("el equipo 2", team2)
                    .replace("equipo 2", team2))
    return text


def translate_period(period: str, lang: str = "es") -> str:
    """'Full time with overtimes' → 'Final con prórrogas'."""
    p = (period or "").strip()
    if not p:
        return ""
    if lang != "es":
        return p
    return _PERIODS.get(p.lower(), p)


# ══════════════════════════════════════════════════════════
#  NÚCLEO: el mercado en sí
# ══════════════════════════════════════════════════════════

def _translate_core(s: str) -> str:
    s = (s or "").strip()
    if not s:
        return s

    # ── Hándicaps: AH1(-0.5), EH2(1.0), AH1(0.0)/DNB ──────
    m = _RE_HANDICAP.match(s)
    if m:
        kind = _HCAP_NAME.get(m.group("kind").upper(), "Hándicap")
        team = m.group("team").upper()
        val = m.group("val")
        rest = s[m.end():]
        dnb = bool(_RE_DNB.match(rest))
        txt = f"{kind} equipo {team} ({_fmt_handicap(val)})"
        if dnb:
            txt += " (sin empate)"
        return txt

    # ── Totales: TO(1.5) / TU(0.5) ─────────────────────────
    m = _RE_TOTAL.match(s)
    if m:
        kind = _TOTAL_NAME.get(m.group("kind").lower())
        if kind:
            return f"{kind} {_fmt_num(m.group('val'))}"

    # ── Exact (2) - Sets ───────────────────────────────────
    m = _RE_EXACT.match(s)
    if m:
        return f"Exactamente {_fmt_num(m.group('val'))}"

    # ── Team1 Win / Team2 Win ──────────────────────────────
    m = _RE_TEAM_WIN.match(s)
    if m:
        return f"Gana el equipo {m.group('team')}"

    # ── 1 / X / 2 / 1X / X2 / 12 ───────────────────────────
    key = s.upper()
    if key in _EXACT_RESULTS:
        return _EXACT_RESULTS[key]

    # ── Both to score / One scoreless ──────────────────────
    if re.fullmatch(r"both\s*to\s*score", s, re.IGNORECASE):
        return "Ambos marcan"
    if re.fullmatch(r"one\s*scoreless", s, re.IGNORECASE):
        return "Algún equipo no marca"
    if re.fullmatch(r"(no\s*)?both\s*to\s*score\s*-\s*(yes|no)", s, re.IGNORECASE):
        yn = "Sí" if s.strip().lower().endswith("yes") else "No"
        return f"Ambos marcan · {yn}"

    # ── Odd / Even ─────────────────────────────────────────
    if re.fullmatch(r"odd", s, re.IGNORECASE):
        return "Total impar"
    if re.fullmatch(r"even", s, re.IGNORECASE):
        return "Total par"

    # ── Win1 and TO(2.5) [ - Yes/No ] ──────────────────────
    m = _RE_WIN_AND.match(s)
    if m:
        team = m.group("team").upper()
        rest = _translate_core(m.group("rest").strip())
        return f"Gana el equipo {team} y {rest[0].lower() + rest[1:]}" \
            if rest else f"Gana el equipo {team}"

    # ── Both To Score and W1 - yes/no ──────────────────────
    m = re.match(r"^both\s*to\s*score\s*and\s*w(?P<team>[12])\s*[-–]?\s*"
                 r"(?P<yn>yes|no)?\s*$", s, re.IGNORECASE)
    if m:
        team = m.group("team")
        txt = f"Ambos marcan y gana el equipo {team}"
        if m.group("yn"):
            txt += " · Sí" if m.group("yn").lower() == "yes" else " · No"
        return txt

    # ── 1st - yes (Caballo)  [carreras de caballos] ────────
    m = _RE_PLACE.match(s)
    if m:
        pos = _POS_NAME.get(m.group("pos").lower(), m.group("pos"))
        who = m.group("who").strip()
        return (f"Queda {pos} ({who})" if m.group("yn").lower() == "yes"
                else f"No queda {pos} ({who})")

    # ── Player to Score (X) / Player to Score - No (X) ─────
    m = _RE_PLAYER_SCORE.match(s)
    if m:
        who = m.group("who").strip()
        return (f"No marca gol ({who})" if m.group("neg")
                else f"Marca gol ({who})")

    # ── Totales con nombre: "Over 2.5" / "Under 2.5" ───────
    m = re.match(r"^(over|under)\s+([0-9.]+)$", s, re.IGNORECASE)
    if m:
        return (f"{'Más' if m.group(1).lower() == 'over' else 'Menos'} de "
                f"{_fmt_num(m.group(2))}")

    return s


def _fmt_handicap(raw: str) -> str:
    """
    El signo es la clave del hándicap: AH1(-0.5) y AH1(+0.5) son apuestas
    DISTINTAS, así que el '+' hay que conservarlo siempre (menos en el 0).
    """
    try:
        v = float(raw)
    except (TypeError, ValueError):
        return raw
    if abs(v) < 1e-9:
        return "0"
    if abs(v - round(v)) < 1e-9:
        return f"{v:+.0f}"
    return f"{v:+.2f}".rstrip("0")


def _fmt_num(raw: str) -> str:
    """'1.50' → '1.5' · '-0.5' → '-0.5'"""
    try:
        v = float(raw)
    except (TypeError, ValueError):
        return raw
    return f"{v:.0f}" if abs(v - round(v)) < 1e-9 else f"{v:g}"
