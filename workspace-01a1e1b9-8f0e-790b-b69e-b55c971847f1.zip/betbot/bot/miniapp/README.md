# Mini App de filtros

Interfaz web que sustituye los botones inline del panel por una pantalla dentro de
Telegram. Mismo resultado, menos pulsaciones.

```
Telegram ──▶ WebView (esta app) ──▶ POST /api/filters ──▶ SQLite (compartida con el bot)
                    │
                    └── initData firmado ──▶ validación HMAC-SHA256 en el servidor
```

---

## ⚠️ El requisito que no se puede esquivar

**Telegram exige que la Mini App se sirva por HTTPS y desde una URL pública.**
No vale `http://localhost`, no vale `http://192.168.1.135`, no vale HTTP a secas.

Eso NO significa abrir puertos en tu router. Un túnel hace una **conexión saliente**
desde tu servidor hacia el proveedor, y él te da la URL HTTPS.

| Opción | Coste | URL estable | Dominio | Notas |
|---|---|---|---|---|
| **Cloudflare Tunnel** (recomendado) | Gratis | ✅ Sí | Sí (~10 €/año) | Sin abrir puertos. Certificado automático |
| Cloudflare *quick* tunnel | Gratis | ❌ Cambia al reiniciar | No | Solo para probar 5 minutos |
| **Tailscale Funnel** | Gratis | ✅ Sí | No (`*.ts.net`) | La única opción estable sin comprar dominio |
| ngrok | Desde $8/mes | Solo en planes de pago | Opcional | Muy fácil, pero cobran por la URL fija |

**Recomendación:** compra un dominio de 10 €/año y usa Cloudflare Tunnel. Es lo más
estable y te sirve también para cualquier otra cosa que quieras publicar después.

---

## Opción A — Cloudflare Tunnel (recomendada)

1. Compra un dominio barato y dáselo a Cloudflare (plan gratuito).
2. Entra en **Zero Trust → Networks → Tunnels → Create a tunnel**.
3. Elige **Cloudflared**, ponle un nombre y copia el **token**.
4. Pega el token en `.env`:
   ```bash
   TUNNEL_TOKEN=eyJhIjoiXXXXXXXX...
   ```
5. En la pestaña **Public Hostname** del túnel:
   - Subdomain: `filtros`
   - Domain: tu dominio
   - Service: **HTTP** → `http://miniapp:8080`
6. En el `.env` del bot:
   ```bash
   MINIAPP_ENABLED=true
   MINIAPP_URL=https://filtros.tudominio.com
   ```
7. Levanta todo:
   ```bash
   cd ~/bot_v2
   sudo docker compose up -d --build
   sudo docker compose logs -f miniapp cloudflared
   ```

## Opción B — Tailscale Funnel (sin dominio)

```bash
# En el servidor
curl -fsSL https://tailscale.com/install.sh | sh
sudo tailscale up
sudo tailscale funnel --bg 8080      # publica el puerto 8080

# Te da algo como:  https://surebet.tailnet-x.ts.net
```
Esa URL es **estable** y gratuita. Pónsela al bot:
```bash
MINIAPP_ENABLED=true
MINIAPP_URL=https://surebet.tailnet-x.ts.net
```
En este caso **no** arranques el servicio `cloudflared` del compose:
```bash
sudo docker compose up -d --build bot miniapp
```

## Probar en local

```bash
cd ~/bot_v2
BOT_TOKEN=... DB_PATH=./data/bot_v2.db MINIAPP_PORT=8080 python -m miniapp.app
```
Y en otra terminal:
```bash
cloudflared tunnel --url http://localhost:8080
```
Ese comando imprime una URL `https://xxx.trycloudflare.com`. Úsala solo para probar:
**cambia cada vez que reinicias**, así que no sirve para producción, pero sí para
ver la app funcionando dentro de Telegram antes de montar el túnel definitivo.

---

## Seguridad

- Todo endpoint de datos exige la cabecera `X-Telegram-Init-Data` con el
  `initData` firmado por Telegram.
- Se valida con **HMAC-SHA256** contra el token del bot:
  ```
  secret_key = HMAC_SHA256(key="WebAppData", msg=BOT_TOKEN)
  hash       = HMAC_SHA256(key=secret_key, msg="k=v\n..." ordenado)
  ```
- Se rechaza cualquier `initData` con más de `MINIAPP_INITDATA_MAX_AGE` segundos
  (por defecto 3600) → protege contra replay.
- **Nunca** se usa `initDataUnsafe` para autorizar: es manipulable desde el navegador.
- Toda la entrada se sanea en `_clean_payload()`:
  claves de casa y deporte filtradas contra el catálogo, números acotados a rangos,
  booleanos normalizados.

Comprobado:
```
sin initData     → 401
initData falso   → 401
initData caducado→ 401
initData válido  → 200
otro usuario     → solo ve sus propios filtros
```

---

## Endpoints

| Método | Ruta | Qué hace |
|---|---|---|
| GET | `/` | Sirve la SPA |
| GET | `/healthz` | Healthcheck |
| GET | `/api/state` | Filtros + catálogos + suscripción + stats |
| POST | `/api/filters` | Guarda los filtros |
| POST | `/api/mute` | Silenciar N horas (`hours=0` lo quita) |

---

## Notas de implantación

- La Mini App y el bot comparten **la misma BD SQLite** a través del volumen
  `./data`. Por eso se activa **WAL** y `busy_timeout` en `data/repository.py`:
  dos procesos escribiendo sin WAL acaban en `database is locked`.
- Con `MINIAPP_ENABLED=false` el bot **sigue funcionando igual** con los botones
  inline de siempre. La Mini App es aditiva: si falla el túnel, no se cae el bot.
- El botón de la Mini App aparece:
  - como **botón permanente** junto al campo de texto (menú),
  - y como primera fila del panel (`/start`).
- La app detecta si se abre fuera de Telegram y entra en **modo demostración**,
  para que puedas verla en el navegador sin montar nada.
