"""
AdminService: quién es administrador.

Combina dos fuentes:
  · Los IDs "dueños" del .env (ADMIN_ID / ADMIN_IDS) — siempre lo son,
    no se pueden quitar desde la app.
  · Los administradores guardados en la BD, que se añaden y quitan desde
    la pestaña 👑 de la Mini App.

Además, los administradores **no necesitan suscripción**: reciben las
apuestas igual.
"""
from __future__ import annotations

import logging
from typing import List

from config import CONFIG
from data.repository import AdminRepository

log = logging.getLogger(__name__)


class AdminService:
    """Única forma de preguntar «¿este usuario es admin?»."""

    def __init__(self, repo: AdminRepository):
        self.repo = repo

    # ── consulta ─────────────────────────────────────────
    def is_admin(self, user_id: int) -> bool:
        """True si es dueño (del .env) o admin de la BD."""
        if not user_id:
            return False
        if CONFIG.is_admin(user_id):      # dueños, sin consultar la BD
            return True
        return self.repo.is_admin(user_id)

    def owners(self) -> List[int]:
        """IDs fijados en el .env (no gestionables desde la app)."""
        out = set()
        if CONFIG.admin_id:
            out.add(int(CONFIG.admin_id))
        for a in CONFIG.admin_ids or ():
            try:
                out.add(int(a))
            except (TypeError, ValueError):
                pass
        return sorted(out)

    def extra(self) -> List[int]:
        """IDs añadidos desde la Mini App."""
        return self.repo.all()

    # ── gestión ──────────────────────────────────────────
    def add(self, user_id: int, note: str = "", added_by: int = 0) -> bool:
        if int(user_id) in self.owners():
            return True                    # ya es dueño: nada que hacer
        ok = self.repo.add(int(user_id), note or "", added_by)
        if ok:
            log.info("👑 Nuevo admin: %s (por %s)", user_id, added_by)

    def remove(self, user_id: int) -> bool:
        if int(user_id) in self.owners():
            log.warning("Intento de quitar al dueño %s — ignorado", user_id)
            return False
        return self.repo.remove(int(user_id))

    def list_all(self) -> List[dict]:
        """Para la Mini App: dueños + admins, marcados."""
        owners = self.owners()
        out = [
            {"id": uid, "owner": True, "note": "dueño (del .env)"}
            for uid in owners
        ]
        for row in self.repo.all_detailed():
            if row["telegram_id"] in owners:
                continue
            out.append({
                "id": row["telegram_id"],
                "owner": False,
                "note": row.get("note") or "",
                "added_by": row.get("added_by"),
                "created_at": row.get("created_at"),
            })
        return out
