"""
codere.py — colector de cuotas de Codere (codere.es) sin navegador (con fallback a navegador si bloquean).

Codere sirve su sportsbook (web y app) desde una API JSON interna "NavigationService":

    GET /NavigationService/Home/GetSports                         -> deportes (NodeId, Name, SportHandle)
    GET /NavigationService/Sports/GetCountries?parentId=<sport>   -> países
    GET /NavigationService/Sports/GetLeagues...?parentId=<país>   -> ligas
    GET /NavigationService/Event/GetEvents?parentId=<liga>        -> partidos de la liga con sus mercados principales
    GET /NavigationService/Event/GetMarkets?parentId=<evento>     -> TODOS los mercados (Games con Results) del partido
    GET /NavigationService/Live/...                               -> en directo

Los nombres exactos de algunos endpoints cambian entre versiones, así que en codere.json cada endpoint
tiene una lista de candidatos: se usa el primero que responde con datos y se recuerda. `--probe` enseña
cuál funciona y qué campos devuelve; si alguno no responde, se añade el nombre correcto al json.

Normalización: markets.py (mercados) + competitions.json (competiciones, etiqueta "País - Liga").
Escribe en odds.db con bookmaker `codere`.

Uso:  python codere.py            (bucle)   --once   --list (competiciones)   --probe (endpoints)
      python codere.py --dump <nodeId>      (mercados crudos + normalizados de un evento)
"""
from __future__ import annotations

import fastjson as json
import logging
import os
import re
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from competitions import Competitions
from markets import _team_in, classify, parse_ou_label
from storage import OddsStore
from transport import Http

log = logging.getLogger("codere")
CFG_PATH = Path(os.getenv("CODERE_CFG", Path(__file__).parent / "codere.json"))

_FOLD = {"á": "a", "é": "e", "í": "i", "ó": "o", "ú": "u", "ñ": "n", "ü": "u", "à": "a", "è": "e", "ò": "o"}
_DATE_RE = re.compile(r"/Date\((-?\d+)")


def load_cfg() -> dict:
    import pace
    return pace.apply(json.loads(CFG_PATH.read_text(encoding="utf-8")))


def _fold(s: str) -> str:
    return "".join(_FOLD.get(c, c) for c in (s or "").lower()).strip()


def _num(v) -> float | None:
    if v is None or v == "":
        return None
    try:
        return float(str(v).replace(",", "."))
    except ValueError:
        return None


def _date(raw) -> datetime | None:
    """'/Date(1761330600000)/' o ISO -> datetime local."""
    if not raw:
        return None
    if isinstance(raw, (int, float)):
        return datetime.fromtimestamp(raw / 1000, tz=timezone.utc).astimezone()
    m = _DATE_RE.search(str(raw))
    if m:
        return datetime.fromtimestamp(int(m.group(1)) / 1000, tz=timezone.utc).astimezone()
    try:
        return datetime.fromisoformat(str(raw).replace("Z", "+00:00")).astimezone()
    except ValueError:
        return None


def _get(d: dict, *keys, default=None):
    """Primer campo presente (Codere mezcla PascalCase y camelCase según el endpoint)."""
    for k in keys:
        if k in d and d[k] not in (None, ""):
            return d[k]
        lk = k[:1].lower() + k[1:]
        if lk in d and d[lk] not in (None, ""):
            return d[lk]
    return default


# ──────────────────────────────────────────────────────────────────────────────
class Api:
    """GET JSON con descubrimiento de endpoint: para cada clave de cfg['endpoints'] prueba los candidatos
    en orden y se queda con el primero que devuelve datos."""

    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.base = cfg["api_base"].rstrip("/")
        self.http = Http(cfg["origin"], cfg.get("transport", "auto"), cfg.get("headers"), cfg.get("start_url"),
                         cfg.get("workers", 6), api_hint="/NavigationService/")
        self.resolved: dict[str, str] = {}             # clave -> plantilla que funciona

    def _url(self, tpl: str, **fmt) -> str:
        return f"{self.base}/{tpl.format(**fmt)}"

    def call(self, key: str, **fmt):
        """Devuelve el JSON (lista/dict) del endpoint `key`, o None si ningún candidato responde."""
        cands = self.cfg["endpoints"].get(key) or []
        if key in self.resolved:
            cands = [self.resolved[key]] + [c for c in cands if c != self.resolved[key]]
        first_ok = None
        for tpl in cands:
            try:
                st, js = self.http.get(self._url(tpl, **fmt))
            except KeyError:                           # plantilla con parámetro que no aplica ({handle} vs {id})
                continue
            if st == 200 and js is not None:
                if js:                                 # con datos: nos lo quedamos
                    if self.resolved.get(key) != tpl:
                        log.info("endpoint %s -> %s", key, tpl.split("?")[0])
                        self.resolved[key] = tpl
                    return js
                if first_ok is None:
                    first_ok = (tpl, js)
            if key in self.resolved and tpl == self.resolved[key] and st in (404, 0):
                self.resolved.pop(key, None)
        if first_ok:
            self.resolved.setdefault(key, first_ok[0])
            return first_ok[1]
        return None

    def call_many(self, key: str, fmts: list[dict]) -> list:
        """Misma llamada para muchos ids (en paralelo con el transporte). Resuelve primero el endpoint con 1."""
        if not fmts:
            return []
        if key not in self.resolved:
            first = self.call(key, **fmts[0])
            rest = self.call_many(key, fmts[1:]) if key in self.resolved else [None] * (len(fmts) - 1)
            return [first] + rest
        tpl = self.resolved[key]
        urls = [self._url(tpl, **f) for f in fmts]
        out = []
        for st, js in self.http.get_many(urls):
            out.append(js if st == 200 else None)
        return out


# ──────────────────────────────────────────────────────────────────────────────
# Mercados
def _games_in(obj) -> list[dict]:
    """Encuentra recursivamente los mercados (dicts con lista `Results`) en la respuesta de Codere."""
    found: list[dict] = []
    if isinstance(obj, dict):
        res = _get(obj, "Results")
        if isinstance(res, list) and res and isinstance(res[0], dict):
            found.append(obj)
        else:
            for v in obj.values():
                if isinstance(v, (dict, list)):
                    found += _games_in(v)
    elif isinstance(obj, list):
        for v in obj:
            found += _games_in(v)
    return found


def _side(name: str, home: str, away: str) -> str | None:
    f = _fold(re.sub(r"\s*\(?[+-]\d+(?:[.,]\d+)?\)?\s*$", "", name))
    if f in ("x", "empate", "draw"):
        return "X"
    if f in ("1", "2"):
        return f
    h, a = _fold(home), _fold(away)
    if f and (f == h or f in h or h in f):
        return "1"
    if f and (f == a or f in a or a in f):
        return "2"
    return None


def _spov(g: dict) -> float | None:
    """'<Spov>2.5' -> 2.5 ; '<Spov>0:2' (hándicap 3 vías) -> None."""
    raw = str(_get(g, "Spov", "SpecialOddsValue", default="") or "").replace("<Spov>", "").strip()
    return _num(raw) if re.fullmatch(r"[+-]?\d+(?:[.,]\d+)?", raw) else None


_SKIP_GAME = re.compile(r"mejorada|maxicuota|superaumento|ventaja de|remontando|descanso o final|1ª y 2ª|resultado final|"
                        r"m[uú]ltiples|primer (equipo|goleador)|goleador|marca gol|anotar[áa]|asistir[áa]|penalti|acca|"
                        r"ganador y m[áa]s|margen|minuto|tiempo de|exacto", re.I)


def _hcp(name: str) -> float | None:
    m = re.search(r"\(([+-]?\d+(?:[.,]\d+)?)\)\s*$", name or "") or re.search(r"\s([+-]\d+(?:[.,]\d+)?)\s*$", name or "")
    return _num(m.group(1)) if m else None


_PERIOD_WORD = re.compile(r"parte|mitad|cuarto|\bset\b|tiempo|descanso|pr[oó]rroga|periodo|half|quarter", re.I)
_PLAYER_METRIC = re.compile(r"(puntos|rebotes|asistencias|triples|tapones|robos|tiros|goles|remates|paradas|faltas|tarjetas|juegos|aces)", re.I)


def game_selections(g: dict, sport: str, home: str, away: str) -> list[dict]:
    """Un mercado de Codere (Game con Results) -> selecciones normalizadas."""
    name = str(_get(g, "Name", "GameName", default="") or "")
    results = [r for r in (_get(g, "Results") or []) if isinstance(r, dict)]
    rows = []
    for r in results:
        if _get(r, "IsBlocked", "Locked", "isLocked", "IsNonRunner", default=False):
            continue
        odd = _num(_get(r, "Odd", "Price", "Quote"))
        rn = str(_get(r, "Name", default="") or "")
        if odd and odd > 1.0:
            rows.append((rn, odd, r))
    if not rows or len(rows) > 60:
        return []
    if _SKIP_GAME.search(name) or _get(g, "Locked", default=False):
        return []
    spov = _spov(g)
    names_f = [_fold(n) for n, _, _ in rows]
    out: list[dict] = []
    nf = _fold(name)

    # ── más/menos ──
    if all(re.match(r"(mas|menos|over|under|\+|-)", n) for n in names_f) and len(rows) >= 2:
        player = None
        title = name
        if " - " in name:                              # "Jugador - Puntos" / "Puntos - Jugador" (props)
            a, b = (p.strip() for p in name.split(" - ", 1))
            # "Álvaro García (Rayo Vallecano)" -> el paréntesis es el equipo del jugador, no un mercado de equipo
            a, b = (re.sub(r"\s*\((?:[^()]*)\)\s*$", "", x).strip() for x in (a, b))

            def _is_player(x: str) -> bool:
                return bool(x) and not _PLAYER_METRIC.search(x) and not _PERIOD_WORD.search(x) and not _side(x, home, away) \
                    and not re.search(r"\d|m[aá]s|menos|total", _fold(x))

            if _PLAYER_METRIC.search(a) and _is_player(b):
                player, title = b, a
            elif _PLAYER_METRIC.search(b) and _is_player(a):
                player, title = a, b
        # Retabet live "Puntos"/"Triples"/"Rebotes"…: cada opción es "Más 10,5 Peyton Watson" (jugador dentro de la
        # opción). Si el resto de la etiqueta es un nombre propio (no equipo), el mercado es un prop de ESE jugador.
        def _row_player(rn: str) -> str | None:
            rest = re.sub(r"^\s*(m[aá]s|menos|over|under)\s*(de\s*)?[+-]?\d+(?:[.,]\d+)?\s*", "", rn, flags=re.I).strip(" -:()")
            if not rest or re.search(r"\d", rest) or _side(rest, home, away) or _PLAYER_METRIC.search(rest) \
                    or _PERIOD_WORD.search(rest) or re.search(r"total|m[aá]s|menos|punto|equipo", _fold(rest)):
                return None
            return rest if 2 <= len(rest.split()) <= 4 else None

        if player is None and sport != "tenis" and _PLAYER_METRIC.search(name):
            rps = [_row_player(rn) for rn, _, _ in rows]
            if any(rps):
                if not all(rps):
                    return []                              # mezcla de opciones con y sin jugador: no fiable
                for (rn, odd, r), rp in zip(rows, rps):
                    inf = classify(name, sport, home, away, kind="total", player=rp)
                    if not inf or not inf.player:
                        continue
                    sel, ln = parse_ou_label(rn)
                    if sel is None:
                        sel = "Over" if re.match(r"(mas|over|\+)", _fold(rn)) else "Under"
                    if ln is not None:
                        out.append({"market": inf.market, "selection": sel, "line": ln, "player": inf.player, "price": odd})
                return out
        info = classify(title, sport, home, away, kind="total", player=player)
        if not info:
            return []
        # Totales POR EQUIPO dentro de un mismo mercado ("Córners": "Más 5,5 Milan" / "Menos 5,5 Inter"): el equipo
        # va en la opción, no en el título. Se clasifica cada opción con su equipo; si quedan dos opciones iguales
        # (dos "Más 5,5") sin equipo reconocido, el mercado es ambiguo y se descarta entero.
        seen = set()
        for rn, odd, r in rows:
            sel, ln = parse_ou_label(rn)
            if sel is None:
                sel = "Over" if re.match(r"(mas|over|\+)", _fold(rn)) else "Under"
            if ln is None:
                ln = spov if spov is not None else _num(_get(r, "SpecialOddsValue", "Spov"))
            if ln is None:
                continue
            mk = info.market
            if not info.team and not info.player:
                rest = re.sub(r"^\s*(m[aá]s|menos|over|under)\s*(de\s*)?[+-]?\d+(?:[.,]\d+)?\s*", "", rn, flags=re.I).strip(" -:()")
                tm = _team_in(_fold(rest), home, away) if rest else None
                if tm in ("HOME", "AWAY"):
                    ti = classify(f"{title} {home if tm == 'HOME' else away}", sport, home, away, kind="total")
                    if not ti or not ti.team:
                        continue
                    mk = ti.market
            key = (mk, sel, ln, info.player)
            if key in seen:
                return []
            seen.add(key)
            out.append({"market": mk, "selection": sel, "line": ln, "player": info.player, "price": odd})
        return out

    # ── sí/no (ambos marcan) ──
    if set(names_f) <= {"si", "sí", "yes", "no"} and len(rows) == 2:
        if not re.search(r"ambos|both", nf):
            return []
        info = classify(name, sport, home, away, kind="btts")
        if not info:
            return []
        for rn, odd, _ in rows:
            out.append({"market": info.market, "selection": "No" if _fold(rn) == "no" else "Yes", "line": None, "price": odd})
        return out

    # ── doble oportunidad ──
    if len(rows) == 3 and all(re.fullmatch(r"(1x|x2|12|1 ?o ?x|x ?o ?2|1 ?o ?2|.+ o empate|empate o .+|.+ o .+)", n) for n in names_f):
        info = classify(name, sport, home, away, kind="dc")
        if not info:
            return []
        for rn, odd, _ in rows:
            f = _fold(rn).replace(" ", "")
            if f in ("1x", "x2", "12"):
                key = f.upper()
            else:
                parts = [p.strip() for p in re.split(r"\s+o\s+", _fold(rn))]
                sides = frozenset(_side(p, home, away) or "?" for p in parts)
                key = {frozenset({"1", "X"}): "1X", frozenset({"X", "2"}): "X2", frozenset({"1", "2"}): "12"}.get(sides)
            if key:
                out.append({"market": info.market, "selection": key, "line": None, "price": odd})
        return out

    # ── ganador / hándicap (resultados con nombre de equipo, 1/X/2) ──
    sides = [_side(rn, home, away) for rn, _, _ in rows]
    if len(rows) in (2, 3) and all(sides):
        lines = [_hcp(rn) for rn, _, _ in rows]
        is_hcp = re.search(r"handicap|hándicap|spread|ventaja", nf) or any(l is not None for l in lines) or spov is not None
        if is_hcp and len(rows) == 2:
            info = classify(name if re.search(r"handicap|hándicap", nf) else f"Hándicap {name}", sport, home, away, kind="handicap")
            if not info:
                return []
            for (rn, odd, _), s, ln in zip(rows, sides, lines):
                if ln is None and spov is not None:
                    ln = spov if s == "1" else -spov
                if s in ("1", "2") and ln is not None:
                    out.append({"market": info.market, "selection": s, "line": ln, "price": odd})
            return out
        if is_hcp:
            return []                                  # hándicap 3 vías: no comparable
        if sport == "baloncesto" and "X" in sides:
            return []
        info = classify(name, sport, home, away, kind="result")
        if not info or not info.market.startswith(("1X2", "DNB")):
            return []
        # fútbol: un 1X2 sin empate (2 filas) o un "sin empate" con empate (3 filas) es otro mercado -> no comparable
        if sport == "futbol" and (info.market.startswith("1X2") != ("X" in sides)):
            return []
        for (rn, odd, _), s in zip(rows, sides):
            out.append({"market": info.market, "selection": s, "line": None, "price": odd})
        return out
    return []


def event_selections(games: list[dict], sport: str, home: str, away: str) -> list[dict]:
    out: list[dict] = []
    seen: set[tuple] = set()
    for g in games:
        for s in game_selections(g, sport, home, away):
            k = (s["market"], s.get("player"), s.get("line"), s["selection"])
            if k not in seen:
                seen.add(k)
                out.append(s)
    return out


# ──────────────────────────────────────────────────────────────────────────────
def _teams(ev: dict) -> tuple[str, str]:
    home = str(_get(ev, "ParticipantHome", "HomeTeam", "Home", default="") or "")
    away = str(_get(ev, "ParticipantAway", "AwayTeam", "Away", default="") or "")
    if home and away:
        return home.strip(), away.strip()
    name = str(_get(ev, "Name", default="") or "")
    for sep in (" - ", " vs ", " v "):
        if sep in name:
            a, b = name.split(sep, 1)
            return a.strip(), b.strip()
    return home, away


def _label(ev: dict, league: dict | None = None) -> str:
    country = str(_get(ev, "CountryName", "Country", default="") or (league or {}).get("_country") or "")
    lg = str(_get(ev, "LeagueName", "League", "ParentName", default="") or (league or {}).get("Name") or "")
    return f"{country} - {lg}".strip(" -")


def _is_live(ev: dict) -> bool:
    return bool(_get(ev, "isLive", "IsLive", "Live", default=False))


def _score(ev: dict) -> dict:
    """Marcador/periodo/tiempo del evento en directo (liveData de Codere)."""
    ld = _get(ev, "liveData", "LiveData", default={}) or {}
    out = {}
    h, a = _get(ld, "ResultHome"), _get(ld, "ResultAway")
    sets = _get(ld, "Sets")
    if isinstance(sets, list) and sets and all(isinstance(x, (list, tuple)) and len(x) == 2 for x in sets):
        # tenis: Sets = [[5, 7], [3, 5]] (juegos por set); ResultHome/Away son los puntos del juego en curso.
        # Mismo formato que Kambi/bwin/Bet777/TonyBet ("5:7 3:5") para que el filtro de marcador pueda comparar.
        out["score"] = " ".join(f"{x[0]}:{x[1]}" for x in sets)
    elif h is not None and a is not None:
        out["score"] = f"{h}:{a}"
    per = _get(ld, "PeriodName")
    if per:
        out["period"] = str(per)
    mt = _get(ld, "MatchTime")
    rem = _get(ld, "RemainingPeriodTime")
    if isinstance(mt, (int, float)) and mt >= 0:
        out["timer"] = f"{int(mt)}'"
    elif rem:
        out["timer"] = str(rem)
    if not out and _get(ev, "ResultInfo"):
        out["score"] = str(_get(ev, "ResultInfo")).split()[0].replace("-", ":")
    return out


def _event_url(ev: dict, nid: str, cfg: dict) -> str:
    """La web de Codere es una app con rutas por hash (…/deportesEs/#/Pagina?param=…); las rutas "bonitas"
    /deportesEs/soccer/Liga/nonLive/Partido dan 404. En vivo la página de detalle no lleva el evento en la URL
    (…#/NowLiveDetailPage a secas), así que enlazamos la lista de directos; en pre-partido, la página de mercados
    con el NodeId del evento."""
    if _is_live(ev):
        return cfg.get("live_url", "https://m.apuestas.codere.es/deportesEs/#/NowLivePage")
    return cfg["event_url"].format(nodeId=nid)


def event_row(ev: dict, games: list[dict], sport: str, competition: str, cfg: dict) -> dict | None:
    home, away = _teams(ev)
    if not home or not away:
        return None
    sels = event_selections(games, sport, home, away)
    if not sels:
        return None
    nid = str(_get(ev, "NodeId", "EventId", "Id", default=""))
    dt = _date(_get(ev, "StartDate", "StartTime", "Date"))
    row = {"event_id": nid, "home": home, "away": away, "competition": competition,
           "date": dt.strftime("%Y-%m-%d") if dt else None, "start_time": dt.strftime("%H:%M") if dt else None,
           "url": _event_url(ev, nid, cfg), "selections": sels}
    if _is_live(ev):
        row.update(_score(ev))
    return row


# ──────────────────────────────────────────────────────────────────────────────
class Collector:
    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.api = Api(cfg)
        self.catalog = Competitions()
        self.store = OddsStore(bookmaker=cfg["bookmaker"])
        self._cfg_mtime = CFG_PATH.stat().st_mtime
        self.leagues: dict[str, tuple[str, str, str]] = {}      # leagueNodeId -> (deporte, competición, etiqueta)
        self.handles: dict[str, str] = {}                        # sportHandle -> deporte canónico
        self.sport_nodes: dict[str, str] = {}                    # deporte -> NodeId del deporte
        self._tree_ok: bool | None = None                        # ¿responde el árbol país->liga?
        self._last_catalog = 0.0
        self._last_prematch = 0.0
        self._last_live_list = 0.0
        self._last_prune = 0.0
        self.live: dict[str, tuple[dict, str, str]] = {}         # nodeId -> (evento, deporte, competición)
        self._cats: dict[str, list[str]] = {}                    # nodeId -> categorías relevantes (ids)
        self._cat_cursor: dict[str, int] = {}
        self._live_games: dict[str, dict[str, list[dict]]] = {} # nodeId -> {categoría: juegos} (caché live)
        self._pm_cursor = 0

    def _reload_if_changed(self):
        self.catalog.reload()
        mt = CFG_PATH.stat().st_mtime
        if mt != self._cfg_mtime:
            self.cfg = load_cfg()
            self.api.cfg = self.cfg
            self._cfg_mtime = mt
        if time.time() - self._last_prune > 3600:
            self.store.prune()
            self._last_prune = time.time()

    # catálogo ---------------------------------------------------------------
    def _sport_of(self, node: dict) -> str | None:
        handle = _fold(str(_get(node, "SportHandle", "Handle", default="") or ""))
        name = _fold(str(_get(node, "SportName", "Name", default="") or ""))
        return self.cfg["sports"].get(handle) or self.cfg["sports"].get(name)

    def _add_league(self, node_id: str, sport: str, label: str) -> bool:
        if re.search(r"anticipadas|ganador del torneo|outright|especiales", label, re.I):
            return False                                   # apuestas a largo plazo, no partidos
        comp = self.catalog.match(self.cfg["bookmaker"], sport, label)
        if comp and node_id:
            self.leagues[node_id] = (sport, comp, label)
            return True
        return False

    def refresh_catalog(self, force: bool = False):
        if not force and self.leagues and time.time() - self._last_catalog < self.cfg.get("interval_catalog", 3600):
            return
        sports = self.api.call("sports") or []
        for sp in sports if isinstance(sports, list) else []:
            sport = self._sport_of(sp)
            if sport:
                self.handles[_fold(str(_get(sp, "SportHandle", default="")))] = sport
                self.sport_nodes[sport] = str(_get(sp, "NodeId", "Id", default=""))
        before = len(self.leagues)
        # 1) árbol país -> liga (si la API lo expone)
        if self._tree_ok is not False:
            found_tree = False
            for sport, sid in self.sport_nodes.items():
                countries = self.api.call("countries", id=sid)
                if not isinstance(countries, list) or not countries:
                    continue
                found_tree = True
                # Home/GetCountries ya trae las ligas de cada país en `Leagues`; si no, se piden aparte
                need = [c for c in countries if not isinstance(_get(c, "Leagues"), list)]
                extra = dict(zip([id(c) for c in need],
                                 self.api.call_many("leagues", [{"id": str(_get(c, "NodeId", "Id", default=""))} for c in need]))) if need else {}
                for c in countries:
                    lgs = _get(c, "Leagues") if isinstance(_get(c, "Leagues"), list) else extra.get(id(c))
                    for lg in lgs if isinstance(lgs, list) else []:
                        self._add_league(str(_get(lg, "NodeId", "Id", default="")), sport,
                                         f"{_get(c, 'Name', default='')} - {_get(lg, 'Name', default='')}")
            self._tree_ok = found_tree
            if not found_tree:
                log.warning("Codere no expone el árbol país->liga con los endpoints conocidos: uso league_nodes + ligas vistas en directo")
        # 2) ligas fijadas a mano en codere.json
        for nid, sport in (self.cfg.get("league_nodes") or {}).items():
            if nid.startswith("_") or nid in self.leagues:
                continue
            evs = self.api.call("events", id=nid)
            ev = next((e for e in evs if isinstance(e, dict)), None) if isinstance(evs, list) else None
            if ev:
                if not self._add_league(nid, sport, _label(ev)):
                    log.warning("league_nodes %s (%s) no casa con competitions.json", nid, _label(ev))
            else:
                self.leagues[nid] = (sport, "", "")                 # sin partidos ahora; se resuelve cuando los haya
        self._last_catalog = time.time()
        if len(self.leagues) != before or force:
            log.info("catálogo: %d ligas seleccionadas: %s", len(self.leagues),
                     ", ".join(sorted({c for _, c, _ in self.leagues.values() if c})) or "ninguna")

    def _learn_league(self, ev: dict, sport: str) -> str | None:
        """Liga de un evento visto (lista live / GetEvents): se añade si es una competición principal."""
        lid = str(_get(ev, "ParentNodeId", "LeagueId", default="") or "")
        if lid in self.leagues and self.leagues[lid][1]:
            return self.leagues[lid][1]
        label = _label(ev)
        comp = self.catalog.match(self.cfg["bookmaker"], sport, label)
        if comp and lid:
            if lid not in self.leagues:
                log.info("liga descubierta: %s (%s)", label, lid)
            self.leagues[lid] = (sport, comp, label)
        return comp

    # mercados -----------------------------------------------------------------
    def _relevant_cats(self, cats: list) -> list[str]:
        skip = [s.upper() for s in self.cfg.get("skip_categories", [])]
        out = []
        for c in cats if isinstance(cats, list) else []:
            name = str(_get(c, "CategoryName", default="") or "").upper()
            cid = str(_get(c, "CategoryId", default="") or "")
            if cid and not any(s in name for s in skip):
                out.append(cid)
        return out

    def _prematch_games(self, ev_ids: list[str]) -> list[list[dict]]:
        """Todos los mercados de cada evento: categorías del evento x GetGamesNoLiveByCategoryInfo."""
        cats_list = self.api.call_many("categories", [{"id": i} for i in ev_ids])
        reqs, owner = [], []
        for eid, cats in zip(ev_ids, cats_list):
            for cid in self._relevant_cats(cats):
                reqs.append({"id": eid, "cat": cid})
                owner.append(eid)
        games: dict[str, list[dict]] = {eid: [] for eid in ev_ids}
        for eid, js in zip(owner, self.api.call_many("games", reqs)):
            games[eid] += _games_in(js) if js is not None else []
        return [games[eid] for eid in ev_ids]

    def _live_games_for(self, ev_ids: list[str]) -> list[list[dict]]:
        """Mercados live: PRINCIPALES en cada ciclo + rotación de N categorías más; el resto se sirve de caché."""
        per = self.cfg.get("live_categories_per_cycle", 3)
        reqs, owner = [], []
        for eid in ev_ids:
            cats = self._cats.get(eid)
            if cats is None:
                reqs.append({"id": eid, "cat": "99"}); owner.append((eid, "99"))
                continue
            pick = ["99"] if "99" in cats else cats[:1]
            others = [c for c in cats if c not in pick]
            if others:
                cur = self._cat_cursor.get(eid, 0)
                pick += [others[(cur + k) % len(others)] for k in range(min(per, len(others)))]
                self._cat_cursor[eid] = cur + per
            for c in dict.fromkeys(pick):
                reqs.append({"id": eid, "cat": c}); owner.append((eid, c))
        for (eid, cid), js in zip(owner, self.api.call_many("live_games", reqs)):
            if js is None:
                continue
            if isinstance(js, dict) and eid not in self._cats:
                self._cats[eid] = self._relevant_cats(_get(js, "CategoryInfos", default=[]) or [])
            ev = js.get("Event") if isinstance(js, dict) else None
            if isinstance(ev, dict) and eid in self.live:                    # marcador fresco
                self.live[eid] = (dict(self.live[eid][0], **{k: ev[k] for k in ("liveData", "ResultInfo", "isLive") if k in ev}),
                                  self.live[eid][1], self.live[eid][2])
            self._live_games.setdefault(eid, {})[cid] = _games_in(js)
        return [[g for gs in self._live_games.get(eid, {}).values() for g in gs] for eid in ev_ids]

    # ciclos -------------------------------------------------------------------
    def live_cycle(self) -> tuple[int, int]:
        # timeout corto en directo: una API colgada no debe dejar la casa ciega 60-100 s (ver Http.timeout_scope)
        with self.api.http.timeout_scope(self.cfg.get("timeout_live", 8)):
            return self._live_cycle()

    def _live_cycle(self) -> tuple[int, int]:
        now = time.time()
        if now - self._last_live_list >= self.cfg.get("interval_live_list", 20) or not self._last_live_list:
            js = self.api.call("live_events")
            evs = _get(js, "Events", default=[]) if isinstance(js, dict) else (js or [])
            live: dict[str, tuple[dict, str, str]] = {}
            for ev in evs if isinstance(evs, list) else []:
                sport = self._sport_of(ev)
                if not sport or not isinstance(ev, dict):
                    continue
                comp = self._learn_league(ev, sport)
                nid = str(_get(ev, "NodeId", "EventId", default=""))
                if comp and nid:
                    live[nid] = (ev, sport, comp)
            if js is not None:
                self.live = live
                for gone in set(self._live_games) - set(live):
                    self._live_games.pop(gone, None); self._cats.pop(gone, None); self._cat_cursor.pop(gone, None)
                self.store.sweep(set(live), "live")
            self._last_live_list = now
        ids = list(self.live)[: self.cfg.get("max_live_per_cycle", 12)]
        if not ids:
            return 0, 0
        games_list = self._live_games_for(ids)
        by_sport: dict[str, list[dict]] = {}
        for nid, games in zip(ids, games_list):
            ev, sport, comp = self.live[nid]
            if not games:
                games = _games_in(_get(ev, "Games", default=[]) or []) + _games_in([_get(ev, "DefaultGame", default={}) or {}])
            row = event_row(ev, games, sport, comp, self.cfg)
            if row:
                by_sport.setdefault(sport, []).append(row)
        rows = changed = 0
        for sport, rs in by_sport.items():
            changed += self.store.save_rows(sport, "live", rs)
            rows += len(rs)
        return rows, changed

    def prematch_cycle(self) -> tuple[int, int]:
        now = time.time()
        horizon = now + self.cfg.get("prematch_hours", 48) * 3600
        lids = [lid for lid in self.leagues]
        todo, present = [], set()
        for lid, evs in zip(lids, self.api.call_many("events", [{"id": l} for l in lids])):
            sport = self.leagues[lid][0]
            for ev in evs if isinstance(evs, list) else []:
                if not isinstance(ev, dict) or _is_live(ev):
                    continue
                comp = self.leagues[lid][1] or self._learn_league(ev, sport)
                if not comp:
                    continue
                nid = str(_get(ev, "NodeId", "EventId", default=""))
                dt = _date(_get(ev, "StartDate", "StarDate"))
                present.add(nid)
                if nid and dt and now - 300 <= dt.timestamp() <= horizon:
                    todo.append((dt.timestamp(), nid, ev, sport, comp))
        if present:
            self.store.sweep(present, "prematch")
        todo.sort(key=lambda t: t[0])
        cap = self.cfg.get("max_prematch_per_cycle", 25)
        if len(todo) > cap:
            start = self._pm_cursor % len(todo)
            todo = (todo + todo)[start:start + cap]
            self._pm_cursor += cap
        games_list = self._prematch_games([t[1] for t in todo])
        by_sport: dict[str, list[dict]] = {}
        for (_, nid, ev, sport, comp), games in zip(todo, games_list):
            if not games:
                games = _games_in(_get(ev, "Games", default=[]) or [])
            row = event_row(ev, games, sport, comp, self.cfg)
            if row:
                by_sport.setdefault(sport, []).append(row)
        rows = changed = 0
        for sport, rs in by_sport.items():
            changed += self.store.save_rows(sport, "prematch", rs)
            rows += len(rs)
        if not lids:
            log.warning("prematch: sin ligas (añade NodeIds en league_nodes de codere.json o pásame el HAR del menú Fútbol > España)")
        return rows, changed

    def run(self, once: bool = False):
        bk = self.cfg["bookmaker"]
        backoff = 2
        while True:
            t0 = time.time()
            try:
                self._reload_if_changed()
                self.refresh_catalog()
                rows, changed = self.live_cycle()
                msg = f"live {rows} ev / {changed} cambios"
                if t0 - self._last_prematch >= self.cfg.get("interval_prematch", 180):
                    prow, pchg = self.prematch_cycle()
                    self._last_prematch = time.time()
                    msg += f" | prematch {prow} ev / {pchg} cambios"
                self.store.set_status(**{f"{bk}_last_ok": time.time(), f"{bk}_live_events": rows})
                log.info("%s [%s] (%.1fs)", msg, self.api.http.name, time.time() - t0)
                backoff = 2
                if once:
                    return
            except Exception as e:
                log.warning("error de ciclo: %s — reintento en %ss", e, backoff, exc_info=log.isEnabledFor(logging.DEBUG))
                self.store.set_status(**{f"{bk}_last_error": f"{time.time():.0f} {e}"})
                time.sleep(backoff)
                backoff = min(backoff * 2, 60)
                continue
            time.sleep(max(0.5, self.cfg.get("interval_live", 5) - (time.time() - t0)))


# ──────────────────────────────────────────────────────────────────────────────
def _peek(js, n: int = 1) -> str:
    if isinstance(js, list):
        head = js[:n]
        keys = sorted(head[0].keys()) if head and isinstance(head[0], dict) else []
        return f"lista[{len(js)}] campos={keys[:25]}"
    if isinstance(js, dict):
        return f"dict campos={sorted(js.keys())[:25]}"
    return repr(js)[:200]


def probe(cfg: dict):
    """Prueba los endpoints: lo confirmado (eventos de liga, categorías, mercados, directo) y los candidatos del árbol país->liga."""
    api = Api(cfg)
    base = api.base
    print(f"transporte inicial: {api.http.name}")

    def try_all(key: str, **fmt):
        print(f"\n== {key}")
        best = None
        for tpl in cfg["endpoints"].get(key, []):
            try:
                url = f"{base}/{tpl.format(**fmt)}"
            except KeyError:
                continue
            st, js = api.http.get(url)
            print(f"   [{st}] {tpl.split('?')[0]:48} {_peek(js) if js is not None else ''}")
            if st == 200 and js and best is None:
                best = js
        return best

    sports = try_all("sports") or []
    mine = [sp for sp in sports if cfg["sports"].get(_fold(str(_get(sp, "SportHandle", default=""))))]
    for sp in mine:
        print(f"      · {_get(sp, 'Name')}  handle={_get(sp, 'SportHandle')}  NodeId={_get(sp, 'NodeId')}")
    # árbol país -> liga (pendiente de confirmar)
    tree = False
    for sp in mine:
        sid = str(_get(sp, "NodeId"))
        countries = try_all("countries", id=sid)
        if isinstance(countries, list) and countries:
            tree = True
            print(f"      países: {[_get(c, 'Name') for c in countries[:12]]}")
            if isinstance(_get(countries[0], "Leagues"), list):
                print(f"      ligas de {_get(countries[0], 'Name')} (embebidas): {[_get(l, 'Name') for l in _get(countries[0], 'Leagues')[:12]]}")
            else:
                lgs = try_all("leagues", id=str(_get(countries[0], "NodeId", "Id")))
                if isinstance(lgs, list):
                    print(f"      ligas de {_get(countries[0], 'Name')}: {[_get(l, 'Name') for l in lgs[:12]]}")
            break
    if not tree:
        print("\n   (ningún candidato del árbol país->liga responde: se usarán league_nodes + ligas vistas en directo)")
        # ¿devuelve GetEvents todos los partidos del deporte si se le pasa el nodo del deporte?
        for sp in mine[:1]:
            st, js = api.http.get(f"{base}/Event/GetEvents?parentId={_get(sp, 'NodeId')}&gameTypes=")
            print(f"   [{st}] Event/GetEvents?parentId=<deporte>  {_peek(js) if js is not None else ''}")
            if isinstance(js, list) and js:
                from collections import Counter
                print("      ligas:", Counter(_label(e) for e in js if isinstance(e, dict)).most_common(15))
    # ligas fijadas: eventos + categorías + mercados
    for nid, sport in (cfg.get("league_nodes") or {}).items():
        if nid.startswith("_"):
            continue
        evs = try_all("events", id=nid) or []
        for ev in evs[:4]:
            print(f"      · {_teams(ev)}  NodeId={_get(ev, 'NodeId')}  start={_get(ev, 'StartDateFormatted')}  live={_is_live(ev)}  label={_label(ev)!r}")
        if evs:
            eid = str(_get(evs[0], "NodeId"))
            cats = try_all("categories", id=eid) or []
            print(f"      categorías: {[(_get(c, 'CategoryId'), _get(c, 'CategoryName')) for c in cats]}")
            games = try_all("games", id=eid, cat="99") or []
            print(f"      mercados PRINCIPALES: {len(games)}")
            for g in games[:6]:
                print(f"      · {_get(g, 'Name')!r} spov={_get(g, 'Spov')!r} {[(_get(r, 'Name'), _get(r, 'Odd')) for r in (_get(g, 'Results') or [])[:3]]}")
        break
    live = try_all("live_events")
    evs = _get(live, "Events", default=[]) if isinstance(live, dict) else []
    from collections import Counter
    print("      en directo:", Counter((e.get("SportHandle"), _label(e)) for e in evs if isinstance(e, dict)).most_common(12))
    mine_live = [e for e in evs if isinstance(e, dict) and cfg["sports"].get(_fold(str(e.get("SportHandle") or "")))]
    if mine_live:
        e = mine_live[0]
        js = try_all("live_games", id=str(_get(e, "NodeId")), cat="99")
        games = _games_in(js) if js is not None else []
        print(f"      {_teams(e)} score={_score(e)} mercados PRINCIPALES live: {len(games)}")
    print("\nPega esta salida completa si algo sale en 404 o vacío.")
    api.http.close()


def list_catalog(cfg: dict):
    """Ligas que ve el colector (árbol si responde, league_nodes y las de los partidos en directo) y si entran por competitions.json."""
    c = Collector(cfg)
    c.refresh_catalog(force=True)
    js = c.api.call("live_events")
    for ev in (_get(js, "Events", default=[]) if isinstance(js, dict) else []) or []:
        sp = c._sport_of(ev)
        if sp:
            c._learn_league(ev, sp)
    seen = {}
    for lid, (sport, comp, label) in c.leagues.items():
        seen[(sport, label or lid)] = (comp, lid)
    cur = None
    for (sport, label), (comp, lid) in sorted(seen.items()):
        if sport != cur:
            print(f"\n=== {sport}")
            cur = sport
        print(f" {'✔' if comp else ' '} {label}   NodeId={lid}")
    if not c._tree_ok:
        print("\nSin árbol país->liga: para añadir una liga, abre su página en m.apuestas.codere.es, copia el NodeId de la URL "
              "(o de la llamada Event/GetEvents?parentId=...) y ponlo en league_nodes de codere.json.")
    c.api.http.close()


def dump(cfg: dict, node_id: str):
    """Todos los mercados de un evento (todas sus categorías) crudos + normalizados."""
    c = Collector(cfg)
    live = "--live" in sys.argv
    cats = c.api.call("categories", id=node_id) if not live else None
    if live:
        first = c.api.call("live_games", id=node_id, cat="99")
        cats = _get(first, "CategoryInfos", default=[]) if isinstance(first, dict) else []
        ev = _get(first, "Event", default={}) if isinstance(first, dict) else {}
    else:
        ev = {}
    cids = c._relevant_cats(cats or [])
    games = []
    for js in c.api.call_many("live_games" if live else "games", [{"id": node_id, "cat": cid} for cid in cids]):
        games += _games_in(js) if js is not None else []
    Path("snapshots").mkdir(exist_ok=True)
    out = Path("snapshots") / f"dump_codere_{node_id}.json"
    out.write_text(json.dumps({"event": ev, "categories": cats, "games": games}, ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"{len(games)} mercados en {len(cids)} categorías guardados en {out}")
    if ev:
        print("liveData crudo:", json.dumps(_get(ev, "liveData", "LiveData", default={}), ensure_ascii=False)[:1500])
        print("ResultInfo:", repr(_get(ev, "ResultInfo")), "| marcador normalizado:", _score(ev))
    home, away = _teams(ev) if ev else ("", "")
    if "--teams" in sys.argv:
        home, away = sys.argv[sys.argv.index("--teams") + 1].split("|", 1)
    sport = sys.argv[sys.argv.index("--sport") + 1] if "--sport" in sys.argv else cfg["sports"].get(_fold(str(ev.get("SportHandle") or "")), "futbol")
    for g in games[:80]:
        print(f" · {_get(g, 'Name')!r} spov={_get(g, 'Spov')!r} {[(_get(r, 'Name'), _get(r, 'Odd')) for r in (_get(g, 'Results') or [])[:4]]}")
    if home and away:
        sels = event_selections(games, sport, home, away)
        from collections import Counter
        print(f"\n{len(sels)} selecciones normalizadas ({home} - {away}, {sport}):")
        for k, v in Counter(s["market"] for s in sels).most_common():
            print(f"   {k:28} {v}")
    else:
        print("\n(para ver el mapeo normalizado añade --teams \"Local|Visitante\" [--sport baloncesto]; con --live se usa el evento en directo)")
    c.api.http.close()


def main():
    logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"), format="%(asctime)s %(levelname)s %(name)s: %(message)s",
                        datefmt="%H:%M:%S")
    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    cfg = load_cfg()
    if "--probe" in sys.argv:
        probe(cfg)
    elif "--list" in sys.argv:
        list_catalog(cfg)
    elif "--dump" in sys.argv:
        dump(cfg, sys.argv[sys.argv.index("--dump") + 1])
    else:
        c = Collector(cfg)
        try:
            c.run(once="--once" in sys.argv)
        finally:
            c.api.http.close()


if __name__ == "__main__":
    main()
