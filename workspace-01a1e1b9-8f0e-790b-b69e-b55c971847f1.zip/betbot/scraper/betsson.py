"""
betsson.py — colector de cuotas de Betsson (betsson.es).

Betsson usa el sportsbook OBG: la web es un SPA que consume una API JSON en el mismo dominio
(`/api/sb/v1/...`). La API está detrás de AWS WAF y geobloqueo (IP española), por eso las llamadas
pueden ir con `requests` o desde una pestaña de Chrome real (transport.py, modo `auto`).

Endpoints usados (descubiertos en el bundle JS y en las capturas):
    widgets/categories/v2?slug=futbol   -> árbol categoría > región > competición (ids)
    widgets/events-table/v2?categoryIds=1&competitionIds=a,b,c&eventPhase=Live|Prematch&pageNumber=N
                                    -> lista de eventos (id, participantes, región/competición, fase, inicio)
    widgets/event/v2?eventId=X      -> evento + `accordionSummaries` (todos los grupos de mercados que ofrece)
    widgets/accordion/v1?eventId=X&marketTemplateIds=a,b,c
                                    -> mercados + selecciones CON cuotas de esos grupos (líneas alternativas,
                                       periodos, props de jugador…)

Todo se normaliza con markets.py y competitions.json; escribe en odds.db con bookmaker `betsson`.
Uso:  python betsson.py          (bucle)      python betsson.py --once      python betsson.py --list
"""
from __future__ import annotations

import fastjson as json
import logging
import os
import re
import sys
import time
from datetime import datetime, timezone, timedelta
from pathlib import Path
from urllib.parse import unquote, urlencode

from competitions import Competitions
from markets import classify, implied_line, parse_ou_label, period_of, is_full_match_label
import storage
from storage import OddsStore
from demand import Demand
from transport import Http

log = logging.getLogger("betsson")
CFG_PATH = Path(os.getenv("BETSSON_CFG", Path(__file__).parent / "betsson.json"))

SEL_MAP = {"HOME": "1", "DRAW": "X", "AWAY": "2", "OVER": "Over", "UNDER": "Under", "YES": "Yes", "NO": "No",
           "1": "1", "X": "X", "2": "2"}
_PLAYER_MARKET = re.compile(r"goleador|marcador|anota|jugador|player|scorer|asistencia|tarjeta a|remates? de|"
                            r"tiros? de|puntos de|rebotes de|asistencias de|triples de", re.I)
# títulos que contienen esas palabras pero NO son props de jugador (auditoría 2026-11-16: "Marcador correcto de set 1"
# acababa como PLAYER_GOALS_SET1; "El jugador anotará o recibirá una tarjeta" es una combinada, no PLAYER_CARDS)
_NOT_PLAYER = re.compile(r"marcador (correcto|exacto|final)|resultado exacto|correct score|anotar\w* o recibir|recibir\w* o anotar|"
                         r"\bo\b.*tarjeta.*\bgol|primer marcador\b.*\bresultado", re.I)


def load_cfg() -> dict:
    import pace
    return pace.apply(json.loads(CFG_PATH.read_text(encoding="utf-8")))


# ──────────────────────────────────────────────────────────────────────────────
class Api:
    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.http = Http(cfg["origin"], cfg.get("transport", "auto"), cfg.get("headers"), cfg.get("start_url"),
                         cfg.get("workers", 8), gap=cfg.get("request_gap"), api_hint="/api/sb/", headless=cfg.get("headless"))

    def url(self, path: str, **params) -> str:
        q = {k: v for k, v in params.items() if v is not None}
        base = self.cfg["api_base"]
        if path.startswith("../"):                 # "../v2/markets" -> .../api/sb/v2/markets
            base, path = base.rsplit("/", 1)[0], path[3:]
        return f"{base}/{path}?{urlencode(q)}"

    def many(self, urls: list[str], max_parallel: int | None = None) -> list[dict | None]:
        """`max_parallel`: el pre-partido (hilo de fondo) pide de pocas en pocas para dejar hueco al live."""
        t0 = time.time()
        if max_parallel and len(urls) > max_parallel:
            res = []
            for i in range(0, len(urls), max_parallel):
                res += self.http.get_many(urls[i:i + max_parallel])
        else:
            res = self.http.get_many(urls)
        self.last = (len(urls), sorted({st for st, _ in res}), time.time() - t0,
                     next((str(js)[:160] for st, js in res if st != 200 or not isinstance(js, dict)), ""))
        if urls and not any(st == 200 and isinstance(js, dict) for st, js in res):
            err = next((js.get("_error") for _, js in res if isinstance(js, dict) and js.get("_error")), "")
            log.warning("API sin respuesta válida (%d peticiones, códigos %s, transporte %s) %s | %s",
                        len(urls), sorted({st for st, _ in res}), self.http.name, urls[0][:200], err[:300])
        return [js if st == 200 and isinstance(js, dict) and "_error" not in js else None for st, js in res]

    def one(self, url: str) -> dict | None:
        return self.many([url])[0]


# ──────────────────────────────────────────────────────────────────────────────
# Normalización de mercados/selecciones de Betsson a la taxonomía común
# ──────────────────────────────────────────────────────────────────────────────
def _line(m: dict) -> float | None:
    raw = m.get("lineValueRaw")
    if isinstance(raw, (int, float)) and (raw != 0 or (m.get("lineValue") or "").strip() not in ("", "0")):
        return float(raw)
    lv = (m.get("lineValue") or "").strip()
    mm = re.match(r"^([+-]?\d+(?:[.,]\d+)?)$", lv)
    return float(mm.group(1).replace(",", ".")) if mm else None


def _hcp_line(m: dict, sel: dict) -> float | None:
    """Hándicap: la línea del LOCAL es lineValueRaw; cada selección se guarda con su propio hándicap."""
    raw = m.get("lineValueRaw")
    lbl = sel.get("label") or ""
    mm = re.search(r"\(([+-]?\d+(?:[.,]\d+)?)\)", lbl) or re.search(r"([+-]\d+(?:[.,]\d+)?)\s*$", lbl)
    if mm:
        return float(mm.group(1).replace(",", "."))
    if not isinstance(raw, (int, float)):
        return None
    t = sel.get("selectionTemplateId")
    return float(raw) if t == "HOME" else -float(raw) if t == "AWAY" else None


def _norm_tid(t: str | None) -> str | None:
    """HANDICAPHOME -> HOME · OVERSHOTS/OVERCORNERS… -> OVER · UNDERX -> UNDER."""
    if not t:
        return t
    if t in SEL_MAP:
        return t
    if t.startswith("HANDICAP") and t[8:] in ("HOME", "AWAY", "DRAW"):
        return t[8:]
    if t.startswith("OVER"):
        return "OVER"
    if t.startswith("UNDER"):
        return "UNDER"
    return t


def _is_hcp(sels: list[dict]) -> bool:
    return any(str(s.get("_rawTid") or "").startswith("HANDICAP") or re.search(r"\([+-]\d", s.get("label") or "") for s in sels)


def accordion_selections(acc: dict, sport: str, home: str, away: str) -> list[dict]:
    """`acc` = data.accordions[key] = {markets:[…], selections:[…]} -> selecciones normalizadas."""
    out: list[dict] = []
    by_market: dict[str, list[dict]] = {}
    for s in acc.get("selections") or []:
        if s.get("status") not in (None, "Open") or not s.get("odds"):
            continue
        s["_rawTid"] = s.get("selectionTemplateId")
        by_market.setdefault(s.get("marketId"), []).append(s)
    for m in acc.get("markets") or []:
        if m.get("status") not in (None, "Open"):
            continue
        if re.search(r"2UP|UPEP|BOOST|SUPERODDS", m.get("marketTemplateId") or "", re.I):
            continue                          # variantes "pago anticipado 2-0" / cuotas mejoradas: no comparables
        sels = by_market.get(m.get("id"))
        if not sels:
            continue
        title = m.get("marketFriendlyName") or m.get("label") or ""
        # OBG a veces lleva el periodo fuera del título (eventPart / grupo de la pestaña): "Ambos equipos marcarán"
        # dentro de "1ª Parte".  Si el título no dice periodo, se toma del campo; si el campo dice algo que no
        # sabemos interpretar ni como periodo ni como partido completo, se descarta el mercado (antes que mapearlo mal).
        if period_of(title) is None:
            hint = _period_hint(m)
            if hint:
                per = period_of(hint)
                if per:
                    title = f"{title} - {_PERIOD_ES.get(per, hint)}"
                elif not is_full_match_label(hint):
                    continue
        for s_ in sels:
            s_["selectionTemplateId"] = _norm_tid(s_.get("selectionTemplateId"))
        tids = {s.get("selectionTemplateId") for s in sels}
        line = _line(m)
        # props de jugador OBG: "1er Tiempo - Total de tiros | Maxence Caqueret"
        pl_title = None
        if " | " in title:
            title, pl_title = (x.strip() for x in title.split(" | ", 1))
        if tids & {"HOME", "AWAY"} and re.search(r"margen de puntos|margen de goles|spread", title, re.I) and _is_hcp(sels):
            title = re.sub(r"margen de (puntos|goles)|spread", r"hándicap de \1", title, flags=re.I)
        # ── props de jugador: las selecciones son jugadores (goleador, "2+ goles", tarjeta…) ──
        if _NOT_PLAYER.search(title):
            continue
        if _PLAYER_MARKET.search(title) and not tids & {"HOME", "AWAY", "DRAW", "OVER", "UNDER", "YES", "NO"}:
            il = implied_line(title)
            info = classify(title, sport, home, away, player="?")
            if not info or il is None:
                continue
            for s in sels:
                pl = s.get("participantLabel") or s.get("label")
                if not pl or pl in (home, away):
                    continue
                out.append({"market": info.market, "ot": info.ot, "selection": "Over", "line": il, "player": pl, "price": s["odds"]})
            continue
        if tids & {"OVER", "UNDER"}:
            # el nombre del jugador puede venir en el título ("Remates de Vinícius Jr.") o en selectionSpecifics
            player = pl_title
            sp = (sels[0].get("selectionSpecifics") or {}).get("values") or {}
            for k in ("playerName", "participantName", "player"):
                if sp.get(k):
                    player = sp[k]
            info = classify(title, sport, home, away, kind="total", player=player)
            if not info:
                continue
            for s in sels:
                sel = SEL_MAP.get(s.get("selectionTemplateId"))
                if sel not in ("Over", "Under"):
                    sel, _ = parse_ou_label(s.get("label") or "")
                if not sel:
                    continue
                ln = parse_ou_label(s.get("label") or "")[1]
                ln = ln if ln is not None else line
                out.append({"market": info.market, "ot": info.ot, "selection": sel, "line": ln, "player": info.player, "price": s["odds"]})
        elif (re.search(r"h[aá]ndicap|handicap", title, re.I) or _is_hcp(sels)) and tids & {"HOME", "AWAY"}:
            if "DRAW" in tids and sport != "futbol":
                continue
            info = classify(title, sport, home, away, kind="handicap")
            if not info:
                continue
            for s in sels:
                sel = SEL_MAP.get(s.get("selectionTemplateId"))
                if sel not in ("1", "2"):
                    continue
                out.append({"market": info.market, "ot": info.ot, "selection": sel, "line": _hcp_line(m, s), "price": s["odds"]})
        elif tids <= {"HOME", "DRAW", "AWAY"} and tids & {"HOME", "AWAY"}:
            if "DRAW" in tids and sport != "futbol":
                continue
            info = classify(title, sport, home, away)
            if not info or not (info.market.startswith("1X2") or info.market.startswith("DNB")):
                continue
            if sport == "futbol" and (info.market.startswith("1X2") != ("DRAW" in tids)):
                continue                      # 1X2 sin empate o "sin empate" con empate: otro mercado
            for s in sels:
                out.append({"market": info.market, "ot": info.ot, "selection": SEL_MAP[s["selectionTemplateId"]], "price": s["odds"]})
        elif tids == {"YES", "NO"}:
            info = classify(title, sport, home, away)
            if not info or not info.market.startswith("BTTS"):
                continue
            for s in sels:
                out.append({"market": info.market, "ot": info.ot, "selection": SEL_MAP[s["selectionTemplateId"]], "price": s["odds"]})
    return out


_PERIOD_KEYS = re.compile(r"eventpart|period|marketgroup|groupname|tab|collection", re.I)
_PERIOD_ES = {"1H": "1ª parte", "2H": "2ª parte", "Q1": "1er cuarto", "Q2": "2º cuarto", "Q3": "3er cuarto",
              "Q4": "4º cuarto", "SET1": "set 1", "SET2": "set 2", "SET3": "set 3", "SET4": "set 4", "SET5": "set 5",
              "OT": "prórroga"}


def _period_hint(m: dict) -> str:
    """Texto de periodo/pestaña que acompaña al mercado en el JSON de OBG (si lo hay)."""
    bits = []
    for k, v in m.items():
        if isinstance(v, str) and v.strip() and _PERIOD_KEYS.search(k) and not k.lower().endswith("id"):
            bits.append(v.strip())
        elif isinstance(v, dict) and _PERIOD_KEYS.search(k):
            for kk in ("label", "name", "friendlyName", "title"):
                if isinstance(v.get(kk), str) and v[kk].strip():
                    bits.append(v[kk].strip())
    return " / ".join(bits)


def _scoreboard(sb: dict | None, participants: list[dict]) -> dict:
    if not sb:
        return {}
    spp = sb.get("scorePerParticipant") or {}
    score = None
    if spp:
        order = [str(p.get("id")) for p in participants] or list(spp)
        vals = [spp.get(pid, spp.get(int(pid)) if pid.isdigit() else None) for pid in order]
        if all(v is not None for v in vals):
            score = ":".join(str(v) for v in vals)
    ph = sb.get("currentPhase") or {}
    period = ph.get("label") or ph.get("name") or (str(ph.get("id")) if ph.get("id") is not None else None)
    clock = sb.get("matchClock") or {}
    timer = None
    if isinstance(clock, dict):
        mins = clock.get("minutes", clock.get("minute"))
        secs = clock.get("seconds", clock.get("second"))
        if mins is not None:
            timer = f"{mins}'" if secs is None else f"{int(mins):02d}:{int(secs):02d}"
    return {"score": score, "period": period, "timer": timer}


# ──────────────────────────────────────────────────────────────────────────────
class Collector:
    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.api = Api(cfg)
        self.catalog = Competitions()
        self.bk = cfg.get("bookmaker", "betsson")
        self.store = OddsStore(bookmaker=self.bk)
        self._cfg_mtime = CFG_PATH.stat().st_mtime
        self._last_prematch = 0.0
        self._last_catalog = 0.0
        self.comps: dict[str, tuple[str, str]] = {}
        self._templates: dict[str, tuple[float, list[str]]] = {}   # eventId -> (ts, marketTemplateIds)
        self._full_at: dict[str, float] = {}                        # eventId -> última ficha completa

    def _reload_if_changed(self):
        self.catalog.reload()
        mt = CFG_PATH.stat().st_mtime
        if mt != self._cfg_mtime:
            self.cfg = load_cfg()
            self.api.cfg = self.cfg
            self._cfg_mtime = mt
            log.info("betsson.json recargado")

    def _scan(self, cat: str, phase: str, max_pages: int = 12) -> list[dict]:
        """Todos los eventos de una categoría (sin filtrar competición), paginando events-table."""
        now = datetime.now(timezone.utc)
        p = dict(categoryIds=cat, eventPhase=phase, eventSortBy="StartDate", includeSkeleton="true",
                 maxMarketCount=1, pageNumber=1, priceFormats=1)
        if phase == "Prematch":
            p["startsOnOrAfter"] = now.strftime("%Y-%m-%dT%H:%M:%SZ")
            p["startsBefore"] = (now + timedelta(hours=self.cfg.get("prematch_hours", 48))).strftime("%Y-%m-%dT%H:%M:%SZ")
        out, seen = [], set()
        for page in range(1, max_pages + 1):
            p["pageNumber"] = page
            js = self.api.one(self.api.url("widgets/events-table/v2", **p))
            evs = ((js or {}).get("data") or {}).get("events") or []
            new = [e for e in evs if e.get("id") not in seen]
            seen.update(e.get("id") for e in new)
            out.extend(new)
            if not new or len(evs) < 10:
                break
        return out

    # ── catálogo de competiciones (widgets/categories/v2?slug=<deporte>) ───────
    def _walk(self, node, region: str | None, out: list[tuple[str, str, str]]):
        if isinstance(node, list):
            for n in node:
                self._walk(n, region, out)
            return
        if not isinstance(node, dict):
            return
        key = str(node.get("key") or node.get("globalId") or "")
        label = node.get("label") or node.get("name") or ""
        if key.startswith("competition.") and node.get("id") is not None:
            reg = region or (node.get("region") or {}).get("name") or ""
            out.append((str(node["id"]), reg, label))
        elif key.startswith("region.") or key.startswith("subcategory.") or node.get("readableId"):
            region = label or region
        for k in ("items", "children", "competitions", "regions", "categories"):
            if k in node:
                self._walk(node[k], region, out)

    def refresh_catalog(self):
        comps: dict[str, tuple[str, str]] = {}     # competitionId -> (sport, competición canónica)
        for slug, sport in self.cfg["category_slugs"].items():
            st, js = self.api.http.get_tolerant(self.api.url("widgets/categories/v2", slug=slug))
            if st != 200 or not isinstance(js, dict):
                log.warning("categories/v2?slug=%s -> %s %s", slug, st, (js or {}).get("_error", "") if isinstance(js, dict) else "")
                js = None
            found: list[tuple[str, str, str]] = []
            self._walk((js or {}).get("data") or {}, None, found)
            for cid, region, label in found:
                comp = self._match(sport, region, label)
                if comp:
                    comps[cid] = (sport, comp)
        if not comps:   # respaldo 1: barrido paginado de eventos por categoría -> ids de competición
            for cat, sport in self.cfg["categories"].items():
                for phase in ("Live", "Prematch"):
                    for e in self._scan(cat, phase):
                        cid = str(e.get("competitionId") or "")
                        if cid and cid not in comps:
                            comp = self._match(sport, e.get("regionName", ""), e.get("competitionName", ""))
                            if comp:
                                comps[cid] = (sport, comp)
        if not comps:   # respaldo 2: competiciones más populares
            js = self.api.one(self.api.url("widgets/most-popular-competitions/v1"))
            for it in ((js or {}).get("data") or {}).get("items") or []:
                sport = next((sp for slug, sp in self.cfg["category_slugs"].items() if str(it.get("slug", "")).startswith(slug)), None)
                comp = sport and self._match(sport, (it.get("region") or {}).get("name", ""), it.get("label", ""))
                if comp:
                    comps[str(it["id"])] = (sport, comp)
        for cid, (sport, comp) in self.cfg.get("extra_competitions", {}).items():
            comps.setdefault(cid, (sport, comp))
        self.comps = comps
        self._last_catalog = time.time()
        log.info("catálogo: %d competiciones seleccionadas", len(comps))

    def _match(self, sport: str, region: str, label: str) -> str | None:
        region, label = (region or "").strip(), (label or "").strip()
        short = re.sub(r"^" + re.escape(region) + r"\s+", "", label, flags=re.I) if region else label   # "España La Liga" -> "La Liga"
        for cand in (f"{region} - {short}", f"{region} - {label}", label):
            c = self.catalog.match(self.bk, sport, cand)
            if c:
                return c
        return None

    # ── listados ────────────────────────────────────────────────────────────
    def list_events(self, phase: str) -> list[tuple[dict, str, str]]:
        """Eventos (evento, deporte, competición canónica) de las competiciones principales."""
        if not getattr(self, "comps", None):
            self.refresh_catalog()
        elif time.time() - self._last_catalog > 3600 and not getattr(self, "_cat_thread", None):
            # refresco horario en un hilo: el live sigue con el catálogo actual mientras tanto
            import threading

            def _rc():
                try:
                    self.refresh_catalog()
                except Exception as e:  # noqa: BLE001
                    log.warning("refresco de catálogo falló: %s", e)
                finally:
                    self._cat_thread = None
            self._cat_thread = threading.Thread(target=_rc, daemon=True, name="betsson-catalog")
            self._cat_thread.start()
        now = datetime.now(timezone.utc)
        by_cat: dict[str, list[str]] = {}
        sport_cat = {v: k for k, v in self.cfg["categories"].items()}
        for cid, (sport, _) in self.comps.items():
            by_cat.setdefault(sport_cat[sport], []).append(cid)
        urls = []
        for cat, cids in by_cat.items():
            for i in range(0, len(cids), 25):
                p = dict(categoryIds=cat, competitionIds=",".join(sorted(cids[i:i + 25])), eventPhase=phase,
                         eventSortBy="StartDate", includeSkeleton="true", maxMarketCount=3, pageNumber=1, priceFormats=1)
                if phase == "Prematch":
                    p["startsOnOrAfter"] = now.strftime("%Y-%m-%dT%H:%M:%SZ")
                    p["startsBefore"] = (now + timedelta(hours=self.cfg.get("prematch_hours", 48))).strftime("%Y-%m-%dT%H:%M:%SZ")
                urls.append(self.api.url("widgets/events-table/v2", **p))
        out, seen = [], set()
        self._scores = {}
        pending = urls
        for _page in range(1, 6):            # paginación: repite con pageNumber+1 mientras lleguen eventos
            nxt = []
            for u, js in zip(pending, self.api.many(pending)):
                data = (js or {}).get("data") or {}
                for sb in data.get("scoreboards") or []:
                    if sb.get("eventId"):
                        self._scores[sb["eventId"]] = sb
                evs = data.get("events") or []
                for e in evs:
                    if e.get("id") in seen or e.get("eventType") not in (None, "Fixture"):
                        continue
                    hit = self.comps.get(str(e.get("competitionId")))
                    if not hit:
                        continue
                    seen.add(e["id"])
                    out.append((e, hit[0], hit[1]))
                if len(evs) >= 20:
                    nxt.append(re.sub(r"pageNumber=\d+", f"pageNumber={_page + 1}", u))
            if not nxt:
                break
            pending = nxt
        return out

    # ── detalle ─────────────────────────────────────────────────────────────
    def _market_ids_for(self, events: list[dict]) -> dict[str, list[str]]:
        """marketIds de cada evento (event/v2 -> accordionSummaries[*].marketIds); cache 10 min."""
        now = time.time()
        need = [e["id"] for e in events if e["id"] not in self._templates or now - self._templates[e["id"]][0] > 600]
        res = self.api.many([self.api.url("widgets/event/v2", eventId=eid) for eid in need],
                            max_parallel=int(self.cfg.get("prematch_parallel", 3)) if len(need) > 4 else None)
        for eid, js in zip(need, res):
            if not js:
                continue
            ids: list[str] = []
            summ = ((js.get("data") or {}).get("accordionSummaries")) or {}
            for key, sm in summ.items():
                if not isinstance(sm, dict):
                    continue
                if re.search(r"2UP|UPEP|BOOST|SUPERODDS", ",".join(sm.get("marketTemplateIds") or []), re.I):
                    continue
                for mid in sm.get("marketIds") or ([key] if key.startswith("m-") else []):
                    if mid and mid not in ids:
                        ids.append(mid)
            self._templates[eid] = (now, ids)
        return {e["id"]: self._templates.get(e["id"], (0, []))[1] for e in events}

    def details(self, evs: list[tuple[dict, str, str]], kind: str, full: bool = False) -> dict[str, list[dict]]:
        events = [e for e, *_ in evs]
        mids = self._market_ids_for(events)
        per = self.cfg.get("markets_per_call", 60)
        jobs: list[tuple[str, str]] = []        # (eventId, url)
        now = time.time()
        cap = self.cfg.get("max_market_ids", {}).get(kind, 120 if kind == "prematch" else 240)
        full_every = self.cfg.get("full_detail_every", 600)
        n_ids = 0
        dead_ttl = self.cfg.get("dead_market_ttl", 600)
        self._dead = {m: t for m, t in getattr(self, "_dead", {}).items() if now - t < dead_ttl}
        full_left = self.cfg.get("max_full_per_cycle", 1)      # fichas completas (todos los mercados) por ciclo
        if kind == "live":
            full_left = 1 if full else 0                       # la ficha completa de un partido en directo la hace el hilo de fondo
        par = int(self.cfg.get("prematch_parallel", 3)) if (kind != "live" or full) else None
        for e in events:
            ids = [m for m in (mids.get(e["id"]) or []) if m not in self._dead]
            if not ids:                           # sin resumen: al menos los mercados principales
                jobs.append((e["id"], self.api.url("widgets/accordion/v1", eventId=e["id"], marketTemplateIds="MW3W,MW2W,MTG2W")))
            # Un partido puede tener >1000 mercados (props de cada jugador). Los primeros `cap` (orden de la web:
            # principales primero) se refrescan en cada pasada; la ficha completa solo cada `full_detail_every` s.
            if len(ids) > cap:
                if full_left > 0 and (full or now - self._full_at.get(e["id"], 0) >= full_every):
                    full_left -= 1
                    self._full_at[e["id"]] = now
                else:
                    # principales cada ciclo + una ventana ROTATORIA del resto (props): así cada mercado se vuelve a
                    # ver cada pocos ciclos en vez de esperar a la ficha completa (full_detail_every), que dejaba
                    # las cuotas de props "vistas hace 100 s" y el bot las descartaba en live estricto
                    rot = int(self.cfg.get("live_rotate_ids", 180)) if kind == "live" else 0
                    rest = ids[cap:]
                    ids = ids[:cap]
                    if rot > 0 and rest:
                        offs = self.__dict__.setdefault("_rot_off", {})
                        off = offs.get(e["id"], 0) % len(rest)
                        ids = ids + (rest + rest)[off: off + rot]
                        offs[e["id"]] = off + rot
            else:
                self._full_at[e["id"]] = now
            n_ids += len(ids)
            for chunk in self._chunks(ids, per):
                jobs.append((e["id"], self.api.url("../v2/markets", marketIds=",".join(chunk))))
        res = self.api.many([u for _, u in jobs], max_parallel=par)
        # URL demasiado larga -> 404: partir ese lote en dos y volver a pedir (hasta 3 niveles)
        for _ in range(3):
            redo = [i for i, ((_, u), js) in enumerate(zip(jobs, res)) if js is None and "marketIds=" in u and u.count("%2C") >= 1]
            if not redo:
                break
            new_jobs: list[tuple[int, str, str]] = []           # (índice original, eventId, url)
            for i in redo:
                eid, u = jobs[i]
                ids_i = unquote(u.split("marketIds=", 1)[1]).split(",")
                h = len(ids_i) // 2
                for part in (ids_i[:h], ids_i[h:]):
                    if part:
                        new_jobs.append((i, eid, self.api.url("../v2/markets", marketIds=",".join(part))))
            res2 = self.api.many([u for _, _, u in new_jobs], max_parallel=par)
            extra: list[tuple[tuple[str, str], dict | None]] = []
            for (i, eid, u), js in zip(new_jobs, res2):
                extra.append(((eid, u), js))
            for i in redo:                                       # el lote original queda descartado
                jobs[i] = (jobs[i][0], jobs[i][1].split("marketIds=")[0] + "marketIds=")
                res[i] = None
            for j, r in extra:
                jobs.append(j)
                res.append(r)
        bad = [u for (_, u), js in zip(jobs, res) if js is None and "%2C" in u]
        # lotes pequeños que siguen sin respuesta tras partirlos: mercados cerrados/inexistentes -> no volver a pedirlos
        for (_, u), js in zip(jobs, res):
            if js is None and "marketIds=" in u:
                ids_u = [m for m in unquote(u.split("marketIds=", 1)[1]).split(",") if m]
                if 0 < len(ids_u) <= 8:
                    for m in ids_u:
                        self._dead[m] = now
        if bad:
            log.warning("v2/markets sin respuesta en %d/%d peticiones (longitud URL %d): %s", len(bad), len(jobs), len(bad[0]), bad[0][:200])
        log.debug("detalle %s: %d eventos, %d marketIds, %d peticiones", kind, len(events), n_ids, len(jobs))
        accs: dict[str, list[dict]] = {}
        for (eid, _), js in zip(jobs, res):
            if not js:
                continue
            if "accordions" in (js.get("data") or {}):
                for acc in js["data"]["accordions"].values():
                    accs.setdefault(eid, []).append(acc)
            else:
                body = js if "markets" in js else (js.get("data") or {})
                accs.setdefault(eid, []).append({"markets": body.get("markets") or [], "selections": body.get("selections") or []})
        by_sport: dict[str, list[dict]] = {}
        for e, sport, comp in evs:
            parts = sorted(e.get("participants") or [], key=lambda p: p.get("sortOrder", p.get("side", 0)))
            if len(parts) < 2:
                continue
            home, away = parts[0]["label"], parts[1]["label"]
            if kind == "live":
                self._cache_structure(e, sport, comp, accs.get(e["id"], []))
            sels: list[dict] = []
            for acc in accs.get(e["id"], []):
                sels.extend(accordion_selections(acc, sport, home, away))
            if not sels:
                continue
            dt = None
            try:
                dt = datetime.fromisoformat(e["startDate"].replace("Z", "+00:00")).astimezone()
            except (KeyError, ValueError):
                pass
            row = {"event_id": e["id"], "home": home, "away": away, "competition": comp,
                   "date": dt.strftime("%Y-%m-%d") if dt else None, "start_time": dt.strftime("%H:%M") if dt else None,
                   "url": self._event_url(e.get("slug", "")), "selections": sels}
            if kind == "live":
                row.update(_scoreboard(self._scores.get(e["id"]), parts))
            by_sport.setdefault(sport, []).append(row)
        return by_sport

    def _save(self, by_sport: dict[str, list[dict]], kind: str) -> tuple[int, int]:
        rows = changed = 0
        for sport, rs in by_sport.items():
            changed += self.store.save_rows(sport, kind, rs)
            rows += len(rs)
        return rows, changed

    def _chunks(self, ids: list[str], per: int) -> list[list[str]]:
        """Lotes de marketIds limitados por número y por longitud de URL (la API devuelve 404 con URLs largas)."""
        max_len = int(self.cfg.get("max_url_len", 1800))
        base = len(self.api.url("../v2/markets", marketIds=""))
        out, cur, cur_len = [], [], base
        for mid in ids:
            add = len(mid) * 1.2 + 3                             # %2C y escapes
            if cur and (len(cur) >= per or cur_len + add > max_len):
                out.append(cur)
                cur, cur_len = [], base
            cur.append(mid)
            cur_len += add
        if cur:
            out.append(cur)
        return out

    def _demand(self, evs: list[tuple[dict, str, str]]) -> list[tuple[dict, str, str]]:
        """Solo partidos que otra casa ya tiene en odds.db (los demás no pueden dar surebets)."""
        if not self.cfg.get("demand_only", True):
            return evs
        if not hasattr(self, "demand"):
            self.demand = Demand(self.cfg.get("bookmaker", "betsson"))

        def key(it):
            e, sport, _ = it
            parts = sorted(e.get("participants") or [], key=lambda p: p.get("sortOrder", p.get("side", 0)))
            if len(parts) >= 2:
                return sport, parts[0].get("label", ""), parts[1].get("label", "")
            lab = (e.get("label") or "").split(" - ", 1)
            return sport, lab[0], (lab[1] if len(lab) > 1 else "")
        out = self.demand.filter(evs, key)
        self._skipped = len(evs) - len(out)
        return out

    # ── push (betsson_push.py): la REST da la estructura, el websocket Diffusion el precio al instante ──
    def _push(self):
        if not self.cfg.get("push", True):
            return None
        if "_push_obj" not in self.__dict__:
            try:
                from betsson_push import BetssonPush
                self._push_obj = BetssonPush(self.cfg)
                self._push_obj.start()
            except Exception as e:  # noqa: BLE001
                log.warning("push no disponible (%s): live solo por REST", e)
                self._push_obj = None
            self._live_cache: dict[str, dict] = {}
            self._struct_at = 0.0
            self._push_match_logged = 0.0
        return self._push_obj

    def _cache_structure(self, e: dict, sport: str, comp: str, accs: list[dict]):
        """Guarda mercados/selecciones (tal como los da la REST) de un partido en directo para que el
        tick rápido del push pueda recalcular las filas con los precios nuevos sin volver a pedir nada."""
        if "_live_cache" not in self.__dict__:
            return
        now = time.time()
        c = self._live_cache.setdefault(e["id"], {"mk": {}})
        c["ev"] = (e, sport, comp)
        c["ts"] = now
        for acc in accs:
            by_m: dict[str, list[dict]] = {}
            for s_ in acc.get("selections") or []:
                by_m.setdefault(s_.get("marketId"), []).append(s_)
            for m in acc.get("markets") or []:
                if m.get("id"):
                    c["mk"][m["id"]] = (m, by_m.get(m["id"], []), now)

    def _push_tick(self, push) -> tuple[int, int]:
        """Filas live a partir de la estructura cacheada (REST) + precios/estados del push."""
        max_age = float(self.cfg.get("push_struct_max_age", 45))
        # Las cuotas vienen del websocket (instantáneas): la tanda empieza ahora, no en la última petición REST
        # (si la REST anterior no guardó nada, su fetch_t0 seguiría vivo y sellaría estas cuotas con minutos de antigüedad).
        storage.end_fetch()
        storage.note_fetch()
        now = time.time()
        with push.lock:
            odds = dict(push.odds)
            mstate = dict(push.mstate)
            sstate = dict(push.sstate)
            seen = {k: set(v) for k, v in push.markets_seen.items()}
        by_sport: dict[str, list[dict]] = {}
        n_sel = n_hit = 0
        for eid, c in list(self._live_cache.items()):
            if "ev" not in c or not push.event_fresh(eid):
                continue
            mids = seen.get(eid)
            if not mids:
                continue
            e, sport, comp = c["ev"]
            parts = sorted(e.get("participants") or [], key=lambda p: p.get("sortOrder", p.get("side", 0)))
            if len(parts) < 2:
                continue
            home, away = parts[0]["label"], parts[1]["label"]
            markets, sels = [], []
            for mid, (m, ss, ts) in list(c["mk"].items()):
                if mid not in mids or now - ts > max_age:
                    continue
                st = mstate.get(mid)
                if st and st[0] != 10:                      # 10 = abierto; 20 suspendido; 30 cerrado
                    continue
                mm = dict(m)
                mm["status"] = "Open"
                keep = []
                for s_ in ss:
                    n_sel += 1
                    sid = s_.get("id")
                    po = odds.get(sid) if sid else None
                    if not po:
                        continue
                    sst = sstate.get(sid)
                    if sst and sst[0] != 1:
                        continue
                    n_hit += 1
                    s2 = dict(s_)
                    s2["odds"] = po[0]
                    s2["status"] = "Open"
                    keep.append(s2)
                if keep:
                    markets.append(mm)
                    sels.extend(keep)
            if not markets:
                continue
            out = accordion_selections({"markets": markets, "selections": sels}, sport, home, away)
            if not out:
                continue
            dt = None
            try:
                dt = datetime.fromisoformat(e["startDate"].replace("Z", "+00:00")).astimezone()
            except (KeyError, ValueError):
                pass
            row = {"event_id": e["id"], "home": home, "away": away, "competition": comp,
                   "date": dt.strftime("%Y-%m-%d") if dt else None, "start_time": dt.strftime("%H:%M") if dt else None,
                   "url": self._event_url(e.get("slug", "")), "selections": out, "partial": True}
            row.update(_scoreboard(self._scores.get(e["id"]), parts))
            by_sport.setdefault(sport, []).append(row)
        if n_sel and now - self._push_match_logged > 300:
            self._push_match_logged = now
            log.info("push: %d/%d selecciones de la REST con cuota por websocket (%d partidos)", n_hit, n_sel, len(by_sport))
            if n_hit == 0:
                log.warning("push: ninguna selección casa (¿cambió el formato de ids?) — live por REST")
        return self._save(by_sport, "live")

    def _struct_refresh(self, push) -> tuple[int, int]:
        """Pasada REST completa del live (lista + fichas): estructura para el push y filas a odds.db."""
        evs = self.list_events("Live")
        if evs:                                   # lista vacía = probablemente fallo de red: no barrer
            self.store.sweep({e["id"] for e, *_ in evs}, "live")
        evs = self._demand(evs)
        all_ids = {e["id"] for e, *_ in evs}
        n = self.cfg.get("max_detail_per_cycle", 60)
        if len(evs) > n:                      # rotación: que ningún partido se quede sin detallar nunca
            off = getattr(self, "_live_off", 0) % len(evs)
            evs = (evs + evs)[off: off + n]
            self._live_off = off + n
        self._live_evs = evs
        if push is not None:
            # El push se suscribe a TODOS los partidos en juego y la estructura cacheada se conserva aunque
            # este turno de la rotación no los detalle: solo se descartan los que ya no están en directo.
            for eid in [k for k in list(self._live_cache) if k not in all_ids]:
                self._live_cache.pop(eid, None)
                push.drop_event(eid)
            push.set_events(all_ids)
        res = self._save(self.details(evs, "live"), "live")
        self._struct_at = time.time()
        return res

    def live_cycle(self) -> tuple[int, int]:
        push = self._push()
        now = time.time()
        struct_every = float(self.cfg.get("push_struct_every", 20))
        if push is not None and push.healthy() and self._live_cache:
            # Con push: el tick rápido (precios por websocket) nunca espera por la REST.  La pasada de
            # estructura (17-30 s con muchos partidos) va en un hilo aparte cada `push_struct_every` s.
            self._push_fast = True
            if now - self._struct_at >= struct_every and not self._pm_inline(False):
                bg = self.__dict__.setdefault("_sbg", __import__("pace").Background("betsson-estructura"))
                if not bg.busy():
                    def _job():
                        t0 = time.time()
                        r, c = self._struct_refresh(push)
                        return f"estructura REST {r} ev / {c} cambios ({time.time() - t0:.0f}s)"
                    bg.run(_job)
                return self._push_tick(push)
            elif now - self._struct_at < struct_every:
                return self._push_tick(push)
        self._push_fast = False
        return self._struct_refresh(push)

    def _event_url(self, slug: str) -> str:
        """El slug de la API puede venir relativo ("futbol/espana/laliga/a-b"),
        absoluto ("/apuestas-deportivas/...") o completo (https://...)."""
        slug = (slug or "").strip()
        if slug.startswith("http"):
            return slug
        if slug.startswith("/"):
            return self.cfg["origin"].rstrip("/") + slug
        if slug.startswith("apuestas-deportivas/"):
            return self.cfg["origin"].rstrip("/") + "/" + slug
        return self.cfg["event_url"].format(slug=slug)

    def prematch_events(self) -> list[tuple[dict, str, str]]:
        evs = self.list_events("Prematch")
        if evs:
            self.store.sweep({e["id"] for e, *_ in evs}, "prematch")
        return self._demand(evs)[: self.cfg.get("max_prematch_detail", 400)]

    def prematch_cycle(self) -> tuple[int, int]:
        return self._save(self.details(self.prematch_events(), "prematch"), "prematch")

    # ── pre-partido en segundo plano (pace.Background): el bucle live no espera por listas ni fichas pre-partido ──
    def _pm_inline(self, once: bool) -> bool:
        http = getattr(self, "http", None) or getattr(getattr(self, "api", None), "http", None)
        name = getattr(http, "name", None) or getattr(http, "mode", "") or ""
        return once or "browser" in str(name) or "chrome" in str(name)   # el navegador no se comparte entre hilos

    def _pm_schedule(self, t0: float, once: bool, msg: str) -> str:
        bg = self.__dict__.setdefault("_bg", __import__("pace").Background(f"{getattr(self, 'bk', 'prematch')}-prematch"))
        if not bg.busy():
            job = self._pm_job(t0, once)
            if job is not None:
                r = bg.run(job, inline=self._pm_inline(once))
                if r:
                    msg += " | " + r
        note = bg.note()
        if note:
            msg += " | " + note
        return msg

    def _pm_job(self, t0: float, once: bool):
        if not self._pm_queue and t0 - self._last_prematch >= self.cfg.get("interval_prematch", 180):
            def _list():
                self._pm_queue = self.prematch_events()
                self._last_prematch = time.time()
                out = f"prematch lista {len(self._pm_queue)} ev"
                if once and self._pm_queue:
                    out += " | " + self._pm_job(time.time(), once)()
                return out
            return _list
        live_full = [it for it in getattr(self, "_live_evs", []) if t0 - self._full_at.get(it[0]["id"], 0) >= self.cfg.get("full_detail_every", 600)]
        if live_full and not once:
            it = live_full[0]

            def _full():
                tp = time.time()
                prow, pchg = self._save(self.details([it], "live", full=True), "live")
                return f"ficha completa live 1 ev / {pchg} cambios ({time.time() - tp:.0f}s)"
            return _full
        if self._pm_queue:
            batch = len(self._pm_queue) if once else max(1, self.cfg.get("prematch_batch", 4))
            chunk, self._pm_queue = self._pm_queue[:batch], self._pm_queue[batch:]
            def _detail():
                tp = time.time()
                prow, pchg = self._save(self.details(chunk, "prematch"), "prematch")
                if chunk and not prow:
                    n, sts, dt, sample = getattr(self.api, "last", (0, [], 0.0, ""))
                    log.warning("detalle pre-partido sin resultado para %d eventos en %.1fs: última tanda %d peticiones, "
                                "códigos %s (%.1fs) %s", len(chunk), time.time() - tp, n, sts, dt, sample)
                return f"prematch {prow} ev / {pchg} cambios ({len(self._pm_queue)} pendientes, {time.time() - tp:.0f}s)"
            return _detail
        return None

    def run(self, once: bool = False):
        backoff = 2
        self._pm_queue: list = []
        self._pm_stats = [0, 0]
        while True:
            t0 = time.time()
            try:
                self._reload_if_changed()
                rows, changed = self.live_cycle()
                t_live = time.time() - t0
                msg = f"live {rows} ev / {changed} cambios"
                if getattr(self, "_skipped", 0):
                    msg += f" ({self._skipped} sin pareja en otras casas, no pedidos)"
                # pre-partido en un hilo aparte (pace.Background): el live no espera por él
                msg = self._pm_schedule(t0, once, msg)
                sbg = self.__dict__.get("_sbg")
                if sbg is not None:
                    note = sbg.note()
                    if note:
                        msg += " | " + note
                if t_live > 15:
                    n, sts, dt, _ = getattr(self.api, "last", (0, [], 0.0, ""))
                    msg += f" [live lento: {t_live:.0f}s; última tanda {n} peticiones {sts} en {dt:.0f}s]"
                tname = self.api.http.name + ("+push" if getattr(self, "_push_fast", False) else "")
                self.store.set_status(betsson_last_ok=time.time(), betsson_live_events=rows, betsson_transport=tname)
                log.info("%s [%s] (%.1fs)", msg, tname, time.time() - t0)
                backoff = 2
                if once:
                    return
            except Exception as e:
                log.warning("error de ciclo: %s — reintento en %ss", e, backoff, exc_info=log.isEnabledFor(logging.DEBUG))
                self.store.set_status(betsson_last_error=f"{time.time():.0f} {e}")
                time.sleep(backoff)
                backoff = min(backoff * 2, 60)
                continue
            time.sleep(max(0.5, self.cfg.get("interval_live", 5) - (time.time() - t0)))


def list_catalog(cfg: dict):
    c = Collector(cfg)
    c.refresh_catalog()
    for cat, sport in cfg["categories"].items():
        print(f"\n=== {sport} (categoryId {cat})")
        seen: dict[str, tuple[str, int]] = {}
        for phase in ("Live", "Prematch"):
            for e in c._scan(cat, phase):
                cid = str(e.get("competitionId"))
                lab, n = seen.get(cid, (f"{e.get('regionName', '')} - {e.get('competitionName', '')}", 0))
                seen[cid] = (lab, n + 1)
        for cid, (lab, n) in sorted(seen.items(), key=lambda x: x[1][0]):
            mark = "✔" if cid in c.comps else " "
            print(f" {mark} {lab}   [{cid}] eventos(48h)={n}")
    c.api.http.close()


def dump(cfg: dict, n: int = 2):
    """Vuelca las respuestas crudas (event/v2 + v2/markets) de los primeros `n` eventos de cada deporte a
    snapshots/dump_betsson_*.json, para revisar el mapeo de mercados sin acceso a la web."""
    c = Collector(cfg)
    evs = c.list_events("Prematch") + c.list_events("Live")
    pick, per = [], {}
    for e, sport, comp in evs:
        if per.get(sport, 0) < n:
            per[sport] = per.get(sport, 0) + 1
            pick.append((e, sport, comp))
    out = []
    for e, sport, comp in pick:
        ev2 = c.api.one(c.api.url("widgets/event/v2", eventId=e["id"]))
        mids = c._market_ids_for([e]).get(e["id"]) or []
        accs = [c.api.one(c.api.url("../v2/markets", marketIds=",".join(mids[i:i + 60]))) for i in range(0, len(mids), 60)]
        parsed = c.details([(e, sport, comp)], "prematch")
        out.append({"event": e, "sport": sport, "competition": comp, "event_v2": ev2, "marketIds": mids,
                    "markets_v2": accs, "parsed": parsed})
        log.info("%s %s: %d mercados, %d selecciones mapeadas", sport, e.get("label"), len(mids),
                 sum(len(r["selections"]) for rs in parsed.values() for r in rs))
    p = Path(os.getenv("SNAP_DIR", Path(__file__).parent / "snapshots")) / f"dump_betsson_{int(time.time())}.json"
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")
    log.info("volcado -> %s", p)
    c.api.http.close()


def dump_links(cfg: dict):
    """Imprime URLs candidatas de enlace directo a una selección (para probarlas en el navegador)."""
    c = Collector(cfg)
    evs = (c.list_events("Live") or []) + (c.list_events("Prematch") or [])
    print(f"{len(evs)} eventos candidatos")
    for e, sport, comp in evs[:10]:
        mids = c._market_ids_for([e]).get(e["id"]) or []
        if mids:
            js = c.api.one(c.api.url("../v2/markets", marketIds=",".join(mids[:20]))) or {}
        else:
            js = c.api.one(c.api.url("widgets/accordion/v1", eventId=e["id"], marketTemplateIds="MW3W,MW2W,MTG2W")) or {}
        blocks = []
        if "accordions" in (js.get("data") or {}):
            blocks = list(js["data"]["accordions"].values())
        else:
            body = js if "markets" in js else (js.get("data") or {})
            blocks = [{"markets": body.get("markets") or [], "selections": body.get("selections") or []}]
        for blk in blocks:
            ss = [x for x in (blk.get("selections") or []) if x.get("odds") and x.get("status") in (None, "Open")]
            for m in blk.get("markets") or []:
                if m.get("status") not in (None, "Open"):
                    continue
                sel = next((x for x in ss if x.get("marketId") == m.get("id")), None)
                if not sel:
                    continue
                base = c._event_url(e.get("slug", ""))
                sid, mid = sel.get("id"), m.get("id")
                print(f"\nPartido: {e.get('label')}  eventId={e['id']}")
                print(f"Apuesta: {m.get('marketFriendlyName') or m.get('label')!r} -> selección "
                      f"{sel.get('label') or sel.get('name')!r} @{sel.get('odds')}  marketId={mid} selectionId={sid}\n")
                print("Abre cada URL en incógnito y dime cuál deja la selección ya marcada en la cesta:")
                for i, u in enumerate([
                    f"{base}?selectionId={sid}",
                    f"{base}?betslip={sid}",
                    f"{base}?selections={sid}",
                    f"{base}?selectionIds={sid}",
                    f"{base}?marketId={mid}&selectionId={sid}",
                    f"{base}#selection={sid}",
                    f"{base}?bsid={sid}",
                    f"{cfg['origin'].rstrip('/')}/apuestas-deportivas?betslip={sid}",
                    f"{cfg['origin'].rstrip('/')}/apuestas-deportivas/betslip/{sid}",
                ], 1):
                    print(f"  {i}. {u}")
                c.api.http.close()
                return
        print(f"  {e.get('label')}: {len(mids)} marketIds, respuesta sin selecciones abiertas (claves: {list(js)[:6]})")
    print("sin selecciones en los primeros eventos")
    c.api.http.close()


def main():
    logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"),
                        format="%(asctime)s %(levelname)s %(name)s: %(message)s", datefmt="%H:%M:%S")
    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    cfg = load_cfg()
    if "--list" in sys.argv:
        list_catalog(cfg)
        return
    if "--dump" in sys.argv:
        dump(cfg)
        return
    if "--links" in sys.argv:
        dump_links(cfg)
        return
    Collector(cfg).run(once="--once" in sys.argv)


if __name__ == "__main__":
    main()
