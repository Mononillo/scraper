"""
betway.py — colector de cuotas de Betway España (betway.es) sin navegador.

Betway.es es una app Next.js con API JSON propia (sin cookies ni token):

    POST /es/api/sports/content/getEventDetails  {EventId}   -> Event + Markets (210) + Outcomes (2200) de un partido
    POST /es/api/sports/content/getEvents        {ExternalIds}-> datos básicos de varios eventos (sin mercados)
    POST /es/api/sports/content/getEventMarkets  {MarketIds}  -> mercados sueltos

Las LISTAS de eventos (en directo y próximos) no tienen endpoint propio: van embebidas en el payload
RSC (React Server Components) de las páginas `/es/es/sports/live` y `/es/es/sports/cat/<deporte>`.
Se descargan con la cabecera `RSC: 1` (o, si no, se extraen del HTML `self.__next_f.push`) y se
buscan los objetos {events:{id:{...}}, markets:{}, outcomes:{}} (liveEmos / upcomingEmos).

Normalización: markets.py (mercados) + competitions.json (competiciones; etiqueta "País - Liga").
Escribe en odds.db con bookmaker `betwayes`.

Uso:  python betway.py           (bucle)     --once    --list (competiciones)    --probe (páginas de listado)
      python betway.py --dump <eventId>      (mercados normalizados de un evento)
"""
from __future__ import annotations

import fastjson as json
import logging
import os
import re
import sys
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path

import requests

sys.path.insert(0, str(Path(__file__).resolve().parent))   # permite `python -m scraper.betway` desde betbot\
from competitions import Competitions
from markets import _team_in, classify
from storage import OddsStore

log = logging.getLogger("betway")
CFG_PATH = Path(os.getenv("BETWAY_CFG", Path(__file__).parent / "betway.json"))
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
      "Chrome/130.0.0.0 Safari/537.36")

_FOLD = {"á": "a", "é": "e", "í": "i", "ó": "o", "ú": "u", "ñ": "n", "ü": "u"}


def load_cfg() -> dict:
    import pace
    return pace.apply(json.loads(CFG_PATH.read_text(encoding="utf-8")))


def _fold(s: str) -> str:
    return "".join(_FOLD.get(c, c) for c in (s or "").lower())


# ──────────────────────────────────────────────────────────────────────────────
class Api:
    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.s = requests.Session()
        self.s.headers.update({"User-Agent": UA, "Accept-Language": "es-ES,es;q=0.9",
                               "Origin": cfg["origin"], "Referer": cfg["origin"] + "/es/es/sports"})
        self.pool = ThreadPoolExecutor(max_workers=cfg.get("workers", 6))

    # API JSON -------------------------------------------------------------
    def post(self, method: str, **body) -> dict | None:
        payload = dict(self.cfg["body"], CorrelationId=str(uuid.uuid4()), **body)
        try:
            r = self.s.post(f"{self.cfg['api_base']}/{method}", json=payload,
                            headers={"Accept": "application/json", "x-correlation-id": payload["CorrelationId"]},
                            timeout=self.cfg.get("timeout", 20))
            if r.status_code != 200:
                log.debug("%s -> %s", method, r.status_code)
                return None
            return json.loads(r.content)
        except (requests.RequestException, ValueError) as e:
            log.debug("%s falló: %s", method, e)
            return None

    def details(self, event_id: int) -> dict | None:
        d = self.post("getEventDetails", EventId=int(event_id), ScoreboardRequest={"IncidentRequest": {}, "ScoreboardType": 3})
        return d if d and d.get("Event") else None

    def many_details(self, ids: list[int]) -> list[dict | None]:
        return list(self.pool.map(self.details, ids))

    # Páginas Next.js (RSC) ---------------------------------------------------
    def page_emos(self, path: str) -> list[dict]:
        """Descarga una página del sportsbook y devuelve los bloques {events, markets, outcomes} embebidos."""
        url = self.cfg["origin"] + path
        try:
            r = self.s.get(url, headers={"RSC": "1", "Accept": "text/x-component"}, timeout=self.cfg.get("timeout", 20))
            r.encoding = "utf-8"
            if r.status_code == 200 and ("liveEmos" in r.text or "upcomingEmos" in r.text or "\"events\":{" in r.text):
                return _emos_from_flight(r.text)
            r = self.s.get(url, headers={"Accept": "text/html"}, timeout=self.cfg.get("timeout", 20))
            r.encoding = "utf-8"
            if r.status_code != 200:
                log.debug("%s -> %s", path, r.status_code)
                return []
            return _emos_from_flight(_flight_from_html(r.text))
        except requests.RequestException as e:
            log.debug("%s falló: %s", path, e)
            return []


def _flight_from_html(html: str) -> str:
    """Concatena los trozos `self.__next_f.push([1,"..."])` del HTML en el texto flight original."""
    parts = []
    for m in re.finditer(r'self\.__next_f\.push\(\[1,\s*("(?:[^"\\]|\\.)*")\]\)', html):
        try:
            parts.append(json.loads(m.group(1)))
        except ValueError:
            continue
    return "".join(parts)


def _emos_from_flight(text: str) -> list[dict]:
    found: list[dict] = []

    def walk(o):
        if isinstance(o, dict):
            if isinstance(o.get("events"), dict) and "markets" in o:
                found.append(o)
                return
            for v in o.values():
                walk(v)
        elif isinstance(o, list):
            for v in o:
                walk(v)

    for line in text.split("\n"):
        m = re.match(r"^[0-9a-f]+:(.*)$", line)
        if not m:
            continue
        body = m.group(1)
        if not body.startswith(("{", "[")):
            continue
        try:
            walk(json.loads(body.replace('"$undefined"', "null")))
        except ValueError:
            # línea cortada por el chunking del flight: buscar bloques por regex como último recurso
            for mm in re.finditer(r'"events":\{"\d+":\{', body):
                try:
                    obj, _ = json.JSONDecoder().raw_decode(body, mm.start() + len('"events":'))
                    found.append({"events": obj, "markets": {}})
                except ValueError:
                    pass
    return found


# ──────────────────────────────────────────────────────────────────────────────
# Normalización de getEventDetails
# ──────────────────────────────────────────────────────────────────────────────
_SKIP_TITLE = re.compile(r"ventaja|par/impar|exacto|margen|forma de meter|combinad|qui[eé]n ser[aá]|especial|uno contra uno|"
                         r"cada uno|m[aá]s tiros|ambas mitades|despu[eé]s de ir|una de las dos|las dos mitades|"
                         r"primera parte - final|super cuotas|penalti|propia meta|sin conceder|y goles en total|y ambos|"
                         r"dos o m[aá]s|tres o m[aá]s|cualquiera de los equipos|seguro|\d+ ?up\b|victoria y|juego \d+|punto \d+|"
                         r"tiebreak|iguales|primero que|despu[eé]s de|apuesta de set|intervalo|prórroga\?|habr[aá] pr[oó]rroga",
                         re.I)
_PLAYER_SKIP = re.compile(r"asiste|marca o asiste|1er gol|primer gol|[uú]ltimo|cabeza|fuera del [aá]rea|goleador del partido|portero", re.I)
_NPLUS = re.compile(r"(\d+)\s*\+")
_DC = {"1x": "1X", "12": "12", "2x": "X2", "x2": "X2"}
_STAT_W = r"(?:Puntos|Rebotes|Asistencias|Triples|Robos|Tapones|Dobles dobles|Triples dobles)"
# "Tyler Herro Puntos", "Josh Giddey Rebotes + Asistencias", "Robert Williams III Puntos más Rebotes"
_PLAYER_OU = re.compile(r"^(.+?)\s+(" + _STAT_W + r"(?:\s*(?:\+|&|/|,|\s(?:m[aá]s|y|e)\s)\s*" + _STAT_W + r")*)$", re.I)
_STAT_IN_NAME = re.compile(r"\b(puntos|rebotes|asistencias|triples|robos|tapones|m[aá]s|pts|rebs?|ast)\b", re.I)


def _implied(title: str) -> float | None:
    """'Jugador realiza 2+ Tiros' -> 1.5 · 'Jugador marca 2 o más goles' -> 1.5 · 'Marca gol' -> 0.5."""
    m = _NPLUS.search(title) or re.search(r"(\d+)[^\d]*? o m[aá]s", title, re.I)
    if m:
        return float(m.group(1)) - 0.5
    if re.search(r"marca gol|recibir[aá] una tarjeta|marca$", title, re.I):
        return 0.5
    return None


def event_selections(d: dict, sport: str) -> list[dict]:
    ev = d["Event"]
    home, away = ev.get("HomeTeamName") or "", ev.get("AwayTeamName") or ""
    if not home or not away:
        return []
    oc = {o["Id"]: o for o in d.get("Outcomes") or []
          if o.get("IsActive") and o.get("IsDisplay", True) and (o.get("OddsDecimal") or 0) > 1.0}
    sels: list[dict] = []
    for m in d.get("Markets") or []:
        if m.get("IsSuspended"):
            continue
        title = re.sub(r"\s+", " ", m.get("Title") or "").strip()
        title = re.sub(r"\bvencedor\b", "Ganador", title, flags=re.I)              # baloncesto: "Vencedor del partido"
        title = re.sub(r"\btotal partidos\b", "Juegos en total", title, flags=re.I)  # tenis: "2º Set Total Partidos" = juegos del set
        grp = (m.get("MarketGroupCName") or "").lower()
        tcn = (m.get("TypeCName") or "").lower()
        groups = m.get("OutcomeGroups") or {}
        ids = [i for row in (m.get("Outcomes") or []) for i in row if i in oc]
        if not ids or not title or _SKIP_TITLE.search(title):
            continue
        if re.search(r"protection|[12]up|boost", m.get("MarketCName") or ""):
            continue                                        # variantes promocionales del 1X2 (2 goles de ventaja, etc.)
        if tcn.endswith("3way") or tcn == "handicap-wdw":
            continue                                        # más/exacto/menos y hándicap a 3 bandas: no comparables
        headers = [h or "" for h in (m.get("Headers") or [])]
        team_of = {i: "HOME" for i in groups.get("home", {}).get("outcomes", [])}
        team_of.update({i: "AWAY" for i in groups.get("away", {}).get("outcomes", [])})
        team_of.update({i: "DRAW" for i in groups.get("draw", {}).get("outcomes", [])})
        ou = {(oc[i].get("TeamCName") or "").lower() for i in ids} & {"over", "under"}

        # 1) Más de / Menos de (goles, córners, tarjetas, puntos, juegos, props de jugador con línea)
        if ou or (len(headers) == 2 and _fold(headers[0]).startswith("mas de")):
            player = None
            if grp == "players":
                # props de jugador con línea: "Tyler Herro Puntos", "Josh Giddey Rebotes + Asistencias"
                mp = _PLAYER_OU.match(title)
                if not mp:
                    continue
                player, title = mp.group(1).strip(), mp.group(2).strip()
                if _STAT_IN_NAME.search(player):
                    continue                                # el "nombre" arrastra una estadística: título no entendido, fuera
            info = classify(title, sport, home, away, kind="total", player=player)
            if not info or (grp == "players" and not info.player) or (grp != "players" and info.player):
                continue
            # Totales POR EQUIPO en un mismo mercado ("Córners de equipo": fila Milan / fila Inter, cada una con
            # Más/Menos): el equipo va en el grupo de resultados o en el nombre de la selección, no en el título.
            # Si no sabemos de qué equipo es cada fila y hay dos "Más de X" iguales, el mercado es ambiguo: fuera.
            team_name = {"HOME": home, "AWAY": away}
            rows, seen = [], set()
            for i in ids:
                o = oc[i]
                side = (o.get("TeamCName") or "").lower()
                bn = _fold(o.get("BetName", ""))
                sel = "Over" if side == "over" or bn.startswith("mas") else \
                      "Under" if side == "under" or bn.startswith("menos") else None
                if sel is None and re.search(r"\bmas de\b", bn):
                    sel = "Over"
                elif sel is None and re.search(r"\bmenos de\b", bn):
                    sel = "Under"
                line = o.get("Handicap") if o.get("Handicap") is not None else m.get("Handicap")
                if not sel or line is None:
                    continue
                tm = team_of.get(i) if team_of.get(i) in ("HOME", "AWAY") else None
                if tm is None and not info.team and not info.player:
                    hit = _team_in(bn, home, away)
                    tm = hit if hit in ("HOME", "AWAY") else None
                mk = info.market
                if tm and not info.team and not info.player:
                    ti = classify(f"{title} {team_name[tm]}", sport, home, away, kind="total")
                    if not ti or not ti.team:
                        continue
                    mk = ti.market
                key = (mk, sel, float(line), info.player)
                if key in seen:
                    rows = None                             # dos "Más de 5.5" en el mismo mercado sin equipo: ambiguo
                    break
                seen.add(key)
                rows.append({"market": mk, "selection": sel, "line": float(line), "player": info.player, "price": o["OddsDecimal"]})
            if rows:
                sels.extend(rows)
            continue

        # 2) Mercados por jugador / equipo tipo "Nombre N+" (goleador, tiros, faltas, entradas, tarjetas…)
        if tcn in ("goalscorer", "outright", "standard") and (m.get("TemplateId") in (0, 5) or team_of):
            if _PLAYER_SKIP.search(title):
                continue
            for i in ids:
                o = oc[i]
                name = (o.get("BetName") or "").strip()
                mm = re.match(r"^(.*?)\s+(\d+)\+$", name)
                if grp in ("team-stats", "other") or (mm and _fold(mm.group(1)) in (_fold(home), _fold(away))):
                    # total de equipo / partido: "Alaves 11+" o "7+"
                    if mm:
                        team, n = mm.group(1), int(mm.group(2))
                        t = f"{title} {team}" if _fold(team) in (_fold(home), _fold(away)) else title
                    elif re.match(r"^\d+\+$", name):
                        team, n, t = None, int(name[:-1]), title
                    else:
                        continue
                    info = classify(t, sport, home, away, kind="total")
                    if info and not info.player:
                        sels.append({"market": info.market, "selection": "Over", "line": n - 0.5, "price": o["OddsDecimal"]})
                    continue
                # prop de jugador: línea implícita en el título
                line = _implied(title)
                if line is None:
                    continue
                base = re.sub(r"jugador marca \d+ o m[aá]s goles", "Marca gol", title, flags=re.I)
                if sport != "futbol":
                    # "Jugador anota 25 puntos o más" / "Jugador suma 10 puntos + asistencias o más" -> métrica tras el número
                    mb = re.search(r"\d+\s+(.+?)\s+o m[aá]s", title, re.I)
                    if not mb:
                        continue
                    base = mb.group(1)
                info = classify(base, sport, home, away, player=name)
                if info and info.player:
                    sels.append({"market": info.market, "selection": "Over", "line": line, "player": info.player, "price": o["OddsDecimal"]})
            continue

        # 3) Hándicap a 2 bandas (línea en cada selección)
        if "handicap" in tcn or re.search(r"h[aá]ndicap", title, re.I):
            if not all(oc[i].get("Handicap") is not None for i in ids) or len(ids) != 2:
                continue
            info = classify(title, sport, home, away, kind="handicap")
            if not info:
                continue
            for i in ids:
                side = team_of.get(i) or ("HOME" if (oc[i].get("TeamCName") or "").endswith("home-team-") else
                                          "AWAY" if (oc[i].get("TeamCName") or "").endswith("away-team-") else None)
                if side in ("HOME", "AWAY"):
                    sels.append({"market": info.market, "selection": "1" if side == "HOME" else "2",
                                 "line": float(oc[i]["Handicap"]), "price": oc[i]["OddsDecimal"]})
            continue

        # 4) Doble oportunidad / sin empate / ambos marcan / 1X2 / ganador
        if tcn == "double-chance":
            info = classify(title, sport, home, away)
            if info and info.market.startswith("DC"):
                for i in ids:
                    sel = _DC.get((oc[i].get("TeamCName") or "").lower())
                    if sel:
                        sels.append({"market": info.market, "selection": sel, "price": oc[i]["OddsDecimal"]})
            continue
        if tcn == "draw-no-bet" or team_of and set(team_of.values()) == {"HOME", "AWAY"} and len(ids) == 2:
            t = re.sub(r"1-X-2", "Ganador", title)
            info = classify(t, sport, home, away)
            if not info or not (info.market.startswith("DNB") or info.market.startswith("1X2")):
                continue
            if info.market.startswith("1X2") and re.search(r"c[oó]rner|tarjeta|card", title, re.I):
                continue
            for i in ids:
                side = team_of.get(i) or ("HOME" if oc[i].get("ColumnId") == 0 else "AWAY")
                sels.append({"market": info.market, "selection": "1" if side == "HOME" else "2", "price": oc[i]["OddsDecimal"]})
            continue
        if set(groups) >= {"yes", "no"} or {_fold(h) for h in headers} >= {"si", "no"}:
            info = classify(title, sport, home, away)
            if not info or not info.market.startswith("BTTS"):
                continue
            for i in ids:
                yes = i in groups.get("yes", {}).get("outcomes", []) or _fold(oc[i].get("BetName", "")) in ("si", "yes")
                sels.append({"market": info.market, "selection": "Yes" if yes else "No", "price": oc[i]["OddsDecimal"]})
            continue
        if team_of and "DRAW" in team_of.values():
            if sport != "futbol" or re.search(r"c[oó]rner|tarjeta|card", title, re.I):
                continue
            info = classify(re.sub(r"1-X-2", "Ganador", title), sport, home, away)
            if not info or not info.market.startswith("1X2"):
                continue
            for i in ids:
                sel = {"HOME": "1", "DRAW": "X", "AWAY": "2"}.get(team_of.get(i))
                if sel:
                    sels.append({"market": info.market, "selection": sel, "price": oc[i]["OddsDecimal"]})
    return sels


def event_row(d: dict, sport: str, competition: str, cfg: dict) -> dict | None:
    ev = d["Event"]
    sels = event_selections(d, sport)
    if not sels:
        return None
    dt = None
    if ev.get("Milliseconds"):
        dt = datetime.fromtimestamp(ev["Milliseconds"] / 1000, tz=timezone.utc).astimezone()
    row = {
        "event_id": str(ev["Id"]), "home": ev["HomeTeamName"], "away": ev["AwayTeamName"], "competition": competition,
        "date": dt.strftime("%Y-%m-%d") if dt else None, "start_time": dt.strftime("%H:%M") if dt else None,
        "url": cfg["event_url"].format(eventId=ev["Id"]), "selections": sels,
    }
    sb = d.get("Scoreboard") or {}
    if sb.get("IsLive") or ev.get("IsLive"):
        st = sb.get("State") or {}
        stats = sb.get("Statistics") or {}
        goals = (stats.get("Goals") or stats.get("Points") or stats.get("Sets") or {}).get("Values")
        secs = st.get("Time") or 0
        row.update(score=":".join(str(x) for x in goals) if goals and len(goals) >= 2 else None,
                   period=st.get("PeriodComment") if st.get("PeriodComment") not in ("-", None) else None,
                   timer=f"{int(secs) // 60}'" if secs else None)
    return row


# ──────────────────────────────────────────────────────────────────────────────
def _label(e: dict) -> str:
    sub = e.get("subcategoryName") or e.get("SubCategoryName") or ""
    grp = e.get("groupName") or e.get("GroupName") or ""
    return f"{sub} - {grp}".strip(" -")


class Collector:
    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.api = Api(cfg)
        self.catalog = Competitions()
        self.store = OddsStore(bookmaker=cfg["bookmaker"])
        self._cfg_mtime = CFG_PATH.stat().st_mtime
        self._last_prematch = 0.0
        self._last_live_list = 0.0
        self._last_prune = 0.0
        self.live: dict[int, tuple[str, str]] = {}          # eventId -> (sport, competición)
        self._pm_cursor = 0
        self._list_cache: dict[str, dict[int, dict]] = {}
        self._list_at = 0.0
        self._list_ok = False

    def _reload_if_changed(self):
        self.catalog.reload()
        mt = CFG_PATH.stat().st_mtime
        if mt != self._cfg_mtime:
            self.cfg = load_cfg()
            self.api.cfg = self.cfg
            self._cfg_mtime = mt
        if time.time() - self._last_prune > 3600:
            self.store.prune()
            self._last_prune = time.time()

    def _match(self, e: dict) -> tuple[str, str] | None:
        cat = (e.get("categoryCName") or e.get("CategoryCName") or "").lower()
        sport = self.cfg["sports"].get(cat)
        if not sport or e.get("outright") or e.get("IsOutright"):
            return None
        bk = self.cfg["bookmaker"]
        name = self.catalog.match(bk, sport, _label(e))
        return (sport, name) if name else None

    # listas ---------------------------------------------------------------
    def list_events(self, kind: str) -> dict[int, dict]:
        """Eventos de las páginas de listado: {eventId: evento}. kind = live | prematch.
        Las páginas `live?categoryFilter=<deporte>` traen a la vez los partidos en directo y los próximos,
        así que una sola descarga alimenta las dos listas (se cachea `interval_live_list` segundos)."""
        now = time.time()
        if now - self._list_at > self.cfg.get("interval_live_list", 30) or not self._list_cache:
            pages = list(dict.fromkeys(self.cfg["list_pages"].get("live", []) + self.cfg["list_pages"].get("prematch", [])))
            cache: dict[str, dict[int, dict]] = {"live": {}, "prematch": {}}
            ok = 0
            for emos in self.api.pool.map(self.api.page_emos, pages):
                ok += bool(emos)
                for block in emos:
                    for eid, e in block["events"].items():
                        cache["live" if e.get("started") else "prematch"][int(eid)] = e
            if ok:
                self._list_cache, self._list_at, self._list_ok = cache, now, ok == len(pages)
        return self._list_cache.get(kind, {})

    # ciclos -----------------------------------------------------------------
    def live_cycle(self) -> tuple[int, int]:
        old, self.cfg["timeout"] = self.cfg.get("timeout", 20), self.cfg.get("timeout_live", 8)   # fallar rápido en directo
        try:
            return self._live_cycle()
        finally:
            self.cfg["timeout"] = old

    def _live_cycle(self) -> tuple[int, int]:
        evs = self.list_events("live")
        if self._list_at != self._last_live_list:            # lista nueva
            self.live = {eid: sc for eid, e in evs.items() if (sc := self._match(e))}
            if self._list_ok:
                self.store.sweep({str(i) for i in self.live}, "live")
            self._last_live_list = self._list_at
        ids = list(self.live)[: self.cfg.get("max_detail_per_cycle", 20)]
        details = self.api.many_details(ids)
        by_sport: dict[str, list[dict]] = {}
        for eid, d in zip(ids, details):
            if not d:
                continue
            if not (d.get("Scoreboard") or {}).get("IsLive") and not d["Event"].get("IsLive"):
                self.live.pop(eid, None)            # terminado
                continue
            sport, comp = self.live[eid]
            row = event_row(d, sport, comp, self.cfg)
            if row:
                by_sport.setdefault(sport, []).append(row)
        rows = changed = 0
        for sport, rs in by_sport.items():
            changed += self.store.save_rows(sport, "live", rs)
            rows += len(rs)
        return rows, changed

    def prematch_cycle(self) -> tuple[int, int]:
        evs = self.list_events("prematch")
        now = time.time()
        horizon = now + self.cfg.get("prematch_hours", 48) * 3600
        todo: list[tuple[int, str, str]] = []
        for eid, e in evs.items():
            sc = self._match(e)
            if not sc:
                continue
            try:
                st = datetime.fromisoformat(e["startsAt"].replace("Z", "+00:00")).timestamp()
            except (KeyError, ValueError, AttributeError):
                continue
            if now - 300 <= st <= horizon:
                todo.append((eid, *sc))
        todo.sort()
        cap = self.cfg.get("max_prematch_per_cycle", 120)
        if len(todo) > cap:                                  # rotación: cada ciclo un tramo distinto
            start = self._pm_cursor % len(todo)
            todo = (todo + todo)[start:start + cap]
            self._pm_cursor += cap
        details = self.api.many_details([eid for eid, *_ in todo])
        by_sport: dict[str, list[dict]] = {}
        for (eid, sport, comp), d in zip(todo, details):
            if d:
                row = event_row(d, sport, comp, self.cfg)
                if row:
                    by_sport.setdefault(sport, []).append(row)
        rows = changed = 0
        for sport, rs in by_sport.items():
            changed += self.store.save_rows(sport, "prematch", rs)
            rows += len(rs)
        if not evs:
            log.warning("prematch: las páginas de listado no devolvieron eventos (¿cambió la web? prueba --probe)")
        return rows, changed

    def run(self, once: bool = False):
        bk = self.cfg["bookmaker"]
        backoff = 2
        while True:
            t0 = time.time()
            try:
                self._reload_if_changed()
                rows, changed = self.live_cycle()
                msg = f"live {rows} ev / {changed} cambios"
                if t0 - self._last_prematch >= self.cfg.get("interval_prematch", 180):
                    prow, pchg = self.prematch_cycle()
                    self._last_prematch = time.time()
                    msg += f" | prematch {prow} ev / {pchg} cambios"
                self.store.set_status(**{f"{bk}_last_ok": time.time(), f"{bk}_live_events": rows})
                log.info("%s (%.1fs)", msg, time.time() - t0)
                backoff = 2
                if once:
                    return
            except Exception as e:
                log.warning("error de ciclo: %s — reintento en %ss", e, backoff, exc_info=log.isEnabledFor(logging.DEBUG))
                self.store.set_status(**{f"{bk}_last_error": f"{time.time():.0f} {e}"})
                time.sleep(backoff)
                backoff = min(backoff * 2, 60)
                continue
            time.sleep(max(0.5, self.cfg.get("interval_live", 5) - (time.time() - t0)))


# ──────────────────────────────────────────────────────────────────────────────
def probe(cfg: dict):
    api = Api(cfg)
    for kind, pages in cfg["list_pages"].items():
        for p in pages:
            t0 = time.time()
            emos = api.page_emos(p)
            from collections import Counter
            cnt: Counter = Counter()
            for b in emos:
                for e in b["events"].values():
                    cnt[(e.get("categoryCName") or "?", "live" if e.get("started") else "upcoming")] += 1
            print(f"[{kind}] {p}  bloques={len(emos)}  {time.time() - t0:.1f}s")
            for k, v in sorted(cnt.items()):
                print(f"      {k[0]:12} {k[1]:9} {v}")
    print("\nSi algún deporte no aparece, abre esa sección en el navegador y pásame la URL para ponerla en list_pages.")


def list_catalog(cfg: dict):
    api = Api(cfg)
    cat = Competitions()
    seen: dict[tuple, int] = {}
    for kind in ("live", "prematch"):
        for emos in api.pool.map(api.page_emos, cfg["list_pages"][kind]):
            for b in emos:
                for e in b["events"].values():
                    sport = cfg["sports"].get((e.get("categoryCName") or "").lower())
                    if sport and not e.get("outright"):
                        seen[(sport, _label(e))] = seen.get((sport, _label(e)), 0) + 1
    cur = None
    for (sport, label), n in sorted(seen.items()):
        if sport != cur:
            print(f"\n=== {sport}")
            cur = sport
        ok = cat.match(cfg["bookmaker"], sport, label)
        print(f" {'✔' if ok else ' '} {label}   eventos={n}")


def dump(cfg: dict, event_id: int):
    api = Api(cfg)
    d = api.details(event_id)
    if not d:
        print("sin respuesta"); return
    ev = d["Event"]
    sport = cfg["sports"].get((ev.get("CategoryCName") or "").lower(), "futbol")
    print(f"{ev['HomeTeamName']} - {ev['AwayTeamName']}  [{_label(ev)}]  live={ev.get('IsLive')}  mercados={len(d.get('Markets') or [])}")
    oc = {o["Id"]: o for o in d.get("Outcomes") or []}
    titles = {}
    for m in d.get("Markets") or []:
        titles.setdefault(m.get("Title"), (m.get("TypeCName"), m.get("TemplateId"), m.get("Headers"), [oc[i]["BetName"] for row in m["Outcomes"][:1] for i in row if i in oc]))
    print("\n-- mercados de la casa (título -> tipo, plantilla, cabeceras, 1ª fila):")
    for t, v in titles.items():
        print(f"   {t!r}: {v}")
    sels = event_selections(d, sport)
    print(f"\n-- {len(sels)} selecciones normalizadas:")
    from collections import Counter
    for k, v in Counter(s["market"] for s in sels).most_common():
        print(f"   {k:28} {v}")
    for s in sels[:40]:
        print("   ", s)


def main():
    logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"), format="%(asctime)s %(levelname)s %(name)s: %(message)s",
                        datefmt="%H:%M:%S")
    cfg = load_cfg()
    if "--probe" in sys.argv:
        probe(cfg)
    elif "--list" in sys.argv:
        list_catalog(cfg)
    elif "--dump" in sys.argv:
        dump(cfg, int(sys.argv[sys.argv.index("--dump") + 1]))
    else:
        Collector(cfg).run(once="--once" in sys.argv)


if __name__ == "__main__":
    main()
