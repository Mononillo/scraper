"""
kambi.py — colector genérico para casas que usan el sportsbook de Kambi (LeoVegas, …).

Kambi expone una API pública de solo lectura en su CDN (sin WAF, sin geobloqueo, ya comprimida):
    https://eu-offering-api.kambicdn.com/offering/v2018/<offering>/...?lang=es_ES&market=ES

Endpoints usados:
    group.json                               -> árbol deporte > país > competición (ids y termKeys)
    listView/<sport>/<pais>/<liga>.json      -> eventos de una competición con sus mercados principales
    event/live/open.json                     -> TODOS los eventos en directo (marcador, reloj, groupId) en 1 llamada
    betoffer/event/<id>.json&type=…          -> todos los mercados de un evento (tipos filtrados)

Cada casa Kambi es un fichero json (leovegas.json, …) con `bookmaker`, `offering` y las URLs públicas;
el código es el mismo. Normalización: competitions.json + markets.py; BD: storage.py (odds.db).

Uso:  python kambi.py --cfg leovegas.json            (bucle)
      python kambi.py --cfg leovegas.json --once     python kambi.py --cfg leovegas.json --list
"""
from __future__ import annotations

import fastjson as json
import logging
import os
import re
import sys
import time
from datetime import datetime, timezone, timedelta
from pathlib import Path
from urllib.parse import urlencode

from competitions import Competitions
from markets import classify, implied_line
from storage import OddsStore
from demand import Demand
from transport import Http

log = logging.getLogger("kambi")

SPORT_KEY = {"football": "futbol", "basketball": "baloncesto", "tennis": "tenis"}
# betOfferType.id de Kambi: 1 Handicap · 2 Match · 6 Over/Under · 7 Asian Handicap · 18 Yes/No ·
# 21 Asian Over/Under · 127 Player Occurrence Line (props con línea)
DETAIL_TYPES = "1,2,6,7,18,21,127"
_OT = {"OT_ONE": "1", "OT_CROSS": "X", "OT_TWO": "2", "OT_OVER": "Over", "OT_UNDER": "Under", "OT_YES": "Yes", "OT_NO": "No"}
# etiquetas Kambi que no entran en la taxonomía (markets.py no las reconoce bien por sí solo)
_SKIP = re.compile(r"primero en|primeros con|intervalo|siguiente|pr[oó]xim|resto del|\d{1,2}[:.]\d{2}|\d{1,2}\s*-\s*\d{1,2}\s*min|\bpunto \d|\bjuego \d|juegos? ganados? por|margen|par/impar|"
                   r"al palo|gana al menos|de penalti|propia meta|ambas mitades|penal concedido|sin recibir|y ambos|"
                   r"deuce|quiebre|tiebreak|tie break|break|marca o da|doble-doble|triple-doble|robos y tapones|"
                   r"la mayor[ií]a|primer gol|primera anotaci[oó]n|m[aá]ximo anotador|resultado correcto|descanso ?/|"
                   r"de cabeza|fuera del [aá]rea|tanteador|exacto|race to", re.I)
_EXCLUDE = re.compile(r"esports|^\||\(2x\d|simulated|virtual", re.I)
_CLEAN = [
    (re.compile(r"\s*\((resuelta|resulta|settled)[^)]*\)", re.I), ""),
    (re.compile(r"\s*-\s*(pr[oó]rroga incluida|incluyendo pr[oó]rroga|excluye pr[oó]rroga|incl\.? ?pr[oó]rroga)", re.I), ""),
    (re.compile(r"\s*-\s*pr[oó]rroga incluida", re.I), ""),
    (re.compile(r"puntos, rebotes y asistencias", re.I), "puntos + rebotes + asistencias"),
    (re.compile(r"puntos y asistencias", re.I), "puntos + asistencias"),
    (re.compile(r"puntos y rebotes", re.I), "puntos + rebotes"),
    (re.compile(r"rebotes y asistencias", re.I), "rebotes + asistencias"),
    (re.compile(r"\bdel jugador\b|\bpor el jugador\b|\bdel partido\b", re.I), ""),
    (re.compile(r"\s{2,}"), " "),
]


def _clean(label: str) -> str:
    t = label or ""
    for rx, rep in _CLEAN:
        t = rx.sub(rep, t)
    return t.strip(" -")


def _line(v) -> float | None:
    return None if v is None else v / 1000.0


def _price(v) -> float | None:
    return None if not v else v / 1000.0


def betoffer_selections(bo: dict, sport: str, home: str, away: str, live: bool = False) -> list[dict]:
    """Un betOffer de Kambi -> selecciones normalizadas (market, selection, line, player, price).
    live=True: se descartan los betOffers sin la etiqueta OFFERED_LIVE. En la ficha de un partido en juego quedan
    mercados pre-partido (p. ej. «Hándicap Asiático», DNB, córners) que Kambi NO actualiza en directo ni muestra en
    su vista live: su cuota es la de antes del partido (tras un gol, 5.40 frente al 1.21 real) y duplica el código."""
    typ = (bo.get("betOfferType") or {}).get("id")
    label = (bo.get("criterion") or {}).get("label") or ""
    if typ not in (1, 2, 6, 7, 18, 21, 127) or _SKIP.search(label):
        return []
    if live:
        tags = bo.get("tags")
        if tags and "OFFERED_LIVE" not in tags:
            return []
    if bo.get("suspended") or (bo.get("betOfferStatus") not in (None, "OPEN")):
        return []
    title = _clean(label)
    outs = [o for o in bo.get("outcomes") or [] if o.get("status") in (None, "OPEN") and o.get("odds")]
    if not outs:
        return []
    out: list[dict] = []
    if typ == 127:                                          # props de jugador con línea
        for o in outs:
            player = o.get("participant")
            if not player:
                continue
            info = classify(title, sport, home, away, player=player)
            if not info:
                continue
            sel = _OT.get(o.get("type"))
            line = _line(o.get("line"))
            if sel == "Yes":                                # "Anotará" (línea 1.0 = 1 o más) -> Over 0.5
                sel = "Over"
                line = (line - 0.5) if line is not None else implied_line(title)
            if sel not in ("Over", "Under") or line is None:
                continue
            out.append({"market": info.market, "selection": sel, "line": line, "player": player, "price": _price(o["odds"]), "oid": o.get("id")})
        return out
    if typ in (6, 21):                                      # más/menos
        info = classify(title, sport, home, away, kind="total")
        if not info:
            return []
        for o in outs:
            sel = _OT.get(o.get("type"))
            if sel in ("Over", "Under") and o.get("line") is not None:
                out.append({"market": info.market, "selection": sel, "line": _line(o["line"]), "price": _price(o["odds"]), "oid": o.get("id")})
        return out
    if typ in (1, 7):                                       # hándicap (2 vías); cada pata con su propio hándicap
        info = classify(title, sport, home, away, kind="handicap")
        if not info:
            return []
        for o in outs:
            sel = _OT.get(o.get("type"))
            if sel is None:                                 # asiático: OT_UNTYPED -> por participante
                sel = "1" if o.get("participant") == home else "2" if o.get("participant") == away else None
            if sel in ("1", "2") and o.get("line") is not None:
                out.append({"market": info.market, "selection": sel, "line": _line(o["line"]), "price": _price(o["odds"]), "oid": o.get("id")})
        return out
    if typ == 18:                                           # sí/no: solo "ambos marcan"
        info = classify(title, sport, home, away, kind="btts") if re.search(r"ambos equipos", title, re.I) else None
        if not info:
            return []
        for o in outs:
            sel = _OT.get(o.get("type"))
            if sel in ("Yes", "No"):
                out.append({"market": info.market, "selection": sel, "line": None, "price": _price(o["odds"]), "oid": o.get("id")})
        return out
    # typ 2: resultado / ganador / sin empate (1X2, 1X2_1H, 1X2_Q1, 1X2_SET3, DNB…)
    kind = "dnb" if re.search(r"sin empate|con empate no hay apuesta|draw no bet", title, re.I) else "result"   # Kambi: «Con empate no hay apuesta - Prórroga»
    if kind == "result" and re.search(r"tiros|esquina|tarjeta|saque|c[oó]rner", title, re.I):
        return []                                           # "Más tiros de esquina": no es 1X2
    info = classify(title, sport, home, away, kind=kind)
    if not info:
        return []
    for o in outs:
        sel = _OT.get(o.get("type"))
        if sel in ("1", "X", "2"):
            out.append({"market": info.market, "selection": sel, "line": None, "price": _price(o["odds"]), "oid": o.get("id")})
    return out


# ──────────────────────────────────────────────────────────────────────────────

# Pestaña de la ficha Kambi en la que está cada mercado (URL real comprobada por el usuario 2026-11-15:
# …#event/<id>/tab/3-cuarto, …#event/<id>/tab/partido). Sólo se añade cuando la pestaña es conocida;
# el resto de mercados enlaza a la ficha sin pestaña (abre la primera).
def _tab_for(market: str) -> str | None:
    m = re.search(r"_Q([1-4])$", market or "")
    if m:
        return f"{m.group(1)}-cuarto"
    if market and not re.search(r"_(1H|2H|SET\d|SETS|OT)$|^(PLAYER|CORNERS|CARDS|YELLOW|SHOTS|FOULS)", market):
        return "partido"
    return None


def _sel_url(base: str, sl: dict, oid) -> str:
    tab = _tab_for(sl.get("market") or "")
    return f"{base}{('/tab/' + tab) if tab else ''}?coupon=single|{oid}"

class Collector:
    def __init__(self, cfg: dict, cfg_path: Path):
        self.cfg, self.cfg_path = cfg, cfg_path
        self._cfg_mtime = cfg_path.stat().st_mtime
        self.bk = cfg["bookmaker"]
        self.base = cfg.get("api_base", "https://eu-offering-api.kambicdn.com/offering/v2018").rstrip("/") + "/" + cfg["offering"]
        self.q = {"lang": cfg.get("lang", "es_ES"), "market": cfg.get("market", "ES")}
        self.http = Http(cfg.get("origin", "https://eu-offering-api.kambicdn.com"), cfg.get("transport", "requests"),
                         cfg.get("headers"), cfg.get("start_url"), cfg.get("workers", 4), gap=cfg.get("request_gap"),
                         api_hint="/offering/", pace_group=cfg.get("pace_group"))
        self.store = OddsStore(bookmaker=self.bk)
        # Casas «espejo»: misma empresa y mismo libro Kambi (cuotas idénticas, comprobado), p.ej. Speedybet = Paf.
        # Se escriben las mismas filas bajo su nombre y con sus enlaces, sin descargar nada dos veces.
        self.mirrors = [(m["bookmaker"], OddsStore(bookmaker=m["bookmaker"]), m.get("event_url") or cfg.get("event_url", ""))
                        for m in cfg.get("mirrors") or []]
        self.catalog = Competitions()
        self.demand = Demand(self.bk, also_mine=tuple(m[0] for m in self.mirrors))
        self.groups: dict[int, tuple[str, str, str]] = {}        # groupId -> (sport, competición, path)
        self._groups_at = 0.0
        self._last_prematch = 0.0
        self._pm_queue: list = []
        self._live_off = 0
        self._skipped = 0
        self._live_ids: set[str] = set()
        # Push (websocket de Kambi): las fichas se descargan una vez y el socket las mantiene al día → el ciclo live
        # no sondea fichas (solo open.json + eventos nuevos + un refresco rotatorio). `"push": false` lo desactiva.
        self.push = None
        if cfg.get("push", True):
            from kambi_push import KambiPush
            origin = re.match(r"https?://[^/]+", cfg.get("event_url") or "")
            self.push = KambiPush(cfg["offering"], origin=origin.group(0) if origin else "https://www.kambi.com").start()
        self._push_note = ""

    # ── helpers ──
    def url(self, path: str, **params) -> str:
        q = dict(self.q)
        q.update({k: v for k, v in params.items() if v is not None})
        return f"{self.base}/{path}?{urlencode(q)}"

    def get(self, path: str, **params):
        st, js = self.http.get(self.url(path, **params))
        if st != 200 or not isinstance(js, dict):
            raise RuntimeError(f"{path} -> HTTP {st}")
        return js

    @staticmethod
    def _check_limits(res: list) -> None:
        """Kambi devuelve 429 si se abusa: se aborta el ciclo para que entre el backoff (2 s -> 60 s)."""
        n429 = sum(1 for st, _ in res if st == 429)
        if n429 and n429 >= max(1, len(res) // 3):
            raise RuntimeError(f"HTTP 429 en {n429}/{len(res)} peticiones (límite de Kambi)")

    def _reload_if_changed(self):
        self.catalog.reload()
        mt = self.cfg_path.stat().st_mtime
        if mt != self._cfg_mtime:
            import pace
            self.cfg = pace.apply(json.loads(self.cfg_path.read_text(encoding="utf-8")))
            self._cfg_mtime = mt
            log.info("%s recargado", self.cfg_path.name)

    # ── catálogo ──
    def refresh_groups(self, force: bool = False) -> None:
        if not force and time.time() - self._groups_at < self.cfg.get("groups_ttl", 900):
            return
        data = self.get("group.json")
        groups: dict[int, tuple[str, str, str]] = {}
        for s in (data.get("group") or {}).get("groups") or []:
            sport = SPORT_KEY.get(s.get("termKey"))
            if not sport:
                continue
            for c in s.get("groups") or []:
                subs = c.get("groups") or []
                items = [(f"{c['name']} - {l['name']}", l, f"{s['termKey']}/{c['termKey']}/{l['termKey']}") for l in subs] \
                    if subs else [(c["name"], c, f"{s['termKey']}/{c['termKey']}")]
                for label, g, path in items:
                    comp = self._match(sport, label)
                    if comp:
                        groups[int(g["id"])] = (sport, comp, path)
        extra = self.cfg.get("extra_groups") or {}
        for gid, (sport, comp, path) in extra.items():
            groups[int(gid)] = (sport, comp, path)
        self.groups, self._groups_at = groups, time.time()
        log.info("%d competiciones mapeadas en Kambi/%s", len(groups), self.cfg["offering"])

    def _match(self, sport: str, label: str) -> str | None:
        if _EXCLUDE.search(label):
            return None
        return self.catalog.match(self.bk, sport, label)

    def _group_for(self, ev: dict) -> tuple[str, str, str] | None:
        """(deporte, competición, path) de un evento: por groupId o, si el grupo no está en el árbol, por su `path`."""
        g = self.groups.get(int(ev.get("groupId") or 0))
        if g:
            return g
        path = ev.get("path") or []
        if len(path) < 2:
            return None
        sport = SPORT_KEY.get(path[0].get("termKey"))
        if not sport:
            return None
        label = " - ".join(p.get("name", "") for p in path[1:])
        comp = self._match(sport, label)
        if comp:
            g = (sport, comp, "/".join(p.get("termKey", "") for p in path))
            self.groups[int(ev.get("groupId") or 0)] = g
            return g
        return None

    # ── eventos ──
    def _event_row(self, ev: dict, sport: str, comp: str, live: dict | None = None) -> dict:
        home, away = ev.get("homeName") or "", ev.get("awayName") or ""
        if not home and " - " in (ev.get("name") or ""):
            home, away = ev["name"].split(" - ", 1)
        dt = None
        try:
            dt = datetime.fromisoformat(ev["start"].replace("Z", "+00:00")).astimezone()
        except Exception:  # noqa: BLE001
            pass
        row = {"event_id": str(ev["id"]), "home": home, "away": away, "competition": comp,
               "date": dt.strftime("%Y-%m-%d") if dt else None, "start_time": dt.strftime("%H:%M") if dt else None,
               "url": self.cfg.get("event_url", "").format(id=ev["id"], sport=sport, path=ev.get("_path", "")),
               "selections": []}
        if live:
            sc, clk = live.get("score") or {}, live.get("matchClock") or {}
            if sc.get("home") is not None:
                row["score"] = f"{sc.get('home')}:{sc.get('away')}"
            if sport == "tenis":
                # en tenis `score` son los PUNTOS del juego en curso (30:0); los juegos por set van en statistics.sets
                sets = ((live.get("statistics") or {}).get("sets") or {})
                hs, as_ = sets.get("home") or [], sets.get("away") or []
                pairs = [f"{h}:{a}" for h, a in zip(hs, as_) if h is not None and a is not None and h >= 0 and a >= 0]
                if pairs:
                    row["score"] = " ".join(pairs) + (" -:-" if len(pairs) == 1 else "")
                else:
                    row.pop("score", None)          # solo puntos: mejor sin marcador que uno engañoso
            row["period"] = clk.get("period") or live.get("periodLabel")
            if clk.get("minute") is not None:
                row["timer"] = f"{int(clk['minute']):02d}:{int(clk.get('second') or 0):02d}"
        return row

    def live_events(self) -> list[tuple[dict, str, str, dict]]:
        st, data = self.http.get(self.url("event/live/open.json"))
        if st == 404 and isinstance(data, dict) and "live" in str((data.get("error") or {}).get("message", "")).lower():
            data = {"liveEvents": []}        # Kambi responde 404 "No open live events found" cuando la casa no tiene nada en directo
        elif st != 200 or not isinstance(data, dict):
            raise RuntimeError(f"event/live/open.json -> HTTP {st}")
        out = []
        for le in data.get("liveEvents") or []:
            ev = le.get("event") or {}
            g = self._group_for(ev)
            if g:
                ev["_main"] = le.get("mainBetOffer")                     # mercado principal (1X2 / ganador): viene en open.json
                out.append((ev, g[0], g[1], le.get("liveData") or {}))
        return out

    def _main_rows(self, evs: list) -> dict[str, list[dict]]:
        """Filas «parciales» con el mercado principal de TODOS los eventos live en una sola petición (open.json):
        el 1X2/ganador y el marcador se refrescan en cada ciclo aunque la ficha completa se detalle por turnos."""
        by_sport: dict[str, list[dict]] = {}
        for ev, sport, comp, live in evs:
            bo = ev.get("_main")
            if not bo:
                continue
            row = self._event_row(ev, sport, comp, live)
            row["partial"] = True
            row["selections"] += betoffer_selections(bo, sport, row["home"], row["away"], live=True)
            base = row.get("url") or ""
            for sl in row["selections"]:
                oid = sl.pop("oid", None)
                if oid and base:
                    sl["url"] = _sel_url(base, sl, oid)
            if row["selections"]:
                by_sport.setdefault(sport, []).append(row)
        return by_sport

    def prematch_events(self) -> tuple[dict[str, list[dict]], list[tuple[dict, str, str]]]:
        """listView por competición: devuelve (filas con mercados principales por deporte, eventos candidatos a detalle)."""
        paths = {gid: g for gid, g in self.groups.items()}
        urls = [self.url(f"listView/{g[2]}.json", useCombined="true") for g in paths.values()]
        res = self.http.get_many(urls)
        self._check_limits(res)
        horizon = datetime.now(timezone.utc) + timedelta(hours=self.cfg.get("prematch_hours", 48))
        by_sport: dict[str, list[dict]] = {}
        cands: list[tuple[dict, str, str]] = []
        for (gid, (sport, comp, path)), (st, js) in zip(paths.items(), res):
            if st != 200 or not isinstance(js, dict):
                continue
            for item in js.get("events") or []:
                ev = item.get("event") or {}
                if ev.get("state") != "NOT_STARTED" or "MATCH" not in (ev.get("tags") or []):
                    continue
                try:
                    if datetime.fromisoformat(ev["start"].replace("Z", "+00:00")) > horizon:
                        continue
                except Exception:  # noqa: BLE001
                    pass
                ev["_path"] = path
                row = self._event_row(ev, sport, comp)
                row["partial"] = True                       # solo mercados principales: no retira las líneas del detalle
                for bo in item.get("betOffers") or []:
                    row["selections"] += betoffer_selections(bo, sport, row["home"], row["away"])
                by_sport.setdefault(sport, []).append(row)
                cands.append((ev, sport, comp))
        return by_sport, cands

    def _demand(self, evs: list) -> list:
        if not self.cfg.get("demand_only", True):
            return evs
        out = self.demand.filter(evs, lambda it: (it[1], it[0].get("homeName") or "", it[0].get("awayName") or ""))
        self._skipped = len(evs) - len(out)
        return out

    def details(self, evs: list, kind: str) -> dict[str, list[dict]]:
        urls = [self.url(f"betoffer/event/{it[0]['id']}.json", type=self.cfg.get("detail_types", DETAIL_TYPES)) for it in evs]
        res = self.http.get_many(urls)
        self._check_limits(res)
        by_sport: dict[str, list[dict]] = {}
        for it, (st, js) in zip(evs, res):
            ev, sport, comp = it[0], it[1], it[2]
            live = it[3] if len(it) > 3 else None
            if st != 200 or not isinstance(js, dict):
                continue
            if kind == "prematch":
                # La cola de detalle pre-partido tarda minutos: si el partido ha empezado mientras tanto, su ficha ya
                # es la de directo (cientos de mercados) y guardarla como pre-partido duplica el evento (mismo código,
                # distinta cuota) y lo baila entre pasadas. El estado viene en la propia ficha.
                st_ev = next((e.get("state") for e in js.get("events") or [] if str(e.get("id")) == str(ev["id"])), None)
                if st_ev not in (None, "NOT_STARTED") or str(ev["id"]) in self._live_ids:
                    continue
            row = self._event_row(ev, sport, comp, live)
            for bo in js.get("betOffers") or []:
                row["selections"] += betoffer_selections(bo, sport, row["home"], row["away"], live=(kind == "live"))
            base = row.get("url") or ""
            for sl in row["selections"]:                       # enlace directo verificado: #event/<id>?coupon=single|<outcomeId>
                oid = sl.pop("oid", None)
                if oid and base:
                    sl["url"] = _sel_url(base, sl, oid)
            by_sport.setdefault(sport, []).append(row)
        return by_sport

    def _save(self, by_sport: dict[str, list[dict]], kind: str) -> tuple[int, int]:
        rows = changed = 0
        for sport, rs in by_sport.items():
            changed += self.store.save_rows(sport, kind, rs)
            rows += len(rs)
            for _bk, st, tpl in self.mirrors:
                st.save_rows(sport, kind, self._mirror_rows(rs, sport, tpl))
        return rows, changed

    def _mirror_rows(self, rs: list[dict], sport: str, tpl: str) -> list[dict]:
        """Copia de las filas con los enlaces de la casa espejo (mismo #event/<id>?coupon=single|<oid>)."""
        out = []
        for r in rs:
            old = r.get("url") or ""
            new = tpl.format(id=r["event_id"], sport=sport, path="") if tpl else old
            m = dict(r, url=new)
            m["selections"] = [dict(sl, url=sl["url"].replace(old, new, 1)) if old and sl.get("url") else dict(sl)
                               for sl in r["selections"]]
            out.append(m)
        return out

    def _sweep(self, ids: set[str], kind: str) -> None:
        self.store.sweep(ids, kind)
        for _bk, st, _t in self.mirrors:
            st.sweep(ids, kind)

    # ── ciclos ──
    def _live_cycle_push(self, evs: list) -> tuple[int, int]:
        """Modo push: fichas desde la caché del websocket; HTTP solo para eventos nuevos y un refresco rotatorio."""
        push = self.push
        ids = {int(ev["id"]) for ev, *_ in evs}
        push.drop(ids)
        cached = push.cached()
        n = self.cfg.get("max_detail_per_cycle", 40)
        fetch = [it for it in evs if int(it[0]["id"]) not in cached][:n]
        if len(fetch) < n:
            k = n if push.expired() else self.cfg.get("push_refresh_per_cycle", 2)    # tras reconectar: a tope
            old = set(push.oldest(min(k, n - len(fetch)), min_age=self.cfg.get("push_refresh_min_age", 300)))
            fetch += [it for it in evs if int(it[0]["id"]) in old]
        if fetch:
            urls = [self.url(f"betoffer/event/{it[0]['id']}.json", type=self.cfg.get("detail_types", DETAIL_TYPES)) for it in fetch]
            res = self.http.get_many(urls)
            self._check_limits(res)
            for it, (st, js) in zip(fetch, res):
                if st == 200 and isinstance(js, dict):
                    push.put(int(it[0]["id"]), js)
        by_sport: dict[str, list[dict]] = {}
        from_cache = 0
        for ev, sport, comp, live in evs:
            eid = int(ev["id"])
            bos = push.betoffers(eid)
            pl = push.live_data(eid)
            live = dict(live or {})
            if pl.get("score"):
                live["score"] = pl["score"]
            if pl.get("matchClock"):
                live["matchClock"] = pl["matchClock"]
            if pl.get("statistics"):
                live["statistics"] = pl["statistics"]
            row = self._event_row(ev, sport, comp, live)
            if bos is None:                                             # ficha aún no descargada: principal de open.json
                bos = [ev["_main"]] if ev.get("_main") else []
                row["partial"] = True
            else:
                from_cache += 1
            for bo in bos:
                row["selections"] += betoffer_selections(bo, sport, row["home"], row["away"], live=True)
            base = row.get("url") or ""
            for sl in row["selections"]:
                oid = sl.pop("oid", None)
                if oid and base:
                    sl["url"] = _sel_url(base, sl, oid)
            if row["selections"] or not row.get("partial"):
                by_sport.setdefault(sport, []).append(row)
        self._push_note = f"push {from_cache} fichas en caché, {len(fetch)} descargadas, {push.msgs} msgs"
        return self._save(by_sport, "live")

    def live_cycle(self) -> tuple[int, int]:
        evs = self.live_events()
        self._live_ids = {str(e["id"]) for e, *_ in evs}
        self._sweep(self._live_ids, "live")                             # open.json completo: lista fiable
        evs = self._demand(evs)
        if self.push is not None and self.push.fresh():
            return self._live_cycle_push(evs)
        self._push_note = "push desconectado → sondeo" if self.push is not None else ""
        main_rows, main_chg = self._save(self._main_rows(evs), "live")   # principal + marcador de todos, 0 peticiones extra
        n = self.cfg.get("max_detail_per_cycle", 40)
        if len(evs) > n:
            off = self._live_off % len(evs)
            evs = (evs + evs)[off: off + n]
            self._live_off = off + n
        rows, chg = self._save(self.details(evs, "live"), "live")
        return max(rows, main_rows), chg + main_chg


    # ── pre-partido en segundo plano (pace.Background): el bucle live no espera por listas ni fichas pre-partido ──
    def _pm_inline(self, once: bool) -> bool:
        http = getattr(self, "http", None) or getattr(getattr(self, "api", None), "http", None)
        name = getattr(http, "name", None) or getattr(http, "mode", "") or ""
        return once or "browser" in str(name) or "chrome" in str(name)   # el navegador no se comparte entre hilos

    def _pm_schedule(self, t0: float, once: bool, msg: str) -> str:
        bg = self.__dict__.setdefault("_bg", __import__("pace").Background(f"{getattr(self, 'bk', 'prematch')}-prematch"))
        if not bg.busy():
            job = self._pm_job(t0, once)
            if job is not None:
                try:
                    r = bg.run(job, inline=self._pm_inline(once))
                finally:
                    __import__("transport").low_priority(False)         # si corrió en este hilo, el live recupera prioridad
                if r:
                    msg += " | " + r
        note = bg.note()
        if note:
            msg += " | " + note
        return msg

    def _pm_job(self, t0: float, once: bool):
        if not self._pm_queue and t0 - self._last_prematch >= self.cfg.get("interval_prematch", 30):
            def _list():
                __import__("transport").low_priority(True)              # el live tiene preferencia en el ritmo compartido
                by_sport, cands = self.prematch_events()
                self._sweep({r["event_id"] for rs in by_sport.values() for r in rs}, "prematch")
                prow, pchg = self._save(by_sport, "prematch")          # mercados principales de todos
                self._pm_queue = self._demand(cands)[: self.cfg.get("max_prematch_detail", 400)]
                self._last_prematch = time.time()
                out = f"prematch lista {prow} ev / {pchg} cambios"
                if once and self._pm_queue:
                    out += " | " + self._pm_job(time.time(), once)()
                return out
            return _list
        if self._pm_queue:
            batch = len(self._pm_queue) if once else max(1, self.cfg.get("prematch_batch", 6))
            chunk, self._pm_queue = self._pm_queue[:batch], self._pm_queue[batch:]
            def _detail():
                __import__("transport").low_priority(True)
                prow, pchg = self._save(self.details(chunk, "prematch"), "prematch")
                return f"prematch detalle {prow} ev / {pchg} cambios ({len(self._pm_queue)} pendientes)"
            return _detail
        return None

    def run(self, once: bool = False):
        backoff = 2
        while True:
            t0 = time.time()
            try:
                self._reload_if_changed()
                self.refresh_groups()
                rows, changed = self.live_cycle()
                msg = f"live {rows} ev / {changed} cambios"
                if self._push_note:
                    msg += f" [{self._push_note}]"
                if self._skipped:
                    msg += f" ({self._skipped} sin pareja en otras casas, no detallados)"
                msg = self._pm_schedule(t0, once, msg)
                for bk in (self.bk, *(m[0] for m in self.mirrors)):
                    self.store.set_status(**{f"{bk}_last_ok": time.time(), f"{bk}_live_events": rows,
                                             f"{bk}_transport": self.http.name + ("+push" if self.push is not None and self.push.fresh() else "") + ("" if bk == self.bk else f" (espejo de {self.bk})")})
                log.info("%s [%s] (%.1fs)", msg, self.http.name, time.time() - t0)
                backoff = 2
                if once:
                    return
            except Exception as e:  # noqa: BLE001
                log.warning("error de ciclo: %s — reintento en %ss", e, backoff, exc_info=log.isEnabledFor(logging.DEBUG))
                for bk in (self.bk, *(m[0] for m in self.mirrors)):
                    self.store.set_status(**{f"{bk}_last_error": f"{time.time():.0f} {e}"})
                time.sleep(backoff)
                backoff = min(backoff * 2, 60)
                continue
            if self.push is not None and self.push.fresh():            # con push el ciclo apenas pide (open.json): más rápido
                wait = float(self.cfg.get("interval_live_push", 2))
            else:
                wait = self.cfg.get("interval_live", 5)
            time.sleep(max(0.5, wait - (time.time() - t0)))


def list_catalog(c: Collector):
    data = c.get("group.json")
    for s in (data.get("group") or {}).get("groups") or []:
        sport = SPORT_KEY.get(s.get("termKey"))
        if not sport:
            continue
        print(f"\n=== {sport} ({s['name']}, {s.get('eventCount')} eventos)")
        for cc in s.get("groups") or []:
            subs = cc.get("groups") or []
            items = [(f"{cc['name']} - {l['name']}", l) for l in subs] if subs else [(cc["name"], cc)]
            for label, g in items:
                comp = c._match(sport, label)
                if comp or (g.get("eventCount") or 0) >= 5:
                    print(f" {'✔' if comp else ' '} {label}   [{g['id']}] eventos={g.get('eventCount')}" + (f"  -> {comp}" if comp else ""))


def main():
    logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"),
                        format="%(asctime)s %(levelname)s %(name)s: %(message)s", datefmt="%H:%M:%S")
    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    cfg_name = sys.argv[sys.argv.index("--cfg") + 1] if "--cfg" in sys.argv else os.getenv("KAMBI_CFG", "leovegas.json")
    cfg_path = Path(cfg_name) if os.path.isabs(cfg_name) else Path(__file__).parent / cfg_name
    import pace
    cfg = pace.apply(json.loads(cfg_path.read_text(encoding="utf-8")))
    log.name = cfg.get("bookmaker", "kambi")
    c = Collector(cfg, cfg_path)
    if "--list" in sys.argv:
        list_catalog(c)
        return
    if "--links" in sys.argv:                                # URLs candidatas de enlace directo a una selección
        c.refresh_groups(force=True)
        evs = c.live_events()
        if not evs:
            _, pre = c.prematch_events()
            evs = [(ev, sport, comp, {}) for ev, sport, comp in pre]
        for ev, sport, comp, live in evs[:5]:
            js = c.get(f"betoffer/event/{ev['id']}.json", type=DETAIL_TYPES)
            bo = next((b for b in (js or {}).get("betOffers") or [] if any(_price(o.get("odds")) for o in b.get("outcomes") or [])), None)
            if not bo:
                continue
            o = next(o for o in bo["outcomes"] if _price(o.get("odds")))
            eid, oid, bid = ev["id"], o["id"], bo["id"]
            base = c.cfg.get("event_url", "").format(id=eid, sport=sport, path=ev.get("_path", ""))
            root = base.split("#")[0]
            print(f"Partido: {ev.get('name')}  eventId={eid}")
            print(f"Apuesta: {(bo.get('criterion') or {}).get('label')!r} -> selección {o.get('label')!r} @{_price(o.get('odds'))}  "
                  f"betOfferId={bid} outcomeId={oid}\n")
            print("Abre cada URL en incógnito y dime cuál deja la selección ya marcada en la cesta:")
            for i, u in enumerate([
                f"{root}#event/{eid}?coupon=single|{oid}",
                f"{root}#event/{eid}?coupon=single%7C{oid}",
                f"{root}#bet/{oid}",
                f"{root}#betslip/{oid}",
                f"{root}#event/{eid}/betoffer/{bid}/outcome/{oid}",
                f"{root}#coupon/single/{oid}",
                f"{root}?coupon=single|{oid}#event/{eid}",
                f"{root}#event/{eid}?outcome={oid}",
            ], 1):
                print(f"  {i}. {u}")
            return
        print("sin eventos con cuotas")
        return
    if "--dump" in sys.argv:                                 # mercados en bruto de los directos: etiqueta Kambi -> código nuestro
        c.refresh_groups(force=True)
        for ev, sport, comp, live in c.live_events()[:3]:
            print(f"\n=== {ev.get('name')} [{ev['id']}] {sport} {comp} {live.get('score')}")
            js = c.get(f"betoffer/event/{ev['id']}.json", type=DETAIL_TYPES)
            for bo in (js or {}).get("betOffers") or []:
                label = (bo.get("criterion") or {}).get("label", "")
                outs = " | ".join(f"{o.get('label')} {_line(o.get('line')) if o.get('line') is not None else ''} @{_price(o.get('odds'))}"
                                  for o in bo.get("outcomes") or [])
                mapped = betoffer_selections(bo, sport, ev.get("homeName", ""), ev.get("awayName", ""))
                codes = ", ".join(f"{m['market']}|{m['selection']}|{m['line']}" for m in mapped) or "-"
                print(f"  [{bo.get('betOfferType', {}).get('id')}] {label!r}: {outs}\n        -> {codes}")
        return
    c.run(once="--once" in sys.argv)


if __name__ == "__main__":
    main()
