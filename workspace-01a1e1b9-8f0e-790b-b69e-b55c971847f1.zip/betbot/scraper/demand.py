"""
Descarga bajo demanda: qué partidos merece la pena detallar en una casa.

Una surebet/middle necesita el MISMO partido en al menos dos casas. Por tanto, un colector
"caro" (Betsson: bloquea la IP si se les pide demasiado) solo necesita bajar
los mercados de los partidos que ya existen en odds.db por otra casa. Los demás no pueden
generar ninguna señal y no se piden.

    d = Demand(me="betsson")
    d.refresh()                              # lee odds.db (cache 20 s)
    d.wanted("futbol", "Real Madrid", "Getafe CF")   -> True/False

Si en odds.db no hay NINGÚN evento de otras casas (colectores parados, BD recién creada)
`wanted` devuelve True para todo: mejor pasarse que quedarse ciego.
"""
from __future__ import annotations

import re
import sqlite3
import time
import unicodedata
from pathlib import Path

from storage import DB_PATH

_STOP = {"fc", "cf", "club", "de", "the", "sc", "ud", "cd", "bk", "rc", "sd", "ac", "as", "ss", "us", "bc", "kk",
         "if", "fk", "sk", "cska", "b", "ii", "w", "women", "femenino", "femenina", "u19", "u21", "u20", "u23"}
_ALIASES = {"utd": "united", "man": "manchester", "atl": "atletico", "ath": "athletic", "dep": "deportivo",
            "spo": "sporting", "int": "inter", "bor": "borussia", "olymp": "olympique", "st": "saint", "psg": "paris",
            "rb": "red bull"}


def _tokens(name: str) -> frozenset[str]:
    s = unicodedata.normalize("NFKD", name or "").encode("ascii", "ignore").decode().lower()
    s = re.sub(r"[^a-z0-9 ]", " ", s)
    out = set()
    for w in s.split():
        w = _ALIASES.get(w, w)
        if w not in _STOP and len(w) > 1:
            out.add(w)
    return frozenset(out)


def _sim(a: frozenset, b: frozenset) -> float:
    if not a or not b:
        return 0.0
    inter = len(a & b)
    if not inter:
        return 0.0
    return inter / min(len(a), len(b))          # contención: "Real Madrid" ~ "Real Madrid CF"


class Demand:
    def __init__(self, me: str, db_path: Path = DB_PATH, ttl: float = 20.0, max_age: float = 900.0, threshold: float = 0.5,
                 also_mine: tuple[str, ...] = ()):
        """`also_mine`: casas «espejo» que escribe este mismo proceso (mismas cuotas): no cuentan como pareja."""
        self.me, self.db_path, self.ttl, self.max_age, self.threshold = me, Path(db_path), ttl, max_age, threshold
        self.mine = (me,) + tuple(also_mine)
        self._at = 0.0
        self._by_sport: dict[str, list[tuple[frozenset, frozenset]]] = {}
        self.others = 0

    def refresh(self) -> None:
        if time.time() - self._at < self.ttl:
            return
        self._at = time.time()
        by_sport: dict[str, list[tuple[frozenset, frozenset]]] = {}
        n = 0
        try:
            con = sqlite3.connect(f"file:{self.db_path}?mode=ro", uri=True, timeout=5)
            try:
                ph = ",".join("?" * len(self.mine))
                rows = con.execute(f"SELECT sport, home, away FROM events WHERE bookmaker NOT IN ({ph}) AND last_seen>?",
                                   (*self.mine, time.time() - self.max_age)).fetchall()
            finally:
                con.close()
        except sqlite3.Error:
            rows = []
        for sport, home, away in rows:
            h, a = _tokens(home), _tokens(away)
            if h and a:
                by_sport.setdefault((sport or "").lower(), []).append((h, a))
                n += 1
        self._by_sport, self.others = by_sport, n

    def wanted(self, sport: str, home: str, away: str) -> bool:
        self.refresh()
        if not self.others:
            return True
        h, a = _tokens(home), _tokens(away)
        th = self.threshold
        for oh, oa in self._by_sport.get((sport or "").lower(), ()):
            if (_sim(h, oh) >= th and _sim(a, oa) >= th) or (_sim(h, oa) >= th and _sim(a, oh) >= th):
                return True
        return False

    def filter(self, items: list, key) -> list:
        """items cuyo key(item) -> (sport, home, away) exista en otra casa."""
        return [it for it in items if self.wanted(*key(it))]
