"""
MatchingService: decide si una Bet aplica a un User según sus filtros.
"""
from __future__ import annotations
from domain.models import Bet, User


class MatchingService:

    def matches(self, bet: Bet, user: User) -> bool:
        f = user.filters

        # ── Tipo activo ────────────────────────────────────
        if bet.is_surebet and not f.surebets_enabled:
            return False

        # ── Profit mínimo por tipo ─────────────────────────
        if bet.is_middle and not f.middlebets_marked:      # el usuario puede desactivar los middles
            return False
        # ROI mínimo: se aplica a surebets y también a middles (su profit_pct es el peor caso,
        # es decir, lo garantizado aunque no entre en el hueco).
        if bet.is_surebet and bet.profit_pct < f.surebet_min_profit:
            return False

        # ── Casas ─────────────────────────────────────────
        active_bks = f.surebet_bookmakers
        if active_bks:
            bet_bks = bet.bookmaker_keys()
            # Todas las patas de la bet deben estar entre las casas activas
            if not bet_bks or not all(b in active_bks for b in bet_bks):
                return False

        # ── Directo / pre-partido ──────────────────────────
        is_live = (bet.period or "").upper().startswith("LIVE")
        if is_live and not f.live_enabled:
            return False
        if not is_live and not f.prematch_enabled:
            return False

        # ── Deportes ───────────────────────────────────────
        if f.sports and bet.sport_key not in f.sports:
            return False

        return True

    def is_muted(self, user: User) -> bool:
        return user.is_muted_now()
