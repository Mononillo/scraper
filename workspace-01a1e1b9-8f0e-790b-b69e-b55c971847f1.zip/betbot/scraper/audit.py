"""Auditoría de odds.db en un solo fichero de texto para revisar mapeos y salud de TODAS las casas.

    python audit.py                      -> escribe data/audit.txt (y lo resume por pantalla)
    python audit.py --out C:\\tmp\\a.txt    -> otra ruta
    python audit.py --full               -> además vuelca la tabla completa de títulos -> mercado de cada casa

Secciones del informe:
  1. SALUD      estado de cada colector (último OK, transporte, error, eventos pre/live y antigüedad)
  2. COBERTURA  cuántos eventos de cada casa se emparejan con alguna otra casa (y ejemplos de los que no)
  3. MERCADOS   códigos de mercado que SOLO produce una casa (sospecha de nombre mal mapeado)
  4. SOSPECHAS  mismas selecciones en varias casas con cuotas incoherentes: beneficio de surebet > 0,5 % o cuota
                que se aleja > 30 % de la mediana del resto -> casi siempre un mapeo distinto con el mismo código
  5. TÍTULOS    (con --full) título crudo -> mercado, por casa y deporte (tabla market_map)
Se ejecuta con los colectores en marcha; no escribe en la base de datos.
"""
from __future__ import annotations

import os
import re
import sqlite3
import sys
import time
import unicodedata
from collections import defaultdict
from statistics import median

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:  # noqa: BLE001
    pass

HERE = os.path.dirname(os.path.abspath(__file__))
DB = os.getenv("ODDS_DB", os.path.join(HERE, "..", "data", "odds.db"))
if DB.startswith("/app/") and not os.path.exists(DB):
    DB = os.path.join(HERE, "..", DB[len("/app/"):])
OUT = os.path.join(HERE, "..", "data", "audit.txt")
if "--out" in sys.argv:
    OUT = sys.argv[sys.argv.index("--out") + 1]
FULL = "--full" in sys.argv

_STOP = {"del", "the", "los", "las", "fc", "cf", "club", "de", "the", "sc", "ud", "cd", "bk", "rc", "ac", "as", "ss", "us", "bc", "kk", "fk", "sk",
         "real", "atletico", "athletic", "sporting", "deportivo", "racing", "union", "inter", "dinamo", "dynamo", "city",
         "united", "town", "b", "ii", "w", "women", "femenino", "fem", "sub", "u19", "u20", "u21", "u23", "ii"}
_CYR = str.maketrans({"а": "a", "б": "b", "в": "v", "г": "g", "д": "d", "е": "e", "ё": "e", "ж": "zh", "з": "z", "и": "i",
                      "й": "i", "к": "k", "л": "l", "м": "m", "н": "n", "о": "o", "п": "p", "р": "r", "с": "s", "т": "t",
                      "у": "u", "ф": "f", "х": "h", "ц": "c", "ч": "ch", "ш": "sh", "щ": "sch", "ъ": "", "ы": "y", "ь": "",
                      "э": "e", "ю": "yu", "я": "ya"})


def _norm(s: str) -> str:
    s = (s or "").lower().translate(_CYR)
    s = unicodedata.normalize("NFKD", s).encode("ascii", "ignore").decode()
    return re.sub(r"[^a-z0-9 ]", " ", s)


# mismos alias que el bot (bot/services/signals.py) para que la cobertura de la auditoría refleje lo que el bot empareja
_WORD_ALIASES = {"azerbayan": "azerbaiyan", "azerbaijan": "azerbaiyan", "faroe": "feroe", "faroes": "feroe",
                 "northern": "norte", "ireland": "irlanda", "north": "norte", "republic": "", "rep": "", "of": "",
                 "and": "", "herzegovina": "", "czech": "checa", "czechia": "checa", "chequia": "checa",
                 "ratiopharm": "", "spqr": "", "basketball": "", "baloncesto": "", "basket": ""}


def _toks(name: str) -> set[str]:
    return {w2 for w in _norm(name).split() for w2 in [_WORD_ALIASES.get(w, w)] if len(w2) >= 3 and w2 not in _STOP}


def _pkey(p: str) -> str:
    t = _norm(p).split()
    if not t:
        return ""
    return f"{t[0][:3]}:{t[-1]}" if len(t) > 1 else t[0]


def _age(now: float, ts) -> str:
    if not ts:
        return "   -  "
    s = now - float(ts)
    return f"{s:5.0f}s" if s < 600 else f"{s / 60:4.0f}m " if s < 36000 else f"{s / 3600:4.0f}h "


def main() -> None:
    now = time.time()
    con = sqlite3.connect(f"file:{DB}?mode=ro", uri=True)
    con.row_factory = sqlite3.Row
    L: list[str] = []
    w = L.append
    w(f"AUDITORÍA odds.db  {time.strftime('%Y-%m-%d %H:%M:%S')}   ({DB})")

    # ── 1. salud ───────────────────────────────────────────────────────────────────────────────────────────────
    st = {r["key"]: r["value"] for r in con.execute("select key, value from scraper_status")}
    casas = sorted({r[0] for r in con.execute("select distinct bookmaker from events")})
    # las claves de estado usan el nombre corto del colector (bwin_last_ok) y las filas el de la casa (bwines)
    alias = {"sp888": "888sportes"}
    for pref in {k.split("_")[0] for k in st}:
        if pref in casas:
            continue
        hit = alias.get(pref) or next((c for c in casas if c.startswith(pref) or pref.startswith(c)), None)
        if hit:
            for k in [k for k in st if k.startswith(pref + "_")]:
                st[hit + k[len(pref):]] = st.pop(k)
        else:
            casas.append(pref)
    casas.sort()
    w("\n== 1. SALUD ==")
    w(f"{'casa':<13}{'ult. OK':>8} {'transp.':<10}{'pre':>5}{'live':>5}  {'edad pre (med/p90)':<20}{'edad live (med/p90)':<20} último error")
    for c in casas:
        row = {"pre": [], "live": []}
        for live, ls in con.execute("select is_live, last_seen from events where bookmaker=?", (c,)):
            row["live" if live else "pre"].append(now - (ls or now))
        def pct(a, f):
            a = sorted(a)
            return f"{a[min(len(a) - 1, int(f * len(a)))]:.0f}" if a else "-"
        err = (st.get(f"{c}_last_error") or "")[:70].replace("\n", " ")
        w(f"{c:<13}{_age(now, st.get(f'{c}_last_ok')):>8} {(st.get(f'{c}_transport') or '-')[:9]:<10}"
          f"{len(row['pre']):>5}{len(row['live']):>5}  {pct(row['pre'], .5) + '/' + pct(row['pre'], .9) + ' s':<20}"
          f"{pct(row['live'], .5) + '/' + pct(row['live'], .9) + ' s':<20} {err}")

    # ── eventos y emparejado entre casas ──────────────────────────────────────────────────────────────────────
    evs = con.execute("select bookmaker, event_id, sport, competition, home, away, start_date, is_live from events").fetchall()
    by_key: dict[tuple, list] = defaultdict(list)           # (sport, date) -> eventos
    for e in evs:
        by_key[((e["sport"] or "").lower()[:5], e["start_date"] or "")].append(e)
    groups: dict[tuple[str, str], int] = {}                 # (casa, event_id) -> grupo
    gid = 0
    for key, lst in by_key.items():
        toks = [(_toks(e["home"]), _toks(e["away"])) for e in lst]
        for i, e in enumerate(lst):
            if (e["bookmaker"], e["event_id"]) in groups:
                continue
            gid += 1
            groups[(e["bookmaker"], e["event_id"])] = gid
            for j in range(i + 1, len(lst)):
                f = lst[j]
                if f["bookmaker"] == e["bookmaker"] or (f["bookmaker"], f["event_id"]) in groups:
                    continue
                if (toks[i][0] & toks[j][0]) and (toks[i][1] & toks[j][1]):
                    groups[(f["bookmaker"], f["event_id"])] = gid
    size = defaultdict(int)
    for g in groups.values():
        size[g] += 1
    w("\n== 2. COBERTURA (eventos emparejados con al menos otra casa; mismo deporte, misma fecha, equipos en común) ==")
    w(f"{'casa':<13}{'eventos':>8}{'emparej.':>9}{'%':>5}   ejemplos SIN pareja (competición | partido)")
    for c in casas:
        mine = [e for e in evs if e["bookmaker"] == c]
        if not mine:
            continue
        paired = [e for e in mine if size[groups[(c, e["event_id"])]] > 1]
        alone = [e for e in mine if size[groups[(c, e["event_id"])]] == 1]
        ex = "; ".join(f"{(e['competition'] or '')[:22]} | {e['home']} - {e['away']}" for e in alone[:3])
        w(f"{c:<13}{len(mine):>8}{len(paired):>9}{100 * len(paired) / len(mine):>5.0f}   {ex}")

    # ── cuotas ────────────────────────────────────────────────────────────────────────────────────────────────
    odds = con.execute("select bookmaker, event_id, market, selection, line, player, price, seen_at from odds_latest "
                       "where price is not null and price > 1").fetchall()
    w("\n== 3. MERCADOS QUE SOLO PRODUCE UNA CASA (si otra casa ofrece lo mismo con otro nombre, es un mapeo perdido) ==")
    per_mk: dict[str, set] = defaultdict(set)
    for o in odds:
        per_mk[o["market"]].add(o["bookmaker"])
    only = defaultdict(list)
    for mk, bks in per_mk.items():
        if len(bks) == 1:
            only[next(iter(bks))].append(mk)
    for c in casas:
        if only.get(c):
            w(f"{c:<13}{', '.join(sorted(only[c]))[:400]}")

    # ── 4. sospechas ─────────────────────────────────────────────────────────────────────────────────────────
    w("\n== 4. SOSPECHAS DE MAPEO (misma clave en varias casas, cuotas incoherentes) ==")
    w("   clave = partido | mercado | línea | jugador.  Se listan las 50 peores de cada grupo.  'sure' = beneficio surebet entre casas;")
    w("   'desvío' = cuota de una casa frente a la mediana de las demás en la misma selección.")
    book: dict[tuple, dict[str, dict[str, float]]] = defaultdict(lambda: defaultdict(dict))   # key -> sel -> casa -> price
    label: dict[tuple, str] = {}
    evname = {(e["bookmaker"], e["event_id"]): f"{e['home']} - {e['away']}" for e in evs}
    for o in odds:
        g = groups.get((o["bookmaker"], o["event_id"]))
        if g is None or size[g] < 2:
            continue
        mk = o["market"] or ""
        line = o["line"]
        sel = o["selection"] or ""
        if mk.startswith("HANDICAP") and line is not None:              # desde el punto de vista del local
            line = line if sel == "1" else -line
            line = line + 0.0
        key = (g, mk, None if line is None else round(float(line), 2), _pkey(o["player"] or ""))
        book[key][sel][o["bookmaker"]] = float(o["price"])
        label.setdefault(key, f"{evname[(o['bookmaker'], o['event_id'])]} | {mk} | {'' if line is None else f'{line:g}'} | {o['player'] or ''}")
    sus: list[tuple[float, str]] = []
    for key, sels in book.items():
        # surebet entre casas
        # 1X2 necesita las 3 selecciones; el resto son a 2 vías (en directo las selecciones ya decididas desaparecen
        # y quedarían "surebets" ficticias con 2 de 3 patas)
        need = 3 if key[1].startswith("1X2") else 2
        if len(sels) >= need:
            best = {s: max(p.items(), key=lambda kv: kv[1]) for s, p in sels.items()}
            if len({b for b, _ in best.values()}) >= 2:
                inv = sum(1 / p for _, p in best.values())
                if 0 < inv < 0.995:          # cualquier beneficio >0,5 % (umbral del bot); antes solo >3 % y se escapaban las pequeñas
                    prof = (1 / inv - 1) * 100
                    legs = "  ".join(f"{s}:{b}@{p:.2f}" for s, (b, p) in best.items())
                    sus.append((prof, f"sure {prof:5.1f}%  {label[key]}  ->  {legs}"))
        # desvío por selección
        for s, p in sels.items():
            if len(p) < 3:
                continue
            for b, pr in p.items():
                others = [v for k, v in p.items() if k != b]
                m = median(others)
                dev = abs(pr - m) / m * 100
                if dev > 30 and abs(pr - m) > 0.25:
                    sus.append((dev / 3, f"desvío {dev:4.0f}%  {label[key]}  sel {s}: {b}@{pr:.2f} vs mediana {m:.2f} "
                                         f"({', '.join(f'{k}@{v:.2f}' for k, v in sorted(p.items()) if k != b)})"))
    sus.sort(key=lambda x: -x[0])
    for titulo, es_prop in (("-- mercados de partido/equipo --", False), ("-- props de jugador --", True)):
        w("  " + titulo)
        seen_lbl = set()
        n = 0
        for _, txt in sus:
            k = txt.split("  ->")[0].split("  sel ")[0]
            if ("| PLAYER_" in k) != es_prop or k in seen_lbl:
                continue
            seen_lbl.add(k)
            w("  " + txt)
            n += 1
            if n >= 50:
                break
        if not n:
            w("  (ninguna)")

    # ── 4b. directo: marcador / periodo / reloj de cada casa para el mismo partido ────────────────────────────
    w("\n== 4b. EN DIRECTO: marcador, periodo y reloj por casa (deben coincidir; * = marcador distinto a la mayoría; 0 cuotas = la casa ya no ofrece el partido) ==")
    live_rows = con.execute("select bookmaker, event_id, home, away, score, period, timer, last_seen from events where is_live=1").fetchall()
    n_odds = {(r[0], r[1]): r[2] for r in con.execute(
        "select bookmaker, event_id, count(*) from odds_latest group by bookmaker, event_id")}
    by_g: dict[int, list] = defaultdict(list)
    for e in live_rows:
        by_g[groups.get((e["bookmaker"], e["event_id"]), -1)].append(e)
    if not live_rows:
        w("  (no hay partidos en directo)")
    for g, lst in sorted(by_g.items(), key=lambda kv: -len(kv[1])):
        if len(lst) < 2:
            continue
        from collections import Counter
        _n = lambda x: re.sub(r"[\s]+", "", str(x or "")).replace("-", ":")
        sc = Counter(_n(e["score"]) for e in lst if e["score"])
        mayor = sc.most_common(1)[0][0] if sc else ""
        w(f"\n  {lst[0]['home']} - {lst[0]['away']}   ({len(lst)} casas; marcador mayoritario {mayor or '-'})")
        for e in sorted(lst, key=lambda e: e["bookmaker"]):
            flag = "*" if e["score"] and _n(e["score"]) != mayor else " "
            w(f"   {flag}{e['bookmaker']:<13} {str(e['score'] or '-'):<14} {str(e['period'] or '-'):<22} {str(e['timer'] or '-'):<8} "
              f"hace {now - (e['last_seen'] or now):4.0f}s   {n_odds.get((e['bookmaker'], e['event_id']), 0):>4} cuotas")

    # ── 5. títulos ───────────────────────────────────────────────────────────────────────────────────────────
    if FULL:
        w("\n== 5. TÍTULOS -> MERCADO (market_map, últimos 7 días) ==")
        cur = None
        for r in con.execute("select bookmaker, sport, market, title, kind, n, example from market_map "
                             "order by bookmaker, sport, market, n desc"):
            if (r["bookmaker"], r["sport"]) != cur:
                cur = (r["bookmaker"], r["sport"])
                w(f"\n-- {r['bookmaker']} / {r['sport']} --")
            w(f"  {(r['market'] or '-'):<22} n={r['n']:<5} {r['title']!r}  kind={r['kind']}  ej={r['example']}")
    else:
        w("\n(ejecuta con --full para incluir la tabla completa título -> mercado de cada casa)")

    os.makedirs(os.path.dirname(os.path.abspath(OUT)), exist_ok=True)
    with open(OUT, "w", encoding="utf-8") as fh:
        fh.write("\n".join(L) + "\n")
    print("\n".join(L[:len(casas) + 4]))
    print(f"\n... informe completo ({len(L)} líneas) en {os.path.abspath(OUT)}")


if __name__ == "__main__":
    main()
