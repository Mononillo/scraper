"""
daznbet.py — colector de cuotas de DAZN Bet España (daznbet.es; sportsbook de Flutter/PP en sb-pp-esfe.daznbet.es).

Las cuotas NO van por HTTP: el front abre sockets SockJS+STOMP sin cookies ni token (solo `Origin`) y se suscribe a topics.
El colector hace lo mismo con `websockets` puro (sin navegador), igual que Winamax. Canales:
    eventlivedocl1     events/<id>, eventmarketsmap/<id>, competitions/<id>, categoriespersport/<SP>
    eventmaplivedocl1  eventmap/live<SP>, eventmap/upcoming<SP>  (listas de eventos con competitionId y hora)
    marketlivedocl1    markets/<id>  (mercado completo con selecciones y precios; luego parches JSON-patch por push)
Cada mensaje es JSON-patch (a veces gzip+base64, cabecera is-compressed:true). Un destino inválido cierra el socket.
La taxonomía es estructurada (`taxonomy.type/period/scoreType`, `selTemplate` HOME/DRAW/AWAY/OVER/UNDER/YES/NO…), así que
el mapeo es por tabla, sin regex sobre títulos. Lo que no está en la tabla no se guarda.

Uso:  python daznbet.py            (bucle)     --once     --list [--all] (competiciones)     --dump <eventId>     --raw <eventId> <type>
"""
from __future__ import annotations

import asyncio
import base64
import gzip
import fastjson as json
import logging
import os
import random
import re
import string
import sys
import time
import unicodedata
from datetime import datetime, timedelta, timezone
from pathlib import Path

import websockets

from competitions import Competitions
from markets import classify
from storage import OddsStore
import pace

log = logging.getLogger("daznbet")
CFG_PATH = Path(os.getenv("DAZNBET_CFG", Path(__file__).parent / "daznbet.json"))

# ── mapeo ─────────────────────────────────────────────────────────────────────
PERIOD = {"FLGM": "", "1HLF": "_1H", "2HLF": "_2H", "1QRTR": "_Q1", "2QRTR": "_Q2", "3QRTR": "_Q3", "4QRTR": "_Q4"}
METRIC = {"GL": "", "PT": "", "CORNER": "CORNERS", "CORNERS": "CORNERS", "CARD": "CARDS", "CARDS": "CARDS", "BOOKING": "CARDS",
          "BOOKINGS": "CARDS", "GAME": "GAMES", "GAMES": "GAMES", "SET": "SETS", "SETS": "SETS"}
PLAYER_GOALS = {"WINNERN-A": 0.5, "WINNERN-A-MOREGOALS": 1.5, "WINNERN-A-HATRICK": 2.5}
# props de jugador "Nombre N+" (selTemplate PARTICIPANT, line=N) -> PLAYER_X Over N-0.5.  type -> (scoreType exigido, mercado)
PLAYER_N = {"WINNER-PSGOAL": ("SOG", "PLAYER_SHOTS_OT"), "TOTALS-OU-TS": ("GL", "PLAYER_SHOTS"), "WINNERN-PP": ("AS", "PLAYER_ASSISTS"),
            "WINNERN-PFOUL": ("FOUL", "PLAYER_FOULS"), "WINNERN-PT": ("GL", "PLAYER_TACKLES"), "WINNERN-PSAVES": ("SAVE", "PLAYER_SAVES"),
            "WINNERN-PO": ("OFFSIDE", "PLAYER_OFFSIDES")}
SEL = {"HOME": "1", "DRAW": "X", "AWAY": "2", "OVER": "Over", "UNDER": "Under", "YES": "Yes", "NO": "No",
       "HOME||DRAW": "1X", "DRAW||HOME": "1X", "HOME||AWAY": "12", "AWAY||HOME": "12", "DRAW||AWAY": "X2", "AWAY||DRAW": "X2"}


def _period(tax: dict, sport: str) -> str | None:
    p = tax.get("period") or ""
    n = (tax.get("properties") or {}).get("periodNumber") or ""
    if sport == "baloncesto":
        if p == "FLGMOT":
            return ""
        if p == "FLGM":
            return "_REG"
    elif sport == "tenis":
        if p == "FLGM":
            return ""
        if "SET" in p and n.isdigit():
            return f"_SET{n}"
        return None
    return PERIOD.get(p)


def _half(v) -> bool:
    try:
        return abs(abs(float(v)) % 1 - 0.5) < 1e-9
    except (TypeError, ValueError):
        return False


def is_player_market(meta: dict) -> bool:
    t = meta.get("type") or ""
    return t in PLAYER_GOALS or t == "WINNERN-PC" or t in PLAYER_N or bool((meta.get("properties") or {}).get("playerName"))


def wanted(meta: dict, sport: str) -> bool:
    """Prefiltro con el mapa de mercados (type/period/scoreType) para no suscribirse a lo que no se guarda."""
    t = meta.get("type") or ""
    st = meta.get("scoreType") or "GL"
    if t in PLAYER_GOALS or t == "WINNERN-PC":
        return sport == "futbol" and meta.get("period") == "FLGM" and (st == "GL" if t in PLAYER_GOALS else st == "CARD")
    if t in PLAYER_N:
        return sport == "futbol" and st == PLAYER_N[t][0] and (meta.get("period") or "") in ("FLGM", "1HLF", "2HLF")
    if (meta.get("properties") or {}).get("playerName"):
        return t.startswith("TOTALS-OU")
    if _period(meta, sport) is None:
        return False
    if (meta.get("scoreType") or "GL") not in METRIC:
        return False
    if st != "GL" and t not in ("TOTALS-OU", "TOTALS-OU-1", "TOTALS-OU-2", "HANDICAP2-A", "HANDICAP2"):
        return False                                   # 1X2 de córners, "más tarjetas"…: no se guardan
    return t in ("WINNER2D", "WINNER2", "WINNER2D-S-D", "WINNER2D-G-DC", "WHOSCORES2-G-12", "TOTALS-OU", "TOTALS-OU-1",
                 "TOTALS-OU-2", "HANDICAP2-A", "HANDICAP2")


def market_selections(m: dict, sport: str, home: str, away: str) -> list[dict]:
    if m.get("status") != "OFFERED" or m.get("tradeStatus") != "TRADABLE":
        return []
    tax = dict(m.get("taxonomy") or {})
    tax["properties"] = m.get("properties") or {}
    t = tax.get("type") or ""
    sels = [s for grp in m.get("selections") or [] for s in grp
            if s.get("status") == "OFFERED" and s.get("tradestatus") == "TRADABLE"]
    out: list[dict] = []

    def price(s):
        try:
            p = float((s.get("price") or {}).get("dec") or 0)
        except ValueError:
            return None
        return p if p > 1.0 else None

    st = tax.get("scoreType") or "GL"
    if t in PLAYER_GOALS or t == "WINNERN-PC":
        # "Jugador que marca…" (GL) -> PLAYER_GOALS; "Jugador que recibe tarjeta" (CARD) -> PLAYER_CARDS Over 0.5.
        # Variantes con otro scoreType (marca desde fuera del área SOUTBOX, marca y asiste GL&AS, expulsado R_CARD)
        # NO son el mismo mercado y se descartan.
        if sport != "futbol" or tax.get("period") != "FLGM":
            return []
        if t in PLAYER_GOALS and st == "GL":
            market, line = "PLAYER_GOALS", PLAYER_GOALS[t]
        elif st == "CARD" and t in ("WINNERN-A", "WINNERN-PC"):
            market, line = "PLAYER_CARDS", 0.5
        else:
            return []
        for s in sels:
            p = price(s)
            name = (s.get("name") or "").strip()
            if p and name and s.get("selTemplate") not in ("DRAW", "NOGOAL") and name.lower() not in ("sin goleador", "no goal", "ningún gol", "ninguno", "ningún jugador"):
                out.append({"market": market, "selection": "Over", "line": line, "player": name, "price": p})
        return out

    per = _period(tax, sport)
    if per is None:
        return []
    if t in PLAYER_N:
        if sport != "futbol" or st != PLAYER_N[t][0] or per not in ("", "_1H", "_2H"):
            return []
        for s in sels:
            p, name, ln = price(s), (s.get("name") or "").strip(), s.get("line")
            mm = re.match(r"^(.*?)\s+(\d+)\+$", name)
            if not (p and mm and s.get("selTemplate") == "PARTICIPANT"):
                continue
            n = int(mm.group(2))
            if ln is not None and float(ln) != n:
                continue
            out.append({"market": PLAYER_N[t][1] + per, "selection": "Over", "line": n - 0.5, "player": mm.group(1).strip(), "price": p})
        return out
    metric = METRIC.get(tax.get("scoreType") or "GL")
    if metric is None:
        return []
    player = (tax["properties"].get("playerName") or "").strip() or None

    if t.startswith("TOTALS-OU"):
        if player:
            base = re.sub(r"\(?m[aá]s/menos\)?|over/under|\btotal(es)?\b|\d+(\.\d+)?", " ", m.get("name") or "", flags=re.I)
            base = re.sub(r"\s*-\s*" + re.escape(player) + r"\s*$", "", base.strip(" -"), flags=re.I).strip(" -") or "Puntos"
            info = classify(base, sport, home, away, kind="total", player=player)
            if not info or not info.market.startswith("PLAYER_"):
                return []
            market = info.market + per
            player = info.player
        else:
            side = {"TOTALS-OU": "", "TOTALS-OU-1": "_HOME", "TOTALS-OU-2": "_AWAY"}.get(t)
            if side is None:
                return []
            market = (metric or "TOTAL") + side + per
        for s in sels:
            sel, p = SEL.get(s.get("selTemplate") or ""), price(s)
            if sel in ("Over", "Under") and p and _half(s.get("line")):
                out.append({"market": market, "selection": sel, "line": float(s["line"]), "player": player, "price": p})
        return out

    if t in ("HANDICAP2-A", "HANDICAP2"):
        hk = "HANDICAP" + (f"_{metric}" if metric else "") + per    # HANDICAP, HANDICAP_CORNERS, HANDICAP_CARDS
        for s in sels:
            sel, p = SEL.get(s.get("selTemplate") or ""), price(s)
            if sel in ("1", "2") and p and _half(s.get("line")):
                out.append({"market": hk, "selection": sel, "line": float(s["line"]), "player": None, "price": p})
        return out if len(out) == 2 else []
    if metric:                                   # 1X2 de córners, "más tarjetas"…: no se guardan
        return []
    base = {"WINNER2D": "1X2", "WINNER2": "1X2", "WINNER2D-S-D": "DNB", "WINNER2D-G-DC": "DC", "WHOSCORES2-G-12": "BTTS"}.get(t)
    if not base:
        return []
    if t == "WINNER2D" and sum(len(g) for g in m.get("selections") or []) != 3:
        return []
    if t == "WINNER2" and sport == "futbol":
        return []
    for s in sels:
        sel, p = SEL.get(s.get("selTemplate") or ""), price(s)
        if sel and p:
            out.append({"market": base + per, "selection": sel, "line": None, "player": None, "price": p})
    return out


# ── JSON-patch mínimo (add / replace / remove) ────────────────────────────────
def _tok(s: str):
    s = s.replace("~1", "/").replace("~0", "~")
    return s


def apply_patch(doc, ops: list) -> object:
    for op in ops:
        path = op.get("path", "")
        if path == "":
            if op.get("op") in ("add", "replace"):
                doc = op.get("value")
            elif op.get("op") == "remove":
                doc = None
            continue
        parts = [_tok(p) for p in path.split("/")[1:]]
        cur = doc
        ok = True
        for p in parts[:-1]:
            if isinstance(cur, list):
                try:
                    cur = cur[int(p)]
                except (ValueError, IndexError):
                    ok = False
                    break
            elif isinstance(cur, dict):
                if p not in cur:
                    if op.get("op") in ("add", "replace"):
                        cur[p] = {}
                    else:
                        ok = False
                        break
                cur = cur[p]
            else:
                ok = False
                break
        if not ok:
            continue
        last = parts[-1]
        kind = op.get("op")
        if isinstance(cur, list):
            if kind == "add":
                if last == "-":
                    cur.append(op.get("value"))
                else:
                    try:
                        cur.insert(int(last), op.get("value"))
                    except ValueError:
                        pass
            elif kind == "replace":
                try:
                    cur[int(last)] = op.get("value")
                except (ValueError, IndexError):
                    pass
            elif kind == "remove":
                try:
                    del cur[int(last)]
                except (ValueError, IndexError):
                    pass
        elif isinstance(cur, dict):
            if kind in ("add", "replace"):
                cur[last] = op.get("value")
            elif kind == "remove":
                cur.pop(last, None)
    return doc


# ── STOMP sobre SockJS ────────────────────────────────────────────────────────
class Stomp:
    def __init__(self, cfg: dict, channel: str, on_message):
        self.cfg, self.channel, self.on_message = cfg, channel, on_message
        self.ws = None
        self.subs: dict[str, str] = {}          # destino -> id de suscripción
        self._n = 0
        self._task: asyncio.Task | None = None
        self.closed = asyncio.Event()
        self.closed.set()
        self.received = 0
        self.limit: int | None = None            # nº de suscripciones al recibir "Subscription limit reached"

    def full(self) -> bool:
        return self.limit is not None and len(self.subs) >= self.limit - 2

    def _url(self) -> str:
        srv = f"{random.randint(0, 999):03d}"
        sid = "".join(random.choices(string.ascii_lowercase + string.digits, k=8))
        return f"wss://{self.cfg['host']}/{self.channel}/livedoc/{srv}/{sid}/websocket"

    @staticmethod
    def _frame(cmd: str, headers: dict, body: str = "") -> str:
        return json.dumps([cmd + "\n" + "".join(f"{k}:{v}\n" for k, v in headers.items()) + "\n" + body + "\x00"])

    async def connect(self):
        hdrs = {"User-Agent": self.cfg.get("user_agent", "Mozilla/5.0"), "Accept-Language": "es,es-ES;q=0.9"}
        origin = f"https://{self.cfg['host']}"
        try:
            self.ws = await websockets.connect(self._url(), origin=origin, max_size=50_000_000, additional_headers=hdrs,
                                               ping_interval=None, open_timeout=20)
        except TypeError:                                                   # websockets < 14
            self.ws = await websockets.connect(self._url(), origin=origin, max_size=50_000_000, extra_headers=hdrs,
                                               ping_interval=None, open_timeout=20)
        first = await asyncio.wait_for(self.ws.recv(), 15)
        if first != "o":
            raise RuntimeError(f"{self.channel}: apertura SockJS inesperada {first!r}")
        await self.ws.send(self._frame("CONNECT", {"accept-version": "1.1,1.0", "heart-beat": "10000,10000"}))
        for _ in range(5):
            raw = await asyncio.wait_for(self.ws.recv(), 15)
            if raw.startswith("a[") and "CONNECTED" in raw:
                break
        else:
            raise RuntimeError(f"{self.channel}: sin CONNECTED")
        await self.ws.send(self._frame("SEND", {"destination": ""}))
        self.subs.clear()
        self.closed.clear()
        self._task = asyncio.create_task(self._reader())

    async def subscribe(self, dest: str, extra: dict | None = None):
        if dest in self.subs or self.closed.is_set():
            return
        self._n += 1
        sid = f"sub-{self._n}"
        h = {"X-Lang": "es", "sendEmpty": "true", "content-type": "application/octet-stream"}
        h.update(extra or {})
        h.update({"id": sid, "destination": dest})
        self.subs[dest] = sid
        await self.ws.send(self._frame("SUBSCRIBE", h))

    async def unsubscribe(self, dest: str):
        sid = self.subs.pop(dest, None)
        if sid and not self.closed.is_set():
            try:
                await self.ws.send(self._frame("UNSUBSCRIBE", {"id": sid}))
            except Exception:  # noqa: BLE001
                pass

    async def _reader(self):
        try:
            async for raw in self.ws:
                if raw in ("h", "o"):
                    continue
                if raw.startswith("c"):
                    log.warning("%s: el servidor cierra el socket %s", self.channel, raw[:80])
                    break
                if not raw.startswith("a"):
                    continue
                for frame in json.loads(raw[1:]):
                    head, _, body = frame.partition("\n\n")
                    lines = head.split("\n")
                    hdr = dict(l.split(":", 1) for l in lines[1:] if ":" in l)
                    body = body.rstrip("\x00")
                    if lines[0] == "ERROR":
                        if "limit" in (hdr.get("message") or "").lower():
                            self.limit = max(10, len(self.subs) - 1)
                            log.warning("%s: límite de suscripciones del servidor ≈ %d por socket", self.channel, self.limit)
                        else:
                            log.warning("%s: STOMP ERROR %s", self.channel, hdr.get("message"))
                        continue
                    if lines[0] != "MESSAGE" or not body:
                        continue
                    if hdr.get("is-compressed") == "true":
                        body = gzip.decompress(base64.b64decode(body)).decode("utf-8")
                    try:
                        ops = json.loads(body)
                    except ValueError:
                        continue
                    self.received += 1
                    self.on_message(hdr.get("destination", ""), ops)
        except Exception as e:  # noqa: BLE001
            log.warning("%s: socket caído: %r", self.channel, e)
        finally:
            self.closed.set()

    async def close(self):
        self.closed.set()
        if self._task:
            self._task.cancel()
        if self.ws:
            try:
                await self.ws.close()
            except Exception:  # noqa: BLE001
                pass


# ── colector ──────────────────────────────────────────────────────────────────
def _slug(name: str) -> str:
    s = unicodedata.normalize("NFC", name or "").lower().replace("&", "and")
    s = re.sub(r"[^\w\s-]", "", s, flags=re.U)
    return re.sub(r"\s+", "-", s.strip())


class Collector:
    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.bk = cfg["bookmaker"]
        self.sports: dict[str, str] = cfg["sports"]                     # FBL -> futbol
        self.catalog = Competitions()
        self.store = OddsStore(bookmaker=self.bk)
        self._cfg_mtime = CFG_PATH.stat().st_mtime
        self.transport = "websocket"
        # estado recibido
        self.lists: dict[str, dict] = {}            # "live:FBL" -> {eventId: {...}}
        self.events: dict[str, dict] = {}
        self.emaps: dict[str, dict] = {}            # eventId -> {marketId: meta}
        self.markets: dict[str, dict] = {}
        self.comps: dict[str, dict | None] = {}     # competitionId -> objeto (None = pedido, sin respuesta aún)
        self.comp_name: dict[str, str | None] = {}  # competitionId -> competición canónica o None
        self.market_ts: dict[str, float] = {}
        # sockets
        self.ev = Stomp(cfg, "eventlivedocl1", self._on_msg)              # competiciones (transitorias)
        self.map = Stomp(cfg, "eventmaplivedocl1", self._on_msg)
        self.evs = [Stomp(cfg, "eventlivedocl1", self._on_msg) for _ in range(int(cfg.get("event_sockets", 3)))]
        self.mk = [Stomp(cfg, "marketlivedocl1", self._on_msg) for _ in range(int(cfg.get("market_sockets", 6)))]
        self.ev_of: dict[str, Stomp] = {}           # eventId -> socket de eventos
        self.mk_of: dict[str, Stomp] = {}
        self._cap_warned = -1
        self._limit_per_socket = int(cfg.get("subs_per_socket", 150))
        self._last_prematch = 0.0
        self._pm_note = ""
        self._shutdown = False

    # ── mensajes ──
    def _on_msg(self, dest: str, ops):
        try:
            kind, _, key = dest.partition("/")
            if kind == "eventmap":
                self.lists[key] = (apply_patch(self.lists.get(key) or {}, ops) or {})
            elif kind == "events":
                self.events[key] = apply_patch(self.events.get(key) or {}, ops) or {}
            elif kind == "eventmarketsmap":
                self.emaps[key] = apply_patch(self.emaps.get(key) or {}, ops) or {}
            elif kind == "markets":
                self.markets[key] = apply_patch(self.markets.get(key) or {}, ops) or {}
                self.market_ts[key] = time.time()
            elif kind == "competitions":
                self.comps[key] = apply_patch(self.comps.get(key) or {}, ops) or {}
                self.comp_name[key] = self._match_comp(self.comps[key])
            elif kind == "categoriespersport":
                self.lists["cats:" + key] = apply_patch(self.lists.get("cats:" + key) or {}, ops) or {}
        except Exception as e:  # noqa: BLE001
            log.debug("parche %s: %r", dest, e)

    def _match_comp(self, c: dict) -> str | None:
        sport = self.sports.get(c.get("sportId") or "")
        if not sport:
            return None
        cls = ((c.get("properties") or {}).get("competitionClass") or {}).get("name") or ""
        labels: list[str] = []
        for name in (c.get("name") or "", c.get("defaultName") or ""):
            name = re.sub(r"\s+", " ", name).strip()
            if not name:
                continue
            base, _, suffix = name.rpartition(" - ")            # 'LaLiga - España' -> país en el sufijo
            if base and suffix:
                labels.append(f"{suffix.strip()} - {base.strip()}")
            if cls:
                labels.append(f"{cls} - {base.strip() if base and suffix and suffix.strip().lower() == cls.lower() else name}")
            labels.append(name)
        for label in labels:
            r = self.catalog.match(self.bk, sport, label)
            if r:
                return r
        return None

    # ── conexión ──
    async def ensure_sockets(self):
        for s in (self.ev, self.map, *self.evs, *self.mk):
            if s.closed.is_set():
                for d in (self.ev_of, self.mk_of):                     # las suscripciones de ese socket se perdieron
                    for k in [k for k, v in d.items() if v is s]:
                        d.pop(k)
                        self.markets.pop(k, None)
                if s is self.ev:
                    for cid, v in list(self.comps.items()):
                        if v is None:
                            self.comps.pop(cid)
                await s.connect()
                log.info("%s conectado", s.channel)
                if s is self.map:
                    for sp in self.sports:
                        await s.subscribe(f"eventmap/live{sp}", {"X-Sort": "date", "X-Order": "asc", "X-IncludeComp": "false", "X-size": "3000", "context": "EVENT PAGE"})
                        await s.subscribe(f"eventmap/upcoming{sp}", {"X-Sort": "date", "X-Order": "asc", "X-IncludeComp": "false", "X-size": "3000", "context": "EVENT PAGE"})

    def _pick(self, pool: list[Stomp]) -> Stomp | None:
        """Socket con menos suscripciones que aún admita más (límite conocido del servidor o subs_per_socket)."""
        free = [s for s in pool if not s.closed.is_set() and not s.full() and len(s.subs) < self._limit_per_socket]
        return min(free, key=lambda s: len(s.subs)) if free else None

    # ── selección de eventos ──
    def _candidates(self) -> dict[str, tuple[str, str, bool, str]]:
        """eventId -> (sport, competición, es_live, hora) para los eventos de competiciones principales."""
        now = datetime.now(timezone.utc)
        horizon = now + timedelta(hours=float(self.cfg.get("prematch_hours", 48)))
        out: dict[str, tuple[str, str, bool, str]] = {}
        for sp, sport in self.sports.items():
            for mode in ("live", "upcoming"):
                evs = (self.lists.get(f"{mode}{sp}") or {}).get("events") or {}
                for eid, e in (evs.items() if isinstance(evs, dict) else ((x.get("id"), x) for x in evs)):
                    if not eid:
                        continue
                    cid = e.get("competitionId")
                    if not cid:
                        continue
                    if cid not in self.comps:
                        self.comps[cid] = None                        # se pide en el ciclo
                        continue
                    comp = self.comp_name.get(cid)
                    if not comp:
                        continue
                    start = (e.get("anticipated") or {}).get("startTime") or ""
                    if mode == "upcoming":
                        try:
                            st = datetime.fromisoformat(start.replace("Z", "+00:00"))
                        except ValueError:
                            continue
                        if st > horizon or eid in out:
                            continue
                    out[eid] = (sport, comp, mode == "live", start)
        return out

    async def _rate(self, n: int):
        if n and n % int(self.cfg.get("sub_burst", 40)) == 0:
            await asyncio.sleep(float(self.cfg.get("sub_pause", 0.5)))

    async def sync_subscriptions(self) -> dict[str, tuple[str, str, bool]]:   # eventId -> (sport, competición, live)
        n = 0
        # competiciones: se piden en el socket transitorio y se sueltan al recibirlas (son estáticas)
        for cid, v in list(self.comps.items()):
            dest = f"competitions/{cid}"
            if v is None and dest not in self.ev.subs and not self.ev.full() and len(self.ev.subs) < self._limit_per_socket:
                await self.ev.subscribe(dest)
                n += 1
                await self._rate(n)
            elif v is not None and dest in self.ev.subs:
                await self.ev.unsubscribe(dest)
        cands = self._candidates()
        live_ids = [e for e, v in cands.items() if v[2]]
        pre_ids = sorted((e for e, v in cands.items() if not v[2]), key=lambda e: cands[e][3])[: int(self.cfg.get("prematch_max_events", 120))]
        keep = set(live_ids) | set(pre_ids)
        for eid in list(self.ev_of):
            if eid not in keep:
                s = self.ev_of.pop(eid)
                await s.unsubscribe(f"events/{eid}")
                await s.unsubscribe(f"eventmarketsmap/{eid}")
                for mid in list(self.emaps.pop(eid, {})):
                    ms = self.mk_of.pop(mid, None)
                    if ms:
                        await ms.unsubscribe(f"markets/{mid}")
                    self.markets.pop(mid, None)
                self.events.pop(eid, None)
        for eid in live_ids + pre_ids:                        # live primero: si falta sitio, se queda fuera el pre
            if eid in self.ev_of:
                continue
            s = self._pick(self.evs)
            if s is None:
                break
            self.ev_of[eid] = s
            await s.subscribe(f"events/{eid}")
            await s.subscribe(f"eventmarketsmap/{eid}")
            n += 2
            await self._rate(n)
        # mercados
        # Prioridad: 1) mercados principales de los partidos en directo, 2) principales pre-partido,
        # 3) props de jugador en directo, 4) props pre-partido. Si no cabe todo en los sockets, lo que
        # se queda fuera son los props del pre-partido, nunca el 1X2/total/hándicap de un partido en directo.
        tiers: list[list[str]] = [[], [], [], []]
        for eid in live_ids + pre_ids:
            if eid not in self.ev_of:
                continue
            sport, live = cands[eid][0], cands[eid][2]
            for mid, meta in (self.emaps.get(eid) or {}).items():
                if isinstance(meta, dict) and wanted(meta, sport):
                    tiers[(2 if is_player_market(meta) else 0) + (0 if live else 1)].append(mid)
        capacity = sum(min(self._limit_per_socket, (s.limit or 10**9) - 2) for s in self.mk if not s.closed.is_set())
        want = [m for tier in tiers for m in tier]
        n_main = len(tiers[0]) + len(tiers[1])
        if len(want) > capacity:                              # recorta por el final (props pre-partido primero)
            if n_main > capacity:
                log.warning("sockets de mercados insuficientes incluso para los mercados principales (%d > %d): sube market_sockets en daznbet.json", n_main, capacity)
            want = want[:max(capacity, 0)]
        wset = set(want)
        for mid in list(self.mk_of):
            if mid not in wset:
                s = self.mk_of.pop(mid)
                await s.unsubscribe(f"markets/{mid}")
                self.markets.pop(mid, None)
        for mid in want:
            if mid in self.mk_of:
                continue
            s = self._pick(self.mk)
            if s is None:
                left = sum(1 for m in want if m not in self.mk_of)
                if left != self._cap_warned:
                    self._cap_warned = left
                    log.warning("tope de suscripciones de mercados alcanzado (%d sockets x %d): %d mercados fuera — sube market_sockets en daznbet.json",
                                len(self.mk), self._limit_per_socket, left)
                break
            self.mk_of[mid] = s
            await s.subscribe(f"markets/{mid}")
            n += 1
            await self._rate(n)
        return {e: cands[e][:3] for e in keep if e in self.ev_of}

    # ── filas ──
    def _row(self, eid: str, sport: str, comp: str, live: bool) -> dict | None:
        ev = self.events.get(eid) or {}
        parts = [p for grp in ev.get("participants") or [] for p in grp]
        if len(parts) < 2 or ev.get("status") not in (None, "OFFERED") or ev.get("type") not in (None, "MATCH"):
            return None
        parts.sort(key=lambda p: (p.get("participantTeamData") or {}).get("participantSide") or 0)
        home, away = parts[0].get("name") or "", parts[1].get("name") or ""
        if not home or not away:
            return None
        sels: list[dict] = []
        for mid in (self.emaps.get(eid) or {}):
            m = self.markets.get(mid)
            if m and m.get("eventId", eid) == eid:
                sels.extend(market_selections(m, sport, home, away))
        if not sels:
            return None
        best: dict[tuple, dict] = {}                               # dos mercados para lo mismo (live/pre): la cuota más baja
        for x in sels:
            k = (x["market"], x["selection"], x["line"], x["player"])
            if k not in best or x["price"] < best[k]["price"]:
                best[k] = x
        sels = list(best.values())
        dt = None
        try:
            dt = datetime.fromisoformat(((ev.get("anticipated") or {}).get("startTime") or "").replace("Z", "+00:00")).astimezone()
        except ValueError:
            pass
        sp_slug = {"futbol": "futbol", "baloncesto": "baloncesto", "tenis": "tenis"}[sport]
        row = {"event_id": eid, "home": home, "away": away, "competition": comp,
               "date": dt.strftime("%Y-%m-%d") if dt else None, "start_time": dt.strftime("%H:%M") if dt else None,
               "url": self.cfg["event_url"].format(sport=sp_slug, slug=f"{_slug(ev.get('defaultName') or ev.get('name') or '')}-{eid.lower()}"),
               "selections": sels}
        if live:
            res = ev.get("result") or {}
            pid = {p.get("id"): i for i, p in enumerate(parts)}
            sc: list[list[str]] = [[], []]
            for s in res.get("currentScore") or []:
                i = pid.get(s.get("participantId"))
                if i in (0, 1) and s.get("score"):
                    sc[i] = [str(x) for x in s["score"]]
            if sport == "tenis":
                score = " ".join(f"{x}:{y}" for x, y in zip(sc[0], sc[1])) or None
            else:
                score = f"{sc[0][-1] if sc[0] else 0}:{sc[1][-1] if sc[1] else 0}"
            per = (res.get("currentPeriod") or {}).get("description") or None
            clk = res.get("clock") or {}
            timer = None
            if clk.get("displayClock") and isinstance(clk.get("current"), (int, float)):
                cur = int(clk["current"])
                if clk.get("isRunning") and clk.get("referenceTime"):
                    try:
                        ref = datetime.fromisoformat(clk["referenceTime"].replace("Z", "+00:00"))
                        cur += int((datetime.now(timezone.utc) - ref).total_seconds()) * (-1 if clk.get("isCountdown") else 1)
                    except ValueError:
                        pass
                timer = f"{max(cur, 0) // 60}:{max(cur, 0) % 60:02d}"
            row.update(score=score, period=per, timer=timer)
        return row

    def _reload_cfg(self):
        mt = CFG_PATH.stat().st_mtime
        if mt != self._cfg_mtime:
            self._cfg_mtime = mt
            self.cfg = pace.apply(json.loads(CFG_PATH.read_text(encoding="utf-8")))
            log.info("daznbet.json recargado")
        if self.catalog.reload():
            self.comp_name = {k: self._match_comp(v) for k, v in self.comps.items() if v}

    async def run(self, once: bool = False):
        backoff = 2
        t_start = time.time()
        while not self._shutdown:
            t0 = time.time()
            try:
                self._reload_cfg()
                await self.ensure_sockets()
                keep = await self.sync_subscriptions()
                if once and time.time() - t_start < 12:
                    await asyncio.sleep(1)
                    continue
                live_rows: dict[str, list[dict]] = {}
                pre_rows: dict[str, list[dict]] = {}
                do_pre = t0 - self._last_prematch >= float(self.cfg.get("interval_prematch", 60))
                for eid, (sport, comp, live) in keep.items():
                    r = self._row(eid, sport, comp, live)
                    if not r:
                        continue
                    (live_rows if live else pre_rows).setdefault(sport, []).append(r)
                n_live = changed = 0
                present: set[str] = set()
                for sp, rs in live_rows.items():
                    changed += await asyncio.to_thread(self.store.save_rows, sp, "live", rs)
                    n_live += len(rs)
                    present |= {r["event_id"] for r in rs}
                await asyncio.to_thread(self.store.sweep, present, "live")
                msg = f"live {n_live} ev / {changed} cambios"
                if do_pre:
                    self._last_prematch = t0
                    n_pre = c_pre = 0
                    pres: set[str] = set()
                    for sp, rs in pre_rows.items():
                        c_pre += await asyncio.to_thread(self.store.save_rows, sp, "prematch", rs)
                        n_pre += len(rs)
                        pres |= {r["event_id"] for r in rs}
                    await asyncio.to_thread(self.store.sweep, pres, "prematch")
                    self._pm_note = f"prematch {n_pre} ev / {c_pre} cambios"
                msg += " | " + (self._pm_note or "prematch pendiente") + f" | subs {len(self.mk_of)} mercados, {len(self.ev_of)} eventos"
                self.store.set_status(**{f"{self.bk}_last_ok": time.time(), f"{self.bk}_live_events": n_live,
                                         f"{self.bk}_transport": self.transport})
                log.info("%s [%s] (%.1fs)", msg, self.transport, time.time() - t0)
                backoff = 2
                if once:
                    return
            except Exception as e:  # noqa: BLE001
                log.warning("error de ciclo: %s — reintento en %ss", e, backoff, exc_info=log.isEnabledFor(logging.DEBUG))
                self.store.set_status(**{f"{self.bk}_last_error": f"{time.time():.0f} {e}"})
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2, 120)
                continue
            await asyncio.sleep(max(0.5, float(self.cfg.get("interval_live", 2)) * random.uniform(0.85, 1.2) - (time.time() - t0)))

    async def close(self):
        self._shutdown = True
        for s in (self.ev, self.map, *self.evs, *self.mk):
            await s.close()


# ── CLI ───────────────────────────────────────────────────────────────────────
async def list_catalog(c: Collector):
    """Competiciones con partidos (listas live/próximos) y si casan con competitions.json. `--all`: catálogo entero."""
    await c.ensure_sockets()
    await asyncio.sleep(4)
    cnt: dict[str, int] = {}
    for sp in c.sports:
        for mode in ("live", "upcoming"):
            for e in ((c.lists.get(f"{mode}{sp}") or {}).get("events") or {}).values():
                cnt[e.get("competitionId")] = cnt.get(e.get("competitionId"), 0) + 1
    seen = [cid for cid in cnt if cid]
    if "--all" in sys.argv:
        for sp in c.sports:
            await c.ev.subscribe(f"categoriespersport/{sp}")
        await asyncio.sleep(5)
        for sp in c.sports:
            for cat in (c.lists.get("cats:" + sp) or {}).values():
                seen += [cid for cid in cat.get("competitions") or [] if cid not in cnt]
    print(f"{len(seen)} competiciones ({sum(1 for x in seen if cnt.get(x))} con partidos); pidiendo por lotes de 60…", flush=True)
    for i in range(0, len(seen), 60):
        if c.ev.closed.is_set():
            await c.ev.connect()
        batch = seen[i:i + 60]
        for cid in batch:
            c.comps.setdefault(cid, None)
            await c.ev.subscribe(f"competitions/{cid}")
        for _ in range(20):                                   # hasta 2 s: salir en cuanto lleguen todas
            await asyncio.sleep(0.1)
            if all(c.comps.get(cid) for cid in batch):
                break
        for cid in batch:
            await c.ev.unsubscribe(f"competitions/{cid}")
        print(f"  {min(i + 60, len(seen))}/{len(seen)}", flush=True)
    by: dict[str, list] = {}
    for cid, comp in c.comps.items():
        if comp:
            by.setdefault(c.sports.get(comp.get("sportId"), "?"), []).append((cid, comp))
    for sport, items in by.items():
        print(f"\n=== {sport} ({len(items)} competiciones, {sum(1 for _, x in items if c.comp_name.get(x['id']))} principales)")
        for cid, comp in sorted(items, key=lambda x: (not c.comp_name.get(x[0]), -cnt.get(x[0], 0), x[1].get("name") or "")):
            flag = "+" if c.comp_name.get(cid) else " "
            print(f"  {flag} {cid:10s} {cnt.get(cid, 0):3d} ev  {comp.get('name')!r:55s} -> {c.comp_name.get(cid) or '-'}")
    print("\nPatrones en competitions.json (clave 'daznbet'); etiqueta comparada: 'País - Nombre'. `--all` para el catálogo completo.")


async def dump_event(c: Collector, eid: str):
    await c.ensure_sockets()
    es = c.evs[0]
    await es.subscribe(f"events/{eid}")
    await es.subscribe(f"eventmarketsmap/{eid}")
    await asyncio.sleep(4)
    ev = c.events.get(eid) or {}
    sport = c.sports.get(ev.get("sportId") or "", "futbol")
    print(json.dumps({k: ev.get(k) for k in ("id", "name", "sportId", "competitionId", "status", "anticipated", "result")}, ensure_ascii=False, indent=1))
    emap = c.emaps.get(eid) or {}
    print(f"mercados en el mapa: {len(emap)}; suscribiendo a todos…")
    for i, mid in enumerate(emap):
        await c.mk[i % len(c.mk)].subscribe(f"markets/{mid}")
        if i % 40 == 39:
            await asyncio.sleep(0.5)
    await asyncio.sleep(6)
    parts = [p for grp in ev.get("participants") or [] for p in grp]
    home, away = (parts[0].get("name"), parts[1].get("name")) if len(parts) >= 2 else ("", "")
    n_saved = 0
    for mid, meta in sorted(emap.items(), key=lambda x: (x[1].get("type") or "", x[1].get("period") or "")):
        m = c.markets.get(mid)
        sels = market_selections(m, sport, home, away) if m else []
        n_saved += len(sels)
        tag = "+" if sels else ("~" if wanted(meta, sport) else " ")
        print(f"{tag} {meta.get('type'):28s} {meta.get('period'):14s} {meta.get('scoreType') or '':7s} {m.get('name') if m else meta.get('name')!r}")
        for s in sels:
            print(f"      {s['market']:22s} {s['selection']:6s} {s['line'] if s['line'] is not None else '':>6} {s['player'] or '':24s} @{s['price']}")
    print(f"\n{n_saved} selecciones se guardarían.")


async def raw_markets(c: Collector, eid: str, needle: str, limit: int = 3):
    """Imprime el JSON crudo de los mercados cuyo type contiene `needle` (para mapear mercados nuevos)."""
    await c.ensure_sockets()
    es = c.evs[0]
    await es.subscribe(f"events/{eid}")
    await es.subscribe(f"eventmarketsmap/{eid}")
    await asyncio.sleep(4)
    emap = c.emaps.get(eid) or {}
    ids = [mid for mid, meta in emap.items() if needle.upper() in (meta.get("type") or "").upper() and "‡" not in (meta.get("type") or "")][:limit]
    print(f"{len(ids)} mercados con type~{needle!r} (de {len(emap)})")
    for mid in ids:
        await c.mk[0].subscribe(f"markets/{mid}")
    await asyncio.sleep(4)
    for mid in ids:
        m = c.markets.get(mid)
        if not m:
            print(f"-- {mid}: sin datos"); continue
        m = dict(m)
        m["selections"] = [grp[:4] for grp in (m.get("selections") or [])][:3]
        print(f"-- {mid}\n" + json.dumps(m, ensure_ascii=False, indent=1))


def main():
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace", line_buffering=True)
    except Exception:  # noqa: BLE001
        pass
    logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"), format="%(asctime)s %(levelname)s daznbet: %(message)s")
    cfg = pace.apply(json.loads(CFG_PATH.read_text(encoding="utf-8")))
    if not cfg.get("enabled", True):
        log.info("daznbet deshabilitado (enabled=false)")
        return
    c = Collector(cfg)

    async def go():
        try:
            if "--list" in sys.argv:
                await list_catalog(c)
            elif "--dump" in sys.argv:
                await dump_event(c, sys.argv[sys.argv.index("--dump") + 1])
            elif "--raw" in sys.argv:
                i = sys.argv.index("--raw")
                await raw_markets(c, sys.argv[i + 1], sys.argv[i + 2] if len(sys.argv) > i + 2 else "WINNER-PSGOAL")
            else:
                await c.run(once="--once" in sys.argv)
        finally:
            await c.close()
    try:
        asyncio.run(go())
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
