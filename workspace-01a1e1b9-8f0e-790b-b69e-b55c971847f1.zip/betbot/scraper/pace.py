"""Ritmo común de los colectores.

`INTERVAL_LIVE` (variable de entorno, en segundos; por defecto 2) manda sobre el `interval_live` de cada perfil
JSON, salvo que el perfil fije `min_interval_live` (casas sensibles al baneo).  Así el
en-directo de todas las casas va al mismo ritmo cambiando un solo valor en .env.
"""
from __future__ import annotations

import os


def _desync(cfg: dict) -> None:
    """Desfasa el intervalo pre-partido de cada casa unos segundos (determinista por nombre) para que las pasadas
    pesadas de 25 colectores no caigan todas en el mismo segundo (30/60/90 s coinciden cada minuto y medio →
    pico de CPU y cola en la BD que retrasa el en-directo de todos).  Con 60→60…75 s los ciclos se separan solos."""
    try:
        base = float(cfg.get("interval_prematch") or 0)
    except (TypeError, ValueError):
        return
    if base < 10 or cfg.get("_desynced"):
        return
    name = str(cfg.get("bookmaker") or cfg.get("name") or "")
    h = sum((i + 1) * ord(c) for i, c in enumerate(name)) % 19          # 0..18
    cfg["interval_prematch"] = round(base * (1.0 + 0.25 * h / 18.0), 1)       # hasta +25 % del intervalo
    cfg["_desynced"] = True


def apply(cfg: dict) -> dict:
    _desync(cfg)
    raw = os.getenv("INTERVAL_LIVE", "").strip()
    if not raw:
        return cfg
    try:
        want = max(1.0, float(raw))
    except ValueError:
        return cfg
    floor = float(cfg.get("min_interval_live") or 0)
    cfg["interval_live"] = max(want, floor)
    return cfg


class Background:
    """Trabajo pre-partido en un hilo aparte, para que el bucle en directo no espere por él.

    Uso en el ciclo live:  `if self._pm_queue and not self._bg.busy(): self._bg.run(fn)` y, al componer el log,
    `self._bg.note()` devuelve (una sola vez) el resumen del último trabajo terminado.  `inline=True` (modo
    --once o transporte navegador, que no es seguro entre hilos) lo ejecuta en el propio hilo.
    """

    def __init__(self, name: str = "prematch"):
        import threading
        self._threading = threading
        self._name = name
        self._t = None
        self._note = ""

    def busy(self) -> bool:
        return self._t is not None and self._t.is_alive()

    def run(self, fn, inline: bool = False) -> str:
        if inline:
            return fn() or ""
        if self.busy():
            return ""

        def _w():
            try:
                self._note = fn() or ""
            except Exception as e:  # noqa: BLE001
                self._note = f"{self._name} error: {e}"

        self._t = self._threading.Thread(target=_w, daemon=True, name=self._name)
        self._t.start()
        return ""

    def note(self) -> str:
        n, self._note = self._note, ""
        return n
