# betbot — colectores de cuotas multi-casa + bot de Telegram

```
 COLECTORES (cada uno escribe en data/odds.db con su `bookmaker`)        BOT (python-telegram-bot)
 ├ winamax.py   Winamax       Socket.IO público, sin navegador    ├──► │ OddsSource (poll 3 s)             │
 ├ paston.py    Pastón        API REST Altenar, sin navegador     │    │  └ SignalEngine                   │
 ├ betsson.py   Betsson       API JSON OBG (requests→Chrome auto)│    │     ├ OddsMoveDetector (drops)    │
 └ kambi.py     LeoVegas (…)  API pública CDN Kambi, sin navegador ┘    │                                  │
   ▲ común: competitions.json (competiciones) + markets.py (mercados)  │  → Bet → filtros usuario → 🔓     │
                                                                       └──────────────────────────────────┘
```

## Qué se recoge (igual en todas las casas)
* **Deportes**: fútbol, baloncesto, tenis. **Competiciones principales** definidas UNA vez en
  `scraper/competitions.json` (Champions, Europa/Conference League, LaLiga, Copa del Rey, Premier, Serie A,
  Bundesliga, Ligue 1, selecciones, Libertadores · NBA, Euroliga, EuroCup, ACB · ATP, WTA, Grand Slams, Finals,
  Davis/BJK). Cada competición tiene un nombre canónico (el que se guarda) y las regex con las que la nombra cada
  casa. Se recarga en caliente en todos los colectores. `python winamax.py --list` / `python paston.py --list`
  vuelcan el catálogo de la casa con ✔ en lo seleccionado (útil para añadir patrones).
* **Mercados** (taxonomía en `scraper/markets.py`, clave `METRICA[_HOME|_AWAY][_PERIODO]`):
  * Resultado: `1X2` (2 vías en tenis/baloncesto), `DNB`, `BTTS`, `HANDICAP` (+ `HANDICAP_CORNERS`, `HANDICAP_SETS`…).
  * **Todos los Más/Menos**: `TOTAL` (goles/puntos/juegos) con todas las líneas alternativas, por equipo
    (`TOTAL_HOME`, `TOTAL_AWAY`) y por periodo (`_1H`, `_2H`, `_Q1`…`_Q4`, `_SET1`…), `CORNERS`, `CARDS`, `SHOTS`,
    `SHOTS_OT`, `FOULS`, `OFFSIDES`, `THREES`, `SETS`, `ASSISTS`, `REBOUNDS`, `STEALS`, `BLOCKS`…
  * **Props de jugador**, todo lo que ofrezca cada casa: `PLAYER_GOALS` (goleador = Más de 0.5; "marca 2 o más" =
    Más de 1.5), `PLAYER_SHOTS`, `PLAYER_SHOTS_OT`, `PLAYER_ASSISTS`, `PLAYER_CARDS`, `PLAYER_SAVES`, `PLAYER_FOULS`,
    `PLAYER_OFFSIDES`, `PLAYER_POINTS`, `PLAYER_REBOUNDS`, `PLAYER_THREES`, `PLAYER_PRA`/`PR`/`PA`/`RA`,
    `PLAYER_STEALS`, `PLAYER_BLOCKS`… con el nombre en la columna `player` (también por periodo: `PLAYER_GOALS_1H`).
  * Se descartan a propósito: combinadas, resultado exacto, par/impar, márgenes, minutos concretos, "X o suplente",
    dúos/tríos, intentos de tiro en NBA (FGA/FTA/2PA) y cualquier estadística no reconocida (así nunca se
    emparejan mercados distintos entre casas).
* Cuotas **pre-partido** (próximas 48 h) y **en vivo** (marcador, periodo, minuto).

## Casas
| casa (`bookmaker`) | cómo | IP española | intervalo |
|---|---|---|---|
| `winamaxes` | Socket.IO `sports-eu-west-3.winamax.es` (EIO3). `live` + `match:ID` (todos los mercados) de los partidos seleccionados; pre-partido en paralelo cada 60 s. | no | live 5 s / pre 60 s |
| `paston` | REST Altenar `sb2frontend-altenar2.biahosted.com/api/widget/*?integration=paston` (`GetSportMenu`, `GetEvents`, `GetLiveOverview`, `GetEventDetails` con `markets` + `childMarkets` por jugador). | no | live 5 s / pre 180 s |
| `betsson` | API JSON del sportsbook OBG en `www.betsson.es/api/sb/v1` (`widgets/categories/v2` catálogo de competiciones, `widgets/events-table/v2` listados por competición, `widgets/event/v2` grupos de mercados, `widgets/accordion/v1` mercados+cuotas: líneas alternativas, periodos, props). AWS WAF + geobloqueo → `transport.py` modo `auto`: `requests` y, si bloquea, Chrome real en Xvfb haciendo `fetch()` desde la web. **Live por push**: `betsson_push.py` abre el websocket Diffusion `wss://www.betsson.es/diffusion` (binario + CBOR, sin navegador) y recibe precio/estado de cada mercado al instante; la REST solo refresca la estructura cada 20 s. | **sí** | live push (~0-2 s) / pre 60 s |
| `casumo` | `kambi.py --cfg casumo.json`: Kambi (offering `caes`), idéntico a LeoVegas; solo `requests`. |
| `speedybet` | `kambi.py --cfg speedybet.json`: Kambi (offering `pafspeedybetes`, grupo Paf), idéntico a LeoVegas; solo `requests`. |
| `paf` | `kambi.py --cfg paf.json`: Kambi (offering `pafes`), misma empresa y mismas cuotas que Speedybet; solo `requests`. |
| `limpieza` | `housekeeping.py`: cada 5 min borra de odds.db (por lotes) el histórico de más de 20 min y eventos sin ver en 6 h; VACUUM diario; **único proceso que hace checkpoint del `-wal`** (cada 15 s, reinicio forzado si pasa de 64 MB) (`DB_*`, `WAL_*` en .env). |
| `versus` | `sportium.py --cfg versus.json`: Playtech sportswidget (`sportswidget-cdn.versus.es`), idéntico a Sportium/Marca; solo `requests`. |
| `leovegas` | `kambi.py --cfg leovegas.json`: API pública de Kambi `eu-offering-api.kambicdn.com/offering/v2018/leoes` (`group.json` catálogo, `listView/<deporte>/<país>/<liga>.json` eventos+mercados principales por competición, `event/live/open.json` todos los directos en 1 llamada, `betoffer/event/<id>.json&type=1,2,6,7,18,21,127` todos los mercados). Sin WAF ni geobloqueo (devuelve 429 solo si se abusa → backoff). Mismo fichero sirve para cualquier otra casa Kambi cambiando `offering`. | no | live 5 s / pre 30 s |
| `bwines` | `bwin.py`: API Entain `www.bwin.es/cds-api` con `x-bwin-accessid` público (`bettingoffer/counts` catálogo, `bettingoffer/fixtures?state=Live` todos los directos en 1 llamada, `fixtures?competitionIds=…` pre-partido por competición con mercados principales, `fixture-view?fixtureIds=` todos los mercados). Mercados en 2 formatos (`optionMarkets` con parámetros MarketType/Period/DecimalValue y `games` legado), ambos tratados. Geobloqueo → `transport.py` `auto`. | **sí** | live 2 s / pre 30 s |
| `888sportes` | `spectate888.py`: API Spectate `spectate-web.888sport.es/spectate` (`inplay-req/getInplayEvents/all` todos los directos en 1 llamada, `inplay-req/event/<id>` todos los mercados de un directo, `sportsbook-req/getUpcomingEvents/<deporte>/<día>` pre-partido por día con mercado principal, `sportsbook/getEventData/…/<id>` todos los mercados pre-partido, ~1,8 MB). Requiere cookie de sesión anónima: se intenta con requests, luego `SPECTATE_COOKIE`/`cookie` de `spectate888.json`, y si no Chrome real solo para obtener la sesión. | **sí** | live 5 s / pre 60 s |
| `pokerstarses` | `pokerstars.py`: plataforma **Sisal** (desde 11-2025): API JSON pública `betting.pokerstars.es/api/lettura-palinsesto-sport/` (GET, sin cookies): `palinsesto/live/alberatura` árbol de todo el directo (62 KB, cada ciclo) + `palinsesto/live/v1/eventDetail/1-<id>` por evento de nuestras ligas (~45 KB, hasta `live_detail_per_cycle` por ciclo); pre-partido `schedaManifestazione/0/<deporte>-<competición>` (lista) + `prematch/v1/eventDetail/1-<id>` (todos los mercados; NBA ~2 MB). El tipo de mercado se deduce de las etiquetas de resultado (MÁS DE/MENOS DE, 1/X/2, SÍ/NO) y el texto pasa por `markets.classify`. Sin endpoint conocido del árbol pre-partido: catálogo por `shortcuts`/`hot-bets`/`top-match`/alberatura + `catalog_paths` candidatos + `extra_competitions` en `pokerstars.json` (`--probe` para ver qué responde). Geobloqueada fuera de España. | **sí** (IP) | live 2 s / pre 60 s |
| `codere` | `codere.py`: API JSON interna `m.apuestas.codere.es/NavigationService/…` (deporte → país → liga → evento → mercados `Games/Results`), sin cookies. Los nombres de algunos endpoints se autodescubren entre candidatos de `codere.json` (`--probe` enseña cuál responde). Etiqueta de competición `País - Liga`. Enlace: página del evento. | ¿sí? (IP) | live 5 s / pre 180 s |
| `tonybet` | `tonybet.py`: API JSON pública `platform.tonybet.es/api` (feed Sportradar): `v4/menu/line|live/es` ligas, `event/list` con `relations=odds,result,competitors,players` (live por deporte con `sportId_eq`, pre-partido por liga con `leagueId_in` + `time_lte` 48 h, `main=0` = todos los mercados). Los mercados no traen nombre: se normalizan por `vendorMarketId`/`vendorOutcomeId` de UOF (tabla fija en el código, `--dump <eventId>` la enseña). Etiqueta de competición `Categoría - Liga`. Enlace: página del evento `tonybet.es/prematch|live/...`. | sí (requests puro) | live 3 s / pre 300 s |
| `admiralbet` | `paston.py --cfg admiralbet.json`: Altenar (`integration=admiralbet.es`), solo configuración; enlace `#/sport/…/event/<id>`. | sí | live 6 s / pre 240 s |
| `solcasino` | `paston.py --cfg solcasino.json`: Altenar (`integration=solcasino`), solo configuración; enlace `?page=event&eventId=<id>`. | sí | live 7 s / pre 300 s |
| `yaass` | `yaass.py`: Yaass (Grupo Orenes, ex-Wanabet). Sportsbook propio de Orenes con feed Sportradar: API GraphQL pública `online-sportsbook.orenes.tech/offermanager/graphql` (cabecera `x-api-key` fija del front, sin cookies ni navegador). `categories` → torneos; `currentOffer` (status Live por deporte / Prematch por torneo, `to` 48 h) trae todos los mercados en la misma respuesta. **Live por push**: `yaass_push.py` abre la suscripción GraphQL `eventsChanged` por websocket (mismo endpoint en `wss://`, filtro status Live de los 3 deportes) y recibe el evento completo en cada cambio; el HTTP `currentOffer` Live solo se usa para sembrar/limpiar cada `push_refresh` s (30) y como respaldo si el socket cae (`"push": false` lo desactiva). Mercados normalizados por `marketKey` propio de Orenes + `marketSpecialSelectionsValues` (tabla MK en el código; `--dump <eventId>` la enseña). Etiqueta de competición `Categoría - Torneo`. Enlace: `yaasscasino.es/apuestas/event/<eventId>`. | sí (requests puro) | live push 2 s (sondeo 3 s) / pre 60 s |
| `dafabet` | `dafabet.py`: Dafabet España (Eurasia Solutions, licencia DGOJ). Sportsbook propio con API REST JSON pública en el mismo dominio (`dafabet.es/xapi/rest/...`, solo cabeceras `x-sb-brand: DAFASPAIN`; sin cookies ni navegador). `eventpathtree` → ligas (etiqueta `País - Liga`); `events?periodType=IN_RUNNING&liveOnly=true&eventPathIds=<deporte>` (una petición por deporte, todos los mercados) y `eventpaths/<liga>/events?periodType=PRE_MATCH` (una por liga). Mercados por `marketTypeId` + `opponentId` (lado) + `period.fullAbbreviation` + `extraKey1` (línea); props de jugador por descripción `Métrica - Jugador`. Líneas asiáticas cuarto descartadas. Enlace: `dafabet.es/es/events/<slug>`. Solo responde a IP española (fuera redirige a dafabet.com). `--list`, `--dump <eventId>`. | sí (requests puro) | live push 2 s (sondeo 3 s) / pre 60 s |
| `interwetten` | `interwetten.py`: Interwetten España. Directo por **websocket SignalR** `wss://sr5.gamesassists.com/lbfeventHub` (otro dominio, sin WAF ni cookies: `SubscribeLiveCalendar` + `SubscribeEventV2` + pushes `updateOutcome/addMarket/…`); competiciones reconocidas por nombre de liga. Catálogo y pre-partido por HTTP (turbo-stream `.data`: `top-leagues/country.data` → ligas; `/l/<liga>/x` → eventos; `/e/<evento>/x` → mercados) con **`curl_cffi`** (huella TLS de Chrome): la web está tras Cloudflare Bot Management y da 403 a `requests` normal aunque tenga cookies. Sin navegador (`browser_fallback: false`). `--list`, `--dump <id>`, `--probe`, `--hub [--all]`. | sí (websocket + curl_cffi) | live push / pre 300 s |
| `daznbet` | `daznbet.py`: DAZN Bet España (plataforma Flutter/PP, `sb-pp-esfe.daznbet.es`). Cuotas por **WebSocket SockJS+STOMP** sin cookies ni token, con `websockets` puro (sin navegador), como Winamax: listas `eventmap/live<SP>` y `eventmap/upcoming<SP>`, `events/<id>` + `eventmarketsmap/<id>`, `markets/<id>` (estado inicial + parches JSON-patch por push, gzip+base64). Taxonomía estructurada (`type/period/scoreType`, `selTemplate`) → mapeo por tabla: 1X2/DC/DNB/BTTS (+mitades, cuartos), totales (partido/equipo, córners, tarjetas), hándicap asiático/puntos, goleadores (0.5/1.5/2.5), props de jugador por `playerName`. Un destino inválido o pasarse del límite de suscripciones por socket cierra el socket: `event_sockets` (3) / `market_sockets` (6) / `subs_per_socket` (150); `prematch_max_events` (120). `--list`, `--dump <eventId>`. | sí (websockets puro) | push; volcado cada 2 s / pre 60 s |
| `goldenpark` | `goldenpark.py`: GoldenPark (plataforma **SportnCo / Gaming1**). Pre-partido por `POST ws.goldenpark.es/component/datatree` (árbol JSON, sin cookies; WAF F5 → `request_gap` 2 s y pausa 90 s al primer 429). Directo por **SSE** `events.goldenpark.es/live` con todos los `match_id` en vivo (snapshots completos cada 1-2 s, 0 peticiones por ciclo). Competiciones «Categoría - Competición» (`competitions.json`). `--list` / `--once` / `--dump <event_id>`. Enlace: página del evento. | sí | live 2 s (push) / pre 300 s |
| `bet777` | `bet777.py`: Bet777 España (plataforma **Swarm de BetConstruct**). Un único websocket `wss://eu-swarm-ws-re.betcoswarm.com/` (Origin bet777.es, `site_id` 999999, sin cookies ni WAF, `websockets` puro): directo por **suscripción** con parches incrementales (0 peticiones por ciclo, estado local siempre al día), pre-partido con un `get` por deporte. Mercados por `market.type` estable de BetConstruct (tabla `MK`), periodo por `market.sequence`. `--list` / `--dump <gameId>`. Enlace: página del evento `bet777.es/match/<gameId>/`. | sí | live 2 s (push) / pre 60 s |
| `betinia` | `paston.py --cfg betinia.json`: Altenar (`integration=betiniaes`), solo configuración; enlace al widget WSDK (`?sportRoutingParams=page~event__…__eventId~<id>`). | sí | live 5 s / pre 180 s |
| `jokerbet` | `paston.py --cfg jokerbet.json`: mismo sportsbook Altenar que Pastón (`integration=jokerbet`); solo configuración (`jokerbet.json`). Enlace a la página del partido (`apuestas-deportivas.html#/sport/…/event/<id>`). | **sí** (IP) | live 5 s / pre 180 s |
| `betwayes` | `betway.py`: API JSON propia de betway.es sin cookies (`POST /es/api/sports/content/getEventDetails` → todos los mercados de un evento, ~100 KB gzip). Listas de eventos (directo + próximos por deporte) sacadas del payload RSC de `/es/es/sports/live?categoryFilter=<deporte>` (cabecera `RSC: 1`). Responde desde cualquier IP. `--probe` comprueba las páginas de listado, `--dump <eventId>` muestra los mercados. | no | live 5 s / pre 180 s |
| `sportium` | `sportium.py`: feed público del CDN Playtech "sportswidget" (`sportswidget-cdn.sportium.es/v2/getmeta` + `getslice/*.bin`, LZMA + tablas columnares, decodificador en `ptslice.py`). Foto completa al arrancar (~4 MB, 3 s) y después solo deltas de 2-5 KB cada ciclo; mercados completos por evento con `getslice/event/full/...` (~20 KB, cacheado). Sin cookies, sin geobloqueo, sin navegador. `--list`, `--probe`, `--dump <eventId>`. Enlace a la página del partido. | no | live 5 s / pre 30 s |
| `marca` | `sportium.py --cfg marca.json`: Marca Apuestas usa la misma plataforma Playtech (`sportswidget-cdn.marcaapuestas.es`); solo configuración. El catálogo de competiciones tiene otros nombres (`España - Primera División`, `Reino Unido - Inglaterra - Premier League`…), por eso tiene sus propios patrones `marca` en `competitions.json`. | no | live 5 s / pre 30 s |

> **Betsson** se analizó con capturas hechas desde un PC en España (sus APIs no responden desde
> fuera). La estructura de listados y mercados principales está verificada; el mapeo de props de jugador y
> mercados menos comunes es heurístico (`markets.py`): si en el log ves muchos "0 ev" o faltan mercados, ejecuta
> `python betsson.py --list` (competiciones que ve la casa y cuáles casan con
> `competitions.json`) y manda el log. `transport` en `betsson.json`: `auto` (por defecto),
> `requests` (solo directo) o `browser` (solo Chrome).

**Casas descartadas (no volver a intentar):** Kirolbet y Luckia (WAF Akamai/Cloudflare), Retabet (F5),
OlyBet (captcha), bet365.

## Bot
Mismo bot de suscripciones (Stripe, Mini App, filtros por usuario); la fuente es `odds.db`. Señales:
* **Middlebet entre casas** (`MIDDLE_*`): Más de L1 en una casa + Menos de L2 > L1 en otra (o hándicaps con hueco
  local/visitante), hueco ≥ `MIDDLE_MIN_GAP` y pérdida máxima fuera del hueco ≤ `MIDDLE_MAX_LOSS_PCT` %. Se marcan 🎯 y
  el usuario puede desactivarlos en sus filtros (`middlebets_marked`).
* **Surebet entre casas**: para cualquier mercado de la taxonomía — 1X2 a 3 vías (fútbol) o 2 vías, `DNB`, `BTTS`,
  hándicaps (línea local ↔ línea visitante opuesta) y **todos los Más/Menos incluidos props de jugador**. Emite si
  Σ(1/cuota) < 1 y beneficio ≥ `SUREBET_DETECTOR_MIN_PROFIT`, con ≥ 2 casas distintas.
  Emparejamiento de eventos entre casas difuso (`Man Utd` ≈ `Manchester United`, `Como 1907` ≈ `Como`,
  `ORL Magic` ≈ `Orlando Magic`; misma fecha y deporte) y de jugadores (`Nico Paz` ≈ `Nicolas Paz Martinez`).
  El mensaje muestra mercado legible ("Total Como 1ª parte", "Paolo Banchero · Puntos") y patas con casa y cuota.

## Arranque (servidor con IP española residencial, Docker)
```bash
cp .env.example .env     # BOT_TOKEN, ADMIN_ID y umbrales SUREBET_* / MIDDLE_*
docker compose up -d --build                  # winamax + paston + betsson + bot
docker compose --profile miniapp up -d        # + Mini App (requiere MINIAPP_URL https público: Cloudflare Tunnel, ver bot/miniapp/README.md)
docker compose logs -f winamax                # "live 3 ev / 38 cambios (0.4s)" · "prematch 113 ev / … (11s)"
docker compose logs -f paston                 # "live 2 ev / 40 cambios | prematch 102 ev / … (7.9s)"
docker compose logs -f scraper                # "pasada 0.4s | live_futbol:0/0 prematch_futbol:14/3 ..."
# mercados/eventos guardados por casa (desde el host: python scraper/dbstats.py data/odds.db [casa])
docker exec -it betbot-scraper python dbstats.py /app/data/odds.db
```
Winamax y Pastón funcionan desde cualquier IP. Betsson necesita IP española; un VPS de
datacenter puede recibir 403 del WAF → `PROXY=` residencial español en `.env`.

## Mantenimiento (Betsson)
Si una casa cambia su API, su colector lo avisa en el log (StructureChanged) y se corrige su `<casa>.py`/`<casa>.json`.

## Estructura
```
docker-compose.yml  .env.example  .gitignore
run_all.py / start.bat  (arranque en Windows: todos los colectores + bot + Mini App + túnel)
scraper/  competitions.json / competitions.py  (competiciones, común)   markets.py (taxonomía de mercados, común)
          storage.py (OddsStore → odds.db)   transport.py (requests; Chrome real solo como respaldo si una casa bloquea)
          <casa>.py + <casa>.json por casa (kambi.py sirve a leovegas/casumo/speedybet/paf; paston.py a las Altenar;
          sportium.py a sportium/marca/versus)   *_push.py (websockets de Kambi/Betsson/Yaass)   pace.py · demand.py · ptslice.py
          housekeeping.py (limpieza de odds.db)   dbstats.py · audit.py (diagnóstico)   Dockerfile.* (imágenes)
bot/      main.py · config.py · services/odds_source.py (lee odds.db) · services/signals.py (detectores + emparejado)
          services/distribution.py (envío en paralelo) · miniapp/ (Flask + index.html) · Stripe, suscripciones, filtros
data/     bot_v2.db · odds.db (la Mini App lee el estado de los colectores de su tabla scraper_status)
```

## Datos en odds.db
`events(bookmaker,event_id,sport,competition,home,away,start_date,start_time,url,is_live,score,period,timer)` ·
`odds_latest(bookmaker,event_id,market_code,market,selection,line,player,price,prev_price,changed_at,seen_at)` ·
`odds_history` (solo cambios) · `scraper_status` (`last_run`, `winamax_last_ok`, `paston_last_ok`…).
`market_code = MARKET|jugador|línea|selección` es estable entre casas. Selecciones: `1/X/2`, `Over/Under`, `Yes/No`.
Hándicap: la línea es la de la selección (`1 -1.5` ↔ `2 +1.5`).

### Añadir otra casa
Si usa Kambi (LeoVegas, Casumo, Paf…): copia `leovegas.json` con su `offering` y `event_url`, añade el
servicio en `run_all.py`/`docker-compose.yml` y la casa en `bot/domain/bookmakers.py` (+ `bot/miniapp/app.py`,
`bot/miniapp/static/index.html`). El `offering` se ve en el HTML de la web (`kambiOffering`) o en las peticiones a
`kambicdn.com` de la pestaña Red.
Con API propia: copia `paston.py` (REST) o `winamax.py` (WebSocket), convierte cada mercado con
`classify(título, deporte, local, visitante, kind=…, player=…)` y guarda `row["selections"]` con
`OddsStore(bookmaker="<clave de bot/domain/bookmakers.py>")`. Si la API está protegida (WAF/geo), usa `transport.Http`
como `betsson.py`. Sin API: usa `transport.Http(mode='browser')` (Chrome real) como Betsson.
Añade los patrones de nombres en `competitions.json`.

## Prueba local sin Docker (Windows)
1. Copia `.env.example` a `.env` y rellena `BOT_TOKEN` y `ADMIN_ID` (el resto puede quedarse; las rutas `/app/data/...`
   se traducen solas a `./data/`).
2. Opcional: descarga `cloudflared.exe` a la carpeta del proyecto para que la Mini App sea pública automáticamente.
3. Doble clic en `start.bat` (o `python run_all.py`). Arranca todos los colectores, el bot, la Mini App y el túnel; cada
   línea de log va con el prefijo de su servicio, los servicios caídos se reinician solos y Ctrl+C lo para todo.
   La URL del túnel se escribe en `data/miniapp_url.txt` y el bot la usa sin reiniciar: `/start` → ⚙️ Panel.
   `python run_all.py --only bot,miniapp,winamax` para arrancar solo algunos; `--no-tunnel` sin cloudflared.
4. `python dbstats.py ..\data\odds.db` (carpeta `scraper`) muestra qué hay en la base de cuotas; `python audit.py --full`
   genera `data\audit.txt` (salud de cada casa, cobertura, mercados únicos, cuotas incoherentes y títulos → mercado).

Ritmo de peticiones: Betsson bloquea la IP si se les pide demasiado (403 en toda la web durante horas).
Para no pasarse, esos dos colectores (a) solo detallan partidos que otra casa ya tiene en `odds.db` (`demand_only`,
`scraper/demand.py`: sin pareja no hay surebet posible), (b) separan las peticiones `request_gap` s en vez de lanzarlas
en ráfaga.
partido desaparece de la casa, el colector escribe una retirada (fila con `price NULL` en `odds_history`) y el bot la
saca de su libro: sin surebets fantasma con cuotas suspendidas.

