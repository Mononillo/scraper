"""
BetFormatter: convierte una Bet en el mensaje que se envía al usuario.

REGLA DE ORO: **los importes NO se tocan**. El stake se muestra exactamente
como lo manda el proveedor (ya viene en euros y redondeado). No se recalcula
el reparto, no se redondea, no se convierte ninguna divisa.

    🔒 SUREBET · 💰 4.53%
    ⚽ Fútbol · Paraguay. Copa Paraguay
    ⚔️ Cerro Porteno - Rubio Nu · Tiempo reglamentario
    🕒 30 Sep 22:30 UTC

    Bet365ES
    ▫️ Hándicap asiático Cerro Porteno (-0.5) → `1.65`
       Stake: `63.35 €` · Apostar

    Codere
    ▫️ En contra · Hándicap asiático Cerro Porteno (+0.5) → `1.54`
       Stake: `67.87 €` · Riesgo `36.65 €` · Apostar

    💰 Beneficio: `4.53 €` por cada 100 €

Lo único que se AÑADE (no se modifica):
  · En una pata LAY se aclara el RIESGO real: stake × (cuota − 1).
    BetBurger solo muestra el stake del exchange y confunde: con 63.35 + 67.87
    parece que arriesgas 131 cuando en realidad arriesgas 100.
  · La última línea aplica el % del proveedor al banco de ejemplo
    (EXAMPLE_STAKE) para ver el beneficio en euros.
"""
from __future__ import annotations
from urllib.parse import urlsplit, urlunsplit

from domain.models import Bet
from domain.bookmakers import CATALOG as BOOKMAKERS
from domain.sports import CATALOG as SPORTS
from domain.markets import translate_selection, translate_period, split_teams
from config import CONFIG
from i18n import t


# ── Banco de ejemplo y divisa ─────────────────────────────
# Se pueden cambiar desde el .env:  EXAMPLE_STAKE=250 · STAKE_CURRENCY=€
EXAMPLE_STAKE = int(getattr(CONFIG, "example_stake", 0) or 100)
CURRENCY = (getattr(CONFIG, "stake_currency", "") or "€").strip()


class BetFormatter:

    def format(self, bet: Bet, lang: str = "es",
               deep_links: bool = False) -> str:
        """
        `deep_links=True`  → botón al "Place Bet" del proveedor (exige su
                             sesión: solo tiene sentido para ti / los admins).
        `deep_links=False` → botón a la web de la casa (funciona para todos).
        """
        return self._format_surebet(bet, lang, deep_links)

    def _format_surebet(self, bet: Bet, lang: str, deep_links: bool = False) -> str:
        t1, t2 = split_teams(bet.game)   # "Team1 Win" → "Gana Cerro Porteno"

        parts = []
        if bet.is_middle:
            # middle: profit_pct es el PEOR caso (solo entra una pata); si el resultado cae en el hueco cobran las dos
            worst = ("peor caso" if lang == "es" else "worst case")
            headline = f"*{t('bet.middle_tag', lang)}* · {worst} `{bet.profit_pct:+.2f}%`"
        else:
            headline = (f"🔒 *{t('bet.surebet', lang)}* · 💰 "
                        f"`{bet.profit_pct:.2f}%`")
        parts.append(headline)
        parts.append(self._sport_line(bet, lang))
        if bet.game:
            event = f"⚔️ *{esc(bet.game)}*"
            if bet.period:
                event += f" · _{esc(translate_period(bet.period, lang))}_"
            parts.append(event)
        if bet.market:
            parts.append(f"📊 {('Mercado' if lang == 'es' else 'Market')}: *{esc(bet.market)}*")
        if bet.starts_at:
            parts.append(f"🕒 {esc(bet.starts_at)}")
        parts.append("")

        blocks = [self._render_block(line, lang, deep_links, t1, t2)
                  for line in bet.lines]
        parts.append("\n\n".join(blocks))

        # El beneficio es el % del proveedor aplicado al banco del ejemplo:
        # no recalculamos nada, los stakes se muestran tal cual llegan.
        parts.append("")
        if bet.is_middle:
            both = sum((l.provider_stake or 0) * l.odds for l in bet.lines) - 100.0
            gap = self._middle_gap_text(bet, lang)
            if gap:
                parts.append(gap)
            win_txt = "Si cae en el hueco ganas las dos" if lang == "es" else "If it lands in the gap both win"
            out_txt = "si no, resultado" if lang == "es" else "otherwise"
            parts.append(f"🎯 {win_txt}: *{money(round(EXAMPLE_STAKE * both / 100, 2))}* · "
                         f"{out_txt}: *{money(round(EXAMPLE_STAKE * bet.profit_pct / 100, 2))}* "
                         f"{t('bet.per', lang, amount=money(EXAMPLE_STAKE))}")
        else:
            parts.append(
                f"💰 {t('bet.profit', lang)}: "
                f"*{money(round(EXAMPLE_STAKE * bet.profit_pct / 100, 2))}* "
                f"{t('bet.per', lang, amount=money(EXAMPLE_STAKE))}")
        return "\n".join(parts)

    @staticmethod
    def _middle_gap_text(bet: Bet, lang: str) -> str:
        """'🪟 Hueco: 19 exacto' · '🪟 Hueco: de 19 a 21' (totales) · hándicaps: margen de victoria dentro del hueco."""
        import math
        vals = [l.line_value for l in bet.lines if l.line_value is not None]
        if len(vals) != 2:
            return ""
        label = "Hueco" if lang == "es" else "Gap"
        codes = [(l.market_code or "").split("|")[0] for l in bet.lines]
        if any(c.startswith("HANDICAP") for c in codes):
            # hándicap: la pata del local (línea la) gana si margen > -la; la del visitante (lb) si margen < lb.
            # Las dos cobran cuando -la < margen local < lb.
            la = lb = None
            for l in bet.lines:
                sel = (l.market_code or "").split("|")
                side = sel[3] if len(sel) > 3 else ""
                if side == "1" or (side == "" and la is None):
                    la = l.line_value
                else:
                    lb = l.line_value
            if la is None or lb is None:
                return ""
            first, last = math.floor(-la) + 1, math.ceil(lb) - 1
            if first > last:
                return ""
            t1, t2 = split_teams(bet.game)
            def _m(x):      # margen expresado como "Local por N" / "Visitante por N" / "empate"
                if x > 0:
                    return f"{t1} {'gana por' if lang == 'es' else 'wins by'} {x}"
                if x < 0:
                    return f"{t2} {'gana por' if lang == 'es' else 'wins by'} {-x}"
                return "empate" if lang == "es" else "draw"
            if first == last:
                txt = _m(first) + (" exactamente" if lang == "es" else " exactly")
            elif first < 0 < last or first == 0 or last == 0:
                txt = (f"de {_m(first)} a {_m(last)}" if lang == "es" else f"{_m(first)} to {_m(last)}")
            elif last < 0:
                txt = (f"{t2} por {-last}–{-first}" if lang == "es" else f"{t2} by {-last}–{-first}")
            else:
                txt = (f"{t1} por {first}–{last}" if lang == "es" else f"{t1} by {first}–{last}")
            return f"🪟 {label}: *{esc(txt)}*"
        lo, hi = sorted(vals)
        first, last = math.floor(lo) + 1, math.ceil(hi) - 1
        if first > last:
            return ""
        rng = f"{first}" if first == last else f"{first}–{last}"
        word = ("exacto" if first == last else "") if lang == "es" else ("exactly" if first == last else "")
        return f"🪟 {label}: *{rng} {word}*".rstrip()

    # ── Bloque de una casa ─────────────────────────────────
    def _render_block(self, line, lang: str,
                      deep_links: bool = False,
                      team1: str = "", team2: str = "") -> str:
        """
        IMPORTANTE: el stake NO se recalcula. Se muestra exactamente el que
        manda el proveedor (ya viene en euros y redondeado).
        """
        bk = BOOKMAKERS.get(line.bookmaker_key)
        bk_name = BOOKMAKERS.label(line.bookmaker_key)
        # Con deep_links usamos el "Place Bet" del proveedor; si no, la web
        # de la casa (que funciona sin estar registrado en ningún sitio).
        if deep_links:
            bk_url = line.url or (bk.url if bk else "")
        else:
            bk_url = bk.url if bk else ""
        selection = esc(translate_selection(line.selection, lang,
                                            team1, team2))

        age = getattr(line, "_age", None)
        age_txt = f" _(hace {int(round(age))}s)_" if age is not None else ""
        out = [f"*{esc(bk_name)}*", f"▫️ {selection} → `{fmt_odds(line.odds)}`{age_txt}"]

        bits = []
        stake = line.provider_stake
        if stake is not None:
            bits.append(f"{t('bet.stake', lang)}: `{money2(stake)}`")
        if bk_url:
            bits.append(f"[{esc(t('bet.place_bet', lang))}]({safe_url(bk_url)})")
        if bits:
            out.append("   " + " · ".join(bits))
        return "\n".join(out)

    # ── Helpers ────────────────────────────────────────────
    def _sport_line(self, bet: Bet, lang: str) -> str:
        s = SPORTS.get(bet.sport_key)
        name = (s.name_es if lang == "es" else s.name_en) if s else bet.sport_key
        emoji = s.emoji if s else "🎲"
        line = f"{emoji} *{esc(name.upper())}*"
        if bet.league:
            line += f" · _{esc(bet.league)}_"
        return line


# ══════════════════════════════════════════════════════════
#  Utilidades de formato
# ══════════════════════════════════════════════════════════

def money2(amount) -> str:
    """Muestra el importe tal cual llega: 42 → '42 €' · 63.35 → '63.35 €'."""
    if amount is None:
        return "—"
    try:
        v = float(amount)
    except (TypeError, ValueError):
        return f"{amount} {CURRENCY}"
    txt = f"{v:.0f}" if abs(v - round(v)) < 1e-9 else f"{v:.2f}"
    return f"{txt} {CURRENCY}"


def money(amount) -> str:
    """63.35 → '63.35 €' · 100 → '100 €' (divisa: STAKE_CURRENCY)."""
    if amount is None:
        return "—"
    try:
        v = float(amount)
    except (TypeError, ValueError):
        return f"{amount} {CURRENCY}"
    txt = f"{v:.0f}" if abs(v - round(v)) < 0.005 else f"{v:.2f}"
    return f"{txt} {CURRENCY}"


def fmt_odds(odds) -> str:
    """1.65 → '1.65' · 2.0 → '2.0' · 1.7143 → '1.7143'"""
    try:
        s = f"{float(odds):.4f}".rstrip("0")
        return s + "0" if s.endswith(".") else s
    except (TypeError, ValueError):
        return str(odds)


def safe_url(url: str) -> str:
    """
    Telegram (Markdown legacy) se hace un lío con algunos caracteres dentro
    de los enlaces. Codificamos '_' de la QUERY (is_live=0 → is%5Flive=0),
    que los servidores decodifican igual.
    """
    if not url:
        return ""
    try:
        parts = urlsplit(url)
        if parts.query:
            q = parts.query.replace("_", "%5F")
            return urlunsplit((parts.scheme, parts.netloc, parts.path, q,
                               parts.fragment))
    except Exception:
        pass
    return url


def esc(s: str) -> str:
    """Escapa caracteres conflictivos del Markdown legacy de Telegram."""
    if not s:
        return ""
    return (s.replace("\\", "\\\\")
             .replace("_", "\\_")
             .replace("*", "\\*")
             .replace("`", "\\`")
             .replace("[", "\\["))
