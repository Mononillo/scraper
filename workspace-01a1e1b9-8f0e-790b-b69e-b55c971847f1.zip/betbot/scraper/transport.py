"""
transport.py — capa HTTP común para los colectores "API JSON" (Betsson, PokerStars, 888sport).

Dos transportes, mismo interfaz (`get_many(urls) -> list[(status, json|None)]`):

  requests : peticiones directas con una sesión `requests` (rápido, sin navegador).
  browser  : un Chrome real (patchright) con la web de la casa abierta en una pestaña; las llamadas a la
             API se hacen DESDE la página con `fetch()` (mismas cookies, token del WAF, cabeceras y TLS que
             un usuario). Es lo que hace falta cuando la casa protege la API (AWS WAF en Betsson, geo/DC
             en 888sport). En Docker corre bajo Xvfb; en Windows la ventana se abre fuera de pantalla.

  auto     : empieza con `requests`; si la API responde 202/403/429/5xx o algo que no es JSON, pasa a
             `browser` y se queda ahí (se vuelve a probar `requests` cada hora).

Variables de entorno: CHROME_PATH, PROFILE_DIR, HEADLESS (0/1), OFFSCREEN (0/1), PROXY.
"""
from __future__ import annotations

import fastjson as json
import logging
import atexit
import contextlib
import os
import random
import re
from urllib.parse import urlparse
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import requests

log = logging.getLogger("transport")
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
      "Chrome/130.0.0.0 Safari/537.36")
BLOCKED = {202, 400, 401, 403, 429}
_SKIP_HDR = {"cookie", "host", "content-length", "connection", "accept-encoding", "user-agent", "referer", "origin",
             "sec-fetch-mode", "sec-fetch-site", "sec-fetch-dest", "priority"}
def _note_fetch():
    try:
        from storage import note_fetch
        note_fetch()
    except Exception:  # noqa: BLE001
        pass


LEARNED: dict[str, str] = {}      # cabeceras que la propia web envía a su API (brandId, X-OBG-Device…)
SESSION: dict = {}                # cookies + User-Agent del navegador que hicieron funcionar `requests` (se persisten)


def _learned_path(origin: str):
    from pathlib import Path
    host = re.sub(r"[^a-z0-9.]+", "_", origin.lower().split("//")[-1])
    return Path(os.getenv("DATA_DIR", Path(__file__).parent.parent / "data")) / f"headers_{host}.json"


def _save_learned(origin: str):
    """Guarda las cabeceras aprendidas para que el siguiente arranque no necesite abrir el navegador."""
    if not LEARNED:
        return
    try:
        p = _learned_path(origin)
        p.parent.mkdir(parents=True, exist_ok=True)
        d = dict(LEARNED)
        if SESSION.get("cookies"):
            d["_session"] = {"cookies": SESSION["cookies"], "ua": SESSION.get("ua"), "ts": time.time()}
        p.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
    except Exception as e:  # noqa: BLE001
        log.debug("no pude guardar cabeceras: %s", e)


def _load_learned(origin: str) -> bool:
    try:
        p = _learned_path(origin)
        if p.exists() and time.time() - p.stat().st_mtime < 7 * 86400:
            d = json.loads(p.read_text(encoding="utf-8"))
            if isinstance(d, dict) and d:
                sess = d.pop("_session", None)
                if isinstance(sess, dict) and sess.get("cookies") and time.time() - float(sess.get("ts") or 0) < 2 * 86400:
                    SESSION.update({"cookies": dict(sess["cookies"]), "ua": sess.get("ua")})
                LEARNED.update({str(k): str(v) for k, v in d.items()})
                log.info("cabeceras de la web recuperadas de %s (%d%s)", p.name, len(d),
                         ", con %d cookies de sesión" % len(SESSION["cookies"]) if SESSION.get("cookies") else "")
                return True
    except Exception as e:  # noqa: BLE001
        log.debug("no pude cargar cabeceras: %s", e)
    return False

_JS_FETCH_START = """
([urls, headers, key, offset]) => {
  // Lanza los fetch y deja los resultados en window[key]; SIN setTimeout: en una ventana fuera de pantalla Chrome/Edge
  // estrangula los timers de la página (hasta 1/min) y cualquier espera/timeout en JS se eterniza. El ritmo y el
  // tiempo máximo los controla Python con evaluate() cortos, que no dependen de los timers de la pestaña.
  const st = window[key] || (window[key] = {done: 0, res: []});
  urls.forEach((u, i) => {
    fetch(u, {credentials: 'include', headers})
      .then(r => r.text().then(t => [r.status, t]))
      .catch(e => [0, String(e)])
      .then(v => { st.res[offset + i] = v; st.done++; });
  });
  return st.done;
}
"""
_JS_FETCH_POLL = "(key) => { const s = window[key]; return s ? s.done : -1; }"
_JS_FETCH_TAKE = "([key, n]) => { const s = window[key]; delete window[key]; const out = []; for (let i = 0; i < n; i++) out.push((s && s.res[i]) || [0, 'timeout']); return out; }"



def _find_chrome() -> str | None:
    env = os.getenv("CHROME_PATH")
    if env and Path(env).exists():
        return env
    pf = os.getenv("ProgramFiles", r"C:\Program Files")
    pf86 = os.getenv("ProgramFiles(x86)", r"C:\Program Files (x86)")
    local = os.getenv("LOCALAPPDATA", "")
    for c in [rf"{pf}\Google\Chrome\Application\chrome.exe", rf"{pf86}\Google\Chrome\Application\chrome.exe",
              rf"{local}\Google\Chrome\Application\chrome.exe", rf"{pf86}\Microsoft\Edge\Application\msedge.exe",
              "/usr/bin/google-chrome-stable", "/usr/bin/google-chrome", "/usr/bin/chromium"]:
        if c and Path(c).exists():
            return c
    return None


def kill_browsers(profile_dir: str | Path) -> int:
    """Mata procesos Chrome/Edge huérfanos que usen `profile_dir` (quedan vivos si el colector murió sin cerrar).
    Solo toca navegadores lanzados con nuestro --user-data-dir (los del usuario tienen otro perfil)."""
    needle = str(profile_dir)
    try:
        import subprocess
        if sys.platform == "win32":
            # cadena con el perfil escapada para -like (solo [ ] * ? son comodines) y para la cadena PowerShell
            n = needle.replace("'", "''").replace("[", "`[").replace("]", "`]")
            ps = ("$n='*--user-data-dir=*" + n + "*'; $k=0; "
                  "Get-CimInstance Win32_Process -Filter \"Name='msedge.exe' OR Name='chrome.exe'\" | "
                  "Where-Object { $_.CommandLine -like $n } | ForEach-Object { "
                  "try { Stop-Process -Id $_.ProcessId -Force -ErrorAction Stop; $k++ } catch {} }; $k")
            r = subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps],
                               capture_output=True, text=True, timeout=40)
            if r.returncode != 0 or r.stderr.strip():
                log.warning("kill_browsers: powershell rc=%s %s", r.returncode, r.stderr.strip()[:200])
            try:
                return int((r.stdout or "0").strip().splitlines()[-1])
            except (ValueError, IndexError):
                return 0
        r = subprocess.run(["pkill", "-f", "--", "--user-data-dir=" + needle], capture_output=True)
        return 1 if r.returncode == 0 else 0
    except Exception as e:  # noqa: BLE001
        log.warning("kill_browsers: %s", e)
        return 0


_SIGNALS_SET = False


def _install_signal_handlers():
    """SIGTERM / SIGINT / Ctrl+Break (Windows) -> cerrar navegadores (atexit no corre si matan el proceso)."""
    global _SIGNALS_SET
    if _SIGNALS_SET:
        return
    _SIGNALS_SET = True
    import signal
    import threading
    if threading.current_thread() is not threading.main_thread():
        return

    def _bye(signum, frame):
        raise SystemExit(0)                      # dispara atexit -> BrowserTransport.close()
    for name in ("SIGTERM", "SIGINT", "SIGBREAK"):
        sig = getattr(signal, name, None)
        if sig is not None:
            try:
                signal.signal(sig, _bye)
            except Exception:  # noqa: BLE001
                pass


def _merge(*dicts: dict | None) -> dict:
    """Une cabeceras sin duplicar por mayúsculas/minúsculas (la última gana): 'marketCode' + 'marketcode' -> una sola."""
    out: dict[str, str] = {}
    for d in dicts:
        for k, v in (d or {}).items():
            for k2 in [x for x in out if x.lower() == k.lower()]:
                del out[k2]
            out[k] = v
    return out


def _parse(status: int, text: str):
    if status != 200:
        return status, {"_error": (text or "")[:400]}     # cuerpo del error, para el log
    if not text:
        return status, None
    try:
        return status, json.loads(text)
    except ValueError:
        return status, None


# Perfil "suave": separación mínima entre el inicio de dos peticiones (todas las clases la respetan).
# Volumen igual, pero sin ráfagas de 8 peticiones simultáneas, que es lo que el WAF detecta.
import threading as _th
_PACE = {"gap": float(os.getenv("REQUEST_GAP", "0") or 0), "next": 0.0, "lock": _th.Lock()}


def set_request_gap(gap: float, group: str | None = None) -> None:
    """`group`: varias casas (procesos) que salen por la misma IP contra el mismo proveedor comparten UN ritmo:
    el instante del próximo permiso se guarda en data/pace_<group> con cerrojo de fichero. Así 4 casas Kambi no
    suman 4 × (1/gap) peticiones/s hacia el mismo CDN (que responde 429 a toda la IP)."""
    _PACE["gap"] = max(0.0, float(gap or 0))
    _PACE["group"] = None
    if group:
        try:
            d = Path(os.getenv("DATA_DIR", Path(__file__).parent.parent / "data"))
            d.mkdir(parents=True, exist_ok=True)
            f = d / f"pace_{group}"
            if not f.exists():
                f.write_bytes(b"0" * 24)
            _PACE["group"] = f
        except OSError as e:
            log.warning("ritmo compartido %s no disponible (%s): ritmo por proceso", group, e)


def _lock_file(fh, on: bool) -> None:
    if os.name == "nt":
        import msvcrt
        fh.seek(0)
        msvcrt.locking(fh.fileno(), msvcrt.LK_LOCK if on else msvcrt.LK_UNLCK, 24)
    else:
        import fcntl
        fcntl.flock(fh.fileno(), fcntl.LOCK_EX if on else fcntl.LOCK_UN)


_TLS = threading.local()


def low_priority(on: bool = True) -> None:
    """Marca el hilo actual como «segundo plano» (fichas pre-partido): en el ritmo compartido sólo coge hueco
    cuando no hay cola de peticiones prioritarias (live). Así las fichas pre-partido nunca retrasan el live."""
    _TLS.low = bool(on)


def _pace_shared(gap: float, low: bool = False, max_defer: float = 20.0) -> float:
    """Reserva el siguiente hueco en el fichero del grupo; devuelve cuánto hay que dormir.
    `low`: si hay cola (próximo hueco a más de 2 huecos vista), cede el turno y vuelve a mirar en breve."""
    f = _PACE["group"]
    t_start = time.time()
    try:
        while True:
            with open(f, "r+b") as fh:
                _lock_file(fh, True)
                try:
                    fh.seek(0)
                    raw = fh.read(24).strip(b"\0 ").decode() or "0"
                    try:
                        nxt = float(raw)
                    except ValueError:
                        nxt = 0.0
                    now = time.time()
                    if low and nxt > now + 2 * gap and now - t_start < max_defer:
                        defer = True
                    else:
                        defer = False
                        t = max(now, nxt)
                        fh.seek(0)
                        fh.write(f"{t + gap:<24.6f}".encode()[:24])
                        fh.flush()
                finally:
                    _lock_file(fh, False)
            if not defer:
                return max(0.0, t - now)
            time.sleep(max(gap, 0.05) + random.uniform(0, gap))
    except OSError:
        return 0.0


def _pace() -> None:
    gap = _PACE["gap"]
    if gap <= 0:
        return
    if _PACE.get("group"):
        wait = _pace_shared(gap, getattr(_TLS, "low", False))
        if wait > 0:
            time.sleep(wait)
        return
    with _PACE["lock"]:
        now = time.monotonic()
        t = max(now, _PACE["next"])
        _PACE["next"] = t + gap
    if t > now:
        time.sleep(t - now)


class RequestsTransport:
    name = "requests"

    def __init__(self, origin: str, headers: dict | None = None, workers: int = 8):
        self.s = requests.Session()
        _ad = requests.adapters.HTTPAdapter(pool_connections=4, pool_maxsize=max(10, int(workers) + 2))
        self.s.mount("https://", _ad)
        self.s.mount("http://", _ad)
        if os.getenv("PROXY"):
            self.s.proxies = {"http": os.getenv("PROXY"), "https": os.getenv("PROXY")}
        self.s.headers.update({"User-Agent": UA, "Accept": "application/json, text/plain, */*",
                               "Accept-Language": "es-ES,es;q=0.9", "Origin": origin, "Referer": origin + "/"})
        self.extra = headers or {}
        self.pool = ThreadPoolExecutor(max_workers=workers)
        self.origin = origin
        self.timeout = 20.0          # ajustable por ciclo (ver Http.timeout_scope): en directo se acorta
        self._warm = False
        if SESSION.get("cookies"):          # sesión persistida de un arranque anterior (ver _save_learned)
            self.adopt(SESSION["cookies"], SESSION.get("ua"), persist=False)

    def _one(self, url: str, headers: dict | None = None):
        try:
            if not self._warm:        # primera visita: cookies de la home
                self._warm = True
                try:
                    self.s.get(self.origin + "/", timeout=20, headers={"Accept": "text/html"})
                except requests.RequestException:
                    pass
            _pace()
            r = self.s.get(url, timeout=self.timeout, headers=_merge(self.extra, LEARNED) if headers is None else headers)
            return _parse(r.status_code, r.text)
        except requests.RequestException as e:
            log.debug("GET %s: %s", url[:120], e)
            return 0, None

    def get_many(self, urls: list[str], headers: dict | None = None):
        return list(self.pool.map(lambda u: self._one(u, headers), urls))

    def adopt(self, cookies: dict, ua: str | None = None, persist: bool = True):
        """Hereda cookies (y UA) de la pestaña real: con ellas + cabeceras aprendidas muchas APIs aceptan requests."""
        for k, v in (cookies or {}).items():
            self.s.cookies.set(k, v)
        if ua:
            self.s.headers["User-Agent"] = ua
        self._warm = True
        if persist and cookies:
            SESSION.update({"cookies": dict(cookies), "ua": ua})

    def remember(self):
        """Guarda cookies+UA actuales junto a las cabeceras aprendidas: el próximo arranque prueba con ellas antes
        de abrir el navegador."""
        SESSION.update({"cookies": self.s.cookies.get_dict(), "ua": self.s.headers.get("User-Agent")})
        _save_learned(self.origin)

    def close(self):
        self.pool.shutdown(wait=False)


class BrowserTransport:
    name = "browser"

    def __init__(self, origin: str, headers: dict | None = None, start_url: str | None = None,
                 profile_dir: str | None = None, reload_every: int = 1800, api_hint: str = "/api/",
                 headless: bool | None = None):
        self.origin, self.headers, self.api_hint = origin, headers or {}, api_hint
        self.headless = (os.getenv("HEADLESS", "0") == "1") if headless is None else bool(headless)
        self.start_url = start_url or origin + "/"
        # Un perfil por casa: dos procesos con el mismo user-data-dir hacen que
        # Chrome/Edge "abra en la sesión existente" y el lanzamiento falle.
        host = re.sub(r"^www\.", "", urlparse(origin).netloc).split(":")[0].replace(".", "_")
        self.profile_dir = Path(profile_dir or os.getenv("PROFILE_DIR")
                                or Path(__file__).parent / f"chrome_profile_{host}")
        self.reload_every = reload_every
        self._reload_at = reload_every * random.uniform(0.8, 1.1)
        self.restart_every = int(os.getenv("BROWSER_RESTART_EVERY", "21600"))   # 6 h
        self._launched = 0.0
        self._next_gesture = time.time() + random.uniform(60, 180)
        self._pw = self._ctx = self._page = None
        self._opened = 0.0

    def _open(self):
        from patchright.sync_api import sync_playwright
        if sys.platform == "win32":
            import asyncio
            asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())
        _install_signal_handlers()
        n = kill_browsers(self.profile_dir)       # ventanas huérfanas de un arranque anterior
        if n:
            log.info("cerrados %s procesos de navegador huérfanos del perfil %s", n, self.profile_dir.name)
        self._pw = sync_playwright().start()
        chrome = _find_chrome()
        headless = self.headless
        args = ["--window-size=1366,900", "--disable-blink-features=AutomationControlled",
                "--no-first-run", "--no-default-browser-check", "--disable-session-crashed-bubble",
                "--hide-crash-restore-bubble",
                "--disable-features=TabRestore,SessionRestore,CalculateNativeWinOcclusion,IntensiveWakeUpThrottling,"
                "TabFreezing,PerformanceManagerPageFreezing,BackgroundTabLoadingFromPerformanceManager,msSleepingTabs,msEfficiencyMode",
                # la ventana va fuera de pantalla: sin estos flags Chrome la trata como "ocluida" y estrangula los
                # timers de la página (setTimeout a 1/s o peor) → los fetch escalonados tardan minutos y el ciclo se cuelga
                "--disable-background-timer-throttling", "--disable-backgrounding-occluded-windows",
                "--disable-renderer-backgrounding", "--disable-ipc-flooding-protection"]
        if sys.platform == "win32" and not headless and os.getenv("OFFSCREEN", "1") == "1":
            args.append("--window-position=-32000,-32000")
        kw = dict(user_data_dir=str(self.profile_dir), headless=headless, locale="es-ES",
                  timezone_id="Europe/Madrid", viewport={"width": 1366, "height": 900}, args=args,
                  ignore_default_args=["--enable-automation"])
        if chrome:
            kw["executable_path"] = chrome
        else:
            kw["channel"] = "chromium"
        if os.getenv("PROXY"):
            kw["proxy"] = {"server": os.getenv("PROXY")}
        self._ctx = self._pw.chromium.launch_persistent_context(**kw)
        self._page = self._ctx.pages[0] if self._ctx.pages else self._ctx.new_page()
        # cierra las pestañas restauradas de sesiones anteriores y cualquier popup que abra la web
        for p in list(self._ctx.pages):
            if p is not self._page:
                self._close_page(p)
        self._ctx.on("page", lambda p: p is not self._page and self._close_page(p))
        atexit.register(self.close)
        # NO se minimiza la ventana: minimizada, Chrome/Edge trata la pestaña como oculta y congela el renderer.
        # Fuera de pantalla (posición negativa) + flags anti-oclusión es lo menos estrangulado sin ser visible.
        self._page.on("request", self._learn)
        self._page.goto(self.start_url, wait_until="domcontentloaded", timeout=90000)
        for _ in range(30):                      # WAF challenge / cookies / primera llamada de la web a su API
            self._page.wait_for_timeout(500)
            if LEARNED:
                break
        self._page.wait_for_timeout(1500)
        log.info("cabeceras aprendidas de la web: %s", sorted(LEARNED) or "ninguna")
        _save_learned(self.origin)
        self._opened = self._launched = time.time()
        log.info("navegador abierto en %s (%s)", self.start_url, chrome or "chromium")

    @staticmethod
    def _close_page(p):
        try:
            p.close()
        except Exception:
            pass

    def _learn(self, req):
        """Copia las cabeceras con las que la web llama a su API (sin cookies): sirven para fetch y para requests."""
        try:
            if self.api_hint in req.url and req.resource_type in ("xhr", "fetch"):
                for k, v in req.headers.items():
                    if not k.startswith(":") and k.lower() not in _SKIP_HDR:
                        LEARNED[k] = v
        except Exception:
            pass

    def _liveness(self):
        """Cada 2–4 min un gesto de usuario (ratón/scroll) para que la sesión no parezca un navegador fantasma."""
        now = time.time()
        if now < self._next_gesture:
            return
        self._next_gesture = now + random.uniform(120, 240)
        try:
            vp = self._page.viewport_size or {"width": 1366, "height": 900}
            self._page.mouse.move(random.randint(50, vp["width"] - 50), random.randint(80, vp["height"] - 80), steps=random.randint(5, 15))
            if random.random() < 0.6:
                self._page.mouse.wheel(0, random.choice([-1, 1]) * random.randint(100, 600))
        except Exception:  # noqa
            pass

    def page(self):
        if self._page is None or self._page.is_closed():
            self.close()
            self._open()
        elif time.time() - self._opened > self._reload_at:
            if time.time() - self._launched > self.restart_every:       # reinicio completo: memoria del navegador
                log.info("reinicio periódico del navegador (%.1f h)", (time.time() - self._launched) / 3600)
                self.close()
                self._open()
            else:
                try:
                    self._page.reload(wait_until="domcontentloaded", timeout=60000)
                    self._page.wait_for_timeout(random.randint(2500, 5000))
                except Exception as e:  # noqa
                    log.warning("reload falló (%s): reabro navegador", e)
                    self.close()
                    self._open()
            self._opened = time.time()
            self._reload_at = self.reload_every * random.uniform(0.8, 1.1)   # jitter: nunca cada 1800 s exactos
        self._liveness()
        return self._page

    def get_many(self, urls: list[str], headers: dict | None = None, chunk: int = 60, timeout: float = 20.0):
        out = []
        for i in range(0, len(urls), chunk):
            batch = urls[i:i + chunk]
            t0 = time.time()
            key = f"__bb_{int(t0 * 1000) % 10_000_000}_{random.randint(0, 9999)}"
            try:
                hdrs = _merge(self.headers, LEARNED) if headers is None else headers
                page = self.page()
                gap = max(0.04, _PACE["gap"] or 0.04)
                step = 4                                               # arranques escalonados en grupos pequeños
                for k in range(0, len(batch), step):
                    page.evaluate(_JS_FETCH_START, [batch[k:k + step], hdrs, key, k])
                    if k + step < len(batch):
                        time.sleep(gap * step * random.uniform(0.6, 1.4))
                deadline = time.time() + timeout + 0.02 * len(batch)
                while time.time() < deadline:
                    if page.evaluate(_JS_FETCH_POLL, key) >= len(batch):
                        break
                    time.sleep(0.2)
                res = page.evaluate(_JS_FETCH_TAKE, [key, len(batch)])
                dt = time.time() - t0
                missing = sum(1 for st, _ in res if int(st) == 0)
                if missing:
                    log.warning("navegador: %d/%d peticiones sin respuesta en %.0fs", missing, len(batch), dt)
                elif dt > 20:
                    log.warning("navegador lento: %d peticiones en %.0fs", len(batch), dt)
            except Exception as e:  # noqa
                log.warning("fetch en página falló: %s", e)
                self.close()
                res = [[0, ""]] * len(batch)
            out.extend(_parse(int(st), tx) for st, tx in res)
        return out

    def get_text(self, url: str, headers: dict | None = None, timeout: float = 20.0) -> tuple[int, str]:
        """GET desde la pestaña devolviendo el cuerpo en crudo (para respuestas que no son JSON)."""
        key = f"__bb_{int(time.time() * 1000) % 10_000_000}_{random.randint(0, 9999)}"
        try:
            page = self.page()
            page.evaluate(_JS_FETCH_START, [[url], headers or _merge(self.headers, LEARNED), key, 0])
            deadline = time.time() + timeout
            while time.time() < deadline:
                if page.evaluate(_JS_FETCH_POLL, key) >= 1:
                    break
                time.sleep(0.15)
            st, tx = page.evaluate(_JS_FETCH_TAKE, [key, 1])[0]
            return int(st), tx or ""
        except Exception as e:  # noqa
            log.warning("fetch en página falló: %s", e)
            self.close()
            return 0, ""

    def warm(self, seconds: float = 8.0):
        """Simula a una persona en la web (ratón, scroll, segunda página) para que el sensor del WAF (Akamai
        `_abck`/`bm_sz`) valide la sesión antes de volver a usar las cookies con requests."""
        try:
            page = self.page()
            t_end = time.time() + seconds
            while time.time() < t_end:
                page.mouse.move(random.randint(100, 1200), random.randint(100, 800), steps=random.randint(5, 20))
                page.mouse.wheel(0, random.randint(-400, 900))
                page.wait_for_timeout(random.randint(400, 1200))
            links = page.eval_on_selector_all("a[href^='/']", "els => els.map(e => e.getAttribute('href')).slice(0, 40)") or []
            links = [l for l in links if l and len(l) > 8 and "#" not in l]
            if links:
                page.goto(self.origin + random.choice(links), wait_until="domcontentloaded", timeout=60000)
                page.wait_for_timeout(2500)
                page.mouse.wheel(0, 600)
                page.wait_for_timeout(1500)
        except Exception as e:  # noqa
            log.debug("warm: %s", e)

    def cookies(self) -> dict:
        try:
            return {c["name"]: c["value"] for c in self._ctx.cookies() if c.get("name")}
        except Exception:  # noqa
            return {}

    def user_agent(self) -> str | None:
        try:
            return self._page.evaluate("navigator.userAgent")
        except Exception:  # noqa
            return None

    def close(self):
        if self._ctx is None and self._pw is None:
            return
        for fn in ((lambda: [self._close_page(p) for p in list(self._ctx.pages)]),
                   (lambda: self._ctx.close()), (lambda: self._pw.stop())):
            try:
                fn()
            except Exception:
                pass
        self._pw = self._ctx = self._page = None
        kill_browsers(self.profile_dir)


class Http:
    """Fachada: elige transporte según `mode` ('auto' | 'requests' | 'browser')."""

    def __init__(self, origin: str, mode: str = "auto", headers: dict | None = None, start_url: str | None = None,
                 workers: int = 8, api_hint: str = "/api/", gap: float | None = None, headless: bool | None = None,
                 blocked: set | None = None, pace_group: str | None = None):
        self.origin, self.mode, self.headers, self.start_url, self.workers = origin, mode, headers, start_url, workers
        if mode != "browser" and not LEARNED:
            _load_learned(origin)
        self.blocked = set(blocked) if blocked is not None else set(BLOCKED)   # códigos que significan "WAF/bloqueo"
        self.headless = headless
        self.retry_requests = float(os.getenv("REQUESTS_RETRY", "600"))   # s entre intentos de volver a requests
        if gap is not None:
            set_request_gap(gap, pace_group)
        self.api_hint = api_hint
        self.t = BrowserTransport(origin, headers, start_url, api_hint=api_hint, headless=headless) if mode == "browser" \
            else RequestsTransport(origin, headers, workers)
        self._since_block = 0.0

    @property
    def name(self) -> str:
        return self.t.name

    def _switch_to_browser(self, why: str):
        log.warning("API bloqueada con requests (%s): paso a navegador", why)
        new = BrowserTransport(self.origin, self.headers, self.start_url, api_hint=self.api_hint, headless=self.headless)
        old, self.t = self.t, new
        try:
            old.close()
        except Exception:   # noqa: BLE001
            pass
        # primer reintento de requests (ya con cabeceras y cookies de la web) a los ~30 s
        self._since_block = time.time() - self.retry_requests + 30

    def get_many(self, urls: list[str], headers: dict | None = None) -> list[tuple[int, dict | list | None]]:
        _note_fetch()
        if not urls:
            return []
        if headers is not None:
            return self.t.get_many(urls, headers)
        if self.mode == "auto" and self.t.name == "browser" and time.time() - self._since_block > self.retry_requests:
            probe = RequestsTransport(self.origin, self.headers, self.workers)
            probe.adopt(self.t.cookies(), self.t.user_agent())
            st, js = probe.get_many(urls[:1])[0]
            if st == 200 and js is not None:
                log.info("requests funciona con las cookies/cabeceras del navegador: dejo el navegador")
                self.t.close()
                self.t = probe
                probe.remember()
            else:
                probe.close()
                self._since_block = time.time()
        res = self.t.get_many(urls)
        if self.mode == "auto" and self.t.name == "requests":
            sts = [s for s, _ in res]
            bad = sum(1 for s, j in res if s in self.blocked or s >= 500 or (s == 200 and j is None))
            if bad and bad >= max(1, len(res) // 2) and len(res) == 1 and res[0][0] in (400, 500, 502, 503, 504):
                # Un único 400/5xx puede ser un fallo puntual (petición mal formada, caída momentánea), no un WAF:
                # se repite una vez antes de abrir el navegador (que es lento y mete minutos de retraso).
                time.sleep(1.0)
                res = self.t.get_many(urls)
                sts = [s for s, _ in res]
                bad = sum(1 for s, j in res if s in self.blocked or s >= 500 or (s == 200 and j is None))
            if bad and bad >= max(1, len(res) // 2):
                self._switch_to_browser(f"{bad}/{len(res)} respuestas {sorted(set(sts))}")
                res = self.t.get_many(urls)
        return res

    def relearn(self, probe_url: str) -> bool:
        """Tras un 403/202 persistente del WAF: abre un navegador NUEVO, se comporta como una persona unos
        segundos, comprueba que la API responde y vuelve a `requests` con esas cookies frescas.
        Devuelve True si la API vuelve a responder (con requests o, si no, con el navegador)."""
        try:
            self.t.close()
        except Exception:   # noqa: BLE001
            pass
        browser = BrowserTransport(self.origin, self.headers, self.start_url, api_hint=self.api_hint, headless=self.headless)
        self.t = browser
        try:
            browser.page()
            browser.warm()
            st, js = browser.get_many([probe_url])[0]
            if st != 200 or js is None:
                log.warning("renovación de sesión: la API sigue bloqueada también desde el navegador (%s)", st)
                return False
            probe = RequestsTransport(self.origin, self.headers, self.workers)
            probe.adopt(browser.cookies(), browser.user_agent())
            st2, js2 = probe.get_many([probe_url])[0]
            if st2 == 200 and js2 is not None:
                log.info("renovación de sesión: requests vuelve a funcionar con cookies frescas del navegador")
                browser.close()
                self.t = probe
                probe.remember()
            else:
                probe.close()
                log.info("renovación de sesión: la API responde desde el navegador; sigo con él un rato")
                self._since_block = time.time()
            return True
        except Exception as e:   # noqa: BLE001
            log.warning("renovación de sesión falló: %s", e)
            return False

    def get(self, url: str, headers: dict | None = None):
        return self.get_many([url], headers)[0]

    @contextlib.contextmanager
    def timeout_scope(self, seconds: float):
        """Acorta el timeout HTTP mientras dura el bloque (ciclo en directo). Con el timeout por defecto de 20 s,
        una API que se cuelga convertía una pasada live de 2 s en 60-100 s (y la casa se quedaba ciega justo
        después del gol). En directo es mejor fallar rápido y reintentar en el siguiente ciclo."""
        t = self.t
        old = getattr(t, "timeout", None)
        if old is not None:
            t.timeout = seconds
        try:
            yield
        finally:
            if old is not None and getattr(self.t, "timeout", None) is not None:
                self.t.timeout = old

    def get_tolerant(self, url: str):
        """Prueba el GET con subconjuntos de cabeceras cada vez más pequeños (algunos endpoints rechazan
        cabeceras de telemetría). Devuelve (status, json) de la primera variante que responda 200."""
        if self.mode == "auto" and self.t.name == "requests" and LEARNED and getattr(self, "_learned_from_file", None) is None:
            # cabeceras recuperadas del disco: si la API las rechaza (400/401/403) se descartan y se reaprenden
            self._learned_from_file = True
            st0, _ = self.t.get_many([url])[0]
            if st0 == 200:
                return (st0, _)
            if st0 in (400, 401, 403):
                log.info("las cabeceras guardadas ya no valen (%s): se reaprenden", st0)
                LEARNED.clear()
                try:
                    _learned_path(self.origin).unlink()
                except Exception:  # noqa: BLE001
                    pass
        if self.mode == "auto" and self.t.name == "requests" and not LEARNED:
            # Primera llamada: un 400 suele ser una cabecera que el endpoint no acepta, no un WAF. Se prueban las
            # variantes de cabeceras con requests ANTES de pasar por self.get (que abriría el navegador).
            first = self.t.get_many([url])[0]
            if first[0] == 200:
                return first
            if first[0] != 400:
                self.get(url)                # 403/429/202: camino normal (navegador + aprender cabeceras)
        base = _merge(self.headers, LEARNED)
        keep_core = {"brandid", "marketcode", "x-obg-device", "x-obg-channel", "accept", "accept-language"}
        variants = [
            base,
            {k: v for k, v in base.items() if k.lower() not in ("sentry-trace", "baggage", "content-type", "correlationid", "sessiontoken")},
            {k: v for k, v in base.items() if k.lower() in keep_core or k.lower().startswith("x-sb-")},
            {k: v for k, v in base.items() if k.lower() in keep_core},
            {k: v for k, v in base.items() if k.lower() in ("brandid", "marketcode")},
        ]
        last = (0, None)
        for i, h in enumerate(variants):
            last = self.t.get_many([url], h)[0]
            if last[0] == 200:
                if i:
                    log.info("endpoint %s acepta solo la variante %d de cabeceras (%s)", url.split("?")[0][-40:], i, sorted(h))
                return last
        return last

    def close(self):
        self.t.close()
