"""
paston.py — colector de cuotas de Pastón (paston.es) sin navegador.

Pastón usa el sportsbook de Altenar: la web es un widget JS que consume una API REST pública
(`sb2frontend-altenar2.biahosted.com/api/widget/...`, parámetro `integration=paston`). Responde desde
cualquier IP. Endpoints usados:

    GetSportMenu      catálogo: deportes -> categorías -> campeonatos (con nombres)
    GetEvents         eventos pre-partido de un campeonato (apuesta principal)      champIds=…&eventCount=…
    GetLiveOverview   todos los eventos en vivo (marcador, minuto, periodo)
    GetEventDetails   TODOS los mercados de un evento (markets + childMarkets por jugador + odds)

Todos los mercados se normalizan con markets.py; competiciones con competitions.json (común a todas
las casas). Escribe en odds.db con bookmaker `paston`.

Uso:  python paston.py            (bucle)       python paston.py --once      python paston.py --list
"""
from __future__ import annotations

import fastjson as json
import logging
import os
import re
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from pathlib import Path

import requests

sys.path.insert(0, str(Path(__file__).resolve().parent))   # permite `python -m scraper.paston` desde betbot\
from competitions import Competitions
from markets import classify, parse_ou_label
from storage import OddsStore

log = logging.getLogger("paston")
def _cfg_path() -> Path:
    name = sys.argv[sys.argv.index("--cfg") + 1] if "--cfg" in sys.argv else os.getenv("PASTON_CFG", "paston.json")
    return Path(name) if os.path.isabs(name) else Path(__file__).parent / name


CFG_PATH = _cfg_path()
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
      "Chrome/130.0.0.0 Safari/537.36")

# typeId de las cuotas (odds) en Altenar
T_HOME, T_DRAW, T_AWAY, T_OVER, T_UNDER, T_YES, T_NO = 1, 2, 3, 12, 13, 74, 76
T_SCORER_ANY, T_SCORER_2PLUS, T_SCORER_3PLUS = 2092, 2101, 2102
OVER_TYPES, UNDER_TYPES = {12, 2501}, {13, 2502}       # 2501/2502 = Más de/Menos de en props de jugador (baloncesto)
_OU_NAME = re.compile(r"\b(m[aá]s|menos) de\b", re.I)


def load_cfg(path: Path | None = None) -> dict:
    import pace
    cfg = pace.apply(json.loads((path or CFG_PATH).read_text(encoding="utf-8")))
    cfg["_cfg_path"] = str(path or CFG_PATH)      # cada Collector recuerda su fichero (varias marcas por proceso)
    return cfg


class Api:
    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.s = requests.Session()
        self.s.headers.update({"User-Agent": UA, "Origin": cfg["origin"], "Referer": cfg["origin"] + "/",
                               "Accept": "application/json"})
        self.pool = ThreadPoolExecutor(max_workers=cfg.get("workers", 8))
        self.last_status: int | str | None = None        # último código HTTP (o excepción) para diagnosticar «0 eventos»
        self.timeout = 20.0                              # se acorta en el ciclo live (timeout_live)

    def get(self, endpoint: str, **params) -> dict | None:
        q = dict(self.cfg["query"], **params)
        try:
            r = self.s.get(f"{self.cfg['api_base']}/{endpoint}", params=q, timeout=self.timeout)
            self.last_status = r.status_code
            if r.status_code != 200:
                log.debug("%s -> %s", endpoint, r.status_code)
                return None
            return json.loads(r.content)
        except (requests.RequestException, ValueError) as e:
            self.last_status = type(e).__name__
            log.debug("%s falló: %s", endpoint, e)
            return None

    def many(self, endpoint: str, param_list: list[dict]) -> list[dict | None]:
        return list(self.pool.map(lambda p: self.get(endpoint, **p), param_list))


# ──────────────────────────────────────────────────────────────────────────────
# Conversión de un evento (GetEventDetails) a fila de OddsStore
# ──────────────────────────────────────────────────────────────────────────────
def _clean(name: str) -> str:
    name = re.sub(r"\(incl\.? pr[oó]rroga\)", "", name or "")
    return re.sub(r"\s+", " ", name.replace("\t", " ")).strip()


_TEAM_TOTAL = re.compile(r"^(?:(?P<per>[^-]+?)\s*-\s*)?(?P<team>.+?)\s+total(?: de goles| de puntos| de juegos)?\s*$", re.I)
_PERIOD_WORDS = re.compile(r"^(?:(?:1|2|3|4)\s*(?:ª|º|\.ª|\.º|er|a|o)?|primer[ao]?|segund[ao]|tercer[ao]?|cuart[ao])?\s*(mitad|parte|tiempo|cuarto|set|prórroga|prorroga)\b|^total\b|^goles\b", re.I)


def _norm_team_total(name: str, home: str, away: str) -> str | None:
    """Altenar: 'Villarreal Total de goles', '1ª Mitad - Villarreal Total de goles'. Si el texto delante de
    'Total de goles' es un equipo, se reescribe con el nombre EXACTO del competidor (a veces el título abrevia o
    traduce el nombre y markets.py no lo reconocía -> acababa como total del partido/1ª parte). Si no se puede
    atribuir a ninguno de los dos, se devuelve None y el mercado se descarta (nunca se guarda como total global)."""
    m = _TEAM_TOTAL.match(name)
    if not m:
        return name
    team = m.group("team").strip()
    if _PERIOD_WORDS.match(team) or re.fullmatch(r"(1ª|2ª)?\s*(mitad|parte)?\s*-?\s*", team, re.I):
        return name                                              # 'Total de goles', '1ª Mitad - total de goles'
    def _toks(x: str) -> set[str]:
        return {t for t in re.split(r"[^a-z0-9]+", x.lower().replace("á", "a").replace("é", "e").replace("í", "i")
                                     .replace("ó", "o").replace("ú", "u").replace("ñ", "n")) if len(t) >= 3
                and t not in {"club", "the", "los", "las", "del", "real", "deportivo", "sporting", "atletico", "athletic", "united", "city", "fc", "cf", "sc"}}
    tt = _toks(team)
    sh, sa = tt & _toks(home), tt & _toks(away)
    if team.lower() == home.lower() or (sh and not sa):
        side = home
    elif team.lower() == away.lower() or (sa and not sh):
        side = away
    else:
        return None
    return f"{m.group('per').strip()} - {side} Total de goles" if m.group("per") else f"{side} Total de goles"


# typeId de mercado de Altenar -> mercado de equipo. Es el identificador fijo del tipo de mercado (igual en Pastón,
# JokerBet, Betinia y AdmiralBet) y no depende del texto: en directo AdmiralBet titula "1 - Total de tarjetas" o
# "2 - Remates" y el texto no identifica al equipo; el typeId sí. Tiene prioridad sobre la clasificación por título.
TEAM_TOTAL_TYPES = {
    19: "TOTAL_HOME", 20: "TOTAL_AWAY", 69: "TOTAL_HOME_1H", 70: "TOTAL_AWAY_1H", 91: "TOTAL_HOME_2H", 92: "TOTAL_AWAY_2H",
    167: "CORNERS_HOME", 168: "CORNERS_AWAY", 178: "CORNERS_HOME_1H", 179: "CORNERS_AWAY_1H",
    140: "CARDS_HOME", 141: "CARDS_AWAY", 153: "CARDS_HOME_1H", 154: "CARDS_AWAY_1H",
    15728: "SHOTS_HOME", 15729: "SHOTS_AWAY", 15726: "SHOTS_OT_HOME", 15727: "SHOTS_OT_AWAY",
    15730: "OFFSIDES_HOME", 15731: "OFFSIDES_AWAY", 15732: "FOULS_HOME", 15733: "FOULS_AWAY",
    25166: "TACKLES_HOME", 25167: "TACKLES_AWAY",
}
# "1 - Total de juegos", "1 Total juegos", "Total de juegos 1", "Total de juegos (jugador 1)" -> local/visitante
_SIDE_PREFIX = re.compile(r"^(?:(?P<h>1|local|equipo 1|team 1|jugador 1)|(?P<a>2|visitante|equipo 2|team 2|jugador 2))(?:\s*[-–:]\s*|\s+)(?P<rest>[^\W\d].+)$", re.I)
# "2º Set 1 - Total de juegos", "1ª Mitad 2 - Total de goles", "3er cuarto 1 - Total de puntos": el número que va
# DETRÁS del período es el competidor (1 local / 2 visitante), no parte del período -> "<competidor> - <período> - <resto>"
# AdmiralBet tenis prematch: "Tercer set - 1 total" (= total de juegos del jugador 1 en el 3er set) frente a
# "Tercer set - total juegos" (total del set). El número puede ir pegado al período o tras un guion.
_SIDE_AFTER_PERIOD = re.compile(
    r"^(?P<per>(?:\d+\s*(?:ª|º|\.ª|\.º|er|a|o)?|primer[ao]?|segund[ao]|tercer[ao]?|cuart[ao]|quint[ao])"
    r"\s*(?:mitad|parte|tiempo|cuarto|set|periodo|período|prórroga|prorroga))"
    r"\s*(?:[-–:]\s*)?(?:(?P<h>1|jugador 1|equipo 1)|(?P<a>2|jugador 2|equipo 2))\s*(?:[-–:]\s*|\s+)(?P<rest>[^\W\d].+)$", re.I)
_SIDE_SUFFIX = re.compile(r"^(?P<rest>.+?[^\W\d])(?:\s*[-–:(]\s*|\s+)(?:(?P<h>1|local|equipo 1|team 1|jugador 1)|(?P<a>2|visitante|equipo 2|team 2|jugador 2))\)?\s*$", re.I)


def _line(sv: str | None) -> float | None:
    if not sv:
        return None
    m = re.match(r"\s*([+-]?\d+(?:[.,]\d+)?)", str(sv).split("|")[0])
    return float(m.group(1).replace(",", ".")) if m else None


def event_selections(d: dict, sport: str) -> list[dict]:
    comps = d.get("competitors") or []
    if len(comps) < 2:
        return []
    home, away = comps[0]["name"], comps[1]["name"]
    home_id, away_id = comps[0]["id"], comps[1]["id"]
    odds = {o["id"]: o for o in d.get("odds", [])}
    sels: list[dict] = []

    for m in list(d.get("markets", [])) + list(d.get("childMarkets", [])):
        ids = [i for row in (m.get("desktopOddIds") or []) for i in row]
        os_ = [odds[i] for i in ids if i in odds and odds[i].get("oddStatus", 0) == 0 and odds[i].get("price")]
        if not os_:
            continue
        name = _clean(m.get("name", ""))
        # "Goleador O el sustituto", "Remates (X) y suplente", "Incl. suplente": mercado distinto (peores cuotas) -> fuera
        if re.search(r"suplente|sustituto|(mitad|parte) de la pr[oó]rroga", name, re.I):
            continue                       # ('1ª Mitad de la prórroga - Total' no es la 1ª parte del partido)
        player = _clean(m.get("childName") or "") or None
        if player:
            # "Remates - Diallo Amad (MNU)" -> "Remates"; "Goleador - X ( COM)" -> "Goleador"
            name = re.sub(r"\s*[-(]?\s*" + re.escape(player) + r".*$", "", name).strip(" -(") or name
        types = {o.get("typeId") for o in os_}

        if types & (OVER_TYPES | UNDER_TYPES) or all(_OU_NAME.search(o.get("name", "")) for o in os_):
            if not player:
                # "1 - Total de tiros de esquina" / "2 - Total de goles" (en directo Altenar numera los equipos):
                # 1 = local, 2 = visitante -> se sustituye por el nombre para que NO acabe como total del partido
                mper = _SIDE_AFTER_PERIOD.match(name)
                if mper:
                    name = f"{home if mper.group('h') else away} - {mper.group('per').strip()} - {mper.group('rest')}"
                else:
                    mside = _SIDE_PREFIX.match(name) or _SIDE_SUFFIX.match(name)
                    if mside:
                        name = f"{home if mside.group('h') else away} - {mside.group('rest')}"
            if not player and sport == "futbol":
                name = _norm_team_total(name, home, away)
                if name is None:
                    continue               # '<equipo desconocido> Total de goles': ni total del partido ni de nadie
            info = classify(name, sport, home, away, kind="total", player=player)
            forced = TEAM_TOTAL_TYPES.get(m.get("typeId")) if not player else None
            if forced:
                market_name = forced       # el typeId manda: nunca se guarda como total del partido
            elif info:
                market_name = info.market
            else:
                continue
            for o in os_:
                if o.get("typeId") in OVER_TYPES:
                    sel = "Over"
                elif o.get("typeId") in UNDER_TYPES:
                    sel = "Under"
                else:
                    mm = _OU_NAME.search(o.get("name", ""))
                    sel = ("Over" if mm.group(1).lower() in ("más", "mas") else "Under") if mm else None
                if not sel:
                    continue
                line = _line(o.get("sv")) or parse_ou_label(o.get("name", ""))[1]
                sels.append({"market": market_name, "selection": sel, "line": line, "player": info.player if info else None, "price": o["price"]})
        elif types & {T_SCORER_ANY, T_SCORER_2PLUS, T_SCORER_3PLUS} and player:
            info = classify("Goleador", sport, home, away, player=player)
            if not info:
                continue
            for o in os_:
                line = {T_SCORER_ANY: 0.5, T_SCORER_2PLUS: 1.5, T_SCORER_3PLUS: 2.5}.get(o.get("typeId"))
                if line is not None:
                    sels.append({"market": info.market, "selection": "Over", "line": line, "player": info.player, "price": o["price"]})
        elif re.search(r"h[aá]ndicap", name, re.I) and all(o.get("competitorId") for o in os_):
            info = classify(name, sport, home, away, kind="handicap")
            if not info:
                continue
            for o in os_:
                sel = "1" if o["competitorId"] == home_id else "2" if o["competitorId"] == away_id else None
                if not sel:
                    continue
                # `sv` es siempre la línea del LOCAL; la línea real de cada selección va en el nombre "Equipo (-0.75)"
                mm = re.search(r"\(([+-]?\d+(?:[.,]\d+)?)\)\s*$", o.get("name") or "")
                sv = _line(o.get("sv"))
                line = _line(mm.group(1)) if mm else (sv if sel == "1" else (-sv if sv is not None else None))
                sels.append({"market": info.market, "selection": sel, "line": line, "price": o["price"]})
        elif types <= {T_HOME, T_DRAW, T_AWAY} and types & {T_HOME, T_AWAY}:
            if T_DRAW in types and sport != "futbol":
                continue                   # baloncesto/tenis: 1X2 con empate (tiempo reglamentario) no es el ganador
            info = classify(name, sport, home, away)
            if not info or not (info.market.startswith("1X2") or info.market.startswith("DNB")):
                continue
            for o in os_:
                sel = {T_HOME: "1", T_DRAW: "X", T_AWAY: "2"}[o["typeId"]]
                sels.append({"market": info.market, "selection": sel, "price": o["price"]})
        elif types == {T_YES, T_NO}:
            info = classify(name, sport, home, away)
            if not info or not info.market.startswith("BTTS"):
                continue
            for o in os_:
                sels.append({"market": info.market, "selection": "Yes" if o["typeId"] == T_YES else "No", "price": o["price"]})
    return sels


def event_url(d: dict, live: bool, cfg: dict) -> str:
    """Enlace profundo del widget Altenar de Pastón.

    La web lee la ruta interna del sportsbook del parámetro `?ar=`:
      /sport/<sportId>/category/<catId>/championship/<champId>/event/<eventId>   (pre-partido)
      /sport/<sportId>/category/<catId>/championship/<champId>/liveEvent/<eventId> (en directo)
    Si falta algún id usamos la forma corta /event/<id> | /liveEvent/<id>, que el widget sigue aceptando.
    """
    kind = "liveEvent" if live else "event"
    sid, cid, chid = d.get("sportId"), d.get("catId"), d.get("champId")
    if sid and cid and chid:
        route = f"/sport/{sid}/category/{cid}/championship/{chid}/{kind}/{d['id']}"
    else:
        route = f"/{kind}/{d['id']}"
    return cfg["event_url"].format(route=route, eventId=d["id"], sportId=sid or "", catId=cid or "", champId=chid or "",
                                   page="liveEvent" if live else "event")


def event_row(d: dict, sport: str, competition: str, live_info: dict | None, cfg: dict) -> dict | None:
    sels = event_selections(d, sport)
    comps = d.get("competitors") or []
    if not sels or len(comps) < 2:
        return None
    start = d.get("startDate")
    dt = None
    if start:
        try:
            dt = datetime.fromisoformat(start.replace("Z", "+00:00")).astimezone()
        except ValueError:
            pass
    row = {
        "event_id": str(d["id"]), "home": comps[0]["name"], "away": comps[1]["name"], "competition": competition,
        "date": dt.strftime("%Y-%m-%d") if dt else None, "start_time": dt.strftime("%H:%M") if dt else None,
        "url": event_url(d, live_info is not None, cfg), "selections": sels,
    }
    if live_info:
        sc = live_info.get("score")
        row.update(score=":".join(str(x) for x in sc) if isinstance(sc, list) and sc else None,
                   period=live_info.get("ls"), timer=live_info.get("liveTime"))
    return row


# ──────────────────────────────────────────────────────────────────────────────
class Collector:
    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.api = Api(cfg)
        self.catalog = Competitions()
        self.store = OddsStore(bookmaker=cfg.get("bookmaker", "paston"))
        self.champs: dict[int, tuple[str, str]] = {}      # champId -> (sport, competición canónica)
        self.cfg_path = Path(cfg.get("_cfg_path") or CFG_PATH)
        self._cfg_mtime = self.cfg_path.stat().st_mtime
        self._last_catalog = 0.0
        self._last_prematch = 0.0
        self._prematch_events: dict[int, tuple[dict, str, str]] = {}   # eventId -> (event, sport, comp)

    # catálogo -------------------------------------------------------------
    def refresh_catalog(self):
        menu = self.api.get("GetSportMenu")
        if not menu:
            raise RuntimeError("GetSportMenu sin respuesta")
        cats = {c["id"]: c for c in menu.get("categories", [])}
        champs = {c["id"]: c for c in menu.get("champs", [])}
        sel: dict[int, tuple[str, str]] = {}
        for s in menu.get("sports", []):
            sport = self.cfg["sports"].get(str(s["id"]))
            if not sport:
                continue
            for cid in s.get("catIds", []):
                c = cats.get(cid)
                if not c:
                    continue
                for chid in c.get("champIds", []):
                    ch = champs.get(chid)
                    if not ch:
                        continue
                    name = self.catalog.match(self.cfg.get("bookmaker", "paston"), sport, f"{c['name']} - {ch['name']}")
                    if name:
                        sel[chid] = (sport, name)
        self.champs = sel
        self._last_catalog = time.time()
        log.info("catálogo: %d campeonatos seleccionados", len(sel))

    def _reload_if_changed(self):
        changed = self.catalog.reload()
        mt = self.cfg_path.stat().st_mtime
        if mt != self._cfg_mtime:
            self.cfg = load_cfg(self.cfg_path)
            self.api.cfg = self.cfg
            self._cfg_mtime = mt
            changed = True
        if changed or time.time() - self._last_catalog > 3600:
            self.refresh_catalog()
            self.store.prune()

    # ciclos -----------------------------------------------------------------
    def live_cycle(self) -> tuple[int, int]:
        # timeout corto en directo: con 20 s y la API colgada, una pasada de 13 partidos tardaba 60-110 s (visto el
        # 13-11 tras el gol de Escocia: las 5 casas Altenar con 84-114 s de retraso). Mejor fallar y reintentar en 2 s.
        old, self.api.timeout = self.api.timeout, self.cfg.get("timeout_live", 8)
        try:
            return self._live_cycle()
        finally:
            self.api.timeout = old

    def _live_cycle(self) -> tuple[int, int]:
        # GetLiveOverview devuelve un solo deporte por llamada: una petición por deporte (en paralelo)
        overviews = self.api.many("GetLiveOverview", [{"sportId": sid} for sid in self.cfg["sports"]])
        live = []
        for ov in overviews:
            for e in (ov or {}).get("events", []):
                if e.get("champId") in self.champs:
                    live.append((e, *self.champs[e["champId"]]))
        if all(ov is None for ov in overviews):
            # Antes esto salía como «live 0 ev / 0 cambios» sin más (el 07-11 las cinco casas Altenar estuvieron así
            # 66 s a la vez: límite de la API por IP compartida). Se hace visible y entra el backoff del bucle.
            raise RuntimeError(f"GetLiveOverview sin respuesta en los {len(overviews)} deportes (HTTP {self.api.last_status})"
                               " — probable límite de Altenar (varias casas desde la misma IP)")
        if all(ov is not None for ov in overviews):
            self.store.sweep({str(e["id"]) for e, *_ in live}, "live")     # partidos terminados → cuotas retiradas
        live = live[: self.cfg.get("max_detail_per_cycle", 60)]
        details = self.api.many("GetEventDetails", [{"eventId": e["id"]} for e, *_ in live])
        by_sport: dict[str, list[dict]] = {}
        for (e, sport, comp), d in zip(live, details):
            if d:
                row = event_row(d, sport, comp, e, self.cfg)
                if row:
                    by_sport.setdefault(sport, []).append(row)
        rows = changed = 0
        for sport, rs in by_sport.items():
            changed += self.store.save_rows(sport, "live", rs)
            rows += len(rs)
        return rows, changed

    def prematch_cycle(self) -> tuple[int, int]:
        # 1) lista de eventos por campeonato
        lists = self.api.many("GetEvents", [{"champIds": chid, "eventCount": self.cfg.get("events_per_champ", 100)}
                                            for chid in self.champs])
        now = time.time()
        horizon = now + self.cfg.get("prematch_hours", 48) * 3600
        todo: list[tuple[dict, str, str]] = []
        for chid, lst in zip(self.champs, lists):
            if not lst:
                continue
            sport, comp = self.champs[chid]
            for e in lst.get("events", []):
                if e.get("status") not in (0, None) or e.get("champId") not in self.champs:
                    continue
                try:
                    st = datetime.fromisoformat(e["startDate"].replace("Z", "+00:00")).timestamp()
                except (KeyError, ValueError):
                    continue
                if now - 300 <= st <= horizon:
                    todo.append((e, sport, comp))
        todo = todo[: self.cfg.get("max_detail_per_cycle", 60) * 3]
        # 2) detalle
        details = self.api.many("GetEventDetails", [{"eventId": e["id"]} for e, *_ in todo])
        by_sport: dict[str, list[dict]] = {}
        for (e, sport, comp), d in zip(todo, details):
            if d:
                row = event_row(d, sport, comp, None, self.cfg)
                if row:
                    by_sport.setdefault(sport, []).append(row)
        rows = changed = 0
        for sport, rs in by_sport.items():
            changed += self.store.save_rows(sport, "prematch", rs)
            rows += len(rs)
        return rows, changed

    def run(self, once: bool = False):
        backoff = 2
        while True:
            t0 = time.time()
            try:
                self._reload_if_changed()
                rows, changed = self.live_cycle()
                msg = f"live {rows} ev / {changed} cambios"
                if t0 - self._last_prematch >= self.cfg.get("interval_prematch", 180):
                    prow, pchg = self.prematch_cycle()
                    self._last_prematch = time.time()
                    msg += f" | prematch {prow} ev / {pchg} cambios"
                self.store.set_status(**{f"{self.cfg['bookmaker']}_last_ok": time.time(), f"{self.cfg['bookmaker']}_live_events": rows},
                                      **{f"{self.cfg['bookmaker']}_champs": len(self.champs)})
                log.info("%s (%.1fs)", msg, time.time() - t0)
                backoff = 2
                if once:
                    return
            except Exception as e:
                log.warning("error de ciclo: %s — reintento en %ss", e, backoff)
                self.store.set_status(**{f"{self.cfg['bookmaker']}_last_error": f"{time.time():.0f} {e}"})
                time.sleep(backoff)
                backoff = min(backoff * 2, 60)
                continue
            time.sleep(max(0.5, self.cfg.get("interval_live", 5) - (time.time() - t0)))


def list_catalog(cfg: dict):
    api = Api(cfg)
    cat = Competitions()
    menu = api.get("GetSportMenu") or {}
    cats = {c["id"]: c for c in menu.get("categories", [])}
    champs = {c["id"]: c for c in menu.get("champs", [])}
    for s in menu.get("sports", []):
        sport = cfg["sports"].get(str(s["id"]))
        if not sport:
            continue
        print(f"\n=== {sport} (sportId {s['id']})")
        for cid in s.get("catIds", []):
            c = cats.get(cid)
            if not c:
                continue
            for chid in c.get("champIds", []):
                ch = champs.get(chid)
                if not ch:
                    continue
                label = f"{c['name']} - {ch['name']}"
                mark = "✔" if cat.match(cfg.get("bookmaker", "paston"), sport, label) else " "
                print(f" {mark} {label}   [{chid}] eventos={ch.get('eventsCount')}")


def dump_links(cfg: dict):
    """Imprime URLs candidatas de enlace directo a una selección (para probarlas en el navegador)."""
    api = Api(cfg)
    d = None
    for sid in cfg["sports"]:
        ov = api.get("GetLiveOverview", sportId=sid) or {}
        for e in ov.get("events", []):
            d = api.get("GetEventDetails", eventId=e["id"])
            if d and d.get("odds"):
                break
        if d:
            break
    if not d:
        ev = (api.get("GetEvents", sportId=list(cfg["sports"])[0]) or {}).get("events") or []
        d = api.get("GetEventDetails", eventId=ev[0]["id"]) if ev else None
    if not d or not d.get("odds"):
        print("sin eventos"); return
    comps = d.get("competitors") or [{}, {}]
    m = next(m for m in d.get("markets", []) if any(i for row in (m.get("desktopOddIds") or []) for i in row))
    oid = [i for row in m["desktopOddIds"] for i in row][0]
    o = next(o for o in d["odds"] if o["id"] == oid)
    base = event_url(d, bool(d.get("isLive")), cfg)
    route = base.split("ar=", 1)[1]
    eid = d["id"]
    print(f"Partido: {comps[0].get('name')} - {comps[1].get('name')}  eventId={eid}")
    print(f"Apuesta: {m.get('name')!r} -> selección {o.get('name')!r} @{o.get('price')}  marketId={m.get('id')} oddId={oid}\n")
    print("Abre cada URL en incógnito y dime cuál deja la selección ya marcada en la cesta:")
    cands = [
        f"{base}&oddIds={oid}",
        f"{base}&oddId={oid}",
        f"{base}&betslip={oid}",
        f"https://www.paston.es/apuestas-deportivas?ar={route}/odd/{oid}",
        f"https://www.paston.es/apuestas-deportivas?ar=/betslip/{oid}",
        f"https://www.paston.es/apuestas-deportivas?ar={route}&selectionIds={oid}",
        f"https://www.paston.es/apuestas-deportivas?ar={route}&ao={oid}",
        f"https://www.paston.es/apuestas-deportivas?betslip={oid}",
        f"https://www.paston.es/apuestas-deportivas?ar={route}&bet={m.get('id')}&outcome={oid}",
    ]
    for i, u in enumerate(cands, 1):
        print(f"  {i}. {u}")


def dump_event(cfg: dict, event_id: str):
    """Mercados en bruto de un evento (nombre, jugador, tipos, sv, selecciones) -> código nuestro. Para auditar mapeos."""
    api = Api(cfg)
    d = api.get("GetEventDetails", eventId=event_id)
    if not d or not d.get("odds"):
        print("sin datos"); return
    comps = d.get("competitors") or [{}, {}]
    sport = next((s for s in ("futbol", "baloncesto", "tenis") if s in sys.argv), None) or \
        {1: "futbol", 2: "baloncesto", 3: "tenis", 4: "tenis"}.get(d.get("sportId"), "baloncesto")
    print(f"Partido: {comps[0].get('name')} - {comps[1].get('name')}  eventId={d.get('id')} sportId={d.get('sportId')} deporte={sport}")
    odds = {o["id"]: o for o in d.get("odds", [])}
    for m in list(d.get("markets", [])) + list(d.get("childMarkets", [])):
        ids = [i for row in (m.get("desktopOddIds") or []) for i in row]
        os_ = [odds[i] for i in ids if i in odds]
        if not os_:
            continue
        one = {"competitors": d.get("competitors"), "odds": os_, "markets": [m]}
        mapped = event_selections(one, sport)
        codes = ", ".join(f"{x['market']}|{x['selection']}|{x.get('line')}" + (f"|{x.get('player')}" if x.get("player") else "") for x in mapped) or "-"
        outs = " | ".join(f"{o.get('name')} t={o.get('typeId')} sv={o.get('sv')!r} @{o.get('price')}" for o in os_[:4])
        print(f"  {m.get('name')!r} child={m.get('childName')!r} typeId={m.get('typeId')} id={m.get('id')}\n      {outs}\n      -> {codes}")


def find_event(cfg: dict, text: str, only: str | None = None):
    """Busca un partido por nombre (live + pre-partido de las competiciones seguidas) y vuelca sus mercados.
    `only` filtra los mercados por subcadena (p. ej. 'rner')."""
    col = Collector(cfg)
    col.refresh_catalog()
    api = col.api
    needle = text.lower()
    found: list[tuple[int, str]] = []
    for ov in api.many("GetLiveOverview", [{"sportId": sid} for sid in cfg["sports"]]):
        for e in (ov or {}).get("events", []):
            if needle in (e.get("name") or "").lower():
                found.append((e["id"], e.get("name")))
    lists = api.many("GetEvents", [{"champIds": chid, "eventCount": cfg.get("events_per_champ", 100)} for chid in col.champs])
    for lst in lists:
        for e in (lst or {}).get("events", []):
            if needle in (e.get("name") or "").lower():
                found.append((e["id"], e.get("name")))
    if not found:
        print(f"ningún partido con '{text}'"); return
    for eid, name in found[:3]:
        print(f"\n##### {name}  eventId={eid}")
        d = api.get("GetEventDetails", eventId=eid)
        if not d or not d.get("odds"):
            print("sin datos"); continue
        sport = {1: "futbol", 2: "baloncesto", 3: "tenis", 4: "tenis"}.get(d.get("sportId"), "futbol")
        odds = {o["id"]: o for o in d.get("odds", [])}
        for m in list(d.get("markets", [])) + list(d.get("childMarkets", [])):
            ids = [i for row in (m.get("desktopOddIds") or []) for i in row]
            os_ = [odds[i] for i in ids if i in odds]
            if not os_:
                continue
            mapped = event_selections({"competitors": d.get("competitors"), "odds": os_, "markets": [m]}, sport)
            codes = ", ".join(f"{x['market']}|{x['selection']}|{x.get('line')}" for x in mapped) or "-"
            # el filtro vale tanto para el nombre de la casa como para nuestro código (p. ej. 'CORNERS|Over|1.5')
            if only and only.lower() not in (f"{m.get('name')} {m.get('childName')} {codes}").lower():
                continue
            outs = " | ".join(f"{o.get('name')} sv={o.get('sv')!r} @{o.get('price')}" for o in os_[:4])
            print(f"  {m.get('name')!r} child={m.get('childName')!r} typeId={m.get('typeId')}\n      {outs}\n      -> {codes}")


def main():
    logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"),
                        format="%(asctime)s %(levelname)s %(name)s: %(message)s", datefmt="%H:%M:%S")
    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    cfg = load_cfg()
    log.name = cfg.get("bookmaker", "paston")
    if "--links" in sys.argv:
        dump_links(cfg)
        return
    if "--list" in sys.argv:
        list_catalog(cfg)
        return
    if "--find" in sys.argv:
        i = sys.argv.index("--find")
        find_event(cfg, sys.argv[i + 1], sys.argv[i + 2] if len(sys.argv) > i + 2 and not sys.argv[i + 2].startswith("--") else None)
        return
    if "--dump" in sys.argv:
        dump_event(cfg, sys.argv[sys.argv.index("--dump") + 1])
        return
    Collector(cfg).run(once="--once" in sys.argv)


if __name__ == "__main__":
    main()
