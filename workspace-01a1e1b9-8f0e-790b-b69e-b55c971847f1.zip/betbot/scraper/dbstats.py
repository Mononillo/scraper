"""Resumen rápido de odds.db: `python dbstats.py [ruta_db] [casa]` -> mercados por casa."""
import os
import sqlite3
import sys
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:  # noqa: BLE001
    pass

db = sys.argv[1] if len(sys.argv) > 1 and sys.argv[1].endswith(".db") else os.getenv("ODDS_DB", os.path.join(os.path.dirname(__file__), "..", "data", "odds.db"))
bk = [a for a in sys.argv[1:] if not a.endswith(".db")]
c = sqlite3.connect(db)
# `python dbstats.py --event kym [--market TOTAL]`: vuelca las cuotas actuales de cada casa para un evento
# (para localizar mapeos erróneos: líneas imposibles, periodos mal etiquetados…)
# `python dbstats.py --titles codere [BTTS]`: qué títulos crudos de la casa acabaron en qué mercado (tabla market_map)
if "--titles" in sys.argv:
    casa = sys.argv[sys.argv.index("--titles") + 1]
    mk = sys.argv[sys.argv.index("--titles") + 2].upper() if len(sys.argv) > sys.argv.index("--titles") + 2 else None
    q = "select sport, market, title, kind, n, example from market_map where bookmaker=?"
    args = [casa]
    if mk:
        q += " and market like ?"
        args.append(mk + "%")
    for sport, market, title, kind, n, ex in c.execute(q + " order by sport, market, n desc", args):
        print(f"  {sport:<11}{(market or '-'):<22} n={n:<5} {title!r}  kind={kind}  ej={ex}")
    sys.exit(0)
# `python dbstats.py --age`: por casa, cuántos eventos pre-partido/live hay y qué antigüedad tiene su last_seen
# (si la mediana supera ODDS_MAX_AGE_PREMATCH/LIVE el bot ignora esa casa aunque tenga cuotas)
if "--age" in sys.argv:
    import time
    now = time.time()
    print(f"  {'casa':<14}{'tipo':<10}{'eventos':>8}{'mediana':>9}{'p90':>7}{'max':>7}   (segundos desde last_seen)")
    for bkm, live in c.execute("select distinct bookmaker, is_live from events order by bookmaker, is_live"):
        ages = sorted(now - (r[0] or 0) for r in c.execute("select last_seen from events where bookmaker=? and is_live=?", (bkm, live)))
        if not ages:
            continue
        q = lambda f: ages[min(len(ages) - 1, int(f * len(ages)))]
        print(f"  {bkm:<14}{('live' if live else 'prematch'):<10}{len(ages):>8}{q(0.5):>9.0f}{q(0.9):>7.0f}{ages[-1]:>7.0f}")
    sys.exit(0)
if "--event" in sys.argv:
    import time
    txt = sys.argv[sys.argv.index("--event") + 1].lower()
    mk = sys.argv[sys.argv.index("--market") + 1].upper() if "--market" in sys.argv else None
    now = time.time()
    evs = c.execute("select bookmaker, event_id, home, away, is_live, score, period from events "
                    "where lower(home) like ? or lower(away) like ? order by bookmaker", (f"%{txt}%", f"%{txt}%")).fetchall()
    for bkm, eid, home, away, live, score, period in evs:
        print(f"\n== {bkm}: {home} - {away}  id={eid} live={live} score={score} period={period}")
        q = "select market, line, selection, player, price, seen_at from odds_latest where bookmaker=? and event_id=?"
        args = [bkm, eid]
        if mk:
            q += " and market like ?"
            args.append(mk + "%")
        for m, line, sel, pl, price, seen in c.execute(q + " order by market, line, selection", args):
            print(f"  {m:<22}{'' if line is None else line:>7} {sel:<6}{(pl or ''):<24}@{price:<7} hace {now - (seen or now):4.0f}s")
    sys.exit(0)

q = "select bookmaker, market, count(*) from odds_latest" + (f" where bookmaker in ({','.join('?' * len(bk))})" if bk else "") + " group by 1,2 order by 1,3 desc"
cur = None
for row in c.execute(q, bk):
    if row[0] != cur:
        cur = row[0]
        print(f"\n== {cur}")
    print(f"  {row[1]:<24}{row[2]:>7}")
print("\n== eventos por casa/deporte")
for row in c.execute("select bookmaker, sport, is_live, count(*) from events group by 1,2,3 order by 1,2,3"):
    print("  ", row)
