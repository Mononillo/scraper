"""
storage.py — persistencia de cuotas en SQLite (esquema multi-casa).

Lo escribe el scraper; lo lee el bot (services/odds_source.py). Modo WAL para que
ambos procesos/contenedores puedan acceder a la vez sobre un volumen compartido.

Tablas
  events        un evento por (bookmaker, event_id): deporte, competición, equipos, hora, live, marcador
  odds_latest   última cuota conocida por selección (clave: bookmaker+event_id+market_code)
  odds_history  solo se inserta cuando la cuota CAMBIA -> es lo que consume el motor de señales

Dos formatos de fila (save_rows):
  legado (DOM):  row["markets"] = {data_id: price}, row["line_by_id"] -> parse_market() deduce mercado
  genérico (APIs):     row["selections"] = [{"market": "TOTAL_1H", "selection": "Over", "line": 1.5,
                                             "player": None, "price": 2.1}, ...]   (claves de markets.py)
"""
from __future__ import annotations

import fastjson as json
import logging
import os
import re
import random
import sqlite3
import sys
import threading
import time
from pathlib import Path

from markets import make_code, demote_plain_ot

log = logging.getLogger("storage")

DB_PATH = Path(os.getenv("ODDS_DB", Path(__file__).parent.parent / "data" / "odds.db"))

SCHEMA = """
PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS events (
  bookmaker TEXT NOT NULL, event_id TEXT NOT NULL,
  sport TEXT, competition TEXT, home TEXT, away TEXT,
  start_date TEXT, start_time TEXT, url TEXT,
  is_live INTEGER DEFAULT 0, score TEXT, period TEXT, timer TEXT,
  first_seen REAL, last_seen REAL,
  PRIMARY KEY (bookmaker, event_id)
);
CREATE TABLE IF NOT EXISTS odds_latest (
  bookmaker TEXT NOT NULL, event_id TEXT NOT NULL, market_code TEXT NOT NULL,
  market TEXT, selection TEXT, line REAL, player TEXT,
  price REAL, prev_price REAL, changed_at REAL, seen_at REAL,
  PRIMARY KEY (bookmaker, event_id, market_code)
);
CREATE TABLE IF NOT EXISTS odds_history (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts REAL NOT NULL, bookmaker TEXT, event_id TEXT, market_code TEXT,
  market TEXT, selection TEXT, line REAL, price REAL, prev_price REAL, player TEXT
);
CREATE INDEX IF NOT EXISTS idx_hist_ts ON odds_history(ts);
CREATE TABLE IF NOT EXISTS scraper_status (
  key TEXT PRIMARY KEY, value TEXT
);
CREATE TABLE IF NOT EXISTS market_map (
  bookmaker TEXT NOT NULL, sport TEXT, title TEXT NOT NULL, kind TEXT, market TEXT,
  n INTEGER DEFAULT 0, example TEXT, last_seen REAL,
  PRIMARY KEY (bookmaker, sport, title, kind, market)
);
"""

# data-id de Pragmatic: <eventId>_<marketId>_<selCode>.  Códigos vistos:
#   W2-1 / W2-D / W2-2  -> 1X2 (o ganador a 2 vías: W2-1 / W2-2)
#   T2-O / T2-U         -> total más/menos (línea en 'line')
#   YES / NO            -> ambos marcan
_SEL = {
    "W2-1": ("1X2", "1"), "W2-D": ("1X2", "X"), "W2-2": ("1X2", "2"),
    "T2-O": ("TOTAL", "Over"), "T2-U": ("TOTAL", "Under"),
    "YES": ("BTTS", "Yes"), "NO": ("BTTS", "No"),
    "H2-1": ("HANDICAP", "1"), "H2-2": ("HANDICAP", "2"),
}


def parse_market(data_id: str, line_label: str | None = None):
    """'U-5436779_U-429609394_W2-1' -> (market, selection, line)."""
    data_id, _, full = data_id.partition("@")            # sufijo '@1X2_SET2' / '@TOTAL_HOME' añadido por el scraper (título de la columna)
    parts = data_id.split("_")
    code = parts[-1] if parts else data_id
    market, sel = _SEL.get(code, (code, code))
    if full and code in _SEL:
        market = full
    line = None
    if line_label:
        m = re.search(r"[-+]?\d+(?:[.,]\d+)?", line_label)
        if m:
            line = float(m.group(0).replace(",", "."))
    return market, sel, line


def _to_price(v) -> float | None:
    """'2,60' / '2.60' / 2.6 -> 2.6.  Rechaza textos con más de un número ('2,60 ▲ 2,75') y valores imposibles."""
    try:
        if isinstance(v, (int, float)):
            p = float(v)
        else:
            t = str(v).strip()
            nums = re.findall(r"\d+(?:[.,]\d+)?", t)
            if len(nums) != 1:
                return None
            p = float(nums[0].replace(",", "."))
            if t.startswith((",", ".")):          # ",60": parte decimal suelta (DOM partido en dos nodos)
                return None
        return p if 1.0 < p <= 1000 else None
    except (TypeError, ValueError):
        return None


COMMIT_EVERY = 200     # eventos por transacción
COMMIT_OPS = 20000     # ...o escrituras por transacción. 20k escrituras son ~0,2 s de cerrojo; trocear más no ayudaba:
                       # cada COMMIT+BEGIN intermedio soltaba el cerrojo y la casa volvía a la cola detrás de otras 15.
LOCK_WAIT_S = float(os.getenv("DB_LOCK_WAIT_S", "30") or 30)   # máximo que se espera el cerrojo de escritura
LOCK_POLL_S = (0.002, 0.012)   # el cerrojo se pide en bucle con esperas cortas y aleatorias (ver OddsStore._begin)
SLOW_SAVE_S = float(os.getenv("DB_SLOW_SAVE_S", "1.0"))   # avisa en el log de guardados que tarden más (diagnóstico)
# Con 25 casas escribiendo, cada COMMIT es un relevo del cerrojo de escritura (y SQLite espera con sleeps de 1-100 ms
# cuando está ocupado): pocas transacciones grandes bloquean MENOS en total que muchas pequeñas, y cada commit
# reescribe en el -wal las mismas páginas "calientes" (cola del histórico, índices), así que el WAL también crece menos.
WAL_SELF_CHECK_S = 60.0          # cada cuánto mira el colector el tamaño del -wal (por si housekeeping no corre)
WAL_SELF_MB = float(os.getenv("WAL_SELF_MB", "256") or 256)   # ...y a partir de qué tamaño hace él un checkpoint
# Pre-partido: mismo razonamiento que en directo (abajo). El bot comprueba la antigüedad pre-partido con
# events.last_seen (una fila por evento) y la frescura de la pata con max(seen_at, changed_at, full_seen), así que
# reescribir seen_at de las ~30.000 selecciones pre-partido de una casa cada 60 s era puro gasto: en el log salía
# como "escritura 6.2s [seen 6.08] · 0 cambios" y tenía al resto de casas esperando el cerrojo.
SEEN_EVERY = float(os.getenv("SEEN_EVERY_PREMATCH", "900"))
# En directo el bot toma la frescura de events.full_seen (una escritura por evento y pasada): el seen_at por selección
# solo se refresca de vez en cuando. Antes se escribía cada segundo para cada una de las ~1.000 selecciones de cada
# partido en directo de cada casa: decenas de miles de UPDATE/s que atascaban odds.db para todos.
# El bot toma la frescura de una pata como max(seen_at, changed_at, events.full_seen) (odds_source._verify): en una
# pasada COMPLETA en directo full_seen ya cubre a todas las selecciones del evento, así que reescribir seen_at de cada
# una es trabajo redundante que solo engorda el WAL (175.000 selecciones/15 s = miles de páginas sucias por checkpoint).
# Se refresca cada 15 min solo para que la limpieza (DB_STALE_HOURS) no las dé por muertas. En pasadas PARCIALES
# (partial=True: solo mercados principales, sin full_seen) se mantiene el refresco corto.
SEEN_EVERY_LIVE = float(os.getenv("SEEN_EVERY_LIVE", "900"))
SEEN_EVERY_LIVE_PARTIAL = float(os.getenv("SEEN_EVERY_LIVE_PARTIAL", "15"))
# Sello temporal de las cuotas en directo = momento en que EMPEZÓ la descarga de la pasada, no el momento de guardar.
# Si una pasada tarda 40 s (máquina/BD saturadas, casa lenta), las cuotas son de hace hasta 40 s y así lo verá el bot
# («vista hace Xs»), en vez de darlas por frescas. Se tolera LIVE_STAMP_GRACE s (la descarga normal de 1-2 s).
LIVE_STAMP_GRACE = float(os.getenv("LIVE_STAMP_GRACE", "2"))
_tl = threading.local()


def note_fetch() -> None:
    """Marca el inicio de una tanda de descargas en este hilo (la llama el gancho de requests y transport.get_many)."""
    t0 = getattr(_tl, "fetch_t0", None)
    if t0 is None or getattr(_tl, "saved_at", 0.0) > t0:
        _tl.fetch_t0 = time.time()


def end_fetch() -> None:
    """Cierra la tanda actual sin guardar nada (pasada live sin eventos, datos que llegan por push...):
    la siguiente escritura no heredará un fetch_t0 viejo."""
    _tl.saved_at = time.time()


def _fetch_stamp(now: float, kind: str) -> float:
    t0 = getattr(_tl, "fetch_t0", None)
    if kind != "live" or t0 is None or getattr(_tl, "saved_at", 0.0) > t0:
        return now
    age = now - t0 - LIVE_STAMP_GRACE
    return now - min(max(age, 0.0), 600.0)


try:  # gancho: toda petición HTTP de requests en este hilo marca el inicio de la tanda
    import requests as _rq
    if not getattr(_rq.Session.send, "_betbot_hook", False):
        _orig_send = _rq.Session.send

        def _send(self, *a, **k):
            note_fetch()
            return _orig_send(self, *a, **k)
        _send._betbot_hook = True
        _rq.Session.send = _send
except Exception:  # noqa: BLE001
    pass  # ídem en directo (el bot exige que cada cuota se haya vuelto a ver tras detectar la señal)


def _retry_locked(fn):
    """Reintenta la operación si SQLite devuelve 'database is locked' (con 15 colectores escribiendo a la vez pasa
    aunque haya busy_timeout). Así un bloqueo puntual no tira el ciclo entero del colector (que en las casas
    con navegador puede ser de minutos) sino que solo repite el guardado."""
    def wrap(self, *a, **kw):
        lock = getattr(self, "_lock", None)
        if lock is None:
            self._lock = lock = threading.RLock()
        with lock:                           # el hilo pre-partido y el live comparten la conexión
            return _retry(fn, self, *a, **kw)
    wrap.__name__, wrap.__doc__ = fn.__name__, fn.__doc__
    return wrap


def _retry(fn, self, *a, **kw):
    if True:
        for i in range(6):
            try:
                return fn(self, *a, **kw)
            except sqlite3.OperationalError as e:
                if "locked" not in str(e).lower() and "busy" not in str(e).lower():
                    raise
                try:
                    self.con.execute("ROLLBACK")
                except sqlite3.OperationalError:
                    pass
                if i == 5:
                    raise
                time.sleep(0.05 * (i + 1))


# ── Escrituras en bloque ──────────────────────────────────────────────────────────────────────────────────────
# executemany ejecuta UNA sentencia por fila y el módulo sqlite3 suelta y vuelve a coger el GIL en cada una. Si en
# ese momento otro hilo del mismo proceso está parseando (el pre-partido de Playtech/Betsson/PokerStars son hilos
# que mastican JSON/CBOR durante segundos), cada fila espera el intervalo de conmutación del GIL (5 ms): 108 cuotas
# = "escritura 1.7s [ups 1.74]". Con sentencias de VARIAS filas (VALUES (...),(...),...) el cerrojo se suelta una
# vez por cada 400 filas en vez de una por fila, y el intervalo de conmutación se baja a 1 ms por si acaso.
try:
    sys.setswitchinterval(0.001)
except Exception:  # noqa: BLE001
    pass
ROWS_PER_STMT = 400       # 400 filas × 16 columnas = 6.400 parámetros (< 32.766, límite de SQLite)


def _bulk(cur, head: str, ncols: int, tail: str, rows: list) -> None:
    """Ejecuta `head VALUES (…),(…),… tail` en trozos de ROWS_PER_STMT filas."""
    ph = "(" + ",".join("?" * ncols) + ")"
    for i in range(0, len(rows), ROWS_PER_STMT):
        chunk = rows[i:i + ROWS_PER_STMT]
        cur.execute(head + ",".join([ph] * len(chunk)) + tail, [v for r in chunk for v in r])


# Competiciones cuya variante femenina / sub-XX no se quiere (el usuario quitó el Eurobasket femenino): se filtra por
# nombre de competición en competitions.json y, por si la casa la etiqueta igual que la masculina, por los equipos.
_NO_WOMEN = {"Eurobasket"}
_WOMEN_RX = re.compile(r"\(f\)|\(w\)|\bfem(enino|\.)?\b|\bwomen\b|\bmujeres\b|\bw\b|\bu-?\d\d\b|\bsub-?\d\d\b", re.I)


class OddsStore:
    def __init__(self, path: Path = DB_PATH, bookmaker: str = "unknown"):
        path.parent.mkdir(parents=True, exist_ok=True)
        self.bookmaker = bookmaker
        self._maplog_at = 0.0
        self._lock = threading.RLock()
        self.con = sqlite3.connect(str(path), timeout=30, isolation_level=None, check_same_thread=False)
        self.con.execute("PRAGMA busy_timeout=30000")       # solo durante la creación del esquema (ver abajo)
        # WAL + synchronous=NORMAL: sin fsync en cada commit (en Windows cada fsync cuesta 10-50 ms y con 14
        # colectores escribiendo se notaba como parones sincronizados de todas las casas). Durable salvo apagón.
        self.con.execute("PRAGMA synchronous=NORMAL")
        self.con.execute("PRAGMA temp_store=MEMORY")
        self.con.execute("PRAGMA cache_size=-32000")
        # Checkpoints centralizados en housekeeping (cada 30 s): por defecto CADA proceso intentaba un checkpoint al
        # pasar el WAL de 4 MB, es decir, 25 colectores copiando páginas al fichero principal dentro de su propio
        # commit, a la vez, sin que ninguno consiguiera reiniciar el WAL. Autoprotección más abajo (_wal_selfcheck).
        self.con.execute("PRAGMA wal_autocheckpoint=0")
        self.con.execute("PRAGMA journal_size_limit=67108864")     # al reiniciarse el WAL, el fichero vuelve a <= 64 MB
        try:
            self.con.execute("PRAGMA mmap_size=268435456")          # lecturas por mmap (índices/cachés) sin syscalls
        except sqlite3.OperationalError:
            pass
        self._path = path
        self._wal_checked = time.time()
        # índice de 4 columnas que nadie consultaba (el bot lee por id, la limpieza por ts): cada inserción en
        # odds_history lo mantenía y con ~800 cambios/s entre 25 casas era la mitad del coste de escritura.
        self.con.execute("DROP INDEX IF EXISTS idx_hist_evt")
        self.con.executescript(SCHEMA)
        def _add_col(tbl: str, col: str, typ: str) -> None:
            # 25 colectores arrancan a la vez: dos pueden ver la columna ausente y el segundo ALTER falla con
            # "duplicate column name" → se ignora (la columna ya está).
            cols = {r[1] for r in self.con.execute(f"PRAGMA table_info({tbl})")}
            if col not in cols:
                try:
                    self.con.execute(f"ALTER TABLE {tbl} ADD COLUMN {col} {typ}")
                except sqlite3.OperationalError as e:
                    if "duplicate" not in str(e).lower():
                        raise
        for tbl in ("odds_latest", "odds_history"):
            _add_col(tbl, "player", "TEXT")                          # migración: columna player
            _add_col(tbl, "url", "TEXT")                             # migración: enlace directo a la selección
        _add_col("events", "full_seen", "REAL")                      # migración: última pasada COMPLETA del evento
        self._latest: dict[tuple, float] = {}   # cache en memoria para detectar cambios sin leer la BD
        self._seen: dict[tuple, float] = {}     # último seen_at escrito (se refresca como mucho cada SEEN_EVERY s)
        self._by_event: dict[str, dict[str, str]] = {}   # event_id -> {market_code: market}
        for ev, mc, p, mk in self.con.execute(
                "SELECT event_id, market_code, price, market FROM odds_latest WHERE bookmaker=?", (bookmaker,)):
            self._latest[(ev, mc)] = p
            self._by_event.setdefault(ev, {})[mc] = mk or ""

        # A partir de aquí el cerrojo de escritura se pide en bucle propio (_begin): el busy handler de SQLite,
        # pasados 0,2 s, solo reintenta cada 100 ms, y con 20 casas en cola cada relevo desperdiciaba ~50 ms
        # (de ahí colas de 5-7 s para escrituras que en total suman décimas de segundo).
        self.con.execute("PRAGMA busy_timeout=0")
        self._lock_wait = 0.0

    def _begin(self, cur=None) -> float:
        """BEGIN IMMEDIATE con reintento rápido y aleatorio. Devuelve los segundos esperados (se acumulan en
        self._lock_wait para el diagnóstico de guardado lento)."""
        ex = cur if cur is not None else self.con
        t0 = time.time()
        while True:
            try:
                ex.execute("BEGIN IMMEDIATE")
                w = time.time() - t0
                self._lock_wait += w
                return w
            except sqlite3.OperationalError as e:
                msg = str(e).lower()
                if ("locked" not in msg and "busy" not in msg) or time.time() - t0 > LOCK_WAIT_S:
                    raise
                time.sleep(random.uniform(*LOCK_POLL_S))

    def _remove(self, cur, ev: str, codes: list[str], now: float) -> int:
        return self._remove_many(cur, [(ev, codes)], now)

    def _remove_many(self, cur, removals: list[tuple[str, list[str]]], now: float) -> int:
        """Marca selecciones desaparecidas: fila en odds_history con price NULL (el bot las saca de su libro)
        y borrado de odds_latest. Así una cuota suspendida/retirada no sigue generando surebets fantasma.
        Todos los eventos de la pasada en pocas sentencias (DELETE … WHERE (event_id,market_code) IN (VALUES …))."""
        pairs = [(ev, mc) for ev, codes in removals for mc in codes]
        if not pairs:
            return 0
        found: dict[tuple, tuple] = {}
        for i in range(0, len(pairs), ROWS_PER_STMT):
            chunk = pairs[i:i + ROWS_PER_STMT]
            sql = ("DELETE FROM odds_latest WHERE bookmaker=? AND (event_id, market_code) IN (VALUES %s) "
                   "RETURNING event_id, market_code, selection, line, player" % ",".join(["(?,?)"] * len(chunk)))
            for ev, mc, sel, line, pl in cur.execute(sql, (self.bookmaker, *[v for pr in chunk for v in pr])).fetchall():
                found[(ev, mc)] = (sel, line, pl)
        hist = []
        for ev, mc in pairs:
            prev = self._latest.pop((ev, mc), None)
            mk = (self._by_event.get(ev) or {}).pop(mc, "")
            sel, line, pl = found.get((ev, mc), (None, None, None))
            hist.append((now, self.bookmaker, ev, mc, mk, sel, line, pl, None, prev))
        _bulk(cur, "INSERT INTO odds_history (ts,bookmaker,event_id,market_code,market,selection,line,player,price,prev_price) VALUES ",
              10, "", hist)
        return len(pairs)

    _SQL_EVENT_HEAD = """
        INSERT INTO events (bookmaker,event_id,sport,competition,home,away,start_date,start_time,url,
                            is_live,score,period,timer,first_seen,last_seen,full_seen)
        VALUES """
    _SQL_EVENT_TAIL = """
        ON CONFLICT(bookmaker,event_id) DO UPDATE SET
          sport=excluded.sport, competition=COALESCE(excluded.competition, events.competition),
          home=excluded.home, away=excluded.away,
          start_date=COALESCE(excluded.start_date, events.start_date),
          start_time=COALESCE(excluded.start_time, events.start_time),
          url=COALESCE(excluded.url, events.url),
          is_live=MAX(excluded.is_live, events.is_live),
          score=COALESCE(excluded.score, events.score), period=COALESCE(excluded.period, events.period),
          timer=COALESCE(excluded.timer, events.timer), last_seen=excluded.last_seen,
          full_seen=COALESCE(excluded.full_seen, events.full_seen)"""
    _SQL_UPSERT_HEAD = """
        INSERT INTO odds_latest (bookmaker,event_id,market_code,market,selection,line,player,price,prev_price,changed_at,seen_at,url)
        VALUES """
    _SQL_UPSERT_TAIL = """
        ON CONFLICT(bookmaker,event_id,market_code) DO UPDATE SET
          price=excluded.price, prev_price=odds_latest.price, changed_at=excluded.changed_at,
          seen_at=excluded.seen_at, line=excluded.line, player=excluded.player,
          url=COALESCE(excluded.url, odds_latest.url)"""
    _SQL_HIST_HEAD = "INSERT INTO odds_history (ts,bookmaker,event_id,market_code,market,selection,line,player,price,prev_price,url) VALUES "
    # UPDATE … FROM (VALUES …) (SQLite >= 3.33): una sentencia para cientos de seen_at
    _SQL_SEEN_HEAD = "WITH v(s,b,e,m) AS (VALUES "
    _SQL_SEEN_TAIL = (") UPDATE odds_latest SET seen_at=v.s FROM v "
                      "WHERE odds_latest.bookmaker=v.b AND odds_latest.event_id=v.e AND odds_latest.market_code=v.m")

    def _write(self, cur, name: str, rows: list) -> None:
        if not rows:
            return
        if name == "eventos":
            _bulk(cur, self._SQL_EVENT_HEAD, 16, self._SQL_EVENT_TAIL, rows)
        elif name == "ups":
            _bulk(cur, self._SQL_UPSERT_HEAD, 12, self._SQL_UPSERT_TAIL, rows)
        elif name == "hist":
            _bulk(cur, self._SQL_HIST_HEAD, 11, "", rows)
        elif name == "seen":
            _bulk(cur, self._SQL_SEEN_HEAD, 4, self._SQL_SEEN_TAIL, rows)

    def _flush(self, cur, ups: list, hist: list, seen: list) -> None:
        """Escribe los lotes acumulados de una tanda con executemany (una llamada por tipo en vez de una por fila:
        el bucle corre en C y el coste por cuota baja a una fracción)."""
        self._write(cur, "ups", ups)
        ups.clear()
        self._write(cur, "hist", hist)
        hist.clear()
        self._write(cur, "seen", seen)
        seen.clear()

    def _wal_selfcheck(self) -> None:
        """Si housekeeping no estuviera corriendo, el WAL crecería sin límite (wal_autocheckpoint=0): cada minuto se
        mira el tamaño del -wal y, si pasa de WAL_SELF_MB, este proceso hace un checkpoint pasivo."""
        now = time.time()
        if now - self._wal_checked < WAL_SELF_CHECK_S:
            return
        self._wal_checked = now
        try:
            wal = Path(str(self._path) + "-wal")
            if wal.exists() and wal.stat().st_size > WAL_SELF_MB * 1e6:
                self.con.execute("PRAGMA wal_checkpoint(PASSIVE)")
        except Exception:  # noqa: BLE001
            pass

    @_retry_locked
    def sweep(self, present_ids: set[str], kind: str) -> int:
        """Eventos de `kind` (live/prematch) que ya no aparecen en la lista de la casa: se retiran todas sus cuotas.
        Un partido que termina o pasa a directo deja de alimentar al detector con cuotas viejas."""
        is_live = 1 if kind == "live" else 0
        gone = [r[0] for r in self.con.execute("SELECT event_id FROM events WHERE bookmaker=? AND is_live=?",
                                                (self.bookmaker, is_live)) if r[0] not in present_ids and r[0] in self._by_event]
        if not gone:
            return 0
        now = time.time()
        cur = self.con.cursor()
        self._begin(cur)
        n = 0
        try:
            n += self._remove_many(cur, [(ev, list(self._by_event.get(ev, {}))) for ev in gone], now)
            cur.execute("COMMIT")
        except Exception:
            try:
                cur.execute("ROLLBACK")
            except sqlite3.OperationalError:
                pass
            raise
        return n

    # ------------------------------------------------------------------
    @_retry_locked
    def save_rows(self, sport: str, kind: str, rows: list[dict]) -> int:   # noqa: C901
        """Guarda una pasada de un target. Devuelve nº de cuotas que han cambiado."""
        real_now = t_save0 = time.time()
        now = _fetch_stamp(real_now, kind)      # en directo: hora de inicio de la descarga (ver LIVE_STAMP_GRACE)
        if real_now - now > 10:
            log.info("%s: pasada live de %.0fs: las cuotas se sellan con %.0fs de antigüedad", self.bookmaker, real_now - now + LIVE_STAMP_GRACE, real_now - now)
        is_live = 1 if kind == "live" else 0
        changed = 0
        # FASE 1 (sin cerrojo): todo el trabajo Python —comparar con la caché, detectar duplicados, preparar lotes—
        # se hace ANTES de abrir la transacción. Antes el BEGIN IMMEDIATE iba al principio y cada casa tenía a las
        # otras 24 esperando el cerrojo de escritura mientras *pensaba*; con 25 procesos eso se convertía en oleadas
        # de 10-50 s. Ahora el cerrojo solo se mantiene durante los executemany (fase 2), que corren en C.
        ev_rows: list = []
        ups: list = []
        hist: list = []
        seen_upd: list = []
        removals: list = []   # (event_id, [codes]) retiradas a aplicar en la fase 2
        tx_events: list = []
        for r in rows:
            ev = r.get("event_id")
            if not ev:
                continue
            if _WOMEN_RX.search(f"{r.get('home') or ''} | {r.get('away') or ''}") and (r.get("competition") or "") in _NO_WOMEN:
                continue          # Eurobasket femenino colado bajo la etiqueta "Eurobasket" (equipos "Israel (F)", "Polonia Femenino")
            tx_events.append(ev)
            score = r.get("score")
            ev_rows.append((self.bookmaker, ev, sport, r.get("competition"), r.get("home"), r.get("away"),
                            r.get("date"), r.get("start_time"), r.get("url"), is_live,
                            json.dumps(score, ensure_ascii=False) if score else None,
                            r.get("period"), r.get("timer"), now, now,
                            None if r.get("partial") else now))
            seen_every = SEEN_EVERY if kind != "live" else (SEEN_EVERY_LIVE_PARTIAL if r.get("partial") else SEEN_EVERY_LIVE)
            items = []
            for mc, price in (r.get("markets") or {}).items():            # formato legado (data-id)
                market, sel, line = parse_market(mc, (r.get("line_by_id") or {}).get(mc))
                items.append((mc, market, sel, line, None, price, None))
            if r.get("selections"):
                demote_plain_ot(r["selections"])
            for sl in r.get("selections") or []:                            # formato genérico
                mc = sl.get("code") or make_code(sl["market"], sl["selection"], sl.get("line"), sl.get("player"))
                items.append((mc, sl["market"], sl["selection"], sl.get("line"), sl.get("player"), sl.get("price"), sl.get("url")))
            seen_codes, families = set(), set()
            first_price: dict[str, float] = {}
            # la cuota se convierte UNA vez por selección (antes 4 veces: pre-pasada, orden y bucle)
            items = [(mc, m, s_, l, pl, _to_price(price), u) for mc, m, s_, l, pl, price, u in items]
            # pre-pasada: si un código viene repetido con cuotas distintas, nos quedamos con la MENOR
            _minp: dict[str, float] = {}
            n_valid = 0
            for mc, _m, _s, _l, _pl, p0, _u in items:
                if p0 is not None and p0 >= 1.0:
                    n_valid += 1
                    if mc not in _minp or p0 < _minp[mc]:
                        _minp[mc] = p0
            if n_valid != len(_minp):        # solo hay que reordenar si algún código viene repetido
                items = sorted(items, key=lambda it: 0 if (it[5] is not None and abs((it[5] or 0) - _minp.get(it[0], 0)) < 1e-9) else 1)
            for mc, market, sel, line, player, p, surl in items:
                if p is None or p < 1.0:
                    continue
                if mc in seen_codes:
                    # mismo market_code dos veces en la misma ficha. Si la cuota es la misma (la casa repite el
                    # mercado en dos secciones) es inofensivo. Si difiere, son dos mercados distintos mapeados igual:
                    # se conserva la primera (antes oscilaba A→B→A en cada pasada y contaba como "cambio" eterno)
                    # y se avisa, como mucho una vez por minuto, para corregir el mapeo.
                    if abs((first_price.get(mc) or 0.0) - p) > 1e-9:
                        # misma selección con dos cuotas: por prudencia se guarda la MENOR (si es otro mercado
                        # mapeado igual, la cuota alta es la que fabrica surebets falsas)
                        self._dups = getattr(self, "_dups", 0) + 1
                        if time.time() - getattr(self, "_dups_at", 0.0) > 60:
                            self._dups_at = time.time()
                            log.info("%s: %d selecciones con el mismo código y distinta cuota en la pasada "
                                     "(p. ej. %s %s en %s: %.2f vs %.2f) — revisar mapeo con dbstats --titles",
                                     self.bookmaker, self._dups, mc, market, r.get("home") or ev, first_price.get(mc) or 0.0, p)
                            self._dups = 0
                    continue
                seen_codes.add(mc)
                first_price[mc] = p
                families.add(market)
                self._by_event.setdefault(ev, {})[mc] = market
                prev = self._latest.get((ev, mc))
                if prev is None or abs(prev - p) > 1e-9:
                    ups.append((self.bookmaker, ev, mc, market, sel, line, player, p, prev, now, now, surl))
                    hist.append((now, self.bookmaker, ev, mc, market, sel, line, player, p, prev, surl))
                    self._latest[(ev, mc)] = p
                    self._seen[(ev, mc)] = now
                    changed += 1
                elif now - self._seen.get((ev, mc), 0.0) >= seen_every:   # sin cambio: seen_at periódico
                    seen_upd.append((now, self.bookmaker, ev, mc))
                    self._seen[(ev, mc)] = now
            # selecciones de las familias de mercado cubiertas en esta pasada que ya no vienen → retiradas
            # (las familias no pedidas esta vez, p.ej. colecciones lentas, se dejan tal cual)
            if seen_codes and not r.get("partial"):      # partial=True: solo mercados principales, no retirar nada
                stale = [mc for mc, mk in (self._by_event.get(ev) or {}).items()
                         if mc not in seen_codes and mk in families]
                if stale:
                    removals.append((ev, stale))
        # FASE 2 (con cerrojo): transacciones acotadas por nº de escrituras para no retener el cerrojo más de unas
        # decenas de ms seguidas aunque la pasada sea enorme (pre-partido de 100+ eventos).
        cur = self.con.cursor()
        t_f1 = time.time()
        self._lock_wait = 0.0
        self._begin(cur)
        t_lock = time.time()
        t_w = {"eventos": 0.0, "ups": 0.0, "hist": 0.0, "seen": 0.0, "bajas": 0.0, "commit": 0.0}
        try:
            if ev_rows:
                _t = time.time()
                self._write(cur, "eventos", ev_rows)
                t_w["eventos"] += time.time() - _t
            n_ops = 0
            for name, batch in (("ups", ups), ("hist", hist), ("seen", seen_upd)):
                for i in range(0, len(batch), COMMIT_OPS):
                    _t = time.time()
                    self._write(cur, name, batch[i:i + COMMIT_OPS])
                    t_w[name] += time.time() - _t
                    n_ops += min(COMMIT_OPS, len(batch) - i)
                    if n_ops >= COMMIT_OPS:
                        _t = time.time()
                        cur.execute("COMMIT")
                        t_w["commit"] += time.time() - _t
                        self._begin(cur)
                        n_ops = 0
            _t = time.time()
            changed += self._remove_many(cur, removals, now)
            t_w["bajas"] += time.time() - _t
            _t = time.time()
            cur.execute("COMMIT")
            t_w["commit"] += time.time() - _t
        except Exception:
            try:
                cur.execute("ROLLBACK")
            except sqlite3.OperationalError:
                pass
            # la caché en memoria ya daba por guardadas las cuotas de la transacción deshecha: se olvidan esos
            # eventos para que el reintento (ver _retry) las vuelva a escribir en vez de verlas "sin cambio"
            for ev in set(tx_events):
                for mc in list((self._by_event.pop(ev, None) or {}).keys()):
                    self._latest.pop((ev, mc), None)
                    self._seen.pop((ev, mc), None)
            raise
        finally:
            _tl.saved_at = time.time()
        t_end = time.time()
        if t_end - t_save0 >= SLOW_SAVE_S:
            fetch_t0 = getattr(_tl, "fetch_t0", None)
            detail = " ".join(f"{k} {v:.2f}" for k, v in t_w.items() if v >= 0.05)
            log.warning("%s: guardado %s lento %.1fs (python %.1fs · espera cerrojo %.1fs · escritura %.1fs [%s] · %d cambios · %d eventos%s)",
                        self.bookmaker, kind, t_end - t_save0, t_f1 - t_save0, self._lock_wait, t_end - t_lock - (self._lock_wait - (t_lock - t_f1)),
                        detail or "-", changed, len(rows),
                        f" · descarga previa {t_save0 - fetch_t0:.1f}s" if fetch_t0 and t_save0 - fetch_t0 < 600 else "")
        self._wal_selfcheck()
        return changed

    @_retry_locked
    def set_status(self, **kv) -> None:
        # una sola transacción (antes cada clave pedía el cerrojo por separado)
        self._begin()
        try:
            self.con.executemany("INSERT INTO scraper_status (key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                                 [(k, json.dumps(v, ensure_ascii=False)) for k, v in kv.items()])
            self.con.execute("COMMIT")
        except Exception:
            try:
                self.con.execute("ROLLBACK")
            except sqlite3.OperationalError:
                pass
            raise
        if time.time() - self._maplog_at > 120:
            self._maplog_at = time.time()
            self._flush_maplog()

    def _flush_maplog(self) -> None:
        """Vuelca a market_map qué título crudo acabó en qué mercado (diagnóstico: `dbstats.py --titles casa`)."""
        try:
            import markets as _mk
            items = list(_mk._MAPLOG.items())
            _mk._MAPLOG.clear()
        except Exception:  # noqa: BLE001
            return
        if not items:
            return
        now = time.time()
        self._begin()
        try:
            for (sport, title, kind, market), (n, ex) in items:
                self.con.execute("INSERT INTO market_map (bookmaker,sport,title,kind,market,n,example,last_seen) VALUES (?,?,?,?,?,?,?,?) "
                                 "ON CONFLICT(bookmaker,sport,title,kind,market) DO UPDATE SET n=n+excluded.n, example=excluded.example, last_seen=excluded.last_seen",
                                 (self.bookmaker, sport, title, kind, market, n, ex, now))
            self.con.execute("DELETE FROM market_map WHERE bookmaker=? AND last_seen < ?", (self.bookmaker, now - 7 * 86400))
            self.con.execute("COMMIT")
        except Exception:
            self.con.execute("ROLLBACK")
            raise

    @_retry_locked
    def prune(self, days: int = 7, history_hours: float = 6.0) -> None:
        """Limpieza periódica. El histórico de cambios crece ~10k filas/min con 14 casas: el bot solo lee los
        últimos minutos, así que se conserva solo `history_hours` (si no, la BD engorda GB/día y todo se ralentiza)."""
        cutoff = time.time() - days * 86400
        self._begin()
        try:
            self.con.execute("DELETE FROM odds_history WHERE ts < ?", (time.time() - history_hours * 3600,))
            self.con.execute("DELETE FROM odds_latest WHERE seen_at < ?", (cutoff,))
            self.con.execute("DELETE FROM events WHERE last_seen < ?", (cutoff,))
            self.con.execute("COMMIT")
        except Exception:
            try:
                self.con.execute("ROLLBACK")
            except sqlite3.OperationalError:
                pass
            raise
        try:
            self.con.execute("PRAGMA wal_checkpoint(PASSIVE)")
        except sqlite3.Error:
            pass
