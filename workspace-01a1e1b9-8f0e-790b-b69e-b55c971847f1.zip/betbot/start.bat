@echo off
REM Arranque unificado en Windows (doble clic). Edita PY si tu Python esta en otra ruta.
set PY=C:\Users\pitag\AppData\Local\Programs\Python\Python312\python.exe
cd /d "%~dp0"
"%PY%" run_all.py %*
pause
