"""
markets.py — taxonomía de mercados común a todas las casas.

Cada casa nombra los mercados a su manera ("Número total de goles", "Total de Goles", "1ª Mitad - total de
goles", "Número de puntos del jugador - LeBron James"...). Este módulo los normaliza a una clave única para que
el bot pueda comparar casas (surebets) y el usuario filtrar por tipo.

Clave de mercado = METRICA[_EQUIPO][_PERIODO]      p. ej.  TOTAL · TOTAL_HOME · TOTAL_1H · CORNERS_AWAY_1H
Player props       = PLAYER_METRICA (+ campo `player`)  p. ej.  PLAYER_GOALS · PLAYER_POINTS · PLAYER_SHOTS_OT

Métricas:  TOTAL (goles / puntos / juegos según deporte), CORNERS, CARDS, SHOTS, SHOTS_OT, FOULS, OFFSIDES,
           THREES, SETS, ASSISTS, REBOUNDS, PRA (pts+reb+ast), PR, PA, RA, SAVES, TACKLES, PASSES, BLOCKS, STEALS
Resultado: 1X2 (en tenis/baloncesto = ganador a 2 vías, sin X), HANDICAP, BTTS, DNB (sin empate), DC (doble op.)
Selecciones: "1"/"X"/"2", "Over"/"Under", "Yes"/"No".  Goleador "en cualquier momento" = PLAYER_GOALS Over 0.5,
"marca 2 o más" = PLAYER_GOALS Over 1.5, etc. (así coinciden entre casas que lo expresan distinto).

Uso:  info = classify(title, sport, home, away)  ->  MarketInfo(market, player, scope...) | None
      make_code(market, selection, line, player)   -> código estable para odds_latest.market_code
"""
from __future__ import annotations

import re
from functools import lru_cache
import unicodedata
from dataclasses import dataclass


# Homóglifos griegos/cirílicos que algunas traducciones cuelan en los títulos (Sol Casino: '1ª Μitad' con My griega
# U+039C → al pasar a ASCII desaparecía la M, no se reconocía "mitad" y el total de córners de la 1ª parte acababa como
# total del partido, 30-10-2026). Se sustituyen por su letra latina ANTES de normalizar.
_HOMOGLYPHS = str.maketrans({
    "\u0391": "A", "\u0392": "B", "\u0395": "E", "\u0396": "Z", "\u0397": "H", "\u0399": "I", "\u039a": "K", "\u039c": "M",
    "\u039d": "N", "\u039f": "O", "\u03a1": "P", "\u03a4": "T", "\u03a5": "Y", "\u03a7": "X", "\u03bf": "o", "\u03b1": "a",
    "\u0410": "A", "\u0412": "B", "\u0415": "E", "\u041a": "K", "\u041c": "M", "\u041d": "H", "\u041e": "O", "\u0420": "P",
    "\u0421": "C", "\u0422": "T", "\u0425": "X", "\u0430": "a", "\u0435": "e", "\u043e": "o", "\u0440": "p", "\u0441": "c",
    "\u0443": "y", "\u0445": "x",
})


@lru_cache(maxsize=65536)
def _fold(s: str) -> str:
    s = (s or "").translate(_HOMOGLYPHS)
    s = unicodedata.normalize("NFKD", s.replace("°", "o").replace("₋", "-")).encode("ascii", "ignore").decode()
    return re.sub(r"\s+", " ", s.lower()).strip()


@dataclass
class MarketInfo:
    market: str            # clave normalizada (TOTAL_HOME_1H, PLAYER_POINTS, HANDICAP…)
    player: str | None = None
    team: str | None = None      # HOME / AWAY cuando el mercado es de un equipo
    period: str | None = None    # 1H, 2H, Q1..Q4, SET1..SET5, OT
    ot: bool = False             # el título dice explícitamente "incluida la prórroga" (ver demote_plain_ot)


# ── periodos ────────────────────────────────────────────────────────────────
_PERIODS = [
    (r"\b(1a|1\.a|1ra|primer[ao]?|1er|1\.er|1o|1\.o|1st|1)\s*(mitad|parte|tiempo|tempo|half)\b|\b1st half\b|\b(mitad|parte|half) 1\b|\bdescanso\b(?!/)|\b1t\b|\b1h\b", "1H"),
    (r"\b(2a|2\.a|2da|segund[ao]|2o|2do|2\.o|2nd|2)\s*(mitad|parte|tiempo|tempo|half)\b|\b2nd half\b|\b(mitad|parte|half) 2\b|\b2t\b|\b2h\b", "2H"),
    (r"\b(1er|1\.er|1o|1\.o|1do|primer|1st)\s*(cuarto|quarter)\b|\b(cuarto|quarter) 1\b|\bq1\b", "Q1"),
    (r"\b(2o|2do|2\.o|segundo|2nd)\s*(cuarto|quarter)\b|\b(cuarto|quarter) 2\b|\bq2\b", "Q2"),
    (r"\b(3er|3\.er|3o|3\.o|tercer|3rd)\s*(cuarto|quarter)\b|\b(cuarto|quarter) 3\b|\bq3\b", "Q3"),
    (r"\b(4o|4to|4\.o|cuarto|4th)\s*(cuarto|quarter)\b|\b(cuarto|quarter) 4\b|\bq4\b", "Q4"),
    (r"\b(1er|1\.er|1o|1\.o|primero?|1st)\s*set\b|\bset 1\b", "SET1"), (r"\b(2o|2do|2\.o|segundo|2nd)\s*set\b|\bset 2\b", "SET2"),
    (r"\b(3er|3\.er|3o|3\.o|tercero?|3rd)\s*set\b|\bset 3\b", "SET3"), (r"\b(4o|4to|4\.o|cuarto|4th)\s*set\b|\bset 4\b", "SET4"),
    (r"\b(5o|5to|5\.o|quinto|5th)\s*set\b|\bset 5\b", "SET5"),
    (r"(excluye|excl\.?|excluida|sin|exc)\s*(la\s*)?prorroga|tiempo reglamentario|tiempo regular|\bregulation\b|\bnormal time\b|excluding overtime|sin ot\b", "REG"),
    (r"\bprorroga\b|\bovertime\b", "OT"),
]

# ── métricas (orden importa: lo más específico primero) ─────────────────────
_METRICS = [
    (r"corner|corneres|tiros? de esquina|saques? de esquina", "CORNERS"),
    (r"triples|3 ?pointers|three|tiros? de (3|tres)( puntos)?|puntos de (3|tres)\b|\b(3|tres) puntos\b|\b3pts?\b|\b3pm\b|\b3 ?p\b", "THREES"),
    (r"(tiros?|remates?|disparos?|lanzamientos?)( totales| en total)? (a puerta|al arco|a porteria|a la porteria|entre (los )?(tres |3 )?palos)|"
     r"(total|totales) de (tiros|remates|disparos) a (puerta|porteria)|shots? on target|on target", "SHOTS_OT"),
    (r"\btiros\b|\bremates?\b|\bdisparos?\b|\bshots?\b", "SHOTS"),
    (r"tarjetas? amarillas?|amarillas?\b|yellow", "YELLOW"),
    (r"\btarjetas?\b|\bcards?\b|\bbooking", "CARDS"),
    (r"fueras? de juego|offsides?", "OFFSIDES"),
    (r"(faltas?|fouls?) (recibid|sufrid|provocad)|recib\w* \d+ o mas faltas?|fouls? (drawn|won|suffered)", "FOULS_WON"),
    (r"faltas?\b|fouls?", "FOULS"),
    (r"paradas?|saves?", "SAVES"),
    (r"entradas|tackles", "TACKLES"),
    (r"pases? completados|passes", "PASSES"),
    # combinadas con clave propia (cualquier orden y separador: "+", "y", ",", "/", "&")
    (r"(?=.*\b(puntos|ptos?|pts?|points?)\b)(?=.*\b(rebotes|rebs?|rbs?|rebounds?)\b)(?=.*\b(asistencias|asist|asis|asts?|ass?|assists?)\b)|\bpra\b", "PRA"),
    (r"(?=.*\b(puntos|ptos?|pts?|points?)\b)(?=.*\b(rebotes|rebs?|rbs?|rebounds?)\b)(?!.*\b(asistencias|asist|asis|asts?|ass?|assists?)\b)(?=.*(\+|&|,|/| y | e | mas | and ))(?!.*\b(tapones|bloqueos|robos|triples|blocks?|steals?)\b)", "PR"),
    (r"(?=.*\b(puntos|ptos?|pts?|points?)\b)(?=.*\b(asistencias|asist|asis|asts?|ass?|assists?)\b)(?!.*\b(rebotes|rebs?|rbs?|rebounds?)\b)(?=.*(\+|&|,|/| y | e | mas | and ))(?!.*\b(tapones|bloqueos|robos|triples|blocks?|steals?)\b)", "PA"),
    (r"(?=.*\b(rebotes|rebs?|rbs?|rebounds?)\b)(?=.*\b(asistencias|asist|asis|asts?|ass?|assists?)\b)(?!.*\b(puntos|ptos?|pts?|points?)\b)(?=.*(\+|&|,|/| y | e | mas | and ))(?!.*\b(tapones|bloqueos|robos|triples|blocks?|steals?)\b)", "RA"),
    (r"asistencias|assists?", "ASSISTS"),
    (r"rebotes|rebounds?", "REBOUNDS"),
    (r"tapones|bloqueos|blocks?", "BLOCKS"),
    (r"robos|steals?", "STEALS"),
    (r"(?!.*\b(juegos|games)\b)\bsets?\b", "SETS"),   # "1er Set - Set Juegos en total" (Betway) es total de JUEGOS
    (r"juegos|games", "GAMES"),
    (r"goles|goals?|goleador|anota|marca", "GOALS"),
    (r"puntos|points?|anotador", "POINTS"),
    (r"\btotal\b|mas de|menos de|over|under", "TOTAL"),
]
# relleno admitido en el título de un total de fútbol (además de las métricas y los periodos); cualquier otra palabra
# de 4+ letras (p. ej. "Napoli" cuando el evento dice "Nápoles") hace el título ambiguo -> no se mapea como total
_FILLER = set("""total totales numero cantidad suma apuesta apuestas cuantos cuantas cuanto how many linea lineas alternativa alternativas alternativo alternativos
alt asiatico asiaticos asiatica asiaticas partido encuentro completo completa entero juego mas menos over under ambos ambas
incluye incluida incluidas incluidos incl hora normal tiempo reglamentario regular regulares final finales
amarilla amarillas amarillo amarillos mostradas mostrados cometidas cometidos recibidas recibidos lanzados lanzadas
ejecutados ejecutadas sacados sacadas senalados senaladas concedidos concedidas marcados marcadas anotados anotadas
totales match full time game goals including extra ambos equipos ambos todos todas resultado ganador main principal
opciones opcion mercado mercados especial especiales minimo maximo exactamente estadisticas estadistica
puerta porteria arco palos esquina saque saques tiro tiros remate remates disparo disparos lanzamiento lanzamientos
tarjeta tarjetas gol goles corner corners corneres falta faltas fuera fueras juego parada paradas entradas pases
booking bookings cards card shots shot target corners fouls offsides offside saves tackles passes
cada primera primer segunda segundo prorroga descanso""".split())


def _unknown_words(tm: str) -> list[str]:
    out = []
    for w in re.findall(r"[a-z]{4,}", tm):
        if w in _FILLER or any(re.search(rx, w) for rx, _ in _METRICS):
            continue
        out.append(w)
    return out


# métricas que son "el total del partido" según deporte -> clave TOTAL
_MAIN_METRIC = {"futbol": "GOALS", "baloncesto": "POINTS", "tenis": "GAMES"}

_PLAYER_HINTS = re.compile(r"jugador|player|goleador|anotador|asistente|reboteador|triple-?doble|doble-?doble|"
                           r"marca \d|realiza \d|comete \d|recibe \d|\d+ \w+ o mas", re.I)
_SKIP = re.compile(r"\bmarcara\b(?! ambos)|(?<!equipos )\bmarcaran\b(?! ambos)|dentro del area|con el pie|marca o asiste|anota o asiste|(marca|anota|gol) o (da |de )?asistencia|gol o asistencia|(?<!estrella )rojas?\b|^1x2 |y 1x2|y marcador|"
                   r"con (mayor|menor) puntuacion|cuarto con|mitad con|mas goles|mas puntos|mas corneres|"
                   r"fuera del area|de cabeza|con la cabeza|cabezazo|penalti|tiro libre|falta directa|con la (izquierda|derecha)|"
                   r"desde fuera|en propia|propia puerta|autogol|hat-?trick|poker|"
                   r"rotura|roturas|\bbreaks?\b|\baces?\b|dobles? faltas?|saque directo|juego actual|punto actual|siguiente punto|"
                   r"\bpuntos? del juego\b|ganara el juego|game \d|"
                   r"intentos de|intentad[oa]s?|\bintentos?\b|attempt|fallad[oa]s?|\bmiss|\bfga\b|\bfta\b|\b3pa\b|porcentaje|% de|eficiencia|"
                   r"minutos jugad|\bturnover|balones perdidos|\bdobles? dobles?\b|\b(primer|1er|ultimo) (triple|punto|rebote|asistencia|tapon|robo)|"
                   r"tiros de campo|tiros libres|tiros de (2|dos) puntos|bloq\.?-robos|h2h|perdidas|"
                   r"par/impar|pares/impar|par impar|odd/even|\brangos?\b|\bbandas?\b|eliminatoria|clasifica|se clasifican?|pasa (de|a la) (ronda|siguiente)|3 opciones|defensiv|ofensiv|y puntos totales|\+ total|ganador \+|resultado \+|& o/u|spread &|handicap &|exacto|exacta|margen|combinad|\by (ambos|total|numero|resultado)\b|"
                   r"mitad/final|descanso/final|(primer |1er |1 |1a )?(tiempo|parte|mitad)\s*/\s*(tiempo completo|final|partido)|half\s*/\s*full|ht/ft|carrera a|racha|cara a cara|\bduo\b|\btrio\b|serial|multigol|"
                   r"primer (gol|corner|tarjeta|goleador|anotador|marcador)|\b1\s*(º|o|er|\.er|\.º|ero)?\s*(goleador|anotador|marcador)\b|"
                   r"(anotar[áa]?|marcar[áa]?|anota|marca) (primero|el primero|ultimo|el ultimo)|(anotar[áa]?|anota) o (asistir[áa]?|asiste)|"
                   r"numero de equipos|doblete|hat.?trick|triplete|poker\b|ultimo|first|last|cuando|minuto|intervalo|doble resultado|o tiempo completo|mitad o (tiempo|final|partido)|mitad\s*/\s*2a? mitad|parte\s*/\s*2a? parte|porteria propia|a cero goles|clean sheet|\b2up\b|pago anticipado|pago adelantado|early payout|poste|larguero|palo\b|handicap del set\b(?! \d)|interval|\bmin\.?\s*\d{1,3}\s*-\s*\d{1,3}\b|\d{1,3}\s*-\s*\d{1,3}\s*min|hasta (los|el|la) \d|antes de(l)? \d|suplente|sustituto|del \d+' al|\d{1,2}[:.]\d{2}\s*-\s*\d{1,2}[:.]\d{2}|\b\d{1,2}\s*-\s*\d{1,2}\s*min|proxim|siguiente|\bnext\b|resto del|rest of|\bdel \d{1,2} al \d{1,2}\b|"
                   r"gana (ambas|todos|cualquier)|remontar|ambos tiempos|ambas partes|sin encajar|porteria a cero|"
                   r"metodo|equipo que|que equipo|quien|maximo|mvp|decisivo|cada jugador|numero exacto|boost|"
                   r"y su |(doble|triple) (oportunidad|posibilidad) (goleador|anotador|asistente|jugador)|"
                   r"suplente|sustituto|incl\.? ?(suplente|sustituto)|cada tiempo|cada parte|no empat|en ambos tiempos|"
                   r"juegos? \d+|games? \d+|juegos \d+ y \d+|\d+\s*(o|a|er|do|ro|to)?\s*(juego|punto|game|point)\b|(siguiente|proximo|next) (juego|punto|game|point)|punto \d+|break\b|rotura|saque|servicio|aces?\b|dobles? faltas?|goles de ventaja|^resultado y |ganara y |tie ?break|llegara al|ganara un set|portería a cero|sin encajar|"
                   # combinadas: "ambos marcan y/o más de 2,5", "empate o ambos marcan", "X gana y ambos marcan", "2+ goles"…
                   r"(ambos|ambas|both) [^|]{0,40}\b(y|o|and|or|&)\b [^|]{0,20}(mas|menos|over|under|\d|gana|empat|win|draw|total)|"
                   r"\b(y|o|or|and|&|\+) (ambos|both)\b|(marcan|marcaran|anotan|anotaran) \d|\d\+ gol|en las dos (partes|mitades)|en ambas|both halves|"
                   r"(resultado|ganador|gana|ganara|1x2|empate|doble oportunidad) (y|o|&|\+) |\b(y|o|&|\+) (resultado|ganador|gana|ganara|1x2|total|mas de|menos de|over|under)\b|"
                   r"(alguna|cualquiera|una) de las (dos )?(partes|mitades)|al menos una (parte|mitad)|ganar[a]? (alguna|cualquier|una) (parte|mitad)|gana (alguna|una) |"
                   r"(ambos|both)[^|]{0,30}(\+|/| al menos \d| \d\+| - (sin empate|resultado|total|1x2|mas de|menos de|doble|dnb))|(sin empate|resultado|1x2|doble oportunidad|dnb) - (ambos|both)|(resultado|1x2|total|goles|sin empate|empate|doble oportunidad|dnb)\s*(/|\+|&)\s*|\s*(/|\+|&)\s*(ambos|both|resultado|1x2|sin empate|total|doble oportunidad|dnb)\b", re.I)


_GENERIC_TEAM_WORDS = {"real", "club", "atletico", "athletic", "deportivo", "deportiva", "sporting", "racing", "union",
                       "united", "city", "town", "basket", "baloncesto", "basketball", "basquet", "futbol", "football",
                       "calcio", "olympique", "olimpia", "dinamo", "dynamo", "lokomotiv", "spartak", "inter", "nacional",
                       "national", "internacional", "universidad", "university", "women", "femenino", "reserves",
                       "team", "equipo", "1899", "1900", "1909", "1913"}


def _team_words(name: str, other: str) -> list[str]:
    """Palabras distintivas de un nombre de equipo: >3 letras, no genéricas y no compartidas con el rival."""
    w = [x for x in re.split(r"[^a-z0-9]+", _fold(name)) if x]
    o = set(re.split(r"[^a-z0-9]+", _fold(other)))
    return [x for x in w if len(x) > 3 and x not in _GENERIC_TEAM_WORDS and x not in o]


_PARTICLES = {"de", "del", "la", "le", "da", "di", "du", "van", "von", "der", "den", "el", "al", "y", "e", "do", "dos",
              "das", "mc", "mac", "ten", "ter", "st", "san", "bin", "ibn", "abu", "jr", "sr", "ii", "iii", "the", "of", "fc", "cb", "bc"}


# exónimos habituales (título de la casa -> nombre del evento, ambos plegados); se comparan en los dos sentidos
_EXONYMS = [("koln", "colonia"), ("cologne", "colonia"), ("freiburg", "friburgo"), ("munchen", "munich"), ("munich", "bayern"),
            ("napoli", "napoles"), ("milano", "milan"), ("torino", "turin"), ("firenze", "florencia"), ("roma", "roma"),
            ("lisboa", "lisbon"), ("sevilla", "seville"), ("marseille", "marsella"), ("lyon", "lyon"), ("genoa", "genova"),
            ("hamburger", "hamburgo"), ("hamburg", "hamburgo"), ("frankfurt", "francfort"), ("leverkusen", "leverkusen"),
            ("gladbach", "monchengladbach"), ("borussia monchengladbach", "m gladbach"), ("bruges", "brujas"), ("brugge", "brujas"),
            ("athens", "atenas"), ("praha", "praga"), ("prague", "praga"), ("wien", "viena"), ("warszawa", "varsovia"),
            ("bruxelles", "bruselas"), ("brussel", "bruselas"), ("antwerp", "amberes"), ("antwerpen", "amberes"),
            ("goteborg", "gotemburgo"), ("kobenhavn", "copenhague"), ("copenhagen", "copenhague"), ("moskva", "moscu"),
            ("beograd", "belgrado"), ("belgrade", "belgrado"), ("zagreb", "zagreb"), ("bologna", "bolonia"), ("mainz", "maguncia"),
            ("nurnberg", "nuremberg"), ("hannover", "hanover"), ("saint etienne", "san etienne"), ("london", "londres"),
            ("edinburgh", "edimburgo"), ("geneve", "ginebra"), ("basel", "basilea"), ("zurich", "zurich"), ("bern", "berna")]


def _exonym_hit(title_f: str, name_f: str) -> bool:
    for a, b in _EXONYMS:
        for x, y in ((a, b), (b, a)):
            if re.search(rf"\b{re.escape(x)}\b", title_f) and re.search(rf"\b{re.escape(y)}\b", name_f):
                return True
    return False


def _alias_in(title_f: str, name: str, other: str) -> bool:
    """Una palabra del título (≥5 letras, no de relleno) que empieza igual que una palabra distintiva del equipo
    (5 letras comunes: napol-i/napol-es, hambur-ger/hambur-go) o que contiene/está contenida en ella con ≥6 letras
    (gladbach ⊂ monchengladbach). Nunca si esa palabra también casa con el rival."""
    if _exonym_hit(title_f, _fold(name)) and not _exonym_hit(title_f, _fold(other)):
        return True
    tw = [x for x in _team_words(name, other) if len(x) >= 5]
    ow = [x for x in re.split(r"[^a-z0-9]+", _fold(other)) if len(x) >= 5]
    if not tw:
        return False

    def _m(a: str, b: str) -> bool:
        return a[:5] == b[:5] or (len(a) >= 6 and a in b) or (len(b) >= 6 and b in a)
    for w in re.findall(r"[a-z]{5,}", title_f):
        if w in _FILLER or any(re.search(rx, w) for rx, _ in _METRICS):
            continue
        if any(_m(w, t) for t in tw) and not any(_m(w, o) for o in ow):
            return True
    return False


def _team_in(title_f: str, home: str, away: str) -> str | None:
    h, a = _fold(home), _fold(away)
    if not h or not a:
        return None
    mh = list(re.finditer(rf"\b{re.escape(h)}\b", title_f))
    ma = list(re.finditer(rf"\b{re.escape(a)}\b", title_f))
    if mh and ma:
        # un nombre contenido en el otro ("Milan" dentro de "Inter de Milan"): solo cuenta el que NO está
        # dentro de una aparición del rival
        mh = [x for x in mh if not any(y.start() <= x.start() and x.end() <= y.end() for y in ma)]
        ma = [x for x in ma if not any(y.start() <= x.start() and x.end() <= y.end() for y in mh)]
    fh, fa = bool(mh), bool(ma)
    if fh != fa:                                   # nombre completo de uno solo: inequívoco
        return "HOME" if fh else "AWAY"
    if fh and fa:
        return None
    ih = any(re.search(rf"\b{re.escape(x)}\b", title_f) for x in _team_words(home, away))
    ia = any(re.search(rf"\b{re.escape(x)}\b", title_f) for x in _team_words(away, home))
    if not ih and not ia:                          # sin palabras distintivas: vale cualquier palabra NO compartida con el rival
        hw = [x for x in re.split(r"[^a-z0-9]+", h) if len(x) > 3 and x not in a.split()]
        aw = [x for x in re.split(r"[^a-z0-9]+", a) if len(x) > 3 and x not in h.split()]
        ih = any(re.search(rf"\b{re.escape(x)}\b", title_f) for x in hw)
        ia = any(re.search(rf"\b{re.escape(x)}\b", title_f) for x in aw)
    if not ih and not ia:                          # apellidos cortos ("H. Shi", "A. Li", "J. Kym"): inicial + apellido o apellido ≥2 letras no compartido
        def _short(name: str, other: str) -> bool:
            ws = [x for x in re.split(r"[^a-z0-9]+", _fold(name)) if x]
            ow = set(re.split(r"[^a-z0-9]+", _fold(other)))
            if len(ws) >= 2 and re.search(rf"\b{ws[0][0]}\.?\s*{re.escape(ws[-1])}\b", title_f):
                return True
            # solo el APELLIDO (última palabra) y nunca partículas: "Alex de Minaur" no puede casar con "Total DE juegos"
            return any(re.search(rf"\b{re.escape(x)}\b", title_f) for x in ws[-1:]
                       if 2 <= len(x) <= 3 and x not in ow and x not in _PARTICLES)
        ih, ia = _short(home, away), _short(away, home)
    if not ih and not ia:                          # alias: "Napoli"/"Nápoles", "Hamburger SV"/"Hamburgo", "M'Gladbach"/"Mönchengladbach"
        ih, ia = _alias_in(title_f, home, away), _alias_in(title_f, away, home)
    if ih and not ia:
        return "HOME"
    if ia and not ih:
        return "AWAY"
    if ih and ia:
        return None
    # sin nombre: "equipo local" / "equipo visitante" / home team / away team
    if re.search(r"\b(local|home)\b", title_f) and not re.search(r"\b(visitante|away)\b", title_f):
        return "HOME"
    if re.search(r"\b(visitante|away)\b", title_f) and not re.search(r"\b(local|home)\b", title_f):
        return "AWAY"
    return None


_TOTAL_NOISE = re.compile(r"\b(mas de|menos de|over|under|total(es)?|numero|cantidad|de|del|el|la|los|las|en|por|y|"
                          r"partido|equipo|equipos|incl|prorroga|anotados?|marcados?|conseguidos?|totales|mas/menos|"
                          r"alternativ[oa]s?|lineas?|final|resultado|ambos|visitante|local|hecho|o)\b|[^a-z ]")
_TEAM_WORDS = (r"\b(total|totales|equipo|local|visitante|partido|fc|cb|bc|club|basket|united|city|"
               r"heat|nets|lakers|celtics|bulls|knicks|spurs|suns|jazz|kings|magic|hawks|bucks|"
               r"pacers|pistons|rockets|wizards|raptors|warriors|clippers|pelicans|grizzlies|"
               r"timberwolves|thunder|cavaliers|mavericks|nuggets|76ers|hornets|trail|blazers)\b")
_MAIN_WORDS = re.compile(r"\b(gol|goles|punto|puntos|juego|juegos|tanto|tantos|puntuacion|goals?|points?|games?)\b")


def _leading_name(raw: str, home: str, away: str) -> bool:
    """True si el título empieza por dos o más palabras con mayúscula inicial que no son ni relleno ni métrica ni
    palabras de los equipos (ya borradas de `tm`): un nombre de persona ("Jalen Brunson Total Points")."""
    m = re.match(r"^((?:(?:[A-ZÀ-Ý][\w'’.\-]*|el|de|la|del|van|von|da|di|le|du)\s+){1,3}[A-ZÀ-Ý][\w'’.\-]*)", raw or "")
    if not m:
        return False
    words = re.findall(r"[a-z]{2,}", _fold(m.group(1)))
    if len(words) < 2:
        return False
    tw = {_fold(w) for w in (_team_words(home, away) + _team_words(away, home))} if (home and away) else set()
    _PER = re.compile(r"^(primer|primera|primero|segundo|segunda|tercer|tercera|cuarto|cuarta|quinto|cuarto|cuartos|mitad|parte|tiempo|set|sets|"
                      r"juego|half|quarter|period|periodo|prorroga|overtime|descanso|final|partido|encuentro|match|game|player|jugador|team|equipo|"
                      r"mas|menos|over|under|total|totales|numero|cuantos|puntos|points|goles|goals|juegos|games)$")
    unknown = [w for w in words if w not in tw and w not in _FILLER and not _PER.match(w)
               and not any(re.search(rx, w) for rx, _ in _METRICS)]
    return len(unknown) >= 2


def _is_main_total(t: str, home: str, away: str) -> bool:
    """¿El título (sin métrica reconocida) es el total 'principal' (goles/puntos/juegos)? Rechaza stats desconocidas."""
    if _MAIN_WORDS.search(t):
        return True
    rest = t
    for name in (home, away):
        if name:
            rest = rest.replace(_fold(name), " ")
            parts = _fold(name).split()
            if len(parts) > 1:
                rest = rest.replace(parts[-1], " ")
    rest = _TOTAL_NOISE.sub(" ", rest).strip()
    return rest == ""


# ── registro de mapeos (título crudo → clave), lo vuelca OddsStore a market_map para diagnóstico ─────
_MAPLOG: dict[tuple, list] = {}        # (sport, title, kind, market) -> [n, ejemplo]


def _classify(title: str, sport: str, home: str = "", away: str = "", *, kind: str | None = None,
             player: str | None = None) -> MarketInfo | None:
    info = _classify_raw(title, sport, home, away, kind=kind, player=player)
    if info and sport == "tenis" and "POINTS" in info.market:
        # puntos de tenis ("Más/Menos puntos" del juego en curso, "1er set 4º juego total puntos", "puntos totales del
        # set"): cada casa los corta en un instante distinto y el bot ya los descarta; mejor no guardarlos
        info = None
    if len(_MAPLOG) < 4000:
        # si la casa pasa el jugador aparte, se anota en kind_hint: "Total de tiros" + player -> PLAYER_SHOTS es correcto
        k = (sport, (title or "")[:160], (kind or "") + ("+jugador" if player else ""), info.market if info else "")
        e = _MAPLOG.get(k)
        if e:
            e[0] += 1
        else:
            _MAPLOG[k] = [1, f"{home} - {away}"[:80]]
    return info


def _classify_raw(title: str, sport: str, home: str = "", away: str = "", *, kind: str | None = None,
                  player: str | None = None) -> MarketInfo | None:
    """
    title  : nombre del mercado tal y como lo da la casa ("1ª mitad - Número total córneres Como")
    kind   : pista de la casa sobre el tipo: "total" (más/menos), "handicap", "result" (1X2 / ganador),
             "btts", "dnb", "dc"; None -> se deduce del título.
    player : nombre del jugador si la casa lo da aparte (si no, se intenta extraer tras " - ").
    Devuelve None si el mercado no entra en la taxonomía (combinadas, exactos, par/impar…).
    """
    raw = _OT_RX.sub(" ", title or "")
    raw = re.sub(r"\s*[-–:/]\s*$", "", raw.strip())        # "Total de puntos - Prórroga incluida" → sin el " - " colgante (no es un jugador)
    t = _fold(raw)
    if _SKIP.search(t):
        return None
    if kind == "handicap" and re.search(r"\b1x2\b|europeo|european|3 ?way|tres? v[ií]as|3 v[ií]as|tres opciones", t):
        return None                    # hándicap a 3 vías (con empate): no comparable con el asiático a 2 vías
    period = None
    for rx, p in _PERIODS:
        if re.search(rx, t):
            period = p
            t = re.sub(rx, " ", t)          # quita el periodo para no confundir "2º set" con la métrica SETS
            t = re.sub(r"^[\s:/-]+|[\s:/-]+$", "", re.sub(r"\s+", " ", t))
            break
    if period is None and re.search(r"\b(cuartos?|mitades|mitad|partes?|tiempos?|halves|half|quarters?|periodos?|periods?)\b", t) \
            and not re.search(r"\btiempo (reglamentario|regular)\b|\bpartido completo\b|\btiempo completo\b|\btiempo extra\b", t):
        return None                    # "Hándicap Cuartos", "Más/menos puntos por mitad"…: periodo sin número -> no sabemos cuál es

    # tenis: "Jugador 1 / Jugador 2" (o "Player 1/2") son los lados del partido, no props
    if sport == "tenis":
        # "Más/menos Juegos Set", "Hándicap Juegos Set" (Retabet live): juegos de UN set sin decir cuál (el set en
        # curso) → no es ni el total de sets ni el de juegos del partido: ambiguo, fuera. Igual "Set +1/+2: …".
        if period is None and re.search(r"\bjuegos?\b|\bgames?\b", t) and re.search(r"\bsets?\b", t):
            return None
        if period is not None and re.search(r"\bjuegos?\b|\bgames?\b", t):
            t = re.sub(r"\b(del|de los|en el|por|of the|in) sets?\b", " ", t)   # "Hándicap de juegos del set [2]" → juegos del set 2
        if re.search(r"\bset ?\+\d", t):
            return None
        if re.search(r"\bal menos\b|\bat least\b|\bambos (ganan|jugadores)|\bambos equipos\b|\bgana(ra)? (un|algun) set\b", t):
            return None                                    # "¿Ganará el jugador 2 al menos 1 set?", "Ambos ganan un set": sí/no sin equivalente
        t = re.sub(r"\b(jugador|player) ?1\b", "local", t)
        t = re.sub(r"\b(jugador|player) ?2\b", "visitante", t)
        if player and _fold(player) in (_fold(home), _fold(away)):
            t = f"{t} - {_fold(player)}"
            player = None
    # ── player props ──
    _is_btts_like = re.search(r"ambos (equipos )?(marca|anota)|marcaran ambos|anotaran ambos|both teams|btts|sin empate|draw no bet|doble oportunidad|double chance|\b1x2\b", t)
    if _is_btts_like and (player or _PLAYER_HINTS.search(t)):
        return None                                        # "Ambos marcan" con jugador: combinada/prop raro, fuera
    is_player = bool(player) or bool(_PLAYER_HINTS.search(t))
    if not is_player and sport == "baloncesto" and re.search(r" - [^-]{3,60}$", raw) and \
            re.search(r"\b(puntos|pts|rebotes|rebs?|asistencias|asis|ast|tapones|bloqueos|robos|triples)\b.*(\+|&| y |,).*\b(puntos|pts|rebotes|rebs?|asistencias|asis|ast|tapones|bloqueos|robos|triples)\b", t):
        is_player = True                                   # combinadas de estadísticas con nombre al final: siempre son props
    if not is_player and re.search(r"\b(puntos|pts|rebotes|rebs?|asistencias|asis|ast|tapones|bloqueos|robos|triples)\b\s*\.?\s*(\+|&|,| y | e |/| and | mas )\s*"
                                   r"\b(puntos|pts|rebotes|rebs?|asistencias|asis|ast|tapones|bloqueos|robos|triples)\b", t):
        return None                                        # combinada sin jugador identificable: inservible
    # "Triples anotados - Stephen Curry": cola con nombre propio que NO es un equipo → es un prop de jugador,
    # nunca el total del partido. Si la métrica no admite prop (goles/puntos/córneres…) se descarta por ambigua.
    if not is_player and not player and sport != "tenis" and not _is_btts_like:
        mt = re.search(r" - ([^-()\d]{3,60})(?: \([a-z]{2,4}\))?\s*$", t)   # sobre `t`: ya sin periodo ni acentos
        if mt and home and away and _team_in(t, home, away) is None \
                and not re.search(r"\b(total|totales|resultado|ganador|1x2|partido|local|visitante|equipo|mas de|menos de|handicap|si|no|over|under|"
                                  r"encima|debajo|arriba|abajo|exacto|exactos|par|impar|rango|mas|menos)\b", _fold(mt.group(1))) \
                and re.search(r"[A-Za-zÁ-ú]{2,}", mt.group(1)):
            metric0 = next((k for rx, k in _METRICS if re.search(rx, t)), None)
            if metric0 in ("THREES", "ASSISTS", "REBOUNDS", "BLOCKS", "STEALS", "SHOTS", "SHOTS_OT", "SAVES", "TACKLES",
                           "PASSES", "PRA", "PR", "PA", "RA", "POINTS", "GOALS"):
                is_player = True
            elif kind in (None, "total") and not re.search(r"handicap|h[aá]ndicap", t):
                return None
    # "De'Anthony Melton - Puntos (Más/Menos)" (Sportium): nombre propio al PRINCIPIO que no es ninguno de los
    # dos equipos → prop de jugador, nunca el total del partido (acababa como TOTAL Over 13.5)
    # Retabet live: "Puntos" / "Triples" / "Rebotes" a secas (grupo de props de jugador; cada opción es un jugador) →
    # sin jugador identificado no es comparable con nada: fuera. "Puntos Peyton Watson" → prop de ese jugador.
    if not is_player and not player and sport == "baloncesto" and kind in (None, "total"):
        if re.fullmatch(r"(puntos|pts|triples|rebotes|asistencias|robos|tapones)", t.strip()):
            return None
        mp = re.match(r"^(puntos|triples|rebotes|asistencias|robos|tapones)\s+([^-()\d:]{5,40})$", t.strip())
        if mp and home and away and _team_in(t, home, away) is None and 2 <= len(mp.group(2).split()) <= 4 \
                and not re.search(r"\b(total|totales|equipo|local|visitante|partido|mas|menos|en el)\b", mp.group(2)):
            is_player = True
            mraw = re.match(r"^\S+\s+(.+)$", raw.strip())
            player = (mraw.group(1) if mraw else mp.group(2)).strip()
    if not is_player and not player and sport == "baloncesto" and not _is_btts_like and home and away:
        mh = re.match(r"^((?:[^-()\d]|(?<=\S)-(?=\S)){5,40}?)\s+-\s+(puntos|pts|rebotes|asistencias|triples|tapones|robos)\b", t)
        if mh and _team_in(t, home, away) is None and 2 <= len(mh.group(1).split()) <= 4 \
                and not re.search(_TEAM_WORDS, mh.group(1)):
            is_player = True
            mraw = re.match(r"^((?:[^-()\d]|(?<=\S)-(?=\S)){5,40}?)\s+-\s+", raw)
            player = (mraw.group(1) if mraw else mh.group(1)).strip()
    # Codere: "Alize Johnson Total Puntos" / "Meleek Thomas - Total Puntos": nombre propio delante de "Total <stat>"
    # que no es ninguno de los dos equipos → prop de jugador (acababa como TOTAL del partido Over 10.5)
    if not is_player and not player and sport == "baloncesto" and not _is_btts_like and home and away:
        mt = re.match(r"^((?:[^-()\d]|(?<=\S)-(?=\S)){5,40}?)\s*-?\s+total(?:es)?\s+(?:de\s+)?(puntos|pts|rebotes|asistencias|triples|tapones|robos)\b", t)
        if mt and _team_in(t, home, away) is None and 2 <= len(mt.group(1).split()) <= 4 \
                and not re.search(_TEAM_WORDS, mt.group(1)) and not re.search(r"\b(mas|menos|cuarto|mitad|parte)\b", t):
            is_player = True
            mraw = re.match(r"^((?:[^-()\d]|(?<=\S)-(?=\S)){5,40}?)\s*-?\s+total", raw.strip(), re.I)
            player = (mraw.group(1) if mraw else mt.group(1)).strip()
    if not is_player and not player and sport == "futbol" and not _is_btts_like and home and away:
        mf = re.match(r"^((?:[^-()\d]|(?<=\S)-(?=\S)){5,40}?)\s+-?\s*(tiros a puerta|tiros|remates( a puerta)?|disparos( a puerta)?|goles|asistencias|faltas|tarjetas|fueras de juego)\b", t)
        if mf and _team_in(t, home, away) is None and 2 <= len(mf.group(1).split()) <= 4 \
                and not re.search(_TEAM_WORDS, mf.group(1)) \
                and set(re.findall(r"[a-z]{4,}", mf.group(1))) == set(_unknown_words(mf.group(1))) and _unknown_words(mf.group(1)) \
                and not re.search(r"\b(total|totales|mas|menos|equipo|local|visitante|partido|ambos|handicap|cuant\w*|numero|"
                                  r"apuesta|resultado|ganador|doble|primer|ultimo|parte|mitad|tiempo|jugador|player|sin|con)\b", mf.group(1)):
            is_player = True
            mraw = re.match(r"^((?:[^-()\d]|(?<=\S)-(?=\S)){5,40}?)\s+-?\s*(tiros|remates|disparos|goles|asistencias|faltas|tarjetas|fueras)\b", raw.strip(), re.I)
            player = (mraw.group(1) if mraw else mf.group(1)).strip()
    if is_player and sport == "tenis" and re.search(r"\bjuegos?\b|\bgames?\b|\bsets?\b", t) and not player:
        # "Total de juegos del jugador" sin decir cuál: ambiguo (no es el total del partido) → fuera
        return None
    if is_player:
        if not player:
            m = re.search(r" - ([^-()]{3,60})(?: \([A-Z]{2,4}\))?\s*$", raw)   # "… - LeBron James"
            mh0 = re.match(r"^([^()\d]{3,60}?)\s+-\s+", raw.strip())           # "Luka Doncic - Total de puntos + rebotes"
            _stat = re.compile(r"\b(total|totales|mas|menos|over|under|puntos|pts|rebotes|asistencias|triples|tapones|robos|"
                               r"remates|tiros|disparos|goles|faltas|tarjetas|pases|paradas|entradas|juegos|sets|partido|mitad|cuarto)\b", re.I)
            tail = m.group(1).strip() if m else None
            head = mh0.group(1).strip() if mh0 else None
            if tail and not _stat.search(_fold(tail)):
                player = tail
            elif head and not _stat.search(_fold(head)) and (not (home and away) or _team_in(_fold(head), home, away) is None):
                player = head                                  # métrica detrás, nombre delante
            elif tail:
                player = tail
        tt = t
        if sport == "baloncesto":
            # "anotados", "marca", "anotador"… son verbos, no métricas: sin quitarlos cualquier prop acababa como GOALS
            tt = re.sub(r"\b(anota\w*|marca\w*|goleador\w*|encesta\w*)\b", " ", t)
        metric = next((k for rx, k in _METRICS if re.search(rx, tt)), None)
        if metric in (None, "TOTAL") or kind == "result":
            return None
        if sport == "baloncesto" and metric == "GOALS":
            return None                                    # en baloncesto no hay "goles": métrica desconocida
        # combinaciones de estadísticas ("tapones + robos", "puntos y tapones", "robos+tapones", "stl+blk"):
        # solo se aceptan las combinadas con clave propia (PRA/PR/PA/RA); el resto se descarta
        _ST = r"(tapones|tap|bloqueos|bloq|robos|rob|rebotes|rebs?|asistencias|asis|ast|puntos|pts|triples|blocks?|steals?|rebounds?|assists?|points?|blk|stl)"
        if metric not in ("PRA", "PR", "PA", "RA") and re.search(_ST + r"\.?\s*(\+|&|,| y | e |/| and | mas )\s*" + _ST + r"\b", t):
            return None
        # Betsson: "Total robos jugador + Bloqueos" (las dos estadísticas no van juntas): si el título nombra
        # dos estadísticas distintas y no es una combinada con clave propia, se descarta
        if metric not in ("PRA", "PR", "PA", "RA"):
            _GROUPS = (r"\b(tapones|bloqueos|blocks?|blk)\b", r"\b(robos|steals?|stl)\b", r"\b(rebotes|rebs?|rebounds?)\b",
                       r"\b(asistencias|asist|asis|asts?|assists?)\b", r"\b(puntos|ptos?|pts?|points?)\b", r"\b(triples|threes?|3pt)\b")
            if sum(1 for g in _GROUPS if re.search(g, t)) >= 2:
                return None
        if metric == "POINTS" and sport == "futbol":
            metric = "GOALS"
        return MarketInfo(_join(f"PLAYER_{metric}", None, period), player=player, period=period)

    team = _team_in(t, home, away) if (home and away) else None
    if team and kind in (None, "btts", "yesno") and re.search(r"\b(para )?(marca|marcar|marcara|anota|anotar|anotara|to score)\b", t) \
            and not re.search(r"\b(total|mas de|menos de|over|under|goles|goals|ambos|both|primer|ultimo)\b|\d", t):
        return MarketInfo(_join("TTS", team, period), team=team, period=period)   # "Sunderland marca" (sí/no)
    # la métrica se busca en el título SIN los nombres de los equipos/jugadores ("Mpetshi Perricard" contiene "card",
    # "Tiros FC"...): se eliminan las palabras de ambos nombres antes de mirar las métricas
    tm = t
    if home and away:
        for w in _team_words(home, away) + _team_words(away, home):
            tm = re.sub(rf"\b{re.escape(w)}\b", " ", tm)

    # ── tipo ──
    if kind == "handicap" or re.search(r"handicap|hándicap|h[aá]ndicap", t):
        metric = next((k for rx, k in _METRICS if re.search(rx, tm)), None)
        base = "HANDICAP" if metric in (None, "TOTAL", _MAIN_METRIC.get(sport)) else f"HANDICAP_{metric}"
        return MarketInfo(_join(base, None, period), period=period)
    if kind == "btts" or re.search(r"ambos (equipos )?(marca|anota)(n|ran)?\b|(marcaran|anotaran) ambos|both teams to score|btts", t):
        return MarketInfo(_join("BTTS", None, period), period=period)
    if kind == "dnb" or re.search(r"sin empate|draw no bet|apuesta sin empate|^apuesta sin\b", t):
        return MarketInfo(_join("DNB", None, period), period=period)
    if kind == "dc" or re.search(r"doble oportunidad|double chance", t):
        return MarketInfo(_join("DC", None, period), period=period)
    if kind == "result" or re.fullmatch(r"(resultado|ganador|ganadora|1x2|winner|money ?line|resultado final|"
                                        r"(\S+ ){0,3}- (resultado|ganador|1x2))", t) \
            or re.search(r"^(1x2|resultado|ganador)\b", t) and not re.search(r"total|mas de|menos de", t):
        if team:                       # "Tiros - Resultado" es stats, "Como gana" no es 1X2
            return None
        metric = next((k for rx, k in _METRICS if re.search(rx, tm)), None)
        if metric not in (None, "TOTAL", _MAIN_METRIC.get(sport)):
            return None
        return MarketInfo(_join("1X2", None, period), period=period)
    if kind == "total" or re.search(r"total|numero de|numero total|mas de|menos de|over|under|mas ?/ ?menos", t):
        metric = next((k for rx, k in _METRICS if re.search(rx, tm)), None)
        if team is None and [x for x in re.findall(r"\b[A-Z]{2,4}\b", raw) if x not in ("OT", "ET", "HT", "FT", "AET", "PT")]:
            return None                # siglas de equipo que no reconocemos ("Total puntos LAL"): no es el total del partido
        if team is None and re.search(r"\bequipos?\b|\bteams?\b|\blocal\b|\bvisitante\b|\bhome\b|\baway\b|"
                                      r"(marcados?|anotados?|conseguidos?) por\b|\b(goles|puntos|corneres|tarjetas) (de|del|por) (?!partido|encuentro)\w", t) \
                and not re.search(r"\bambos\b|\bboth\b", t):
            return None                # total de UN equipo que no sabemos cuál es: nunca lo tratamos como total del partido
        if period is None and re.search(r"\b(cuartos?|mitad|parte|tiempo|half|quarter|periodo|period)\b", t) \
                and not re.search(r"\btiempo (reglamentario|regular)\b|\bpartido completo\b", t):
            return None                # habla de un periodo que no hemos reconocido: no es el total del partido
        if team is None and sport == "futbol" and _unknown_words(tm):
            return None                # "Córners Napoli" (alias del equipo que no reconocemos), "Tarjetas Juve"…:
                                       # palabra que no es métrica ni relleno conocido -> NO es el total del partido
        if team is None and _leading_name(raw, home, away):
            return None                # "Jalen Brunson Total Points 25.5" (Versus/Playtech sin PLAYER_INFO): nombre propio
                                       # delante de la métrica -> es de un jugador, nunca el total del partido
        if metric in (None, "TOTAL", _MAIN_METRIC.get(sport)) or (sport == "baloncesto" and metric == "GOALS"):
            if metric in (None, "TOTAL") and not _is_main_total(t, home, away):
                return None            # estadística desconocida ("Pérdidas", "Posesión"…): no se mapea
            base = "TOTAL"
        else:
            base = metric
        return MarketInfo(_join(base, team, period), team=team, period=period)
    return None


def period_of(text: str) -> str | None:
    """Periodo (1H, 2H, Q1…, SET1…, OT) que menciona un texto, o None si no menciona ninguno."""
    t = _fold(text)
    for rx, p in _PERIODS:
        if re.search(rx, t):
            return p
    return None


_FULL_MATCH = re.compile(r"\b(partido|tiempo completo|tiempo reglamentario|90 min|match|full ?time|regular time|"
                         r"principal(es)?|resultado final|final)\b")


def is_full_match_label(text: str) -> bool:
    """True si la etiqueta de pestaña/periodo se refiere al partido completo (o está vacía)."""
    t = _fold(text)
    return not t or bool(_FULL_MATCH.search(t))


def implied_line(title: str) -> float | None:
    """'Marca 2 goles o más' -> 1.5 · 'Realiza 3 o más remates' -> 2.5 · 'Goleador' -> 0.5 · 'Más de 2,5' -> 2.5."""
    t = _fold(title)
    m = re.search(r"(\d+(?:[.,]\d+)?)", t)
    if re.search(r"o mas|or more|\+$", t) and m:
        return float(m.group(1).replace(",", ".")) - 0.5
    if re.search(r"mas de|menos de|over|under", t) and m:
        return float(m.group(1).replace(",", "."))
    if re.search(r"goleador|anytime|cualquier momento|marcara|to score|recibe una|una o mas", t):
        return 0.5
    return None


def _join(base: str, team: str | None, period: str | None) -> str:
    out = base
    if team:
        out += f"_{team}"
    if period:
        out += f"_{period}"
    return out


@lru_cache(maxsize=262144)
def make_code(market: str, selection: str, line: float | None, player: str | None = None) -> str:
    """Código estable e independiente de la casa para odds_latest.market_code (puro → con caché: se llama por
    cada selección de cada pasada, decenas de miles de veces por segundo entre todas las casas)."""
    ln = "" if line is None else f"{line:g}"
    pl = _fold(player).replace(" ", "_") if player else ""
    return f"{market}|{pl}|{ln}|{selection}"


def parse_ou_label(label: str) -> tuple[str | None, float | None]:
    """'Más de 2,5' -> ('Over', 2.5); 'Menos de 217.5' -> ('Under', 217.5)."""
    t = _fold(label)
    sel = "Over" if re.match(r"(mas de|over|\+|more)", t) else "Under" if re.match(r"(menos de|under|-|less)", t) else None
    m = re.search(r"(\d+(?:[.,]\d+)?)", t)
    return sel, (float(m.group(1).replace(",", ".")) if m else None)


_OT_RX = re.compile(r"\(?\b(incl\.?|incluye|incluida|incluyendo|con)\s*(la\s*)?(pr[oó]rroga|t\.?\s?e\.?|tiempo extra)\)?|\(?\bincluding overtime\)?"
                    r"|\(?\b(pr[oó]rroga|tiempo extra|overtime)\s+(incluida|incluido|included|incl\.?)\)?", re.I)   # Kambi: "Ganador - Prórroga incluida"


def classify(title: str, sport: str, home: str = "", away: str = "", *, kind: str | None = None,
             player: str | None = None) -> "MarketInfo | None":
    """Envoltorio de _classify que además anota `ot=True` cuando el título dice "incluida la prórroga"."""
    info = _classify(title, sport, home, away, kind=kind, player=player)
    if info is not None and (_OT_RX.search(title or "") or re.search(r"alternativ", title or "", re.I)):
        info.ot = True          # las líneas alternativas (Playtech) liquidan igual que el mercado principal con prórroga
    return info


def demote_plain_ot(selections: list[dict]) -> None:
    """Baloncesto: si un evento ofrece "Total Puntos (incluida la prórroga)" Y "Total Puntos" a secas (Versus,
    Betsson), el "a secas" es tiempo reglamentario → se renombra a *_REG para que no se cruce con los totales
    normales (que en todas las casas incluyen prórroga). Los colectores añaden `"ot": info.ot` a cada selección;
    aquí se consume y se elimina la clave. Si no hay hermano explícito, no se toca nada."""
    with_ot = {s["market"] for s in selections if s.get("ot")}
    for s in selections:
        if "ot" in s:
            m = s["market"]
            if not s["ot"] and m in with_ot and not m.endswith("_REG"):
                s["market"] = m + "_REG"
            del s["ot"]
