"""
sportium.py — colector de cuotas de Sportium (sportium.es) y Marca Apuestas (misma plataforma Playtech
"sportswidget"). Sin navegador, sin cookies, sin geobloqueo: el feed es un CDN público.

    GET {cdn}/v2/getmeta                                   -> índices actuales (fullIndex, partialIndex, upd2fullIndex…)
    GET {cdn}/v2/getslice/{repo}_8_{lang}_{baseIndex}_0.bin -> BASE: estructura (deportes/países/competiciones),
                                                             tipos de mercado, tabla de cuotas (OddMap: id -> cuota)
    GET {cdn}/v2/getslice/{repo}_2_{lang}_{fullIndex}_{p}.bin  p=0..fullPartitions-1  -> FOTO COMPLETA (eventos,
                                                             mercados, selecciones, diccionario de nombres…)
    GET {cdn}/v2/getslice/{repo}_3_{lang}_{upd2fullIndex}_0.bin -> cambios acumulados desde la foto
    GET {cdn}/v2/getslice/{repo}_1_{lang}_{i}_0.bin           -> DELTA parcial i (uno cada ~1-2 s, 2-5 KB)

Cada .bin es LZMA + tablas columnares (ptslice.py). Se descarga la foto una vez (≈3,5 MB) y después, cada
ciclo, sólo los deltas nuevos: upserts por node_id en Event / Market / Result / NodesInPlayDetail. Cada
`resync_minutes` se vuelve a bajar la foto para no acumular basura. Sólo se guardan en memoria los eventos
de las competiciones del catálogo (competitions.json).

Precios: Result.odd_map_id -> OddMap.dec / 1000.  Nombres: DictionaryEntry (texto "{0}"/"{1}" = local/visitante;
selección = "nombre||código|orden|", código 1/X/2/O/U/Y/N).  Línea: Result.handicap_dictionary_id -> "+1.5".
Marcador en directo: NodesInPlayDetail.data (JSON).

Uso:  python sportium.py            (bucle)     --once     --list (competiciones)     --probe (feed)
      python sportium.py --dump <eventId>       (mercados normalizados de un evento)
      python sportium.py --find Lakers [filtro]  (título de mercado -> clave; filtro regex, p.ej. "110|TOTAL_1H")
      SPORTIUM_CFG=marca.json python sportium.py   (Marca Apuestas)
"""
from __future__ import annotations

import fastjson as json
import logging
import os
import re
import sys
import time
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from pathlib import Path

import requests

sys.path.insert(0, str(Path(__file__).resolve().parent))   # permite `python -m scraper.sportium` desde betbot\
import ptslice
from competitions import Competitions
from markets import classify, implied_line
from storage import OddsStore

log = logging.getLogger("sportium")
CFG_PATH = Path(sys.argv[sys.argv.index("--cfg") + 1] if "--cfg" in sys.argv else os.getenv("SPORTIUM_CFG", Path(__file__).parent / "sportium.json"))
if not CFG_PATH.is_absolute() and not CFG_PATH.exists():
    CFG_PATH = Path(__file__).parent / CFG_PATH
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
      "Chrome/130.0.0.0 Safari/537.36")

BASE_SLICE, FULL_SLICE, UPD2FULL_SLICE, PARTIAL_SLICE = 8, 2, 3, 1
_AV_KEEP = {"PLAYER_INFO", "SELECTION_PLAYER_INFO", "MARKET_EXTRA_VALUE"}   # se guardan aunque el mercado llegue después
TABLES = {"RepoContentSlice", "Structure", "Event", "Market", "Result", "DictionaryEntry", "AdditionalValue",
          "AdditionalValueKey", "MarketType", "OddMap", "NodesInPlayDetail",
          # Deltas compactos: en directo casi todos los cambios de cuota y las suspensiones de mercado llegan así
          # (sólo node_id + campo cambiado). Sin ellos las cuotas live se quedaban congeladas con el precio viejo.
          "EventSmall", "MarketSmall", "ResultSmall"}


_FOLD = {"á": "a", "é": "e", "í": "i", "ó": "o", "ú": "u", "ñ": "n", "ü": "u"}


def _fold(s: str) -> str:
    return "".join(_FOLD.get(c, c) for c in (s or "").lower()).strip()


def load_cfg(path: Path | None = None) -> dict:
    import pace
    cfg = pace.apply(json.loads((path or CFG_PATH).read_text(encoding="utf-8")))
    cfg["_cfg_path"] = str(path or CFG_PATH)      # cada Collector recuerda su fichero (varias marcas por proceso)
    return cfg


# ──────────────────────────────────────────────────────────────────────────────
class Feed:
    """Réplica en memoria del repositorio Playtech, limitada a los eventos que nos interesan."""

    def __init__(self, cfg: dict, catalog: Competitions):
        self.cfg = cfg
        self.catalog = catalog
        self.s = requests.Session()
        pool = max(10, int(cfg.get("workers", 8)) + 2)        # tantas conexiones como hilos de descarga
        self.s.mount("https://", requests.adapters.HTTPAdapter(pool_connections=pool, pool_maxsize=pool))
        self.s.headers.update({"User-Agent": UA, "Accept": "*/*", "Origin": cfg["origin"], "Referer": cfg["origin"] + "/"})
        self.meta: dict = {}
        self.last_partial = 0
        self.synced_at = 0.0
        self.bytes = 0
        self.pool = ThreadPoolExecutor(max_workers=cfg.get("workers", 8))
        self.reset()

    def reset(self):
        self.D: dict[int, str] = {}                       # dictionary_id -> texto
        self.struct: dict[int, tuple[int, int, int]] = {}  # node -> (parent, tipo, dict)
        self.events: dict[int, dict] = {}                 # sólo eventos de competiciones del catálogo
        self.ev_meta: dict[int, tuple[str, str]] = {}     # event -> (deporte, competición canónica)
        self.markets: dict[int, dict] = {}
        self.results: dict[int, dict] = {}
        self.ev_markets: dict[int, set[int]] = defaultdict(set)
        self.mk_results: dict[int, set[int]] = defaultdict(set)
        self.av: dict[int, dict[str, int]] = defaultdict(dict)   # node -> {clave: dict_id}
        self.avk: dict[int, str] = {}
        self.mtypes: dict[int, tuple[str, str]] = {}
        self.oddmap: dict[int, int] = {}
        self.inplay: dict[int, str] = {}
        self.touched: set[int] = set()
        self.detailed: set[int] = set()                   # eventos con su slice completo (todos los mercados) cargado
        self._comp_cache: dict[int, tuple[str, str] | None] = {}   # competición -> (deporte, nombre) | None

    # descarga ---------------------------------------------------------------
    def get_meta(self) -> dict:
        r = self.s.get(f"{self.cfg['cdn']}/v2/getmeta", timeout=self.cfg.get("timeout", 10))
        r.raise_for_status()
        self.meta = json.loads(r.content)
        return self.meta

    def slice_name(self, typ: int, index: int, part: int = 0) -> str:
        return f"{self.meta['repositoryId']}_{typ}_{self.cfg['lang']}_{index}_{part}.bin"

    def fetch(self, name: str) -> dict | None:
        """Descarga y decodifica un slice; None si no existe (404)."""
        url = f"{self.cfg['cdn']}/v2/getslice/{name}"
        last = None
        for attempt in range(3):
            # Reintentos con "cache-buster": a veces un nodo de Cloudflare sirve una copia truncada/corrupta del
            # fichero (inmutable, max-age 60 días) y seguiría sirviéndola para siempre; con ?r=… se va al origen.
            u = url if attempt == 0 else f"{url}?r={int(time.time() * 1000)}"
            hdr = {} if attempt == 0 else {"Cache-Control": "no-cache", "Pragma": "no-cache"}
            r = self.s.get(u, timeout=self.cfg.get("timeout", 10), headers=hdr)
            if r.status_code != 200:
                log.debug("%s -> %s", name, r.status_code)
                return None
            self.bytes += len(r.content)
            try:
                return ptslice.decode(r.content, TABLES)
            except Exception as e:                       # slice corrupto / formato cambiado
                last = e
                log.warning("slice %s corrupto (%d bytes, cabecera %s, cf=%s, enc=%s): %s — reintento %d",
                            name, len(r.content), r.content[:8].hex(), r.headers.get("cf-cache-status"),
                            r.headers.get("content-encoding"), e, attempt + 1)
                time.sleep(0.5)
        raise RuntimeError(f"no puedo decodificar {name}: {last}")

    def _event_slice(self, eid: int) -> str:
        return f"event/full/{self.meta['repositoryId']}/{self.meta['fullIndex']}/{eid}/{self.cfg['lang']}.bin"

    def fetch_events(self, ids: list[int]) -> int:
        """Slice completo de cada evento (todos sus mercados y selecciones, ~20 KB). El feed general sólo trae
        los mercados principales; los props de jugador, líneas alternativas, etc. vienen aquí.
        Se descargan en paralelo y se aplican en secuencia (las tablas en memoria no son thread-safe)."""
        got = 0
        for eid, t in zip(ids, self.pool.map(lambda e: self.fetch(self._event_slice(e)), ids)):
            if t is not None:
                self.apply(t)
                self.detailed.add(eid)
                got += 1
            else:
                self.detailed.add(eid)                    # 404: no insistir hasta el próximo resync
        return got

    def fetch_search_meta(self):
        """Slice 'event_search': nombres de jugador de cada mercado de props (PLAYER_INFO)."""
        t = self.fetch(f"event_search/full/{self.meta['repositoryId']}/{self.meta['fullIndex']}/{self.cfg['lang']}.bin")
        if t is not None:
            self.apply(t)

    def bootstrap(self):
        """Foto completa: base + full (todas las particiones) + upd2full + parciales pendientes."""
        t0 = time.time()
        m = self.get_meta()
        self.reset()
        self.bytes = 0
        names = [self.slice_name(BASE_SLICE, m["baseIndex"])]
        names += [self.slice_name(FULL_SLICE, m["fullIndex"], p) for p in range(m["fullPartitions"])]
        if m.get("upd2fullIndex", 0) > m["fullIndex"]:
            names.append(self.slice_name(UPD2FULL_SLICE, m["upd2fullIndex"]))
        for n in names:
            t = self.fetch(n)
            if t is None:
                raise RuntimeError(f"slice {n} no disponible (404)")
            self.apply(t)
        self.fetch_search_meta()
        last = max(m.get("upd2fullIndex", 0), m["fullIndex"])
        self.last_partial = last
        self.pull_partials(m["partialIndex"])
        self.synced_at = time.time()
        log.info("sincronizado: %d eventos, %d mercados, %d selecciones (%.1f MB, %.1fs)", len(self.events),
                 len(self.markets), len(self.results), self.bytes / 1e6, time.time() - t0)

    def pull_partials(self, upto: int) -> int:
        """Descarga en paralelo los deltas pendientes y los aplica en orden."""
        ids = list(range(self.last_partial + 1, upto + 1))
        if not ids:
            return 0
        for i, t in zip(ids, self.pool.map(lambda i: self.fetch(self.slice_name(PARTIAL_SLICE, i)), ids)):
            if t is not None:
                self.apply(t)
            self.last_partial = i
        return len(ids)

    def update(self) -> int:
        """Un ciclo: lee getmeta y aplica los deltas nuevos. Resincroniza si hay hueco o toca por tiempo."""
        m = self.get_meta()
        gap = m["partialIndex"] - self.last_partial
        if (not self.events and not self.synced_at) or gap > self.cfg.get("max_partials_per_cycle", 150) or gap < 0 \
                or time.time() - self.synced_at > self.cfg.get("resync_minutes", 20) * 60 \
                or m["repositoryId"] != self.meta.get("repositoryId"):
            self.bootstrap()
            return -1
        return self.pull_partials(m["partialIndex"])

    # aplicación de tablas -------------------------------------------------------
    def apply(self, t: dict[str, dict[str, list]]):
        if "DictionaryEntry" in t:
            self.D.update(zip(t["DictionaryEntry"]["id"], t["DictionaryEntry"]["value"]))
        for r in ptslice.rows(t.get("AdditionalValueKey", {})):
            self.avk[r["key_id"]] = r["key"]
        for r in ptslice.rows(t.get("MarketType", {})):
            self.mtypes[r["id"]] = (r["market_type"], r["market_type_category"])
        for r in ptslice.rows(t.get("OddMap", {})):
            self.oddmap[r["id"]] = r["dec"]
        for r in ptslice.rows(t.get("Structure", {})):
            self.struct[r["node_id"]] = (r["parent_node_id"], r["node_type_id"], r["dictionary_id"])
        for r in ptslice.rows(t.get("Event", {})):
            eid = r["node_id"]
            meta = self._classify_event(r)
            if meta is None:
                if eid in self.events:
                    self._drop_event(eid)
                continue
            self.events[eid] = r
            self.ev_meta[eid] = meta
            self.touched.add(eid)
        for r in ptslice.rows(t.get("Market", {})):
            eid = r["parent_node_id"]
            if eid in self.events:
                self.markets[r["node_id"]] = r
                self.ev_markets[eid].add(r["node_id"])
                self.touched.add(eid)
        for r in ptslice.rows(t.get("Result", {})):
            mid = r["parent_node_id"]
            m = self.markets.get(mid)
            if m is not None:
                self.results[r["node_id"]] = r
                self.mk_results[mid].add(r["node_id"])
                self.touched.add(m["parent_node_id"])
        for r in ptslice.rows(t.get("EventSmall", {})):
            ev = self.events.get(r["node_id"])
            if ev is not None:
                ev["is_displayed"], ev["is_active"] = r["is_displayed"], r["is_active"]
                self.touched.add(r["node_id"])
        for r in ptslice.rows(t.get("MarketSmall", {})):
            m = self.markets.get(r["node_id"])
            if m is not None:
                m["is_active"], m["is_displayed"] = r["is_active"], r["is_displayed"]
                self.touched.add(m["parent_node_id"])
        for r in ptslice.rows(t.get("ResultSmall", {})):
            res = self.results.get(r["node_id"])
            if res is not None:
                res["odd_map_id"] = r["odd_map_id"]
                m = self.markets.get(res["parent_node_id"])
                if m is not None:
                    self.touched.add(m["parent_node_id"])
        for r in ptslice.rows(t.get("AdditionalValue", {})):
            n = r["node_id"]
            key = self.avk.get(r["key_id"], str(r["key_id"]))
            if key in _AV_KEEP or n in self.markets or n in self.events:
                self.av[n][key] = r["dictionary_id"]
        for r in ptslice.rows(t.get("NodesInPlayDetail", {})):
            if r["node_id"] in self.events:
                self.inplay[r["node_id"]] = r["data"]
                self.touched.add(r["node_id"])

    def _drop_event(self, eid: int):
        for mid in self.ev_markets.pop(eid, ()):
            for rid in self.mk_results.pop(mid, ()):
                self.results.pop(rid, None)
            self.markets.pop(mid, None)
            self.av.pop(mid, None)
        self.events.pop(eid, None)
        self.ev_meta.pop(eid, None)
        self.detailed.discard(eid)
        self.inplay.pop(eid, None)
        self.av.pop(eid, None)

    # estructura --------------------------------------------------------------
    def name(self, node: int) -> str:
        s = self.struct.get(node)
        return self.D.get(s[2], "") if s else ""

    def sport_of(self, node: int) -> int | None:
        seen = 0
        while node in self.struct and seen < 10:
            parent, typ, _ = self.struct[node]
            if typ == 1:
                return node
            node = parent
            seen += 1
        return None

    def label(self, comp_node: int) -> str:
        parent = self.struct.get(comp_node, (0, 0, 0))[0]
        return f"{self.name(parent)} - {self.name(comp_node)}".strip(" -")

    def _classify_event(self, r: dict) -> tuple[str, str] | None:
        comp = r["parent_node_id"]
        if comp not in self._comp_cache:
            self._comp_cache[comp] = self._match_comp(comp)
        return self._comp_cache[comp]

    def _match_comp(self, comp: int) -> tuple[str, str] | None:
        sp = self.sport_of(comp)
        sport = self.cfg["sports"].get(_fold(self.name(sp))) if sp is not None else None
        if not sport:
            return None
        name = self.catalog.match(self.cfg["bookmaker"], sport, self.label(comp))
        return (sport, name) if name else None

    def forget_rejections(self):
        self._comp_cache.clear()


# ──────────────────────────────────────────────────────────────────────────────
_LINE = re.compile(r"[-+]?\d+(?:[.,]\d+)?")
_NPLUS = re.compile(r"^(\d+)\s*(?:o\s*\+|o m[aá]s|\+)$", re.I)
_SKIP_TITLE = re.compile(r"mejorad|rango|margen|exact|par/impar|cabeza|recibidas|fuera del|asi[aá]tic|descanso o final|descanso/final|entre\s*\(|minuto|\bmin\b|1º goleador|1er? punto|primer|último|ultimo|"
                         r"bet ?builder|pbbb|minuto|intervalo|band|y goles|y ambos|y m[aá]s|y menos|mitad ?/ ?final| y |ganará por|"
                         r"no marcar|que marcar|anotará o|marcar[áa] o|dobles|pago anticipado|ambas mitades|ventaja|cuotas?|"
                         r"\bpuntos?\b.*\(set|juego \d|iguales|tie ?break|carrera|tras \d|después de|marcador|primero en llegar|llegar a", re.I)


def _parts(sel_text: str) -> tuple[str, str]:
    """'Empate||X|1|' -> ('Empate', 'X')  ·  '+de||O|-1|' -> ('+de', 'O')  ·  Marca: 'Más de|+|O|0|' -> ('Más de', 'O')."""
    parts = (sel_text or "").split("|")
    name = parts[0].strip()
    code = parts[2].strip() if len(parts) > 2 else ""
    return name, code


def _line(text: str | None) -> float | None:
    if not text:
        return None
    m = _LINE.search(text.replace(",", "."))
    return float(m.group(0)) if m else None


def event_selections(feed: Feed, eid: int) -> list[dict]:
    ev = feed.events[eid]
    sport = feed.ev_meta[eid][0]
    home, away = feed.D.get(ev["participant_home_dictionary_id"], ""), feed.D.get(ev["participant_away_dictionary_id"], "")
    if not home or not away:
        return []
    sels: list[dict] = []

    def subst(s: str) -> str:
        return s.replace("{0}", home).replace("{1}", away)

    for mid in list(feed.ev_markets.get(eid, ())):   # copia: el hilo live muta los sets mientras el 2º plano itera
        m = feed.markets.get(mid)
        if not m or not m["is_active"] or (not m["is_displayed"] and feed.cfg.get("require_displayed", True)):
            continue                                      # is_displayed=False: mercado aún no visible en la web (p.ej. props NBA horas antes)
        title = re.sub(r"\s+", " ", subst(feed.D.get(m["dictionary_id"], ""))).strip()
        if re.search(r"pr[oó]rroga excl", title, re.I):
            continue                                      # sin prórroga: no comparable con el resto de casas
        title = re.sub(r"\(?\b(pr[oó]rroga inc(l(uida)?)?\.?|incl?\.? ?pr[oó]rroga)\)?", " ", title, flags=re.I)
        mset = re.search(r"\(\s*Set (\d)\s*\)", title)       # tenis: "Juegos Totales en el Set (Más/Menos) (Set 2)"
        if mset:
            title = f"Set {mset.group(1)} - " + re.sub(r"\(\s*Set \d\s*\)|\b(en el|del) set\b|^\s*Set\s*-\s*|\bdel\s*$", " ", title, flags=re.I)
        title = re.sub(r"\s+", " ", title).strip(" -")
        if not title or _SKIP_TITLE.search(title):
            continue
        code, cat = feed.mtypes.get(m["market_type_id"], ("", ""))
        av = {k: feed.D.get(v, "") for k, v in feed.av.get(mid, {}).items()}
        rs = []
        for rid in list(feed.mk_results.get(mid, ())):
            r = feed.results.get(rid)
            if not r:
                continue
            dec = feed.oddmap.get(r["odd_map_id"], 0)
            if dec <= 1000:
                continue                                  # 0 = suspendida / sin precio
            name, c = _parts(feed.D.get(r["dictionary_id"], ""))
            c = {"P1": "1", "P2": "2"}.get(c, c)
            rs.append((subst(name), c, feed.D.get(r["handicap_dictionary_id"]) if r["handicap_dictionary_id"] else None, dec / 1000))
        if not rs:
            continue
        codes = {c for _, c, _, _ in rs}
        has_line = any(h for _, _, h, _ in rs)

        # 0) props de UN jugador (baloncesto): el nombre va en PLAYER_INFO del mercado ('Jayson Tatum||HOME|id|evento')
        if av.get("PLAYER_INFO"):
            player = av["PLAYER_INFO"].split("|")[0].strip()
            info = classify(title, sport, home, away, player=player) if player else None
            if not info or not info.player:
                continue
            for name, c, h, price in rs:
                if c == "O" or c == "U":
                    ln = _line(h)
                    if ln is not None:
                        sels.append({"market": info.market, "ot": info.ot, "selection": "Over" if c == "O" else "Under", "line": abs(ln), "player": player, "price": price})
                elif _NPLUS.match(name):
                    sels.append({"market": info.market, "ot": info.ot, "selection": "Over", "line": int(_NPLUS.match(name).group(1)) - 0.5, "player": player, "price": price})
            continue

        # 1) props de jugador: selecciones = nombres de jugadores; línea en MARKET_EXTRA_VALUE ('SH03|3 o +') o en el título
        if "SELECTION_PLAYER_INFO" in av or "MARKET_EXTRA_VALUE" in av:
            extra = av.get("MARKET_EXTRA_VALUE", "")
            mm = re.search(r"(\d+)\s*(?:o\s*\+|\+)", extra)
            line = float(mm.group(1)) - 0.5 if mm else implied_line(title)
            if line is None and re.search(r"goleador|anotar[áa]|marcar[áa]", title, re.I):
                line = 0.5
            if line is None:
                continue
            for name, c, h, price in rs:
                if not name or name in (home, away) or len(name) < 3:
                    continue
                info = classify(title, sport, home, away, player=name)
                if info and info.player:
                    sels.append({"market": info.market, "ot": info.ot, "selection": "Over", "line": line, "player": name, "price": price})
            continue

        # 2) más/menos (goles, córners, tarjetas, puntos, juegos; de equipo con {0}/{1} en el título)
        if codes & {"O", "U"} or all(re.match(r"^[+-]de$|^m[aá]s de$|^menos de$", n, re.I) for n, _, _, _ in rs):
            if cat not in ("OVER_UNDER", "UNKNOWN", "") or not has_line:
                continue
            if any(re.search(r"\by\b|/", n) for n, _, _, _ in rs):
                continue                                  # combinadas ("{0} y Más de")
            info = classify(title, sport, home, away, kind="total")
            if not info or info.player:
                continue
            for name, c, h, price in rs:
                sel = "Over" if c == "O" or name.lower().startswith(("+", "más", "mas")) else \
                      "Under" if c == "U" or name.lower().startswith(("-", "menos")) else None
                ln = _line(h)
                if sel and ln is not None:
                    sels.append({"market": info.market, "ot": info.ot, "selection": sel, "line": abs(ln), "price": price})
            continue

        # 3) "N o +" de equipo / partido (tiros, tiros a puerta…)
        if all(_NPLUS.match(n) for n, _, _, _ in rs):
            info = classify(title, sport, home, away, kind="total")
            if not info or info.player:
                continue
            for name, c, h, price in rs:
                sels.append({"market": info.market, "ot": info.ot, "selection": "Over", "line": int(_NPLUS.match(name).group(1)) - 0.5, "price": price})
            continue

        # 4) hándicap a 2 bandas
        if has_line and codes <= {"1", "2"} and len(rs) == 2:
            info = classify(title, sport, home, away, kind="handicap")
            if not info:
                continue
            for name, c, h, price in rs:
                ln = _line(h)
                if ln is not None:
                    sels.append({"market": info.market, "ot": info.ot, "selection": c, "line": ln, "price": price})
            continue
        if has_line:
            continue                                      # hándicap a 3 bandas y similares: no comparables

        # 5) sí/no (ambos marcan)
        if codes <= {"Y", "N"} and codes:
            info = classify(title, sport, home, away)
            names = {n.lower() for n, _, _, _ in rs}
            if (info and info.market.startswith("BTTS") and names <= {"sí", "si", "no"}
                    and not re.search(r"\d|ambas|mitades|más|mas|menos|empate|resultado| y ",
                                      re.sub(r"[12][ªº]?\s*(mitad|parte|tiempo)|descanso", "", title, flags=re.I), re.I)):
                for name, c, h, price in rs:
                    sels.append({"market": info.market, "ot": info.ot, "selection": "Yes" if c == "Y" else "No", "price": price})
            continue

        # 6) doble oportunidad ("1 o X", "1 o 2", "2 o X") y sin empate ("Empate No Cuenta")
        if re.search(r"doble oportunidad", title, re.I):
            info = classify(title, sport, home, away)
            if info and info.market.startswith("DC"):
                for name, c, h, price in rs:
                    n = {"1 o x": "1X", "x o 1": "1X", "1 o 2": "12", "2 o 1": "12", "2 o x": "X2", "x o 2": "X2"}.get(name.lower())
                    if not n and c in ("1X", "X1", "12", "21", "X2", "2X"):          # Marca: '{0}/Empate' con código 1X
                        n = {"X1": "1X", "21": "12", "2X": "X2"}.get(c, c)
                    if not n:                                                         # por nombres: 'Alavés/Empate'
                        parts = {p.strip().lower() for p in re.split(r"\s*/\s*| o ", name)}
                        key = {home.lower(): "1", away.lower(): "2", "empate": "X", "x": "X"}
                        got = "".join(sorted(key[p] for p in parts if p in key))
                        n = {"1X": "1X", "12": "12", "2X": "X2"}.get(got) if len(parts) == 2 else None
                    if n:
                        sels.append({"market": info.market, "ot": info.ot, "selection": n, "price": price})
            continue
        if re.search(r"empate no cuenta", title, re.I) and codes <= {"1", "2"} and len(rs) == 2:
            info = classify(re.sub(r"empate no cuenta", "Apuesta sin empate", title, flags=re.I), sport, home, away)
            if info and info.market.startswith("DNB"):
                for name, c, h, price in rs:
                    sels.append({"market": info.market, "ot": info.ot, "selection": c, "price": price})
            continue

        # 7) 1X2 / ganador / sin empate (las selecciones deben ser los equipos o "Empate")
        if codes <= {"1", "X", "2"} and codes >= {"1", "2"}:
            if any(n not in (home, away) and n.lower() not in ("empate", "x") for n, _, _, _ in rs):
                continue
            info = classify(title, sport, home, away)
            if not info or not (info.market.startswith("1X2") or info.market.startswith("DNB")):
                continue
            if info.market.startswith("1X2") and re.search(r"c[oó]rner|tarjeta|card", title, re.I):
                continue
            if info.market.startswith("1X2") and sport == "futbol" and "X" not in codes and not re.search(r"sin empate", title, re.I):
                continue                                  # 2 vías en fútbol sin ser DNB: no es 1X2
            if info.market.startswith("1X2") and sport != "futbol" and "X" in codes:
                continue                                  # baloncesto/tenis: el ganador comparable es el de 2 vías
            for name, c, h, price in rs:
                sels.append({"market": info.market, "ot": info.ot, "selection": c, "price": price})
    return sels


def _inplay(feed: Feed, eid: int) -> dict | None:
    raw = feed.inplay.get(eid)
    if not raw:
        return None
    try:
        d = json.loads(raw)
    except ValueError:
        return None
    return d if d.get("inPlay") else None


def event_row(feed: Feed, eid: int, cfg: dict) -> dict | None:
    ev = feed.events[eid]
    sport, comp = feed.ev_meta[eid]
    sels = event_selections(feed, eid)
    if not sels:
        return None
    dt = ev["start_date"].astimezone() if isinstance(ev["start_date"], datetime) else None
    row = {
        "event_id": str(eid), "home": feed.D.get(ev["participant_home_dictionary_id"]), "away": feed.D.get(ev["participant_away_dictionary_id"]),
        "competition": comp, "date": dt.strftime("%Y-%m-%d") if dt else None, "start_time": dt.strftime("%H:%M") if dt else None,
        "url": cfg["event_url"].format(sportSlug=cfg["sport_slugs"].get(sport, sport), eventId=eid), "selections": sels,
    }
    ip = _inplay(feed, eid)
    if ip:
        ts = ip.get("totalScores") or {}
        ti = ip.get("timeInformation") or {}
        secs = ti.get("time")
        if secs is not None and ip.get("isClockRunning") and ti.get("validAt"):
            secs += max(0, int(time.time()) - int(ti["validAt"]))
        row.update(score=f"{ts.get('home', '')}:{ts.get('away', '')}" if ts else None,
                   period=(ip.get("inplayDescription") or "").strip("_") or None,
                   timer=f"{int(secs) // 60}'" if secs is not None else None)
    return row


# ──────────────────────────────────────────────────────────────────────────────
class Collector:
    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.catalog = Competitions()
        self.feed = Feed(cfg, self.catalog)
        self.store = OddsStore(bookmaker=cfg["bookmaker"])
        self.cfg_path = Path(cfg.get("_cfg_path") or CFG_PATH)
        self._cfg_mtime = self.cfg_path.stat().st_mtime
        self._last_prematch = 0.0
        self._last_prune = 0.0
        self._once = False

    def _reload_if_changed(self):
        if self.catalog.reload():
            self.feed.forget_rejections()
        mt = self.cfg_path.stat().st_mtime
        if mt != self._cfg_mtime:
            self.cfg = load_cfg(self.cfg_path)
            self.feed.cfg = self.cfg
            self._cfg_mtime = mt
        if time.time() - self._last_prune > 3600:
            self.store.prune()
            self._last_prune = time.time()

    def cycle(self) -> str:
        n = self.feed.update()
        now = time.time()
        horizon = now + self.cfg.get("prematch_hours", 48) * 3600
        need = [eid for eid, ev in self.feed.events.items() if eid not in self.feed.detailed
                and now - 10 * 3600 < ev["start_date"].timestamp() < horizon]
        if need:
            t0 = time.time()
            got = self.feed.fetch_events(need[: self.cfg.get("max_detail_per_cycle", 60)])
            log.info("detalle de %d eventos (%d ok, %d pendientes) en %.1fs", min(len(need), self.cfg.get("max_detail_per_cycle", 60)),
                     got, max(0, len(need) - self.cfg.get("max_detail_per_cycle", 60)), time.time() - t0)
        full_prematch = now - self._last_prematch >= self.cfg.get("interval_prematch", 30) or n < 0 or bool(need)
        bg = self.__dict__.setdefault("_bg", __import__("pace").Background(f"{self.cfg['bookmaker']}-prematch"))
        if full_prematch and not self._once and not bg.busy():
            # el barrido pre-partido completo (cientos de eventos, decenas de miles de mercados) va en un hilo aparte:
            # el ciclo live solo guarda lo que cambió
            self._last_prematch = now
            bg.run(lambda: self._full_prematch(now, horizon))
            full_prematch = False
        live_rows: dict[str, list] = defaultdict(list)
        pre_rows: dict[str, list] = defaultdict(list)
        live_ids, pre_ids = set(), set()
        touched = self.feed.touched
        self.feed.touched = set()
        for eid, ev in list(self.feed.events.items()):
            sport = self.feed.ev_meta[eid][0]
            start = ev["start_date"].timestamp() if isinstance(ev["start_date"], datetime) else 0
            live = _inplay(self.feed, eid) is not None and start > now - 10 * 3600 and bool(self.feed.ev_markets.get(eid))
            if not live and (start > horizon or start < now - 4 * 3600):
                continue
            if not ev["is_displayed"]:
                continue
            (live_ids if live else pre_ids).add(str(eid))
            if not live and not full_prematch and eid not in touched:
                continue
            row = event_row(self.feed, eid, self.cfg)
            if row:
                (live_rows if live else pre_rows)[sport].append(row)
        changed = 0
        for sport, rows in live_rows.items():
            changed += self.store.save_rows(sport, "live", rows)
        for sport, rows in pre_rows.items():
            changed += self.store.save_rows(sport, "prematch", rows)
        self.store.sweep(live_ids, "live")
        if full_prematch:
            self.store.sweep(pre_ids, "prematch")
            self._last_prematch = now
        nl, npm = sum(len(v) for v in live_rows.values()), sum(len(v) for v in pre_rows.values())
        bk = self.cfg["bookmaker"]
        self.store.set_status(**{f"{bk}_last_ok": now, f"{bk}_live_events": nl})
        note = bg.note()
        return (f"deltas {n if n >= 0 else 'resync'} | live {nl} ev | prematch {npm}{'' if full_prematch else ' (cambios)'} ev / {changed} cambios"
                + (f" | {note}" if note else ""))

    def _full_prematch(self, now: float, horizon: float) -> str:
        t0 = time.time()
        pre_rows: dict[str, list] = defaultdict(list)
        pre_ids: set[str] = set()
        for eid, ev in list(self.feed.events.items()):
            meta = self.feed.ev_meta.get(eid)
            if not meta:
                continue
            start = ev["start_date"].timestamp() if isinstance(ev["start_date"], datetime) else 0
            live = _inplay(self.feed, eid) is not None and start > now - 10 * 3600 and bool(self.feed.ev_markets.get(eid))
            if live or start > horizon or start < now - 4 * 3600 or not ev["is_displayed"]:
                continue
            pre_ids.add(str(eid))
            row = event_row(self.feed, eid, self.cfg)
            if row:
                pre_rows[meta[0]].append(row)
        changed = 0
        for sport, rows in pre_rows.items():
            changed += self.store.save_rows(sport, "prematch", rows)
        self.store.sweep(pre_ids, "prematch")
        return f"prematch completo {sum(len(v) for v in pre_rows.values())} ev / {changed} cambios ({time.time() - t0:.0f}s, 2º plano)"

    def run(self, once: bool = False):
        bk = self.cfg["bookmaker"]
        self._once = once
        backoff = 2
        while True:
            t0 = time.time()
            try:
                self._reload_if_changed()
                msg = self.cycle()
                log.info("%s (%.1fs)", msg, time.time() - t0)
                backoff = 2
                if once:
                    return
            except Exception as e:
                log.warning("error de ciclo: %s — reintento en %ss", e, backoff, exc_info=log.isEnabledFor(logging.DEBUG))
                self.store.set_status(**{f"{bk}_last_error": f"{time.time():.0f} {e}"})
                if "decodificar" in str(e) or "404" in str(e):
                    self.feed.synced_at = 0.0             # fuerza resync al siguiente intento
                time.sleep(backoff)
                backoff = min(backoff * 2, 60)
                continue
            time.sleep(max(0.5, self.cfg.get("interval_live", 5) - (time.time() - t0)))


# ──────────────────────────────────────────────────────────────────────────────
class _AllCatalog:
    """Catálogo que acepta todo (para --list / --probe)."""
    def match(self, bk, sport, label):
        return label
    def reload(self):
        return False


def probe(cfg: dict):
    f = Feed(cfg, _AllCatalog())
    t0 = time.time()
    m = f.get_meta()
    print("getmeta:", m)
    f.bootstrap()
    print(f"foto completa: {f.bytes / 1e6:.1f} MB en {time.time() - t0:.1f}s · eventos {len(f.events)} · mercados {len(f.markets)} · selecciones {len(f.results)}")
    time.sleep(5)
    t0 = time.time()
    f.bytes = 0
    n = f.update()
    print(f"5 s después: {n} deltas, {f.bytes / 1e3:.0f} KB, {time.time() - t0:.1f}s, eventos tocados {len(f.touched)}")
    live = [e for e in f.events if _inplay(f, e)]
    print(f"en directo ahora: {len(live)} eventos (de los deportes configurados)")


def list_catalog(cfg: dict):
    f = Feed(cfg, _AllCatalog())
    f.bootstrap()
    cat = Competitions()
    now = time.time()
    seen: dict[tuple[str, str], int] = defaultdict(int)
    for eid, ev in f.events.items():
        sport = f.ev_meta[eid][0]
        if 0 < ev["start_date"].timestamp() < now + 7 * 86400:
            seen[(sport, f.label(ev["parent_node_id"]))] += 1
    cur = None
    for (sport, label), n in sorted(seen.items()):
        if sport != cur:
            print(f"\n=== {sport}")
            cur = sport
        ok = cat.match(cfg["bookmaker"], sport, label)
        print(f" {'✔' if ok else ' '} {label}   eventos={n}")


def dump(cfg: dict, event_id: int):
    f = Feed(cfg, _AllCatalog())
    f.bootstrap()
    if event_id not in f.events:
        print("evento no encontrado en el feed (¿deporte no configurado o ya terminado?)"); return
    f.fetch_events([event_id])
    ev = f.events[event_id]
    print(f"{f.D.get(ev['participant_home_dictionary_id'])} - {f.D.get(ev['participant_away_dictionary_id'])}  "
          f"[{f.label(ev['parent_node_id'])}]  {ev['start_date']}  live={_inplay(f, event_id) is not None}  mercados={len(f.ev_markets[event_id])}")
    print("\n-- DUMP v2 --")
    print(f"-- NodesInPlayDetail crudo:\n   {str(f.inplay.get(event_id))[:2500]}")
    print(f"-- Event crudo:\n   {dict(ev)}")
    print("\n-- mercados de la casa (título -> tipo, categoría, selecciones):")
    titles: dict[str, tuple] = {}
    shown_raw = 0
    for mid in f.ev_markets[event_id]:
        m = f.markets[mid]
        _t = f.D.get(m["dictionary_id"], "")
        if shown_raw < 4 and ((f.mtypes.get(m["market_type_id"]) or ("",))[0] in ("P1CT", "P2CT", "GHCS", "STOU")
                              or re.search(r"Apuesta sin empate|Handicap|Ganador del Partido", _t)):
            shown_raw += 1
            print(f"   [market crudo {mid}] {dict(m)}  av={ {k: f.D.get(v) for k, v in f.av.get(mid, {}).items()} }")
            for r in list(f.mk_results[mid])[:4]:
                if r in f.results:
                    print(f"      [result crudo] {dict(f.results[r])}  -> {f.D.get(f.results[r]['dictionary_id'])!r}")
    for mid in f.ev_markets[event_id]:
        m = f.markets[mid]
        rs = [(_parts(f.D.get(f.results[r]["dictionary_id"], ""))[0], f.D.get(f.results[r]["handicap_dictionary_id"]),
               f.oddmap.get(f.results[r]["odd_map_id"], 0) / 1000) for r in list(f.mk_results[mid])[:3] if r in f.results]
        titles.setdefault(("" if m["is_active"] else "[INACTIVO] ") + ("" if m["is_displayed"] else "[OCULTO] ") + f.D.get(m["dictionary_id"], ""), (f.mtypes.get(m["market_type_id"]), {k: f.D.get(v) for k, v in f.av.get(mid, {}).items() if k == "MARKET_EXTRA_VALUE"}, rs))
    for t, v in titles.items():
        print(f"   {t!r}: {v}")
    # props de jugador: título de la casa -> clave normalizada (para auditar mezclas tipo "asistencias" vs "puntos+asistencias")
    home, away = f.D.get(ev["participant_home_dictionary_id"], ""), f.D.get(ev["participant_away_dictionary_id"], "")
    seen_p: set = set()
    print("\n-- props de jugador (título | código | PLAYER_INFO -> clave):")
    for mid in f.ev_markets[event_id]:
        m = f.markets[mid]
        av = {k: f.D.get(v, "") for k, v in f.av.get(mid, {}).items()}
        pi = av.get("PLAYER_INFO", "")
        if not pi:
            continue
        title = re.sub(r"\s+", " ", f.D.get(m["dictionary_id"], "")).strip()
        code = f.mtypes.get(m["market_type_id"], ("", ""))[0]
        key = (title, code)
        if key in seen_p:
            continue
        seen_p.add(key)
        info = classify(title, f.ev_meta[event_id][0], home, away, player=pi.split("|")[0].strip())
        print(f"   {title!r} | {code} | {pi.split('|')[0]!r} -> {info.market if info else None}")
    sels = event_selections(f, event_id)
    print(f"\n-- {len(sels)} selecciones normalizadas:")
    from collections import Counter
    for k, v in Counter(s["market"] for s in sels).most_common():
        print(f"   {k:28} {v}")
    for s in sels[:40]:
        print("   ", s)
    # claves repetidas con precios distintos: de qué nodos de mercado (mid / tipo / atributos) salen
    from storage import make_code
    by_code: dict[str, list] = {}
    for mid in list(f.ev_markets[event_id]):
        m = f.markets.get(mid)
        if not m:
            continue
        for s in _selections_of(f, event_id, [mid]):
            by_code.setdefault(make_code(s["market"], s["selection"], s.get("line"), s.get("player")), []).append(
                (s["price"], mid, m["market_type_id"], f.mtypes.get(m["market_type_id"]), m["is_displayed"],
                 {k: f.D.get(v) for k, v in f.av.get(mid, {}).items()}, f.D.get(m["dictionary_id"])))
    dups = {k: v for k, v in by_code.items() if len({x[0] for x in v}) > 1}
    print(f"\n-- claves con cuotas distintas: {len(dups)}")
    for k, v in list(dups.items())[:15]:
        print("  ", k)
        for x in v:
            print("      ", x)


def _selections_of(feed: Feed, eid: int, mids: list[int]) -> list[dict]:
    """event_selections() restringido a unos nodos de mercado (diagnóstico)."""
    saved = feed.ev_markets[eid]
    feed.ev_markets[eid] = set(mids)
    try:
        return event_selections(feed, eid)
    finally:
        feed.ev_markets[eid] = saved


def find(cfg: dict, text: str, only: str | None = None):
    """--find <texto> [filtro]: busca eventos por nombre de equipo y lista título de mercado -> clave normalizada
    (+ líneas/cuotas de muestra). `filtro` = regex sobre el título, la clave o la línea (p. ej. "110|TOTAL_1H")."""
    f = Feed(cfg, _AllCatalog())
    f.bootstrap()
    rx = re.compile(text, re.I)
    ids = [eid for eid, ev in f.events.items()
           if rx.search(f"{f.D.get(ev['participant_home_dictionary_id'], '')} - {f.D.get(ev['participant_away_dictionary_id'], '')}")]
    if not ids:
        print("ningún evento coincide"); return
    f.fetch_events(ids)
    flt = re.compile(only, re.I) if only else None
    for eid in ids:
        ev = f.events[eid]
        home, away = f.D.get(ev["participant_home_dictionary_id"], ""), f.D.get(ev["participant_away_dictionary_id"], "")
        sport = f.ev_meta[eid][0] if eid in f.ev_meta else "?"
        print(f"\n=== {eid}  {home} - {away}  [{f.label(ev['parent_node_id'])}]  {ev['start_date']}  deporte={sport}")
        seen: set = set()
        for mid in f.ev_markets.get(eid, []):
            m = f.markets[mid]
            title = re.sub(r"\s+", " ", f.D.get(m["dictionary_id"], "")).strip().replace("{0}", home).replace("{1}", away)
            av = {k: f.D.get(v, "") for k, v in f.av.get(mid, {}).items()}
            rs = [(_parts(f.D.get(f.results[r]["dictionary_id"], ""))[0], f.D.get(f.results[r]["handicap_dictionary_id"]),
                   f.oddmap.get(f.results[r]["odd_map_id"], 0) / 1000) for r in list(f.mk_results[mid])[:4] if r in f.results]
            pi = (av.get("PLAYER_INFO") or "").split("|")[0].strip() or None
            has_line = any(h for _, h, _ in rs)
            info = classify(title, sport, home, away, kind="total" if has_line else None, player=pi) \
                or (classify(title, sport, home, away, kind="handicap", player=pi) if has_line else None)
            code = info.market if info else "-"
            line = f"{title!r} | {f.mtypes.get(m['market_type_id'], ('', ''))[0]} | {av.get('MARKET_EXTRA_VALUE', '')} -> {code}  {rs}"
            if (title, code, str(rs)) in seen or (flt and not flt.search(line)):
                continue
            seen.add((title, code, str(rs)))
            print("  ", line)


def main():
    logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"), format="%(asctime)s %(levelname)s %(name)s: %(message)s",
                        datefmt="%H:%M:%S")
    cfg = load_cfg()
    if "--probe" in sys.argv:
        probe(cfg)
    elif "--list" in sys.argv:
        list_catalog(cfg)
    elif "--dump" in sys.argv:
        dump(cfg, int(sys.argv[sys.argv.index("--dump") + 1]))
    elif "--find" in sys.argv:
        i = sys.argv.index("--find")
        rest = [a for a in sys.argv[i + 1:] if not a.startswith("--") and a != CFG_PATH.name and a != str(CFG_PATH)]
        find(cfg, rest[0], rest[1] if len(rest) > 1 else None)
    else:
        Collector(cfg).run(once="--once" in sys.argv)


if __name__ == "__main__":
    main()
