"""Betsson — cuotas en directo por *push* (websocket Diffusion de OBG), sin navegador.

La web de Betsson no refresca las cuotas por HTTP: abre `wss://www.betsson.es/diffusion` (Push Technology
Diffusion, protocolo binario v28) y se suscribe a temas tipo
  obg/sportsbook/transient/markets/<eventId>/<marketId>:<plantilla>/odd        -> cuotas de un mercado
  obg/sportsbook/transient/markets/<eventId>/<marketId>:<plantilla>/state      -> estado del mercado (10 abierto)
  obg/sportsbook/transient/markets/.../marketSelectionStates                   -> estado por selección (1 abierta)
  obg/sportsbook/transient/events/<eventId>/fixture/phase                      -> fase del partido
  obg/sportsbook/transient/events/<eventId>/scoreboards/statistics             -> marcador
Los valores llegan como CBOR (a veces comprimido con zlib) y SIEMPRE completos (PUBLISH_VALUES_ONLY), así
que no hay que aplicar deltas.  Tramas (primer byte):
  0x00 'W'  especificación de tema: id (varint) + ruta         0x84 / 0x04  valor (zlib+CBOR / CBOR) de un tema
  0x00 '*'  tema retirado                                        0x00 '7'     ping del servidor (se contesta 0x06 + resto)
  0x06      respuesta a una petición nuestra                     '#'          saludo de sesión
Suscripción: petición de servicio `obg/gossip/subscribe` con un JSON ["<regex de temas>"] (la web usa
`?obg/sportsbook/transient/markets/(?:f-a|f-b)/` para todos los mercados de varios partidos).

`betsson.py` combina esto con la API REST: la REST da la estructura (nombres de mercados/selecciones, líneas) y
el push da el precio y el estado al instante, por lo que las cuotas en odds.db tienen una antigüedad de ~0-2 s
en vez de los 10-24 s de pedirlo todo por HTTP.
"""
from __future__ import annotations

import asyncio
import fastjson as json
import logging
import random
import struct
import threading
import time
import zlib
from urllib.parse import quote

import websockets

log = logging.getLogger("betsson.push")

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
      "Chrome/131.0.0.0 Safari/537.36")
PREFIX = "obg/sportsbook/transient/"


# ── CBOR mínimo (solo decodificación; evita depender de cbor2) ──────────────────────────────────────────
def cbor_loads(b: bytes):
    pos = 0

    def _head():
        nonlocal pos
        ib = b[pos]
        pos += 1
        mt, ai = ib >> 5, ib & 0x1f
        if ai < 24:
            return mt, ai
        if ai == 24:
            v = b[pos]; pos += 1
        elif ai == 25:
            v = struct.unpack_from(">H", b, pos)[0]; pos += 2
        elif ai == 26:
            v = struct.unpack_from(">I", b, pos)[0]; pos += 4
        elif ai == 27:
            v = struct.unpack_from(">Q", b, pos)[0]; pos += 8
        elif ai == 31:
            v = None                                   # longitud indefinida
        else:
            raise ValueError("cbor: cabecera inválida")
        return mt, v

    def _item():
        nonlocal pos
        mt, v = _head()
        if mt == 0:
            return v
        if mt == 1:
            return -1 - v
        if mt in (2, 3):
            if v is None:                              # trozos hasta 0xff
                parts = []
                while b[pos] != 0xff:
                    parts.append(_item())
                pos += 1
                return (b"" if mt == 2 else "").join(parts)
            s = b[pos:pos + v]
            pos += v
            return s if mt == 2 else s.decode("utf-8", "replace")
        if mt == 4:
            if v is None:
                out = []
                while b[pos] != 0xff:
                    out.append(_item())
                pos += 1
                return out
            return [_item() for _ in range(v)]
        if mt == 5:
            out = {}
            if v is None:
                while b[pos] != 0xff:
                    k = _item(); out[k] = _item()
                pos += 1
                return out
            for _ in range(v):
                k = _item(); out[k] = _item()
            return out
        if mt == 6:                                    # etiqueta: se ignora
            return _item()
        if mt == 7:
            if v is None:
                raise ValueError("cbor: break inesperado")
            # en _head() los valores simples <24 vienen en v; 25/26/27 = float16/32/64 ya leídos como enteros
            ib = b[pos - 1]
            ai = ib & 0x1f
            if ai == 20: return False
            if ai == 21: return True
            if ai in (22, 23): return None
            if ai == 25:
                return struct.unpack(">e", b[pos - 2:pos])[0]
            if ai == 26:
                return struct.unpack(">f", b[pos - 4:pos])[0]
            if ai == 27:
                return struct.unpack(">d", b[pos - 8:pos])[0]
            return v
        raise ValueError("cbor: tipo desconocido")

    return _item()


def _varint(b: bytes, i: int) -> tuple[int, int]:
    n = s = 0
    while True:
        c = b[i]
        i += 1
        n |= (c & 0x7f) << s
        s += 7
        if not c & 0x80:
            return n, i


def _enc_varint(n: int) -> bytes:
    out = bytearray()
    while True:
        c = n & 0x7f
        n >>= 7
        if n:
            out.append(c | 0x80)
        else:
            out.append(c)
            return bytes(out)


def _cbor_text(s: str) -> bytes:
    raw = s.encode("utf-8")
    n = len(raw)
    if n < 24:
        return bytes([0x60 | n]) + raw
    if n < 256:
        return b"\x78" + bytes([n]) + raw
    if n < 65536:
        return b"\x79" + struct.pack(">H", n) + raw
    return b"\x7a" + struct.pack(">I", n) + raw


class BetssonPush:
    """Cliente Diffusion en un hilo propio.  Estado compartido (protegido por `lock`):
      odds[selId] = (precio float, ts)      mstate[marketId] = (código, ts)   sstate[selId] = (código, ts)
      markets_seen[eventId] = {marketId...} (mercados de los que ya hay cuota por push)
      phase[eventId] = código de fase       stats[eventId] = dict de scoreboards/statistics
    """

    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.origin = cfg.get("origin", "https://www.betsson.es")
        self.lock = threading.Lock()
        self.odds: dict[str, tuple[float, float]] = {}
        self.mstate: dict[str, tuple[int, float]] = {}
        self.sstate: dict[str, tuple[int, float]] = {}
        self.markets_seen: dict[str, set[str]] = {}
        self.phase: dict[str, int] = {}
        self.stats: dict[str, dict] = {}
        self.clock: dict[str, dict] = {}
        self.topics: dict[int, str] = {}
        self.last_msg = 0.0
        self.connected = False
        self.n_values = 0
        self._want: set[str] = set()         # eventIds deseados
        self._subscribed: set[str] = set()
        self._dirty = threading.Event()
        self._seq = 0
        self._loop: asyncio.AbstractEventLoop | None = None
        self._ws = None
        self._thread: threading.Thread | None = None
        self._stop = False

    # ── API pública (hilo del colector) ───────────────────────────────────────
    def start(self):
        if self._thread:
            return
        self._thread = threading.Thread(target=self._run_thread, daemon=True, name="betsson-push")
        self._thread.start()

    def set_events(self, event_ids: list[str] | set[str]):
        ids = set(event_ids)
        if ids != self._want:
            self._want = ids
            self._dirty.set()
            if self._loop and self._ws:
                self._loop.call_soon_threadsafe(self._kick)

    def healthy(self, max_age: float = 15.0) -> bool:
        return self.connected and (time.time() - self.last_msg) < max_age

    def event_fresh(self, eid: str) -> bool:
        return eid in self._subscribed and self.healthy()

    def drop_event(self, eid: str):
        with self.lock:
            for mid in self.markets_seen.pop(eid, set()):
                self.mstate.pop(mid, None)
            self.phase.pop(eid, None)
            self.stats.pop(eid, None)
            self.clock.pop(eid, None)

    # ── hilo asyncio ─────────────────────────────────────────────────────────
    def _run_thread(self):
        self._loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self._loop)
        try:
            self._loop.run_until_complete(self._main())
        finally:
            self._loop.close()

    def _kick(self):
        ev = self.__dict__.get("_akick")
        if ev:
            ev.set()

    def _url(self) -> str:
        sp = {"--isReconnection-0--": "", "--channel-1--": "", "--os-Windows--": "", "$Environment": "BROWSER_Chrome_131.0.0.0"}
        return f"{self.origin.replace('https://', 'wss://')}/diffusion?ty=WB&v=28&ca=10&r=60000&sp={quote(json.dumps(sp, separators=(',', ':')))}"

    async def _main(self):
        backoff = 2.0
        while not self._stop:
            try:
                await self._session()
                backoff = 2.0
            except Exception as e:  # noqa: BLE001
                log.warning("push desconectado: %s — reconexión en %.0fs", e, backoff)
                self.connected = False
                self._subscribed = set()
                await asyncio.sleep(backoff + random.uniform(0, 1))
                backoff = min(backoff * 2, 60)

    async def _session(self):
        hdrs = {"User-Agent": UA, "Accept-Language": "es-ES,es;q=0.9", "Pragma": "no-cache", "Cache-Control": "no-cache"}
        try:
            ws = await websockets.connect(self._url(), origin=self.origin, max_size=20_000_000, additional_headers=hdrs,
                                          ping_interval=None, open_timeout=20)
        except TypeError:                                   # websockets < 14
            ws = await websockets.connect(self._url(), origin=self.origin, max_size=20_000_000, extra_headers=hdrs,
                                          ping_interval=None, open_timeout=20)
        self._ws = ws
        self._akick = asyncio.Event()
        hello = await asyncio.wait_for(ws.recv(), 20)
        if not isinstance(hello, bytes) or not hello.startswith(b"#"):
            raise RuntimeError(f"saludo inesperado: {hello[:40]!r}")
        self.connected = True
        self.last_msg = time.time()
        self.topics = {}
        self._subscribed = set()
        self._seq = 0
        log.info("push conectado (%s)", self._url().split("?")[0])
        self._dirty.set()
        sub_task = asyncio.create_task(self._sub_loop(ws))
        wd_task = asyncio.create_task(self._watchdog(ws))
        try:
            async for msg in ws:
                self.last_msg = time.time()
                if isinstance(msg, bytes):
                    try:
                        self._on_frame(ws, msg)
                    except Exception as e:  # noqa: BLE001
                        log.debug("trama no procesada (%s): %r", e, msg[:40])
        finally:
            sub_task.cancel()
            wd_task.cancel()
            self.connected = False
            self._ws = None

    async def _watchdog(self, ws):
        """Sin ninguna trama (ni ping del servidor) en `push_idle_timeout` s -> cerrar para reconectar."""
        idle = float(self.cfg.get("push_idle_timeout", 120))
        while True:
            await asyncio.sleep(10)
            if time.time() - self.last_msg > idle:
                log.warning("push sin tráfico %.0fs: reconectando", idle)
                await ws.close()
                return

    async def _sub_loop(self, ws):
        """Aplica cambios de la lista de eventos deseados (suscribir nuevos / anular retirados)."""
        while True:
            if not self._dirty.is_set():
                self._akick.clear()
                try:
                    await asyncio.wait_for(self._akick.wait(), 5)
                except asyncio.TimeoutError:
                    pass
            if not self._dirty.is_set():
                continue
            self._dirty.clear()
            want = set(self._want)
            add = sorted(want - self._subscribed)
            rem = sorted(self._subscribed - want)
            per = int(self.cfg.get("push_events_per_request", 20))
            for i in range(0, len(rem), per):
                await self._request(ws, "obg/gossip/unsubscribe", self._selector(rem[i:i + per]))
                for eid in rem[i:i + per]:
                    self.drop_event(eid)
            for i in range(0, len(add), per):
                await self._request(ws, "obg/gossip/subscribe", self._selector(add[i:i + per]))
                await asyncio.sleep(0.2)
            self._subscribed = want
            if add or rem:
                log.info("push: %d partidos suscritos (+%d / -%d)", len(want), len(add), len(rem))

    @staticmethod
    def _selector(eids: list[str]) -> str:
        alt = "|".join(eids)
        return f"?{PREFIX}(?:markets|events)/(?:{alt})/"

    async def _request(self, ws, path: str, selector: str):
        self._seq += 1
        body = _cbor_text(json.dumps([selector]))
        frame = (b"\x00U" + _enc_varint(self._seq) + _enc_varint(len(path)) + path.encode()
                 + _enc_varint(6) + b"string" + _enc_varint(len(body)) + body)
        await ws.send(frame)

    # ── tramas ───────────────────────────────────────────────────────────────
    def _on_frame(self, ws, b: bytes):
        t = b[0]
        if t in (0x84, 0x04):
            tid = struct.unpack(">I", b[1:5])[0]
            path = self.topics.get(tid)
            if not path:
                return
            raw = b[5:]
            if t == 0x84:
                raw = zlib.decompress(raw)
            self._on_value(path, cbor_loads(raw))
        elif t == 0x00 and len(b) > 1:
            k = b[1]
            if k == 0x57:                                              # 'W' especificación de tema
                tid, i = _varint(b, 3)
                ln, i = _varint(b, i)
                self.topics[tid] = b[i:i + ln].decode("utf-8", "replace")
            elif k == 0x2a:                                            # '*' tema retirado
                tid, _ = _varint(b, 3)
                path = self.topics.pop(tid, None)
                if path and path.endswith("/odd"):
                    self._drop_market(path)
            elif k == 0x37:                                            # '7' ping -> pong
                if self._loop:
                    asyncio.ensure_future(ws.send(b"\x06" + b[2:]))
        # 0x06: respuesta a nuestras peticiones; '#': saludo.  Nada que hacer.

    def _drop_market(self, path: str):
        parts = path[len(PREFIX):].split("/")
        if len(parts) < 3:
            return
        eid, mid = parts[1], parts[2].split(":")[0]
        with self.lock:
            self.markets_seen.get(eid, set()).discard(mid)
            self.mstate.pop(mid, None)

    def _on_value(self, path: str, v):
        if not isinstance(v, dict) or not path.startswith(PREFIX):
            return
        parts = path[len(PREFIX):].split("/")
        d = v.get("d") or {}
        now = time.time()
        if parts[0] == "markets" and len(parts) >= 4:
            eid, mid, leaf = parts[1], parts[2].split(":")[0], parts[-1]
            if leaf == "odd":
                odds = d.get("odds") or {}
                with self.lock:
                    for sid, o in odds.items():
                        of = (o or {}).get("of") or {}
                        p = of.get("1") or next(iter(of.values()), None)
                        try:
                            self.odds[sid] = (float(p), now)
                        except (TypeError, ValueError):
                            continue
                    self.markets_seen.setdefault(eid, set()).add(mid)
                    self.n_values += 1
            elif leaf == "state":
                s = d.get("s")
                if isinstance(s, int):
                    with self.lock:
                        self.mstate[mid] = (s, now)
            elif leaf == "marketSelectionStates":
                ss = d.get("ss") or {}
                with self.lock:
                    for sid, s in ss.items():
                        if isinstance(s, int):
                            self.sstate[sid] = (s, now)
        elif parts[0] == "events" and len(parts) >= 4:
            eid, leaf = parts[1], parts[-1]
            if leaf == "phase":
                p = d.get("p")
                if isinstance(p, int):
                    self.phase[eid] = p
            elif leaf == "statistics":
                self.stats[eid] = d
            elif leaf == "match-clock":
                self.clock[eid] = d.get("cl") or {}


# ── prueba manual: python betsson_push.py f-xxxx f-yyyy ─────────────────────────────────────────────
if __name__ == "__main__":
    import sys
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    ids = [a for a in sys.argv[1:] if a.startswith("f-")]
    if not ids:
        print("uso: python betsson_push.py f-<eventId> [f-<eventId> ...]   (ids de la API REST / betsson.py --list)")
        sys.exit(1)
    p = BetssonPush({"origin": "https://www.betsson.es"})
    p.start()
    p.set_events(ids)
    t0 = time.time()
    while time.time() - t0 < 40:
        time.sleep(5)
        with p.lock:
            print(f"conectado={p.connected} temas={len(p.topics)} valores={p.n_values} cuotas={len(p.odds)} "
                  f"mercados={sum(len(s) for s in p.markets_seen.values())} estados={len(p.mstate)} fases={p.phase}")
            for sid, (pr, ts) in list(p.odds.items())[:5]:
                print("   ", sid, pr)
