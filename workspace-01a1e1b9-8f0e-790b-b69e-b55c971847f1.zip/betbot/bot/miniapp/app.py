"""
Mini App de Telegram para configurar los filtros del usuario.

Sustituye (opcionalmente) los botones inline del panel por una interfaz web
que se abre dentro de Telegram.

Puntos clave de seguridad:
  · Todo endpoint de datos exige `X-Telegram-Init-Data` con el initData firmado.
  · El initData se valida con HMAC-SHA256 contra el token del bot.
  · NUNCA se confía en `initDataUnsafe` (es manipulable desde el navegador).
  · Se rechaza cualquier initData con más de `MINIAPP_INITDATA_MAX_AGE` segundos.

Arranque:
    python -m miniapp.app          # desde /app (importa domain/, data/, config.py)
"""
from __future__ import annotations

import asyncio
from datetime import datetime, timedelta
import hashlib
import hmac
import json
import logging
from pathlib import Path
import sqlite3
import threading
import time
from functools import wraps
from typing import Any, Dict, List, Optional
from urllib.parse import parse_qsl

from flask import Flask, g, jsonify, request, send_from_directory

from config import CONFIG
from data.repository import (
    Database, StatsRepository, UserRepository, FreebetRepository, AdminRepository,
)
from services.admins import AdminService
from domain.bookmakers import CATALOG as BOOKMAKERS, REGIONS
from domain.sports import CATALOG as SPORTS
from miniapp.strings import strings_for

log = logging.getLogger("miniapp")

app = Flask(__name__, static_folder="static", static_url_path="")

# Repositorios — misma BD que el bot (volumen compartido ./data)
_db = Database(CONFIG.db_path)
users = UserRepository(_db)
stats = StatsRepository(_db)
freebets = FreebetRepository(_db)
_admin_repo = AdminRepository(_db)
admins = AdminService(_admin_repo)


# ══════════════════════════════════════════════════════════
#  VALIDACIÓN DEL initData  (la parte crítica)
# ══════════════════════════════════════════════════════════

def validate_init_data(init_data: str, bot_token: str,
                       max_age: int = 3600) -> Optional[dict]:
    """
    Verifica la firma de Telegram y devuelve el usuario autenticado, o None.

    Algoritmo oficial:
        secret_key = HMAC_SHA256(key="WebAppData", msg=bot_token)
        data_check_string = sort(initData sin "hash") unido por "\\n"  → "k=v"
        hash = HMAC_SHA256(key=secret_key, msg=data_check_string).hexdigest()
    """
    if not init_data or not bot_token:
        return None

    try:
        pairs = dict(parse_qsl(init_data, keep_blank_values=True, strict_parsing=False))
    except Exception:
        return None

    received_hash = pairs.pop("hash", None)
    if not received_hash:
        return None

    data_check_string = "\n".join(
        f"{k}={v}" for k, v in sorted(pairs.items())
    )

    secret_key = hmac.new(
        key=b"WebAppData", msg=bot_token.encode("utf-8"), digestmod=hashlib.sha256
    ).digest()
    computed_hash = hmac.new(
        key=secret_key, msg=data_check_string.encode("utf-8"), digestmod=hashlib.sha256
    ).hexdigest()

    if not hmac.compare_digest(computed_hash, received_hash):
        log.warning("initData con firma inválida")
        return None

    # Frescura: evita replay de un initData capturado
    try:
        auth_date = int(pairs.get("auth_date", 0))
    except (TypeError, ValueError):
        return None
    if auth_date <= 0 or (time.time() - auth_date) > max_age:
        log.warning("initData caducado (auth_date=%s)", auth_date)
        return None

    raw_user = pairs.get("user")
    if not raw_user:
        return None
    try:
        user = json.loads(raw_user)
    except Exception:
        return None
    if not isinstance(user, dict) or not user.get("id"):
        return None

    return user


def require_telegram(fn):
    """Decorador: exige initData válido. Deja el usuario en `g.tg_user`."""

    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not CONFIG.bot_token:
            return jsonify({"error": "BOT_TOKEN no configurado"}), 500

        init_data = (
            request.headers.get("X-Telegram-Init-Data")
            or request.headers.get("Authorization", "").removeprefix("tma ").strip()
            or ""
        )
        tg_user = validate_init_data(
            init_data, CONFIG.bot_token, CONFIG.miniapp_initdata_max_age
        )
        if not tg_user:
            return jsonify({"error": "initData inválido o caducado"}), 401

        g.tg_user = tg_user
        g.user_id = int(tg_user["id"])
        return fn(*args, **kwargs)

    return wrapper


def require_admin(fn):
    """Solo los IDs de ADMIN_ID / ADMIN_IDS. Debe ir DEBAJO de require_telegram."""

    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not admins.is_admin(g.user_id):
            log.warning("Acceso admin denegado a %s", g.user_id)
            return jsonify({"error": "no_autorizado"}), 403
        return fn(*args, **kwargs)

    return wrapper


# ── Estado de los colectores (lo escriben en odds.db → tabla scraper_status) ──
def _collectors_status() -> list:
    """Estado de cada colector (misma lógica que el aviso del bot: services/collector_health.py)."""
    from services import collector_health
    try:
        con = sqlite3.connect(f"file:{CONFIG.odds_db_path}?mode=ro", uri=True, timeout=2)
        st = {}
        for k, v in con.execute("SELECT key, value FROM scraper_status").fetchall():
            try:
                st[k] = json.loads(v)
            except Exception:
                st[k] = v
        con.close()
    except Exception:
        return []
    out = collector_health.evaluate(st)
    for c in out:
        c["cause_text"] = collector_health.CAUSE_TEXT.get(c["cause"], "") if c["state"] != "ok" else ""
    return out


# ── Broadcast en segundo plano ───────────────────────────
_BC = {"running": False, "sent": 0, "failed": 0, "total": 0, "error": None}


def _do_broadcast(message: str, targets):
    async def run():
        from telegram import Bot
        bot = Bot(token=CONFIG.bot_token)
        for u in targets:
            try:
                await bot.send_message(u.telegram_id, message)
                _BC["sent"] += 1
            except Exception as e:                          # noqa: BLE001
                log.warning("Broadcast → %s falló: %s", u.telegram_id, e)
                _BC["failed"] += 1
            await asyncio.sleep(0.05)      # ~20 msg/s, por debajo del límite

    try:
        asyncio.run(run())
    except Exception as e:                                  # noqa: BLE001
        _BC["error"] = str(e)
    finally:
        _BC["running"] = False


# ══════════════════════════════════════════════════════════
#  SANEADO DE LA ENTRADA
# ══════════════════════════════════════════════════════════

_VALID_BK = {b.key for b in BOOKMAKERS.all()}
_VALID_SPORT = {s.key for s in SPORTS.all()}


def _clean_str_list(value: Any, valid: set) -> List[str]:
    if not isinstance(value, list):
        return []
    out = []
    for v in value:
        if isinstance(v, str):
            k = v.strip().lower()
            if k in valid and k not in out:
                out.append(k)
    return out


def _clean_float(value: Any, lo: float, hi: float, default: float = 0.0) -> float:
    try:
        v = float(value)
    except (TypeError, ValueError):
        return default
    return max(lo, min(hi, round(v, 2)))


def _clean_int(value: Any, lo: int, hi: int, default: int = 0) -> int:
    try:
        v = int(value)
    except (TypeError, ValueError):
        return default
    return max(lo, min(hi, v))


def _clean_bool(value: Any, default: bool = True) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(value)
    if isinstance(value, str):
        return value.strip().lower() in ("1", "true", "on", "yes", "si", "sí")
    return default


def _clean_payload(data: Dict[str, Any]) -> Dict[str, Any]:
    """Filtra y acota todo lo que llega del navegador."""
    return {
        "surebets_enabled":   _clean_bool(data.get("surebets_enabled"), True),
        "middlebets_marked":  _clean_bool(data.get("middlebets_marked"), True),
        "live_enabled":       _clean_bool(data.get("live_enabled"), True),
        "prematch_enabled":   _clean_bool(data.get("prematch_enabled"), True),
        "surebet_min_profit": _clean_float(data.get("surebet_min_profit"), 0.0, 50.0),
        "surebet_bookmakers":  _clean_str_list(data.get("surebet_bookmakers"), _VALID_BK),
        "sports":             _clean_str_list(data.get("sports"), _VALID_SPORT),
        "language":           "en" if str(data.get("language", "es")).lower() == "en" else "es",
        "hour_start":         _clean_int(data.get("hour_start"), 0, 23, 0),
        "hour_end":           _clean_int(data.get("hour_end"), 1, 24, 24),
        "mute_hours":         _clean_int(data.get("mute_hours"), 0, 720, 0),
    }


# ══════════════════════════════════════════════════════════
#  API
# ══════════════════════════════════════════════════════════

@app.get("/")
def index():
    resp = send_from_directory(app.static_folder, "index.html")
    resp.headers["Cache-Control"] = "no-store"        # Telegram cachea la web: que siempre cargue la versión actual
    return resp


@app.get("/healthz")
def healthz():
    # incluye las casas del catálogo para comprobar desde fuera qué versión del código está sirviendo
    return jsonify({"ok": True, "service": "miniapp", "bookmakers": [b.key for b in BOOKMAKERS.all()],
                    "code": str(Path(__file__).resolve().parent.parent)})


def _plans_payload(current_plan: str | None) -> list[dict]:
    """Planes disponibles, tal y como se muestran en el bot."""
    out = []
    for key, plan in CONFIG.plans.items():
        out.append({
            "key": key,
            "label": plan.get("label", key.capitalize()),
            "display": plan.get("display", ""),
            "days": plan.get("days", 0),
            "current": key == current_plan,
            "available": bool(CONFIG.stripe_secret_key and plan.get("price_id")),
        })
    return out


@app.get("/api/state")
@require_telegram
def api_state():
    """Filtros + catálogos + suscripción + planes + stats + textos i18n."""

    user = users.get_or_create(
        g.user_id,
        g.tg_user.get("username") or "",
        g.tg_user.get("first_name") or "",
    )

    # Mantener el perfil al día: get_or_create no actualiza a un usuario que
    # ya existe, así que quien entró por otra vía (p. ej. lo creó el poller de
    # Stripe) se quedaba sin nombre y sin usuario para siempre.
    _u = (g.tg_user.get("username") or "").strip()
    _n = (g.tg_user.get("first_name") or "").strip()
    _cambio = False
    if _u and _u != (user.username or ""):
        user.username = _u
        _cambio = True
    if _n and _n != (user.first_name or ""):
        user.first_name = _n
        _cambio = True
    if _cambio:
        users.save(user)

    f = user.filters
    s = user.subscription

    return jsonify({
        "me": {
            "id": user.telegram_id,
            "name": user.first_name or g.tg_user.get("first_name", ""),
            "username": user.username or "",
        },
        "subscription": {
            "active": s.is_active,
            "plan": s.plan.value if s.plan else None,
            "is_trial": s.is_trial,
            "days_left": s.days_left,
            "expires_at": s.expires_at.isoformat() if s.expires_at else None,
            "has_stripe": bool(s.stripe_customer_id),
            "trial_used": s.trial_used,
        },
        "plans": _plans_payload(s.plan.value if s.plan else None),
        "payments_enabled": bool(CONFIG.stripe_secret_key),
        "is_admin": admins.is_admin(user.telegram_id),
        "i18n": strings_for(f.language),
        "filters": {
            "surebets_enabled":   f.surebets_enabled,
            "middlebets_marked":  f.middlebets_marked,
            "live_enabled":       f.live_enabled,
            "prematch_enabled":   f.prematch_enabled,
            "surebet_min_profit": f.surebet_min_profit,
            "surebet_bookmakers": f.surebet_bookmakers,
            "sports":             f.sports,
            "language":           f.language,
            "hour_start":         f.hour_start,
            "hour_end":           f.hour_end,
            "muted":              user.is_muted_now(),
        },
        "catalog": {
            "regions": REGIONS,
            "bookmakers": [
                {
                    "key": b.key,
                    "name": b.name,
                    "region": b.region,
                    "region_label": b.region_label,
                }
                for b in sorted(BOOKMAKERS.all(), key=lambda x: (x.region, x.name))
            ],
            "sports": [
                {"key": s_.key, "name_es": s_.name_es,
                 "name_en": s_.name_en, "emoji": s_.emoji}
                for s_ in SPORTS.all()
            ],
        },
        "stats": stats.user_stats(g.user_id),
    })


@app.post("/api/filters")
@require_telegram
def api_save_filters():
    """Guarda los filtros del usuario autenticado."""

    payload = request.get_json(silent=True)
    if not isinstance(payload, dict):
        return jsonify({"error": "JSON inválido"}), 400

    clean = _clean_payload(payload)

    user = users.get_or_create(
        g.user_id,
        g.tg_user.get("username") or "",
        g.tg_user.get("first_name") or "",
    )
    f = user.filters

    f.surebets_enabled   = clean["surebets_enabled"]
    f.middlebets_marked  = clean["middlebets_marked"]
    f.live_enabled       = clean["live_enabled"]
    f.prematch_enabled   = clean["prematch_enabled"]
    f.surebet_min_profit = clean["surebet_min_profit"]
    f.surebet_bookmakers = clean["surebet_bookmakers"]
    f.sports             = clean["sports"]
    f.language           = clean["language"]
    f.hour_start         = clean["hour_start"]
    f.hour_end           = clean["hour_end"]

    if clean["mute_hours"] > 0:
        f.mute_until = datetime.now() + timedelta(hours=clean["mute_hours"])
    elif payload.get("clear_mute"):
        f.mute_until = None

    users.save(user)
    log.info("Filtros guardados para %s", g.user_id)
    return jsonify({"ok": True, "filters": clean})


@app.post("/api/checkout")
@require_telegram
def api_checkout():
    """Crea una sesión de pago de Stripe y devuelve la URL para abrirla."""
    if not CONFIG.stripe_secret_key:
        return jsonify({"error": "payments_disabled"}), 503

    payload = request.get_json(silent=True) or {}
    plan_key = str(payload.get("plan", "")).strip().lower()
    if plan_key not in CONFIG.plans:
        return jsonify({"error": "plan_invalido"}), 400

    # Si ya tenía suscripción en Stripe, la cancelamos al final del periodo:
    # así no se le cobra dos veces y sus días se acumulan al pagar el nuevo plan
    prev_id = ""
    user = users.find(g.user_id)
    if user and user.subscription.stripe_subscription_id:
        prev_id = user.subscription.stripe_subscription_id

    try:
        from services.stripe_gateway import StripeGateway
        url = StripeGateway().create_checkout_url(
            g.user_id,
            g.tg_user.get("username") or g.tg_user.get("first_name") or "",
            plan_key,
            previous_subscription_id=prev_id,
        )
        return jsonify({"ok": True, "url": url, "cancelled_previous": bool(prev_id)})
    except Exception as e:                                  # noqa: BLE001
        log.error("Stripe checkout falló para %s: %s", g.user_id, e)
        return jsonify({"error": "stripe_error"}), 502


@app.post("/api/portal")
@require_telegram
def api_portal():
    """Abre el portal de cliente de Stripe (cancelar, cambiar plan, facturas)."""
    if not CONFIG.stripe_secret_key:
        return jsonify({"error": "payments_disabled"}), 503

    user = users.find(g.user_id)
    if not user or not user.subscription.stripe_customer_id:
        return jsonify({"error": "no_customer"}), 404

    try:
        from services.stripe_gateway import StripeGateway
        url = StripeGateway().create_portal_url(user.subscription.stripe_customer_id)
        return jsonify({"ok": True, "url": url})
    except Exception as e:                                  # noqa: BLE001
        log.error("Portal Stripe falló para %s: %s", g.user_id, e)
        return jsonify({"error": "stripe_error"}), 502


@app.get("/api/freebets")
@require_telegram
def api_freebets():
    """
    Promociones activas publicadas por el administrador.
    Se marcan las que coinciden con las casas que el usuario tiene
    seleccionadas, y esas se muestran primero.
    """
    user = users.find(g.user_id)
    elegidas = set()
    if user:
        elegidas = set(user.filters.surebet_bookmakers)

    items = []
    for fb in freebets.list_active():
        bk = BOOKMAKERS.get(fb["bookmaker"]) or None
        items.append({
            "id": fb["id"],
            "bookmaker": fb["bookmaker"],
            "bookmaker_name": bk.name if bk else fb["bookmaker"],
            "title": fb["title"],
            "description": fb["description"] or "",
            "value_eur": fb["value_eur"] or 0,
            "url": fb["url"] or "",
            "kind": fb["kind"] or "freebet",
            "expires_at": fb["expires_at"] or "",
            # Sin filtro de casas ⇒ todo se considera relevante
            "yours": (not elegidas) or (fb["bookmaker"] in elegidas),
        })

    # Primero las de tus casas; dentro de cada grupo, las más nuevas antes
    items.sort(key=lambda x: (not x["yours"], -x["id"]))
    return jsonify({"items": items, "total": len(items)})


# ══════════════════════════════════════════════════════════
#  API DE ADMINISTRACIÓN
# ══════════════════════════════════════════════════════════

@app.get("/api/admin")
@require_telegram
@require_admin
def api_admin():
    """Todo lo que necesita la pestaña de administración."""
    a = stats.admin_stats()
    precios = {"weekly": 15, "monthly": 60, "quarterly": 150, "yearly": 480}
    multipliers = {"weekly": 4, "monthly": 1, "quarterly": 1 / 3, "yearly": 1 / 12}
    revenue = sum(cnt * precios.get(plan, 0) * multipliers.get(plan, 1)
                  for plan, cnt in a.get("by_plan", {}).items())

    return jsonify({
        "stats": a,
        "revenue_estimate": round(revenue, 2),
        "trial_days": CONFIG.free_trial_days,
        "collectors": _collectors_status(),
        "users": [
            {
                "id": u.telegram_id,
                "username": u.username or "",
                "name": u.first_name or "",
                "active": u.subscription.is_active,
                "plan": u.subscription.plan.value if u.subscription.plan else None,
                "expires_at": (u.subscription.expires_at.isoformat()
                               if u.subscription.expires_at else None),
                "days_left": u.subscription.days_left,
            }
            for u in users.all()
        ],
        "freebets": freebets.list_all(),
        "admins": admins.list_all(),
        "owners": admins.owners(),
        "plans": [{"key": p["key"], "label": p["label"], "days": p["days"]}
                  for p in _plans_payload(None)],
        "broadcast": _BC,
    })


@app.post("/api/admin/broadcast")
@require_telegram
@require_admin
def api_admin_broadcast():
    payload = request.get_json(silent=True) or {}
    msg = str(payload.get("message", "")).strip()
    if not msg:
        return jsonify({"error": "mensaje_vacio"}), 400
    if _BC["running"]:
        return jsonify({"error": "ya_enviando"}), 409

    targets = [u for u in users.all() if u.has_access]
    _BC.update(running=True, sent=0, failed=0,
               total=len(targets), error=None)
    threading.Thread(target=_do_broadcast, args=(msg, targets), daemon=True).start()
    return jsonify({"ok": True, "recipients": len(targets)})


@app.get("/api/admin/broadcast/status")
@require_telegram
@require_admin
def api_admin_broadcast_status():
    return jsonify(_BC)


@app.post("/api/admin/freebet")
@require_telegram
@require_admin
def api_admin_freebet_add():
    payload = request.get_json(silent=True) or {}
    casa = str(payload.get("bookmaker", "")).strip().lower()
    titulo = str(payload.get("title", "")).strip()
    if not casa or not titulo:
        return jsonify({"error": "faltan_datos"}), 400

    bk = BOOKMAKERS.get(casa)
    if bk:
        casa = bk.key

    try:
        valor = float(str(payload.get("value_eur", 0)).replace(",", "."))
    except (TypeError, ValueError):
        valor = 0.0

    fb_id = freebets.add(
        bookmaker=casa, title=titulo, value_eur=valor,
        url=str(payload.get("url", "")).strip(),
        description=str(payload.get("description", "")).strip(),
        kind=str(payload.get("kind", "freebet")).strip() or "freebet",
        expires_at=str(payload.get("expires_at", "")).strip(),
    )
    return jsonify({"ok": True, "id": fb_id})


@app.post("/api/admin/freebet/delete")
@require_telegram
@require_admin
def api_admin_freebet_del():
    payload = request.get_json(silent=True) or {}
    try:
        fb_id = int(payload.get("id"))
    except (TypeError, ValueError):
        return jsonify({"error": "id_invalido"}), 400
    ok = freebets.deactivate(fb_id)
    return jsonify({"ok": ok})


@app.post("/api/admin/user")
@require_telegram
@require_admin
def api_admin_user():
    """Activar (con plan) o desactivar un usuario a mano."""
    from services.subscription import SubscriptionService

    payload = request.get_json(silent=True) or {}
    action = str(payload.get("action", "")).strip()
    try:
        uid = int(payload.get("user_id"))
    except (TypeError, ValueError):
        return jsonify({"error": "id_invalido"}), 400

    target = users.get_or_create(uid, "", "")
    svc = SubscriptionService(users)

    if action == "grant":
        """
        REGALAR un plan (o cambio de plan): SUMA los días del plan.
        Es la única acción que añade tiempo, y queda registrada.
        """
        plan_key = str(payload.get("plan", "monthly")).strip()
        if plan_key not in CONFIG.plans:
            return jsonify({"error": "plan_invalido"}), 400
        days = svc.grant_plan(target, plan_key,
                              detail=f"admin {g.user_id} → {plan_key}")
        return jsonify({"ok": True, "action": "grant", "plan": plan_key,
                        "days_left": days})

    if action == "set_days":
        """
        FIJAR días exactos. days=0 → quitar TODO el acceso.

        Con days=0 también cancelamos la suscripción en Stripe: si no, el
        poller vería que Stripe la sigue dando por activa y reactivaría al
        usuario en la siguiente vuelta, deshaciendo lo que ha hecho el admin.
        """
        try:
            days = int(payload.get("days", 0))
        except (TypeError, ValueError):
            return jsonify({"error": "dias_invalidos"}), 400
        if days < 0 or days > 36500:          # tope de 100 años
            return jsonify({"error": "dias_invalidos"}), 400

        canceladas = []
        if days == 0:
            # Cancelamos TODAS sus suscripciones, no sólo la guardada: si
            # tuviera duplicados, la otra seguiría viva y el poller lo
            # resucitaría en la siguiente vuelta.
            if CONFIG.stripe_secret_key:
                try:
                    from services.stripe_gateway import StripeGateway
                    canceladas = StripeGateway().cancel_all_for_user(
                        uid, target.subscription.stripe_customer_id or "")
                    if canceladas:
                        log.info("🛑 Admin %s canceló %d suscripción(es) de %s: %s",
                                 g.user_id, len(canceladas), uid, ", ".join(canceladas))
                except Exception as e:                      # noqa: BLE001
                    log.error("No pude cancelar las suscripciones de %s: %s", uid, e)
            # La olvidamos (UPDATE explícito: save() usa COALESCE y no
            # borraría el dato antiguo).
            users.clear_stripe_ids(uid)
            target.subscription.stripe_subscription_id = None
            target.subscription.stripe_customer_id = None

        left = svc.set_days(target, days, detail=f"admin {g.user_id} fijó {days}")
        return jsonify({"ok": True, "action": "set_days", "days_left": left,
                        "active": target.subscription.is_active,
                        "stripe_cancelled": len(canceladas)})

    if action == "revoke":
        """Quitar el acceso SIN tocar los días ni el plan (se pueden restaurar)."""
        svc.deactivate(target)
        return jsonify({"ok": True, "action": "revoke"})

    if action == "restore":
        """Volver a dar acceso SIN sumar días y SIN cambiar el plan."""
        if not svc.restore(target):
            return jsonify({"error": "sin_dias"}), 409
        return jsonify({"ok": True, "action": "restore",
                        "days_left": target.subscription.days_left})

    if action == "trial":
        # NUNCA pisamos una suscripción activa: el usuario perdería los
        # días que le quedan (pagados o de prueba) y no hay vuelta atrás.
        if target.subscription.is_active:
            log.warning("Trial denegado a %s: ya tiene suscripción activa", uid)
            return jsonify({
                "error": "ya_tiene_plan",
                "plan": (target.subscription.plan.value
                         if target.subscription.plan else None),
            }), 409

        target.subscription.is_active = False
        target.subscription.trial_used = False
        users.save(target)
        ok = svc.start_free_trial(target)
        return jsonify({"ok": bool(ok), "action": "trial",
                        "days": CONFIG.free_trial_days})

    return jsonify({"error": "accion_invalida"}), 400


@app.get("/api/admin/admins")
@require_telegram
@require_admin
def api_admin_list_admins():
    """Dueños (.env) + admins de la BD."""
    return jsonify({"admins": admins.list_all(),
                    "owners": admins.owners(),
                    "me": g.user_id})


@app.post("/api/admin/admins")
@require_telegram
@require_admin
def api_admin_add_admin():
    """Añade un administrador nuevo por su id de Telegram."""
    payload = request.get_json(silent=True) or {}
    try:
        uid = int(payload.get("user_id"))
    except (TypeError, ValueError):
        return jsonify({"error": "id_invalido"}), 400
    if uid <= 0:
        return jsonify({"error": "id_invalido"}), 400

    nota = str(payload.get("note", "")).strip()[:80]
    # Creamos el usuario para que conste en la BD
    target = users.get_or_create(uid, "", "")
    admins.add(uid, nota, added_by=g.user_id)
    return jsonify({"ok": True, "user_id": uid,
                    "username": target.username or "",
                    "owner": uid in admins.owners()})


@app.post("/api/admin/admins/remove")
@require_telegram
@require_admin
def api_admin_remove_admin():
    """Quita un administrador de la BD (los dueños no se pueden quitar)."""
    payload = request.get_json(silent=True) or {}
    try:
        uid = int(payload.get("user_id"))
    except (TypeError, ValueError):
        return jsonify({"error": "id_invalido"}), 400
    if uid == g.user_id:
        return jsonify({"error": "no_a_ti_mismo"}), 400
    if not admins.remove(uid):
        return jsonify({"error": "es_dueno_o_no_existe"}), 409
    return jsonify({"ok": True, "user_id": uid})


@app.get("/api/admin/user/<int:uid>/events")
@require_telegram
@require_admin
def api_admin_user_events(uid: int):
    """Historial de cambios de suscripción de un usuario."""
    return jsonify({"user_id": uid, "events": users.sub_events(uid, 40)})


@app.post("/api/admin/events/clear")
@require_telegram
@require_admin
def api_admin_events_clear():
    """Vacía el historial de suscripciones de todos los usuarios."""
    n = users.clear_sub_events()
    log.info("🧹 Admin %s vació el historial de suscripciones (%d filas)",
             g.user_id, n)
    return jsonify({"ok": True, "deleted": n})


@app.get("/api/i18n/<lang>")
def api_i18n(lang: str):
    """Diccionario de textos de un idioma (público: no hay datos de usuario)."""
    return jsonify(strings_for(lang.lower()))


@app.post("/api/mute")
@require_telegram
def api_mute():
    """Silenciar X horas (0 = quitar silencio)."""

    payload = request.get_json(silent=True) or {}
    hours = _clean_int(payload.get("hours"), 0, 720, 0)

    user = users.get_or_create(g.user_id, "", "")
    user.filters.mute_until = (
        datetime.now() + timedelta(hours=hours) if hours > 0 else None
    )
    users.save(user)
    return jsonify({"ok": True, "muted": hours > 0, "hours": hours})


@app.get("/favicon.ico")
def favicon():
    return "", 204


@app.errorhandler(Exception)
def on_error(e):                                   # noqa: BLE001
    from werkzeug.exceptions import HTTPException
    if isinstance(e, HTTPException):               # 404/405…: no son errores internos, no ensuciar el log
        return jsonify({"error": e.name}), e.code
    log.exception("Error no controlado en la mini app: %s", e)
    return jsonify({"error": "Error interno"}), 500


def run():
    """Arranque en producción (lo usa docker-compose)."""
    _db.init_schema()
    app.run(
        host=CONFIG.miniapp_host,
        port=CONFIG.miniapp_port,
        threaded=True,
        debug=False,
    )


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO,
                        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
    run()
