"""
SubscriptionService: gestión de suscripciones (trial + Stripe).

Regla de oro de este módulo
---------------------------
Los días sólo cambian por TRES motivos, y los tres quedan registrados en la
tabla `sub_events` para poder auditarlos:

    1. grant_plan()   → un admin REGALA un plan (o el usuario cambia de plan)
    2. set_days()     → un admin FIJA unos días exactos (0 = quitar el acceso)
    3. sync_stripe()  → el poller copia lo que dice Stripe (idempotente)

Ninguna otra función toca `expires_at`. Si los días suben sin que nadie
haga nada, el historial lo dirá.
"""
from __future__ import annotations

import logging
from datetime import datetime, timedelta
from typing import Optional

from domain.models import User, SubscriptionPlan
from data.repository import UserRepository
from config import CONFIG

log = logging.getLogger(__name__)


class SubscriptionService:

    def __init__(self, users: UserRepository):
        self.users = users

    # ══════════════════════════════════════════════════════
    #  INTERNO: único punto que escribe la fecha
    # ══════════════════════════════════════════════════════
    def _set_expiry(self, user: User, new_expiry: Optional[datetime],
                    action: str, detail: str = "",
                    allow_over_cap: bool = False) -> bool:
        """
        Único punto que escribe la fecha. Devuelve True si se aplicó.

        Tope de seguridad: si el nuevo vencimiento supera
        CONFIG.max_subscription_days y no es una acción explícita de un
        admin, se BLOQUEA y se avisa por el log. Es el freno anti-inflado.
        """
        before = user.subscription.days_left
        now = datetime.now()

        if new_expiry is not None:
            days_new = (new_expiry - now).days
            growth = days_new - before
            cap = CONFIG.max_subscription_days
            # El plan más largo del catálogo: nadie debería crecer más que
            # esto de una sola vez.
            max_plan = max((p.get("days", 30) for p in CONFIG.plans.values()),
                           default=30)

            bloqueo = None
            # a) Crecimiento imposible en una sola operación
            if growth > max_plan + 60 and not allow_over_cap:
                bloqueo = (f"crecía {growth} días de golpe "
                           f"(el plan más largo son {max_plan})")
            # b) Una sincronización automática no debe pasar del tope
            elif days_new > cap and action == "sync":
                bloqueo = f"la sync dejaba {days_new} días (tope {cap})"

            if bloqueo:
                log.error(
                    "🛑 BLOQUEADO: usuario %s, acción '%s': %s → %s días. "
                    "Motivo: %s. No aplico el cambio. (detalle: %s)",
                    user.telegram_id, action, before, days_new, bloqueo, detail,
                )
                self.users.log_sub_event(
                    user.telegram_id, "BLOCKED_" + action, before, before,
                    f"{bloqueo} · {detail}")
                return False

        user.subscription.expires_at = new_expiry
        self.users.save(user)
        after = user.subscription.days_left
        self.users.log_sub_event(user.telegram_id, action, before, after, detail)
        if before != after:
            log.info("📅 %s: %s → %s días (%s)", user.telegram_id, before, after,
                     action)
        return True

    # ══════════════════════════════════════════════════════
    #  1. REGALAR / CAMBIAR DE PLAN  (suma días)
    # ══════════════════════════════════════════════════════
    def grant_plan(self, user: User, plan_key: str, days: Optional[int] = None,
                   detail: str = "") -> int:
        """
        Regala un plan. SUMA los días a los que ya tuviera, para que al
        cambiar de plan no se pierda el tiempo ya pagado.
        Devuelve los días totales que le quedan.
        """
        plan = SubscriptionPlan(plan_key)
        add = int(days if days is not None
                  else CONFIG.plans.get(plan_key, {}).get("days", 30))
        now = datetime.now()
        base = user.subscription.expires_at
        base = base if (base and base > now) else now

        user.subscription.is_active = True
        user.subscription.plan = plan
        self._set_expiry(user, base + timedelta(days=add), "grant",
                         detail or f"plan {plan_key} (+{add}d)",
                         allow_over_cap=True)
        return user.subscription.days_left

    # ══════════════════════════════════════════════════════
    #  2. FIJAR DÍAS EXACTOS  (0 = quitar todo)
    # ══════════════════════════════════════════════════════
    def set_days(self, user: User, days: int, detail: str = "") -> int:
        """
        Deja la suscripción en un número EXACTO de días.
        days=0 → sin días y sin acceso (útil para limpiar una suscripción
        que se haya inflado por error).
        """
        days = max(0, int(days))
        if days == 0:
            # Sin días: fuera acceso Y fuera plan. Si dejáramos el plan
            # puesto, la fila del admin seguiría mostrando "yearly" y
            # parecería que se le ha activado uno.
            user.subscription.is_active = False
            user.subscription.plan = None
            self._set_expiry(user, datetime.now(), "clear", detail or "días a 0")
            return 0
        user.subscription.is_active = True
        # Si el usuario no tenía plan (lo habíamos limpiado), le ponemos el
        # que más se parezca a los días que le damos, para que la fila del
        # admin no muestre "—".
        if user.subscription.plan is None:
            user.subscription.plan = SubscriptionPlan(self._plan_for_days(days))
        self._set_expiry(user, datetime.now() + timedelta(days=days), "set_days",
                         detail or f"fijado a {days}d", allow_over_cap=True)
        return user.subscription.days_left

    @staticmethod
    def _plan_for_days(days: int) -> str:
        """Plan cuyos días más se acercan sin pasarse (o el más pequeño)."""
        mejor, mejor_d = None, None
        for key, plan in CONFIG.plans.items():
            d = plan.get("days", 30)
            if d <= days and (mejor_d is None or d > mejor_d):
                mejor, mejor_d = key, d
        if mejor is not None:
            return mejor
        return min(CONFIG.plans.items(),
                   key=lambda kv: kv[1].get("days", 30))[0]

    # ══════════════════════════════════════════════════════
    #  3. SINCRONIZAR CON STRIPE  (idempotente, nunca acorta)
    # ══════════════════════════════════════════════════════
    def sync_stripe(self, user: User, plan_key: str,
                    expires_at: Optional[datetime] = None,
                    customer_id: Optional[str] = None,
                    subscription_id: Optional[str] = None,
                    plan_changed: bool = False) -> bool:
        """
        Copia el estado desde Stripe.

        · Es IDEMPOTENTE: si la fecha local ya cubre la de Stripe, no escribe.
        · NUNCA acorta: conserva los días acumulados al cambiar de plan.
        · El plan se FIJA SIEMPRE, aunque la fecha no cambie. Si un usuario
          se quedara con plan=None (p. ej. tras quitarle los días), el poller
          vería "was_plan != plan_key" en cada sondeo y le mandaría un
          "Plan actualizado" cada 5 minutos.

        Devuelve True si se modificó algo.
        """
        plan = SubscriptionPlan(plan_key)
        local = user.subscription.expires_at
        now = datetime.now()
        modificado = False

        if customer_id and user.subscription.stripe_customer_id != customer_id:
            user.subscription.stripe_customer_id = customer_id
            modificado = True
        if (subscription_id
                and user.subscription.stripe_subscription_id != subscription_id):
            user.subscription.stripe_subscription_id = subscription_id
            modificado = True

        # ── el plan siempre queda alineado ──
        if user.subscription.plan != plan:
            user.subscription.plan = plan
            modificado = True

        def _guardar(accion: str, detalle: str):
            self.users.save(user)
            d = user.subscription.days_left
            self.users.log_sub_event(user.telegram_id, accion, d, d, detalle)

        if plan_changed:
            # Cambió de plan: conservamos lo que tuviera y sumamos el nuevo
            base = local if (local and local > now) else now
            days = CONFIG.plans.get(plan_key, {}).get("days", 30)
            user.subscription.is_active = True
            self._set_expiry(user, base + timedelta(days=days), "plan_change",
                             f"cambio a {plan_key}")
            return True

        # Sin cambio de plan
        if expires_at is None:
            # Stripe no dice hasta cuándo: sólo ponemos fecha si no hay nada
            if local and local > now:
                if not user.subscription.is_active:
                    user.subscription.is_active = True
                    modificado = True
                if modificado:
                    _guardar("sync", f"{plan_key} sin period_end de Stripe")
                return modificado
            days = CONFIG.plans.get(plan_key, {}).get("days", 30)
            user.subscription.is_active = True
            self._set_expiry(user, now + timedelta(days=days), "sync",
                             f"{plan_key} sin period_end de Stripe")
            return True

        # Tolerancia de 60 s: si la diferencia es de segundos no escribimos
        if local and local >= (expires_at - timedelta(seconds=60)):
            if not user.subscription.is_active:
                user.subscription.is_active = True
                modificado = True
            if modificado:
                _guardar("sync", f"period_end {expires_at:%d/%m/%Y}")
            return modificado

        user.subscription.is_active = True
        self._set_expiry(user, expires_at, "sync",
                         f"period_end {expires_at:%d/%m/%Y}")
        return True

    # ══════════════════════════════════════════════════════
    #  Compatibilidad (nombres antiguos usados en el proyecto)
    # ══════════════════════════════════════════════════════
    def activate(self, user: User, plan_key: str,
                 customer_id: Optional[str] = None,
                 subscription_id: Optional[str] = None,
                 expires_at: Optional[datetime] = None,
                 accumulate: bool = False):
        if accumulate:
            return self.grant_plan(user, plan_key, detail=f"grant {plan_key}")
        return self.sync_stripe(user, plan_key, expires_at=expires_at,
                                customer_id=customer_id,
                                subscription_id=subscription_id)

    # ── Trial ────────────────────────────────────────────
    def start_free_trial(self, user: User) -> bool:
        """
        Activa la prueba gratuita UNA SOLA VEZ en la vida del usuario.
        True si se activó, False si ya no correspondía.

        /start se puede ejecutar muchas veces, así que esto tiene que ser
        a prueba de balas. Tres cerrojos:
        """
        # 1) Las guardas clásicas
        if user.subscription.trial_used or user.subscription.is_active:
            return False

        # 2) Nunca damos una prueba sobre días que ya tenga
        exp = user.subscription.expires_at
        if exp and exp > datetime.now():
            return False

        # 3) Red de seguridad para datos antiguos: si en el historial ya
        #    consta una prueba, no damos otra aunque trial_used se hubiera
        #    perdido por el camino.
        try:
            if any(e.get("action") == "trial"
                   for e in self.users.sub_events(user.telegram_id, 50)):
                log.warning("Trial denegado a %s: ya consta una prueba en el "
                            "historial", user.telegram_id)
                return False
        except Exception:                                   # noqa: BLE001
            pass

        user.subscription.is_active = True
        user.subscription.plan = SubscriptionPlan.TRIAL
        user.subscription.trial_used = True
        self._set_expiry(
            user, datetime.now() + timedelta(days=CONFIG.free_trial_days),
            "trial", f"{CONFIG.free_trial_days}d de prueba")
        return True

    def deactivate(self, user: User):
        """Quita el acceso SIN tocar los días (se pueden restaurar)."""
        user.subscription.is_active = False
        self.users.save(user)
        self.users.log_sub_event(user.telegram_id, "revoke",
                                 user.subscription.days_left,
                                 user.subscription.days_left, "acceso revocado")

    def restore(self, user: User) -> bool:
        """Vuelve a dar acceso sin sumar días."""
        exp = user.subscription.expires_at
        if not exp or exp <= datetime.now():
            return False
        user.subscription.is_active = True
        self.users.save(user)
        self.users.log_sub_event(user.telegram_id, "restore",
                                 user.subscription.days_left,
                                 user.subscription.days_left, "acceso restaurado")
        return True
