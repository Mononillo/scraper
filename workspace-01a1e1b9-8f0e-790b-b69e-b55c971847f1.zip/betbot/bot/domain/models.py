"""Modelos de dominio — sin dependencias de Telegram ni Stripe."""
from __future__ import annotations
import math
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import List, Optional


# ──────────────────────────────────────────────────────────
# ENUMS
# ──────────────────────────────────────────────────────────

class BetKind(str, Enum):
    SUREBET   = "surebet"
    MIDDLEBET = "middlebet"  # derivado de surebet


class SubscriptionPlan(str, Enum):
    TRIAL     = "trial"
    WEEKLY    = "weekly"
    MONTHLY   = "monthly"
    QUARTERLY = "quarterly"
    YEARLY    = "yearly"


class Language(str, Enum):
    ES = "es"
    EN = "en"


# ──────────────────────────────────────────────────────────
# LINEAS DE APUESTA
# ──────────────────────────────────────────────────────────

@dataclass
class BetLine:
    """Una pata de la surebet / middlebet."""
    selection: str            # texto de la selección (ej. "AH1(-0.5)", "LAY 1st - yes")
    odds: float
    bookmaker_key: str        # clave del catálogo
    url: str = ""             # enlace directo ("Place Bet" de BetBurger)

    # Stake que mandó el proveedor (solo para comparar / depurar).
    provider_stake: Optional[float] = None

    # Referencia a la cuota en odds.db (para re-verificarla justo antes de enviar la señal)
    event_id: str = ""
    market_code: str = ""

    # Para middlebets: línea numérica (2.5, +1.5, etc.)
    line_value: Optional[float] = None


# ──────────────────────────────────────────────────────────
# APUESTAS
# ──────────────────────────────────────────────────────────

@dataclass
class Bet:
    """Surebet o middlebet entre casas."""
    kind: BetKind
    sport_key: str
    game: str                 # "Local - Visitante" (de la línea Event:)
    market: str               # mercado (BetBurger lo mete en la selección)
    lines: List[BetLine] = field(default_factory=list)
    profit_pct: float = 0.0   # ROI (en middles: beneficio del peor caso)

    # Campos propios de BetBurger
    league: str = ""          # "Paraguay. Copa Paraguay"
    period: str = ""          # "Regular time", "1st Half", "Race"...
    starts_at: str = ""       # "30 Sep 22:30 UTC"

    # Metadatos
    is_middle: bool = False
    raw_text: str = ""        # texto original recibido
    received_at: datetime = field(default_factory=datetime.now)

    @property
    def is_surebet(self) -> bool:
        return self.kind == BetKind.SUREBET

    def bookmaker_keys(self) -> List[str]:
        return [l.bookmaker_key for l in self.lines]


# ──────────────────────────────────────────────────────────
# FILTROS DE USUARIO
# ──────────────────────────────────────────────────────────

@dataclass
class UserFilters:
    # Casas
    surebet_bookmakers:  List[str] = field(default_factory=list)   # vacío = todas

    # Deportes (comunes)
    sports: List[str] = field(default_factory=list)                # vacío = todos

    # Profit mínimo
    surebet_min_profit:  float = 0.0

    # Activar/desactivar tipos
    surebets_enabled:    bool = True
    middlebets_marked:   bool = True    # marcar cuando sea middle
    live_enabled:        bool = True    # recibir señales de partidos en directo
    prematch_enabled:    bool = True    # recibir señales pre-partido

    # Otros
    language: str = "es"

    # Silencio y horario
    mute_until: Optional[datetime] = None
    hour_start: int = 0
    hour_end:   int = 24


# ──────────────────────────────────────────────────────────
# SUSCRIPCIÓN
# ──────────────────────────────────────────────────────────

@dataclass
class Subscription:
    is_active: bool = False
    plan: Optional[SubscriptionPlan] = None
    expires_at: Optional[datetime] = None
    stripe_customer_id: Optional[str] = None
    stripe_subscription_id: Optional[str] = None
    trial_used: bool = False

    @property
    def days_left(self) -> int:
        """
        Días completos restantes, redondeando hacia ARRIBA.

        Sin el redondeo, un trial recién creado (now + 3 días) muestra "2"
        porque al timedelta le faltan unas milésimas para llegar a 3.
        """
        if not self.expires_at:
            return 0
        seconds = (self.expires_at - datetime.now()).total_seconds()
        if seconds <= 0:
            return 0
        return max(1, math.ceil(seconds / 86400.0))

    @property
    def is_trial(self) -> bool:
        return self.plan == SubscriptionPlan.TRIAL


# ──────────────────────────────────────────────────────────
# USUARIO
# ──────────────────────────────────────────────────────────

@dataclass
class User:
    telegram_id: int
    username: str = ""
    first_name: str = ""
    filters: UserFilters = field(default_factory=UserFilters)
    subscription: Subscription = field(default_factory=Subscription)
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)

    @property
    def has_access(self) -> bool:
        """Puede recibir apuestas si la suscripción está activa y no caducó."""
        if not self.subscription.is_active:
            return False
        if self.subscription.expires_at and self.subscription.expires_at < datetime.now():
            return False
        return True

    def is_muted_now(self) -> bool:
        mu = self.filters.mute_until
        if mu and mu > datetime.now():
            return True
        hs, he = self.filters.hour_start, self.filters.hour_end
        if hs == 0 and he == 24:
            return False
        h = datetime.now().hour
        if hs <= he:
            return not (hs <= h < he)
        return not (h >= hs or h < he)
