"""
interwetten.py — colector de cuotas de Interwetten España (interwetten.es).

Plataforma propia (React Router v7 con SSR). No hay API REST documentada: los datos del pre-partido llegan en el
formato "turbo-stream" de React Router, bien en las rutas `<página>.data` (single fetch), bien embebidos en el HTML
(`window.__reactRouterContext.streamController.enqueue("...")`). El directo sí tiene JSON normal:
    GET {base}/v2/es/web/sportsbook/live/overview/tab?tab=<sportId>&countryId=ESP   -> todos los directos del deporte
         (marcador, minuto, estado y los 1-4 mercados principales de cada evento)
    GET {base}/es/apuestas-deportivas/live/event/<id>[.data]                        -> todos los mercados en directo
    GET {base}/es/apuestas-deportivas/top-leagues/country.data?topLinkId=14         -> `navigation`: todas las ligas
    GET {base}/es/apuestas-deportivas/l/<ligaId>/x[.data]                           -> eventos de la liga (mercados básicos)
    GET {base}/es/apuestas-deportivas/e/<eventId>/x[.data]                          -> evento con TODOS sus mercados
         (`templateGroups[].templates[]` con `key` "<templateId>:<especificadores>" y `markets[].outcomes[]`)
El pre-partido se normaliza por `templateId` (tabla TPL) y, si no está en la tabla, por markets.classify() con el
nombre; el directo (sin templateId) solo por nombre. Solo funciona desde IP española (fuera: "Access Blocked").

DIRECTO (11-2026): la web bloquea `requests` con 403, así que el directo se lee del hub SignalR de la propia web
(wss://sr5.gamesassists.com/lbfeventHub, otro dominio sin WAF; ver LiveHub). El HTTP del directo queda de reserva.
Si el HTTP devuelve 403 se abre una vez el navegador para heredar cookies (catálogo y pre-partido).

Uso:  python interwetten.py            (bucle)     --once     --list     --dump <eventId>     --probe     --hub [--all]
"""
from __future__ import annotations

import fastjson as json
import logging
import os
import re
import sys
import time
from datetime import datetime, timedelta
from pathlib import Path

import requests

from competitions import Competitions
from markets import classify
from storage import OddsStore
import pace

log = logging.getLogger("interwetten")
CFG_PATH = Path(os.getenv("INTERWETTEN_CFG", Path(__file__).parent / "interwetten.json"))

# ───────────────────────── turbo-stream (React Router single fetch) ─────────────────────────
_HOLE, _NAN, _NEG_INF, _NEG_ZERO, _NULL, _POS_INF, _UNDEF = -1, -2, -3, -4, -5, -6, -7
_SPECIAL = {_NULL: None, _UNDEF: None, _HOLE: None, _NAN: float("nan"), _NEG_INF: float("-inf"),
            _POS_INF: float("inf"), _NEG_ZERO: 0.0}


def ts_decode(arr: list):
    """Deserializa un array turbo-stream (índices que se referencian entre sí) a objetos Python."""
    cache: dict[int, object] = {}

    def hyd(i):
        if isinstance(i, int) and i < 0:
            return _SPECIAL.get(i)
        if i in cache:
            return cache[i]
        v = arr[i]
        if isinstance(v, (str, int, float, bool)) or v is None:
            cache[i] = v
            return v
        if isinstance(v, list):
            if v and isinstance(v[0], str) and v[0] in ("D", "P", "E", "B", "R", "S", "U", "Z", "Set", "Map") \
                    and all(isinstance(x, int) for x in v[1:]):
                t = v[0]
                if t in ("D", "P", "U", "B", "R", "S", "Z"):
                    r = hyd(v[1]) if len(v) > 1 else None
                elif t == "Set":
                    r = [hyd(x) for x in v[1:]]
                elif t == "Map":
                    r = {hyd(v[k]): hyd(v[k + 1]) for k in range(1, len(v) - 1, 2)}
                else:
                    r = [hyd(x) for x in v[1:]]
                cache[i] = r
                return r
            out: list = []
            cache[i] = out
            out.extend(hyd(x) for x in v)
            return out
        if isinstance(v, dict):
            o: dict = {}
            cache[i] = o
            for k, x in v.items():
                o[hyd(int(k[1:])) if k.startswith("_") else k] = hyd(x)
            return o
        return v
    return hyd(0)


def ts_decode_text(txt: str) -> list:
    out = []
    for line in txt.splitlines():
        line = line.strip()
        if line:
            try:
                out.append(ts_decode(json.loads(line)))
            except Exception as e:  # noqa: BLE001
                out.append({"_err": str(e)})
    return out


_ENQ = re.compile(r'streamController\.enqueue\((".*?")\);?</script>', re.S)


def html_loader_data(html: str) -> dict | None:
    """Saca el loaderData de una página SSR (los trozos `enqueue("...")` concatenados forman el turbo-stream)."""
    chunks = _ENQ.findall(html)
    if not chunks:
        return None
    txt = "".join(json.loads(c) for c in chunks)
    for obj in ts_decode_text(txt):
        if isinstance(obj, dict) and isinstance(obj.get("loaderData"), dict):
            return obj["loaderData"]
    return None


def find_key(o, key: str):
    """Primer valor con la clave `key` en una estructura anidada (las rutas cambian de nombre; el contenido no)."""
    if isinstance(o, dict):
        if key in o:
            return o[key]
        for v in o.values():
            r = find_key(v, key)
            if r is not None:
                return r
    elif isinstance(o, list):
        for v in o:
            r = find_key(v, key)
            if r is not None:
                return r
    return None


# ───────────────────────── mercados ─────────────────────────
# templateId -> (mercado, tipo).  tipo: 1x2 (outcome.tip 1/X/2), 2way (nombres de los dos equipos), dc, total,
# team_total (equipo en el nombre del mercado/outcome), ah (hándicap asiático, línea entre paréntesis), yesno,
# playerN (jugadores con línea "N-k" del key -> Over k-0.5), hcp2 (hándicap a 2 vías con línea en paréntesis)
TPL: dict[str, dict[int, tuple[str, str]]] = {
    "futbol": {1: ("1X2", "1x2"), 9: ("1X2_1H", "1x2"), 32: ("1X2_2H", "1x2"),
               8: ("DC", "dc"), 23: ("DC_1H", "dc"), 34: ("DC_2H", "dc"),
               56: ("DNB", "2way"), 24: ("DNB_1H", "2way"), 130: ("DNB_2H", "2way"),
               5: ("TOTAL", "total"), 29: ("TOTAL_1H", "total"), 35: ("TOTAL_2H", "total"),
               20: ("TOTAL_HOME", "total"), 21: ("TOTAL_AWAY", "total"), 30: ("TOTAL_HOME_1H", "total"),
               31: ("TOTAL_AWAY_1H", "total"), 119: ("TOTAL_HOME_2H", "total"), 120: ("TOTAL_AWAY_2H", "total"),
               18: ("HANDICAP", "ah"), 28: ("HANDICAP_1H", "ah"), 33: ("HANDICAP_2H", "ah"),
               142: ("BTTS", "yesno"), 139: ("BTTS_1H", "yesno"), 141: ("BTTS_2H", "yesno"),
               336: ("CORNERS", "total"), 347: ("CORNERS_1H", "total"), 310: ("CARDS", "total"),
               412: ("PLAYER_GOALS", "playerplus"), 3224: ("PLAYER_SHOTS", "playerN"), 3225: ("PLAYER_SHOTS_OT", "playerN"),
               3227: ("PLAYER_ASSISTS", "playerN"), 3228: ("PLAYER_SAVES", "playerN"), 3242: ("PLAYER_OFFSIDES", "playerN")},
    "baloncesto": {},
    "tenis": {},
}
TPL_SKIP = {234, 6, 11, 154, 12, 66, 125, 14, 15, 19, 36, 44, 65, 67, 68, 74, 116, 117, 121, 122, 131, 134, 135, 136, 137, 138,
            148, 149, 150, 151, 152, 153, 156, 157, 158, 205, 206, 207, 208, 225, 226, 227, 236, 250, 260, 266, 271, 307,
            320, 321, 335, 339, 342, 343, 344, 346, 350, 351, 353, 359, 362, 363, 364, 437, 438, 439, 440, 441, 442, 443,
            444, 445, 446, 447, 448, 462, 2362, 3226, 3229, 3241, 3243, 3244, 3247, 3248, 3249, 3255, 3256, 3257, 3258, 3259}
_LINE = re.compile(r"([+-]?\d+(?:[.,]\d+)?)")
_OU = re.compile(r"^(?:(?P<team>.+?)\s+)?(?P<dir>m[áa]s|menos|over|under)\s+de\s+(?P<line>\d+(?:[.,]\d+)?)\s*$", re.I)
_PAREN = re.compile(r"\(\s*([+-]?\d+(?:[.,]\d+)?)\s*\)")


_PER_RX = [(re.compile(r"\b([1-4])\s*[°º.]?\s*(quarto|cuarto|quarter|q)\b", re.I), lambda m: f"{m.group(1)}º cuarto"),
           (re.compile(r"\b([1-5])\s*[°º.]?\s*set\b", re.I), lambda m: f"set {m.group(1)}"),
           (re.compile(r"\b(?:1\s*(?:er|°|º|\.)?|primer[ao]?)\s*(tiempo|mitad|half)\b", re.I), lambda m: "1ª parte"),
           (re.compile(r"\b(?:2\s*(?:do|º|°|\.)?|segund[ao])\s*(tiempo|mitad|half)\b", re.I), lambda m: "2ª parte")]


_RESULT_OK = re.compile(r"(?:(?:1ª parte|2ª parte|[1-4]º cuarto|set [1-5]|1er tiempo|2º tiempo|segundo tiempo|primer tiempo)\s*[-–:]?\s*)?"
                        r"(?:partido|resultado( final)?|1x2|ganador( del partido)?|ganador del set [1-5]|2 v[íi]as|quien gana(ra)?|"
                        r"1ª parte|2ª parte|[1-4]º cuarto|set [1-5])")


def _norm_period(name: str) -> str:
    """'4° quarto total Puntos' -> '4º cuarto total Puntos'; '1er tiempo - Goles' ya lo entiende markets.py."""
    for rx, rep in _PER_RX:
        name = rx.sub(rep, name)
    return name


def _f(s: str | None) -> float | None:
    if not s:
        return None
    try:
        return float(s.replace(",", "."))
    except ValueError:
        return None


def _half(v: float | None) -> bool:
    return v is not None and abs(abs(v) % 1 - 0.5) < 1e-9


def _player(name: str) -> str:
    """'Rodrigues, Bruno' -> 'Bruno Rodrigues' (como el resto de casas)."""
    name = re.sub(r"\s+\d+\+\s*$", "", name).strip()
    if "," in name:
        a, _, b = name.partition(",")
        return f"{b.strip()} {a.strip()}".strip()
    return name


def _side(name: str, home: str, away: str) -> str | None:
    n = (name or "").strip().lower()
    h, a = home.lower(), away.lower()
    if n == h or (h and n.startswith(h)):
        return "1"
    if n == a or (a and n.startswith(a)):
        return "2"
    if n in ("x", "empate", "draw"):
        return "X"
    return None


def _ou_sel(name: str) -> tuple[str | None, float | None]:
    m = _OU.match((name or "").strip())
    if not m:
        return None, None
    return ("Over" if m.group("dir").lower() in ("más", "mas", "over") else "Under"), _f(m.group("line"))


def market_selections(tpl_key: str | None, tpl_name: str, m: dict, sport: str, home: str, away: str) -> list[dict]:
    """Normaliza un mercado. tpl_key = 'U5'/'5:(var)'/None (directo)."""
    outs = [o for o in m.get("outcomes") or [] if isinstance(o.get("odd"), (int, float)) and o["odd"] > 1.0]
    if not outs:
        return []
    tid = None
    if tpl_key:
        mm = re.match(r"U?(\d+)", tpl_key)
        tid = int(mm.group(1)) if mm else None
    if tid in TPL_SKIP:
        return []
    name = (m.get("name") or tpl_name or "").strip()
    rule = TPL.get(sport, {}).get(tid) if tid is not None else None
    out: list[dict] = []
    if rule:
        market, typ = rule
        if typ == "1x2":
            for o in outs:
                sel = {"1": "1", "X": "X", "2": "2"}.get((o.get("tip") or "").upper()) or _side(o["name"], home, away)
                if sel:
                    out.append({"market": market, "selection": sel, "line": None, "player": None, "price": o["odd"]})
        elif typ == "2way":
            if len(outs) == 2:
                for o in outs:
                    sel = _side(o["name"], home, away)
                    if sel in ("1", "2"):
                        out.append({"market": market, "selection": sel, "line": None, "player": None, "price": o["odd"]})
        elif typ == "dc":
            for o in outs:
                sel = (o.get("name") or "").upper().replace(" ", "")
                if sel in ("1X", "12", "X2"):
                    out.append({"market": market, "selection": sel, "line": None, "player": None, "price": o["odd"]})
        elif typ == "total":
            for o in outs:
                sel, ln = _ou_sel(o["name"])
                if sel and _half(ln):
                    out.append({"market": market, "selection": sel, "line": ln, "player": None, "price": o["odd"]})
        elif typ == "ah":
            if len(outs) == 2:
                for o in outs:
                    sel = _side(o["name"], home, away)
                    pm = _PAREN.search(o["name"])
                    ln = _f(pm.group(1)) if pm else None
                    if sel in ("1", "2") and _half(ln):
                        out.append({"market": market, "selection": sel, "line": ln, "player": None, "price": o["odd"]})
        elif typ == "yesno":
            for o in outs:
                n = (o.get("name") or "").strip().lower()
                sel = "Yes" if n in ("sí", "si", "yes") else "No" if n == "no" else None
                if sel:
                    out.append({"market": market, "selection": sel, "line": None, "player": None, "price": o["odd"]})
        elif typ == "playerN":                       # key "3224:N-2" -> línea 1.5, outcomes = jugadores
            nm = re.search(r"N-(\d+)", tpl_key or "")
            if nm:
                ln = int(nm.group(1)) - 0.5
                for o in outs:
                    out.append({"market": market, "selection": "Over", "line": ln, "player": _player(o["name"]), "price": o["odd"]})
        elif typ == "playerplus":                    # "Jorge, Kaio 2+"
            for o in outs:
                pm = re.search(r"\s(\d+)\+\s*$", o["name"])
                if pm:
                    out.append({"market": market, "selection": "Over", "line": int(pm.group(1)) - 0.5, "player": _player(o["name"]), "price": o["odd"]})
        elif typ == "scorer":                        # goleador en cualquier momento
            for o in outs:
                out.append({"market": market, "selection": "Over", "line": 0.5, "player": _player(o["name"]), "price": o["odd"]})
        return out
    # ── sin regla: por nombre (baloncesto/tenis y todo el directo) ──
    low = name.lower()
    if re.search(r"\b(y|e|&|/)\b.*\b(m[áa]s|menos|s[íi]|no|1x2|resultado)\b|resultado correcto|exacto|margen|par\s*/\s*impar|par/impar|impar|pr[óo]rroga|horas extras|clasificar|siguiente|pr[óo]ximo|\b1\s*[°º]?\s*(gol|c[óo]rner|corner|tarjeta)|primer(a|o)?\s+(gol|c[óo]rner|corner|tarjeta|jugador)|[úu]ltimo|tiempo con|qui[ée]n marca|gana sin|ambos per|ambos tiempo|en blanco|ganar[áa] o", low):
        return []
    sels_ou = [_ou_sel(o["name"]) for o in outs]
    if all(s for s, _l in sels_ou):
        # total (partido / equipo / jugador).  "Total Puntos", "4° quarto total Puntos", "Más/Menos Real Madrid",
        # "Juegos totales", "Puntos - LeBron James"
        team = None
        for cand in (home, away):
            if cand and cand.lower() in low:
                team = cand
        info = classify(_norm_period(name), sport, home, away, kind="total")
        if not info and team:
            info = classify(_norm_period(re.sub(re.escape(team), "", name, flags=re.I)).strip(" -/:"), sport, home, away, kind="total")
        if not info:
            return []
        market = info.market
        if team and "_HOME" not in market and "_AWAY" not in market and not market.startswith("PLAYER_"):
            market = re.sub(r"^([A-Z_]+?)(_(1H|2H|Q\d|SET\d|OT|REG))?$", lambda mm: f"{mm.group(1)}_{'HOME' if team == home else 'AWAY'}{mm.group(2) or ''}", market)
        for o, (sel, ln) in zip(outs, sels_ou):
            if _half(ln):
                out.append({"market": market, "selection": sel, "line": ln, "player": info.player, "price": o["odd"]})
        return out
    if all(_PAREN.search(o["name"]) for o in outs) and len(outs) == 2 and re.search(r"h[áa]ndicap|handicap|spread", low):
        info = classify(_norm_period(name), sport, home, away, kind="handicap")
        if not info:
            return []
        for o in outs:
            sel = _side(o["name"], home, away)
            ln = _f(_PAREN.search(o["name"]).group(1))
            if sel in ("1", "2") and _half(ln):
                out.append({"market": info.market, "selection": sel, "line": ln, "player": None, "price": o["odd"]})
        return out
    tips = {(o.get("tip") or "").upper() for o in outs}
    if tips in ({"1", "X", "2"}, {"1", "2"}) or all(_side(o["name"], home, away) for o in outs):
        if not _RESULT_OK.fullmatch(_norm_period(name).strip().lower()):
            return []                      # 'Clasificará', 'Resto del partido', 'Prórroga - 1x2'… no son el 1X2
        info = classify(_norm_period(name), sport, home, away, kind="result")
        if not info or not info.market.startswith("1X2"):
            return []
        for o in outs:
            sel = {"1": "1", "X": "X", "2": "2"}.get((o.get("tip") or "").upper()) or _side(o["name"], home, away)
            if sel:
                out.append({"market": info.market, "selection": sel, "line": None, "player": None, "price": o["odd"]})
        return out
    return out


# ───────────────────────── directo por websocket (SignalR) ─────────────────────────
# La web del directo se alimenta de un hub SignalR en OTRO dominio (sr5.gamesassists.com) que no está detrás del
# WAF de interwetten.es: no pide cookies y acepta conexiones con solo `Origin`. Protocolo JSON de SignalR
# (mensajes separados por \x1e). Métodos usados:
#   SubscribeLiveCalendar [7, "ES", "ALL", "ESP", true, null, false]  -> {events:[...]} + pushes de todos los directos
#   SubscribeEventV2      [7, <eventId>, "ES", "ESP", true, true]     -> {event:{groups:[{name, markets:[...]}]}}
# Pushes: updateOutcome [eid, mid, oid, {odd, locked}], updateMarket [eid, mid, {isDeleted…}], addMarket [sid, lid, eid,
# market], updateEvent [eid, patch], updateEventStatus [eid, {gameTime, status}], addOrUpdateScore [eid, score],
# liveAllTabChanged [{eventIds, added, removed}]. Cuotas enteras x100 (150 = 1.50).
import threading

HUB_URL = "wss://sr5.gamesassists.com/lbfeventHub"
_RS = "\x1e"


class LiveHub(threading.Thread):
    def __init__(self, ua: str | None = None, origin: str = "https://www.interwetten.es"):
        super().__init__(name="interwetten-hub", daemon=True)
        self.ua = ua or "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36"
        self.origin = origin
        self.lock = threading.Lock()
        self.events: dict[int, dict] = {}            # eid -> evento del hub (nombre, liga, deporte, scores, status…)
        self.markets: dict[int, dict[int, dict]] = {}  # eid -> {mid: market}
        self.snap_at: dict[int, float] = {}
        self._want: list[int] = []                   # eventos a pedir con SubscribeEventV2
        self._pending: dict[str, int] = {}           # invocationId -> eid
        self._seq = 0
        self.connected = False
        self.started = time.time()
        self.connected_at = 0.0
        self.last_msg = 0.0
        self.n_updates = 0
        self.error: str | None = None
        self._ws = None

    # ── API para el colector ──
    def request_snapshot(self, eid: int):
        with self.lock:
            if eid not in self._want and eid not in self._pending.values():
                self._want.append(eid)

    def healthy(self, max_silence: float = 60.0) -> bool:
        return self.connected and time.time() - self.last_msg < max_silence

    # ── hilo ──
    def run(self):
        backoff = 2
        while True:
            try:
                self._session()
                backoff = 2
            except Exception as e:  # noqa: BLE001
                self.error = str(e)[:200]
                log.warning("hub: %s — reconecto en %ss", str(e)[:200], backoff)
            self.connected = False
            with self.lock:
                self.events.clear(); self.markets.clear(); self.snap_at.clear(); self._pending.clear(); self._want.clear()
            time.sleep(backoff)
            backoff = min(backoff * 2, 60)

    def _send(self, obj: dict):
        self._ws.send(json.dumps(obj, ensure_ascii=False) + _RS)

    def _invoke(self, target: str, args: list) -> str:
        self._seq += 1
        iid = str(self._seq)
        self._send({"target": target, "arguments": args, "invocationId": iid, "type": 1})
        return iid

    def _session(self):
        from websockets.sync.client import connect
        with connect(HUB_URL, additional_headers={"Origin": self.origin, "User-Agent": self.ua},
                     max_size=64 * 1024 * 1024, open_timeout=20, close_timeout=3) as ws:
            self._ws = ws
            self._send({"protocol": "json", "version": 1})
            ws.recv(timeout=15)
            cal = self._invoke("SubscribeLiveCalendar", [7, "ES", "ALL", "ESP", True, None, False])
            self.connected, self.connected_at, self.last_msg = True, time.time(), time.time()
            log.info("hub conectado (%s)", HUB_URL.split("/")[2])
            last_ping = time.time()
            while True:
                try:
                    raw = ws.recv(timeout=1.0)
                except TimeoutError:
                    raw = None
                now = time.time()
                if raw:
                    self.last_msg = now
                    for part in raw.split(_RS):
                        if part:
                            try:
                                self._on_msg(json.loads(part), cal)
                            except Exception as e:  # noqa: BLE001
                                log.debug("hub msg: %s", e)
                if now - last_ping > 15:
                    self._send({"type": 6}); last_ping = now
                if now - self.last_msg > 90:
                    raise RuntimeError("hub sin mensajes 90s")
                with self.lock:
                    want = self._want[:5]; self._want = self._want[5:]
                for eid in want:
                    self._pending[self._invoke("SubscribeEventV2", [7, eid, "ES", "ESP", True, True])] = eid

    def _on_msg(self, j: dict, cal_id: str):
        t = j.get("type")
        if t == 3:                                                   # completion
            iid = j.get("invocationId")
            res = j.get("result")
            if iid == cal_id and isinstance(res, dict):
                with self.lock:
                    for e in res.get("events") or []:
                        self.events[e["id"]] = e
                log.info("hub: %d eventos en directo", len(self.events))
            elif iid in self._pending:
                eid = self._pending.pop(iid)
                ev = (res or {}).get("event") if isinstance(res, dict) else None
                if j.get("error") or not ev:
                    log.debug("hub: SubscribeEventV2 %s: %s", eid, j.get("error") or "sin evento")
                    return
                mk: dict[int, dict] = {}
                for g in ev.get("groups") or []:
                    gname = ((g.get("name") or {}).get("text") or "")
                    for m in g.get("markets") or []:
                        m["_group"] = gname
                        mk[m["id"]] = m
                if not mk and ev.get("mainMarket"):
                    mk[ev["mainMarket"]["id"]] = ev["mainMarket"]
                with self.lock:
                    ev.pop("groups", None)
                    old = self.events.get(eid) or {}
                    old.update(ev)
                    self.events[eid] = old
                    self.markets[eid] = mk
                    self.snap_at[eid] = time.time()
            return
        if t == 7:
            raise RuntimeError(f"hub cerrado por el servidor: {j.get('error')}")
        if t != 1:
            return
        target, a = j.get("target"), j.get("arguments") or []
        self.n_updates += 1
        with self.lock:
            if target == "updateOutcome" and len(a) >= 4:
                m = (self.markets.get(a[0]) or {}).get(a[1])
                if m:
                    for o in m.get("outcomes") or []:
                        if o.get("id") == a[2]:
                            o.update(a[3]); break
            elif target == "updateMarket" and len(a) >= 3:
                mk = self.markets.get(a[0])
                if mk is not None and a[1] in mk:
                    if a[2].get("isDeleted"):
                        mk.pop(a[1], None)
                    else:
                        mk[a[1]].update({k: v for k, v in a[2].items() if k != "outcomes"})
            elif target == "addMarket" and len(a) >= 4:
                mk = self.markets.get(a[2])
                if mk is not None:
                    m = a[3]; m.setdefault("_group", ""); mk[m["id"]] = m
            elif target in ("updateEvent", "updateEventStatus") and len(a) >= 2:
                ev = self.events.get(a[0])
                if a[1].get("isDeleted"):
                    self.events.pop(a[0], None); self.markets.pop(a[0], None); self.snap_at.pop(a[0], None)
                elif ev is not None:
                    ev.update(a[1])
            elif target == "addOrUpdateScore" and len(a) >= 2:
                ev = self.events.get(a[0])
                if ev is not None:
                    sc = [x for x in (ev.get("scores") or []) if x.get("key") != a[1].get("key")]
                    sc.append(a[1]); ev["scores"] = sc
            elif target == "liveAllTabChanged" and a and isinstance(a[0], dict):
                for eid in a[0].get("removed") or []:
                    self.events.pop(eid, None); self.markets.pop(eid, None); self.snap_at.pop(eid, None)
                for eid in a[0].get("added") or []:
                    if eid not in self.events:
                        self.events[eid] = {"id": eid, "_new": True}
                        if eid not in self._want:
                            self._want.append(eid)

    def snapshot(self) -> tuple[dict[int, dict], dict[int, dict[int, dict]]]:
        import copy
        with self.lock:
            return copy.deepcopy(self.events), copy.deepcopy(self.markets)


def hub_event_to_http(e: dict) -> dict:
    """Evento del hub -> forma del JSON del directo por HTTP (la que entienden _teams/_state/_row_from_event)."""
    scores = e.get("scores") or []
    main = next((x for x in scores if x.get("main")), None)
    sets = next((x for x in scores if x.get("key") == "Sets"), None)
    sc: dict = {}
    src = sets or main
    if (e.get("sport") or {}).get("id") == 11:            # tenis: sets ganados (como el resto de casas); sin "Sets" aún = 0:0
        src = sets or {"value": "0 : 0"}
    if src and ":" in str(src.get("value") or ""):
        a, _, b = str(src["value"]).partition(":")
        sc = {"scoreOne": a.strip(), "scoreTwo": b.strip(), "score": f"{a.strip()}:{b.strip()}"}
    st = ((e.get("status") or {}).get("text") or "").strip()
    st = {"primer set": "1er set", "segundo set": "2º set", "tercer set": "3er set", "cuarto set": "4º set",
          "quinto set": "5º set", "primer tiempo": "1er tiempo", "segundo tiempo": "2º tiempo"}.get(st.lower(), st)
    return {"id": e["id"], "name": ((e.get("name") or {}).get("text") or ""), "isLive": e.get("isLive", True),
            "leagueId": (e.get("league") or {}).get("id"), "leagueName": ((e.get("league") or {}).get("name") or {}).get("text"),
            "sportId": (e.get("sport") or {}).get("id"), "score": sc, "liveStatus": st, "gameTime": e.get("gameTime") or "",
            "startFromUtc": e.get("startUtc")}


def hub_market_to_http(m: dict) -> dict:
    outs = []
    for o in m.get("outcomes") or []:
        odd = o.get("odd")
        if o.get("locked") or not isinstance(odd, (int, float)) or (o.get("state") not in (None, "E")):
            continue
        outs.append({"id": o.get("id"), "name": ((o.get("name") or {}).get("text") or "").strip(), "odd": odd / 100.0, "tip": o.get("tip")})
    return {"id": m.get("id"), "name": ((m.get("name") or {}).get("text") or "").strip(), "outcomes": outs}


# ───────────────────────── colector ─────────────────────────
class Collector:
    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.bk = cfg["bookmaker"]
        self.base = cfg["base"].rstrip("/")
        # La web está detrás de Cloudflare Bot Management: deja pasar al navegador sin ninguna cookie pero da 403 a
        # `requests` por la huella TLS/HTTP2. `curl_cffi` es una librería HTTP normal (sin navegador) que imita la
        # huella de Chrome; con ella el catálogo y el pre-partido se piden como siempre.
        hdrs = dict(cfg.get("headers") or {})
        try:
            from curl_cffi import requests as _cffi
            self.sess = _cffi.Session(impersonate=cfg.get("impersonate", "chrome"))
            hdrs.pop("User-Agent", None)              # la UA la pone curl_cffi coherente con la huella TLS
            self.http_lib = "curl_cffi"
        except ImportError:
            self.sess = requests.Session()
            self.http_lib = "requests"
            log.warning("curl_cffi no instalado (pip install curl_cffi): Interwetten devolverá 403 al HTTP normal")
        self.sess.headers.update({"Referer": self.base + "/es/apuestas-deportivas", **hdrs})
        self.catalog = Competitions()
        self.store = OddsStore(bookmaker=self.bk)
        self.sports = {int(k): v for k, v in cfg["sports"].items()}
        self.leagues: dict[int, tuple[str, str]] = {}
        self._all: list[tuple[str, int, str]] = []
        self._menu_at = 0.0
        self._last_prematch = 0.0
        self._pm_queue: list[int] = []
        self._pm_present: set[str] = set()
        self._pm_rows = self._pm_changed = 0
        self._cfg_mtime = CFG_PATH.stat().st_mtime
        self._bg = pace.Background(f"{self.bk}-prematch")
        self._last_req = 0.0
        self._live_detail_at: dict[str, float] = {}
        self._live_cache: dict[str, list[dict]] = {}
        self._live_score: dict[str, dict] = {}
        self._live_bg = pace.Background(f"{self.bk}-livedetail")
        self._live_pending: list[str] = []
        self.transport = "requests"
        self._renewed_at = 0.0
        self._load_session()
        self._browser = None
        self._via_browser = False
        self.http_enabled = bool(cfg.get("http", True))   # False → solo websocket (directo); ni catálogo ni pre-partido
        self.hub: LiveHub | None = None
        if cfg.get("live_hub", True):
            self.hub = LiveHub(ua=(cfg.get("headers") or {}).get("User-Agent"), origin=self.base)
            self.hub.start()

    # ── sesión del navegador (cookies + UA) ──
    # Desde 11-2026 la web devuelve 403 a `requests` sin cookies de navegador. Igual que en Codere: cuando llega un 403
    # se abre una vez el navegador, se copian sus cookies y User-Agent a la sesión de requests y se guardan en
    # data/headers_www.interwetten.es.json para los próximos arranques.
    def _session_path(self) -> Path:
        import transport
        return transport._learned_path(self.base)

    def _apply_session(self, cookies: dict, ua: str | None):
        for k, v in (cookies or {}).items():
            self.sess.cookies.set(k, v)
        if ua:
            self.sess.headers["User-Agent"] = ua

    def _load_session(self):
        try:
            p = self._session_path()
            if not p.exists():
                return
            d = json.loads(p.read_text(encoding="utf-8")).get("_session") or {}
            if d.get("cookies") and time.time() - float(d.get("ts") or 0) < 2 * 86400:
                self._apply_session(d["cookies"], d.get("ua"))
                log.info("sesión del navegador recuperada de %s (%d cookies)", p.name, len(d["cookies"]))
        except Exception as e:  # noqa: BLE001
            log.debug("no pude cargar la sesión: %s", e)

    def _save_session(self):
        try:
            p = self._session_path()
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(json.dumps({"_session": {"cookies": self.sess.cookies.get_dict(),
                                                  "ua": self.sess.headers.get("User-Agent"), "ts": time.time()}},
                                    ensure_ascii=False, indent=1), encoding="utf-8")
        except Exception as e:  # noqa: BLE001
            log.debug("no pude guardar la sesión: %s", e)

    def _renew_session(self) -> bool:
        """Abre el navegador, navega como una persona y hereda cookies+UA. Como mucho cada 10 min. Si aun con las
        cookies `requests` sigue en 403 (el WAF valida más que las cookies), se queda el navegador abierto y las
        peticiones HTTP (catálogo + pre-partido) se hacen con `fetch` desde la propia pestaña."""
        if time.time() - self._renewed_at < 600:
            return False
        self._renewed_at = time.time()
        if not self.cfg.get("browser_fallback", False):
            log.warning("HTTP 403 de www.interwetten.es con %s (browser_fallback desactivado: no se abre navegador)",
                        self.http_lib)
            return False
        try:
            import transport
            log.warning("403 de la web: abro el navegador para renovar cookies")
            if self._browser is None:
                self._browser = transport.BrowserTransport(self.base, start_url=self.base + "/es/apuestas-deportivas/en-directo",
                                                           api_hint="/v2/")
            b = self._browser
            b.page()
            b.warm(6.0)
            cookies, ua = b.cookies(), b.user_agent()
            if not cookies:
                log.warning("el navegador no ha devuelto cookies")
                return False
            self.sess.cookies.clear()
            self._apply_session(cookies, ua)
            probe = self.sess.get(self.base + "/es/apuestas-deportivas/top-leagues/country.data?topLinkId=14", timeout=30)
            if probe.status_code == 200:
                log.info("cookies del navegador adoptadas (%d); requests vuelve a funcionar, cierro el navegador", len(cookies))
                b.close(); self._browser = None
                self._via_browser = False
                self._save_session()
            else:
                log.warning("requests sigue en HTTP %s con las cookies del navegador: el HTTP de Interwetten pasa por la pestaña",
                            probe.status_code)
                self._via_browser = True
            return True
        except Exception as e:  # noqa: BLE001
            log.warning("renovación de sesión fallida: %s", e)
            return False

    class _BrowserResp:
        def __init__(self, st: int, text: str):
            self.status_code, self.text = st, text
            self.content = text.encode("utf-8", "replace")
            self.encoding = "utf-8"

        def json(self):
            return json.loads(self.text)

    # ── HTTP ──
    def _get(self, url: str, gap: float | None = None, _retry: bool = True, **kw) -> requests.Response:
        gap = (self.cfg.get("request_gap", 0.4) if gap is None else gap) - (time.time() - self._last_req)
        if gap > 0:
            time.sleep(gap)
        if self._via_browser and self._browser is not None:
            st, tx = self._browser.get_text(url, headers={**dict(self.sess.headers), **(kw.get("headers") or {})})
            r = self._BrowserResp(st, tx)
            self._last_req = time.time()
            if st == 403 and _retry and time.time() - self._renewed_at >= 600:
                self._via_browser = False                          # cada 10 min se vuelve a probar con requests
                return self._get(url, gap=1.0, _retry=True, **kw)
            if st in (0, 403, 429):
                raise RuntimeError(f"{url} -> HTTP {st} (bloqueo/ritmo): pausa")
            if st >= 400:
                raise RuntimeError(f"{url} -> HTTP {st}")
            return r
        r = self.sess.get(url, timeout=30, allow_redirects=True, **kw)
        r.encoding = "utf-8"                      # las rutas .data no declaran charset y requests asume latin-1
        self._last_req = time.time()
        if r.status_code in (403, 429) or "Access Blocked" in r.text[:600] or "Just a moment" in r.text[:600]:
            if r.status_code == 403 and _retry and self._renew_session():
                return self._get(url, gap=1.0, _retry=False, **kw)
            raise RuntimeError(f"{url} -> HTTP {r.status_code} (bloqueo/ritmo): pausa")
        if r.status_code >= 400:
            raise RuntimeError(f"{url} -> HTTP {r.status_code}")
        return r

    def get_json(self, path: str) -> dict:
        return json.loads(self._get(self.base + path, gap=0.0, headers={"Accept": "application/json"}).content)

    def get_data(self, path: str, _depth: int = 0) -> dict | None:
        """loaderData de una ruta: primero `<ruta>.data` (ligero), si no, el HTML. Sigue los SingleFetchRedirect."""
        p, _, q = path.partition("?")
        r = self._get(f"{self.base}{p}.data" + (f"?{q}" if q else ""))
        txt = r.text.strip()
        self._last_raw = txt[:400]
        self._last_mode = f".data {len(r.content) // 1024} KB"
        if txt.startswith("["):
            for obj in ts_decode_text(txt):
                if isinstance(obj, dict) and "_err" in obj:
                    log.debug("turbo-stream ilegible en %s: %s", path, obj["_err"])
                    break
                if isinstance(obj, dict):
                    red = find_key(obj, "redirect")
                    if isinstance(red, str) and red.startswith("/") and _depth < 2 and "status" in json.dumps(obj)[:400]:
                        return self.get_data(red, _depth + 1)
                    return obj
        # HTML de la página
        r = self._get(self.base + path, headers={"Accept": "text/html"})
        self._last_mode = f"html {len(r.content) // 1024} KB"
        return html_loader_data(r.text)

    def _reload_if_changed(self):
        mt = CFG_PATH.stat().st_mtime
        if mt != self._cfg_mtime:
            self._cfg_mtime = mt
            self.cfg = pace.apply(json.loads(CFG_PATH.read_text(encoding="utf-8")))
            log.info("interwetten.json recargado")
        self.catalog.reload()

    # ── catálogo ──
    def refresh_menu(self, force: bool = False):
        if not force and time.time() - self._menu_at < self.cfg.get("menu_ttl", 900):
            return
        found: dict[int, tuple[str, str]] = {}
        allt: list[tuple[str, int, str]] = []
        try:
            d = self.get_data("/es/apuestas-deportivas/top-leagues/country?topLinkId=14")
            nav = find_key(d, "navigation") or {}
            for s in nav.get("sports") or []:
                sport = self.sports.get((s.get("sport") or {}).get("id"))
                if not sport:
                    continue
                for c in s.get("categories") or []:
                    for lg in c.get("leagues") or []:
                        label = re.sub(r"\s+", " ", f"{c.get('name') or ''} - {lg.get('name') or ''}").strip(" -")
                        allt.append((sport, lg["id"], label))
                        comp = self.catalog.match(self.bk, sport, label)
                        if comp:
                            found[lg["id"]] = (sport, comp)
            if not allt:
                raise RuntimeError("navigation vacío (¿cambió la estructura?)")
        except Exception as e:  # noqa: BLE001
            log.warning("catálogo: %s", e)
            self._menu_at = time.time() - self.cfg.get("menu_ttl", 900) + 60
            return
        self.leagues, self._all = found, allt
        self._menu_at = time.time()
        log.info("%d competiciones mapeadas en Interwetten", len(self.leagues))

    def _league_of(self, ev: dict, sport_hint: str | None) -> tuple[str, str] | None:
        lid = ev.get("leagueId")
        if lid in self.leagues:
            return self.leagues[lid]
        sport = sport_hint or self.sports.get(ev.get("sportId"))
        ln = re.sub(r"\s+", " ", ev.get("leagueName") or "").strip()
        if sport and ln:
            comp = self.catalog.match(self.bk, sport, ln) or self.catalog.match(self.bk, sport, f"{ln} - {ln}")
            if comp:
                self.leagues[lid] = (sport, comp)
                return sport, comp
        return None

    # ── filas ──
    @staticmethod
    def _teams(ev: dict) -> tuple[str, str]:
        n = ev.get("name") or ""
        h, _, a = n.partition(" - ")
        return h.strip(), a.strip()

    @staticmethod
    def _state(ev: dict, sport: str) -> tuple[str | None, str | None, str | None]:
        sc = ev.get("score") or {}
        s1, s2 = str(sc.get("scoreOne") or "").strip(), str(sc.get("scoreTwo") or "").strip()
        score = None
        if sport == "tenis":
            # scoreOne/scoreTwo en tenis pueden traer sets "6:4 2:1" -> dejamos lo que haya
            score = (sc.get("score") or (f"{s1}-{s2}" if s1 and s2 else None)) or None
        elif s1 != "" and s2 != "":
            s1 = s1.split(":")[0].strip() if " : " in s1 else s1
            s2 = s2.split(":")[0].strip() if " : " in s2 else s2
            score = f"{s1}:{s2}"
        st = (ev.get("liveStatus") or "").strip()
        period = {"1. tiempo": "1ª parte", "1er tiempo": "1ª parte", "primer tiempo": "1ª parte", "2. tiempo": "2ª parte",
                  "2º tiempo": "2ª parte", "segundo tiempo": "2ª parte", "descanso": "Descanso", "medio tiempo": "Descanso",
                  "tiempo extra": "Prórroga", "prórroga": "Prórroga", "penaltis": "Penaltis", "primer cuarto": "Q1",
                  "segundo cuarto": "Q2", "tercer cuarto": "Q3", "cuarto cuarto": "Q4", "1er set": "Set 1", "2º set": "Set 2",
                  "3er set": "Set 3", "4º set": "Set 4", "5º set": "Set 5"}.get(st.lower(), st or None)
        gt = (ev.get("gameTime") or "").replace("´", "").replace("'", "").strip()
        timer = f"{gt}:00" if gt.isdigit() else (gt or None)
        return score, period, timer

    def _row_from_event(self, ev: dict, kind: str, sport: str, comp: str, markets: list[tuple[str | None, str, dict]]) -> dict | None:
        home, away = self._teams(ev)
        if not home or not away:
            return None
        sels: list[dict] = []
        for key, tname, m in markets:
            sels.extend(market_selections(key, tname, m, sport, home, away))
        if not sels:
            return None
        dt = None
        try:
            dt = datetime.fromisoformat((ev.get("startFromUtc") or "").replace("Z", "+00:00")).astimezone()
        except Exception:  # noqa: BLE001
            pass
        if kind != "live" and dt and dt - datetime.now(dt.tzinfo) > timedelta(hours=self.cfg.get("prematch_hours", 48)):
            return None
        eid = str(ev["id"])
        url = f"{self.base}/es/apuestas-deportivas/live/event/{eid}" if kind == "live" else f"{self.base}/es/apuestas-deportivas/e/{eid}/x"
        row = {"event_id": eid, "home": home, "away": away, "competition": comp,
               "date": dt.strftime("%Y-%m-%d") if dt else None, "start_time": dt.strftime("%H:%M") if dt else None,
               "url": url, "selections": sels}
        if kind == "live":
            score, period, timer = self._state(ev, sport)
            row.update(score=score, period=period, timer=timer)
        return row

    @staticmethod
    def _event_markets(evfull: dict) -> list[tuple[str | None, str, dict]]:
        """(templateKey, templateName, market) de un evento completo (templateGroups) o en directo (liveGroups)."""
        out = []
        for g in evfull.get("templateGroups") or []:
            for t in g.get("templates") or []:
                for m in t.get("markets") or []:
                    out.append((t.get("key") or t.get("id"), t.get("name") or "", m))
        for g in evfull.get("liveGroups") or []:
            for m in g.get("markets") or []:
                out.append((None, g.get("name") or "", m))
        if not out and evfull.get("mainMarket"):
            out.append((None, "", evfull["mainMarket"]))
        return out

    # ── directo ──
    def live_cycle(self) -> tuple[int, int]:
        if self.hub is not None and self.hub.healthy():
            self.transport = "websocket"
            return self._live_cycle_hub()
        if self.hub is not None and (not self.http_enabled or (time.time() - self.hub.started < 30 and not self.hub.connected)):
            self.transport = "websocket"
            return 0, 0                                   # arrancando (o modo solo-websocket): espera al hub
        self.transport = "browser" if self._via_browser else "requests"
        return self._live_cycle_http()

    def _live_cycle_hub(self) -> tuple[int, int]:
        rows = changed = 0
        present: set[str] = set()
        events, markets = self.hub.snapshot()
        resnap = self.cfg.get("live_resnap", 60)
        by: list[tuple[str, dict]] = []
        now = time.time()
        for eid, e in events.items():
            if e.get("_new") or not e.get("sport"):
                continue
            sport = self.sports.get((e.get("sport") or {}).get("id"))
            if not sport:
                continue
            st = ((e.get("status") or {}).get("text") or "").lower()
            if "final" in st or e.get("isDeleted"):
                continue
            ev = hub_event_to_http(e)
            hit = self._league_of(ev, sport)
            if not hit:
                continue
            mk = markets.get(eid)
            if mk is None or now - self.hub.snap_at.get(eid, 0) > resnap:
                self.hub.request_snapshot(eid)
            if not mk:
                continue
            mlist = [(None, m.get("_group") or "", hub_market_to_http(m)) for m in mk.values()]
            r = self._row_from_event(ev, "live", hit[0], hit[1], mlist)
            if r:
                by.append((hit[0], r))
        for sp in {x[0] for x in by}:
            rs = [r for s2, r in by if s2 == sp]
            present |= {r["event_id"] for r in rs}
            changed += self.store.save_rows(sp, "live", rs)
            rows += len(rs)
        self.store.sweep(present, "live")
        return rows, changed

    def _live_cycle_http(self) -> tuple[int, int]:
        rows = changed = 0
        present: set[str] = set()
        now = time.time()
        every = self.cfg.get("live_detail_every", 6)
        for sid, sport in self.sports.items():
            try:
                data = self.get_json(f"/v2/es/web/sportsbook/live/overview/tab?tab={sid}&countryId=ESP")
            except Exception as e:  # noqa: BLE001
                if "bloqueo" in str(e):
                    raise
                log.warning("live %s: %s", sport, e)
                continue
            by: list[dict] = []
            for s in data.get("sports") or []:
                for lg in s.get("leagues") or []:
                    for ev in lg.get("events") or []:
                        if not ev.get("isLive"):
                            continue
                        lid = (lg.get("league") or {}).get("id")
                        ev.setdefault("leagueId", lid)
                        ev.setdefault("leagueName", (lg.get("league") or {}).get("name"))
                        hit = self._league_of(ev, sport)
                        if not hit:
                            continue
                        eid = str(ev["id"])
                        markets = self._event_markets(ev)
                        # detalle completo (todos los mercados) cada `every` s, en segundo plano
                        if now - self._live_detail_at.get(eid, 0) >= every and eid not in self._live_pending:
                            self._live_pending.append(eid)
                        if eid in self._live_score and not (ev.get("score") or {}).get("scoreOne"):
                            ev["score"] = self._live_score[eid]
                        cached = self._live_cache.get(eid)
                        if cached:
                            seen = {m["id"] for _k, _n, m in markets}
                            markets = markets + [x for x in cached if x[2].get("id") not in seen]
                        r = self._row_from_event(ev, "live", hit[0], hit[1], markets)
                        if r:
                            by.append((hit[0], r))
            for sp in {x[0] for x in by}:
                rs = [r for s2, r in by if s2 == sp]
                present |= {r["event_id"] for r in rs}
                changed += self.store.save_rows(sp, "live", rs)
                rows += len(rs)
        self.store.sweep(present, "live")
        if self._live_pending and not self._live_bg.busy():
            eid = self._live_pending.pop(0)
            self._live_detail_at[eid] = time.time()
            self._live_bg.run(lambda e=eid: self._fetch_live_detail(e))
        for eid in list(self._live_cache):
            if eid not in present:
                self._live_cache.pop(eid, None)
                self._live_detail_at.pop(eid, None)
                self._live_score.pop(eid, None)
        return rows, changed

    def _fetch_live_detail(self, eid: str):
        try:
            d = self.get_data(f"/es/apuestas-deportivas/live/event/{eid}")
            evf = (find_key(d, "liveEventResponse") or {}).get("event") or {}
            if evf.get("liveGroups"):
                self._live_cache[eid] = self._event_markets(evf)
                if evf.get("score"):
                    self._live_score[eid] = evf["score"]
        except Exception as e:  # noqa: BLE001
            log.debug("detalle live %s: %s", eid, e)
            if "bloqueo" in str(e):
                time.sleep(30)
        return None

    # ── pre-partido ──
    def prematch_league(self, lid: int) -> tuple[int, int]:
        sport, comp = self.leagues[lid]
        d = self.get_data(f"/es/apuestas-deportivas/l/{lid}/x")
        lld = find_key(d, "leagueListData") or {}
        ids: list[int] = []
        evs: dict[int, dict] = {}
        for grp in lld.get("leaguesGroupedByTemplate") or []:
            for lg in grp.get("leagues") or []:
                for t in lg.get("templates") or []:
                    for item in t.get("events") or []:
                        ev = item.get("event") or {}
                        if ev.get("id") and not ev.get("isLive"):
                            evs.setdefault(ev["id"], ev)
        if not evs:   # estructura alternativa: lista plana de eventos
            for ev in (find_key(d, "events") or []):
                if isinstance(ev, dict) and ev.get("id"):
                    evs.setdefault(ev["id"], ev)
        ids = list(evs)
        rows: list[dict] = []
        horizon = timedelta(hours=self.cfg.get("prematch_hours", 48))
        for eid in ids:
            ev = evs[eid]
            try:
                dt = datetime.fromisoformat((ev.get("startFromUtc") or "").replace("Z", "+00:00")).astimezone()
                if dt - datetime.now(dt.tzinfo) > horizon:
                    continue
            except Exception:  # noqa: BLE001
                pass
            try:
                d2 = self.get_data(f"/es/apuestas-deportivas/e/{eid}/x")
                evf = (find_key(d2, "templateGroups") is not None and find_key(d2, "event")) or {}
                if isinstance(evf, dict) and isinstance(evf.get("event"), dict):
                    evf = evf["event"]
                if not isinstance(evf, dict) or not evf.get("templateGroups"):
                    evf = dict(ev)
                evf.setdefault("name", ev.get("name"))
                evf.setdefault("startFromUtc", ev.get("startFromUtc"))
                r = self._row_from_event(evf, "prematch", sport, comp, self._event_markets(evf))
                if r:
                    rows.append(r)
            except Exception as e:  # noqa: BLE001
                if "bloqueo" in str(e):
                    raise
                log.warning("evento %s: %s", eid, e)
        self._pm_present |= {r["event_id"] for r in rows}
        return len(rows), (self.store.save_rows(sport, "prematch", rows) if rows else 0)

    def _pm_job(self, t0: float, once: bool):
        if not self._pm_queue and t0 - self._last_prematch >= self.cfg.get("interval_prematch", 300):
            self._pm_queue = list(self.leagues)
            self._pm_present = set()
            self._pm_rows = self._pm_changed = 0
            self._last_prematch = t0
        if not self._pm_queue:
            return None
        batch = len(self._pm_queue) if once else max(1, self.cfg.get("prematch_batch", 3))
        chunk, self._pm_queue = self._pm_queue[:batch], self._pm_queue[batch:]

        def _run():
            for lid in chunk:
                try:
                    r, c = self.prematch_league(lid)
                    self._pm_rows += r
                    self._pm_changed += c
                except Exception as e:  # noqa: BLE001
                    log.warning("prematch liga %s: %s", lid, e)
                    if "bloqueo" in str(e):
                        time.sleep(30)
            if not self._pm_queue:
                self.store.sweep(self._pm_present, "prematch")
                return f"prematch {self._pm_rows} ev / {self._pm_changed} cambios (pasada completa)"
            return f"prematch {self._pm_rows} ev / {self._pm_changed} cambios ({len(self._pm_queue)} ligas pendientes)"
        return _run

    def run(self, once: bool = False):
        backoff = 2
        if once and self.hub is not None:
            t0 = time.time()
            while not self.hub.events and time.time() - t0 < 10:
                time.sleep(0.3)
        while True:
            t0 = time.time()
            try:
                self._reload_if_changed()
                if self.http_enabled:
                    self.refresh_menu()
                rows, changed = self.live_cycle()
                msg = f"live {rows} ev / {changed} cambios"
                if self.http_enabled and not self._bg.busy():
                    job = self._pm_job(t0, once)
                    if job is not None:
                        r = self._bg.run(job, inline=once)
                        if r:
                            msg += " | " + r
                note = self._bg.note()
                if note:
                    msg += " | " + note
                self.store.set_status(**{f"{self.bk}_last_ok": time.time(), f"{self.bk}_live_events": rows,
                                         f"{self.bk}_transport": self.transport})
                log.info("%s [%s] (%.1fs)", msg, self.transport, time.time() - t0)
                backoff = 2
                if once:
                    return
            except Exception as e:  # noqa: BLE001
                if "bloqueo" in str(e):
                    backoff = max(backoff, 60)
                log.warning("error de ciclo: %s — reintento en %ss", e, backoff, exc_info=log.isEnabledFor(logging.DEBUG))
                self.store.set_status(**{f"{self.bk}_last_error": f"{time.time():.0f} {e}"})
                time.sleep(backoff)
                backoff = min(backoff * 2, 180)
                continue
            time.sleep(max(0.5, self.cfg.get("interval_live", 3) - (time.time() - t0)))


# ───────────────────────── CLI ─────────────────────────
def list_catalog(c: Collector):
    c.refresh_menu(force=True)
    by: dict[str, list] = {}
    for sport, lid, label in sorted(set(c._all), key=lambda x: (x[0], x[2])):
        by.setdefault(sport, []).append((lid, label))
    for sport, items in by.items():
        print(f"\n=== {sport}")
        for lid, label in items:
            comp = c.leagues.get(lid)
            print(f" {'✔' if comp else ' '} {label}   [{lid}]" + (f" -> {comp[1]}" if comp else ""))
    print(f"\n{len(c.leagues)} ligas mapeadas")


def dump_event(c: Collector, eid: str):
    c.refresh_menu(force=True)
    live = "--live" in sys.argv
    d = c.get_data(f"/es/apuestas-deportivas/live/event/{eid}" if live else f"/es/apuestas-deportivas/e/{eid}/x")
    if live:
        evf = (find_key(d, "liveEventResponse") or {}).get("event") or {}
    else:
        evf = find_key(d, "templateGroups") is not None and find_key(d, "event") or {}
        if isinstance(evf, dict) and isinstance(evf.get("event"), dict):
            evf = evf["event"]
    if not evf:
        print("sin datos (¿id correcto? prueba con --live si está en directo). Claves:", list((d or {}).keys())[:10])
        return
    sport = c.sports.get(evf.get("sportId"), "futbol")
    home, away = c._teams(evf)
    print(evf.get("name"), "|", evf.get("leagueName"), "|", evf.get("startFromUtc"), "| live:", evf.get("isLive"), evf.get("liveStatus"), evf.get("score"))
    for key, tname, m in c._event_markets(evf):
        sels = market_selections(key, tname, m, sport, home, away)
        print(f"{str(key or '-'):<18} {tname[:30]:<30} {m.get('name', '')[:42]:<42} -> "
              + (", ".join(f"{s['market']} {s.get('player') or ''} {s['selection']} {s.get('line') if s.get('line') is not None else ''} @{s['price']}" for s in sels) or "(sin mapear)"))


def probe(c: Collector):
    for path in ("/es/apuestas-deportivas/top-leagues/country?topLinkId=14", "/es/apuestas-deportivas/l/1030/x"):
        try:
            d = c.get_data(path)
            print("OK  ", path, "->", list(d.keys())[:6] if isinstance(d, dict) else type(d).__name__,
                  "| navigation" if find_key(d, "navigation") else "", "| leagueListData" if find_key(d, "leagueListData") else "")
            if isinstance(d, dict) and "_err" in d or d is None:
                print("     RAW:", getattr(c, "_last_raw", "")[:300])
        except Exception as e:  # noqa: BLE001
            print("FAIL", path, e)
    try:
        d = c.get_data("/es/apuestas-deportivas/l/1030/x")
        ev = None
        for grp in (find_key(d, "leagueListData") or {}).get("leaguesGroupedByTemplate") or []:
            for lg in grp.get("leagues") or []:
                for t in lg.get("templates") or []:
                    for item in t.get("events") or []:
                        ev = ev or (item.get("event") or {}).get("id")
        if ev:
            t0 = time.time()
            d2 = c.get_data(f"/es/apuestas-deportivas/e/{ev}/x")
            print(f"OK   evento {ev} -> {c._last_mode} en {time.time() - t0:.1f}s | templateGroups:", bool(find_key(d2, "templateGroups")))
    except Exception as e:  # noqa: BLE001
        print("FAIL evento", e)
    try:
        j = c.get_json("/v2/es/web/sportsbook/live/overview/tab?tab=10&countryId=ESP")
        print("OK   live tab 10 ->", sum(len(l.get("events") or []) for s in j.get("sports") or [] for l in s.get("leagues") or []), "eventos")
    except Exception as e:  # noqa: BLE001
        print("FAIL live tab", e)


def probe_hub(c: Collector):
    """Muestra lo que llega por el websocket del directo y cómo se mapea (sin tocar la base de datos)."""
    if c.hub is None:
        c.hub = LiveHub(origin=c.base); c.hub.start()
    t0 = time.time()
    while not c.hub.events and time.time() - t0 < 20:
        time.sleep(0.5)
    events, _ = c.hub.snapshot()
    print(f"{len(events)} eventos en directo en el hub")
    for eid, e in events.items():
        sport = c.sports.get((e.get("sport") or {}).get("id"))
        ev = hub_event_to_http(e)
        hit = c._league_of(ev, sport) if sport else None
        print(f"  {eid} {sport or '-':<10} {ev['leagueName'] or '':<40} {ev['name'][:45]:<45} -> {hit[1] if hit else '(fuera del catálogo)'}")
        if hit or ("--all" in sys.argv and sport):
            c.hub.request_snapshot(eid)
    time.sleep(8)
    events, markets = c.hub.snapshot()
    for eid, mk in markets.items():
        e = events.get(eid) or {}
        sport = c.sports.get((e.get("sport") or {}).get("id"))
        ev = hub_event_to_http(e)
        home, away = c._teams(ev)
        print(f"\n== {ev['name']} | {ev['liveStatus']} {ev['score']} | {len(mk)} mercados")
        for m in mk.values():
            hm = hub_market_to_http(m)
            sels = market_selections(None, m.get("_group") or "", hm, sport, home, away)
            print(f"  {(m.get('_group') or '')[:22]:<22} {hm['name'][:44]:<44} -> "
                  + (", ".join(f"{x['market']} {x.get('player') or ''} {x['selection']} {x.get('line') if x.get('line') is not None else ''} @{x['price']}" for x in sels) or "(sin mapear)"))


def main():
    logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"), format="%(asctime)s %(levelname)s %(name)s: %(message)s", datefmt="%H:%M:%S")
    cfg = pace.apply(json.loads(CFG_PATH.read_text(encoding="utf-8")))
    c = Collector(cfg)
    if "--list" in sys.argv:
        list_catalog(c)
    elif "--dump" in sys.argv:
        dump_event(c, sys.argv[sys.argv.index("--dump") + 1])
    elif "--probe" in sys.argv:
        probe(c)
    elif "--hub" in sys.argv:
        probe_hub(c)
    else:
        c.run(once="--once" in sys.argv)


if __name__ == "__main__":
    main()
