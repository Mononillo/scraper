"""
OddsSource: lee los cambios de cuota que escribe el scraper en odds.db y los pasa
al SignalEngine; cada Bet resultante entra en DistributionService.handle_bet().

Sustituye al antiguo forwarder de Telethon (BetBurger). Corre como job de
python-telegram-bot cada ODDS_POLL_SECONDS; la lectura de SQLite se hace en un hilo
para no bloquear el bucle de eventos.

También escribe data/forwarder_status.json (lo lee la Mini App en la pestaña de
administración) con el estado del scraper, para no tocar la Mini App.
"""
from __future__ import annotations

import asyncio
import re
import fastjson as json
import logging
import os
import sqlite3
import time
from datetime import datetime

from config import CONFIG
from services import collector_health
from services.signals import MiddleDetector, OddsChange, SignalEngine, SurebetDetector
from domain.bookmakers import CATALOG as BOOKMAKERS

log = logging.getLogger(__name__)

QUERY = """
SELECT h.id, h.ts, h.bookmaker, h.event_id, h.market_code, h.market, h.selection, h.line, h.player, h.price, h.prev_price,
       e.sport, e.competition, e.home, e.away, e.start_date, e.start_time, e.url, e.is_live, e.score, e.period
FROM odds_history h
LEFT JOIN events e ON e.bookmaker = h.bookmaker AND e.event_id = h.event_id
WHERE h.id > ?
ORDER BY h.id
LIMIT ?
"""
# Cambios que se leen de odds.db por consulta. El bucle de poll encadena lecturas mientras queden cambios, así que el
# tamaño solo acota la memoria y la latencia de cada lote (antes había un LIMIT 5000 fijo por segundo: techo de
# 5.000 cambios/s descontando el tiempo de los detectores, y con 25 casas en una noche de NBA se quedaba corto).
BATCH = max(1000, int(os.getenv("ODDS_BATCH", "20000") or 20000))
# Tiempo máximo seguido drenando cambios antes de ceder el turno a la salud/estado (el siguiente poll continúa).
DRAIN_MAX_S = float(os.getenv("ODDS_DRAIN_MAX_S", "20") or 20)


class OddsSource:
    def __init__(self, distribution, db_path: str | None = None):
        self._period_seen: dict = {}
        self.distribution = distribution
        import threading
        self._engine_lock = threading.Lock()
        self.db_path = db_path or CONFIG.odds_db_path
        self.last_id = 0
        self._started = False
        self.processed = 0
        self.signals = 0
        self.last_change_at: float | None = None
        self._health_state: dict[str, str] = {}      # casa -> último estado notificado (ok/down)
        self._health_alerted: dict[str, float] = {}  # casa -> epoch del último aviso de caída
        self._health_seen_ok: set[str] = set()       # casas que hemos visto funcionando en esta ejecución
        base_urls = {b.key: b.url for b in BOOKMAKERS.all()}
        detectors = []
        if CONFIG.surebet_detector_enabled:
            detectors.append(SurebetDetector(min_profit=CONFIG.surebet_detector_min_profit, base_urls=base_urls))
        if CONFIG.middle_enabled:
            detectors.append(MiddleDetector(max_loss_pct=CONFIG.middle_max_loss_pct, min_gap=CONFIG.middle_min_gap,
                                            base_urls=base_urls))
        self.engine = SignalEngine(detectors)
        # Detectores en proceso aparte (DETECTOR_PROCESS=1, por defecto): el bucle de Telegram no comparte GIL con
        # 2-6 s de CPU por lote. El proceso hijo crea su propio OddsSource(None, ...) y usa `_read` + `engine`.
        self._proc = None
        if distribution is not None and os.getenv("DETECTOR_PROCESS", "1").strip().lower() not in ("0", "false", "no"):
            from services.detector_proc import DetectorProcess
            self._proc = DetectorProcess(self.db_path)

    # ------------------------------------------------------------------
    def _connect(self):
        con = sqlite3.connect(self.db_path, timeout=5)
        con.row_factory = sqlite3.Row
        return con

    def _read(self, with_status: bool = True) -> tuple[list[OddsChange], dict]:
        if not os.path.exists(self.db_path):
            return [], {}
        con = self._connect()
        status: dict = {}
        try:
            if not self._started:
                # Al arrancar no reprocesamos todo el histórico: empezamos por lo de los últimos N minutos
                since = time.time() - 15 * 60
                row = con.execute("SELECT COALESCE(MAX(id),0) FROM odds_history WHERE ts < ?", (since,)).fetchone()
                self.last_id = row[0] if row else 0
                self._started = True
            rows = con.execute(QUERY, (self.last_id, BATCH)).fetchall()
            if with_status:
                status = {r["key"]: json.loads(r["value"]) for r in con.execute("SELECT key, value FROM scraper_status")}
                status["bookmakers"] = [r[0] for r in con.execute(
                    "SELECT bookmaker FROM events WHERE last_seen > ? GROUP BY bookmaker", (time.time() - 600,))]
        except sqlite3.OperationalError as e:        # tabla aún no creada, BD bloqueada...
            log.debug("odds.db no disponible: %s", e)
            return [], {}
        finally:
            con.close()
        changes = []
        for r in rows:
            self.last_id = r["id"]
            if r["prev_price"] is None:
                # primera vez que vemos la selección: alimenta el histórico pero no es un movimiento
                pass
            changes.append(OddsChange(
                ts=r["ts"], bookmaker=r["bookmaker"], event_id=r["event_id"], market_code=r["market_code"],
                market=r["market"] or "", selection=r["selection"] or "", line=r["line"], price=r["price"],
                prev_price=r["prev_price"], sport=r["sport"] or "", competition=r["competition"] or "",
                home=r["home"] or "", away=r["away"] or "", start_date=r["start_date"] or "",
                start_time=r["start_time"] or "", url=r["url"] or "", is_live=bool(r["is_live"]),
                score=self._score(r["score"]), period=r["period"] or "", player=r["player"] or ""))
        return changes, status

    @staticmethod
    def _score(raw) -> str:
        if not raw:
            return ""
        try:
            v = json.loads(raw)
            return "-".join(str(x) for x in v) if isinstance(v, list) else str(v)
        except Exception:
            return str(raw)

    # ------------------------------------------------------------------
    async def poll(self, ctx=None):
        if getattr(self, "_polling", False):          # el poll anterior sigue drenando: no solapar
            return
        self._polling = True
        t0 = time.time()
        status: dict = {}
        try:
            while True:
                # Se lee y procesa en lotes hasta ponerse al día (o hasta DRAIN_MAX_S): el ritmo lo marca la CPU, no
                # el intervalo del job. Dentro de cada lote primero el directo y después el pre-partido, para que
                # una pasada pre-partido de 50.000 cambios no retrase 30 s una surebet en vivo.
                if self._proc is not None:
                    res = await asyncio.to_thread(self._proc.request)            # lectura + detectores en el proceso hijo
                    status = res.get("status") or status
                    n = int(res.get("n") or 0)
                    if not n:
                        break
                    self.processed += n
                    self.last_change_at = time.time()
                    for is_live, bets, dt in res.get("parts") or []:
                        if dt > 2:
                            log.warning("detectores lentos: %.1fs (%s, proceso aparte)", dt, "live" if is_live else "prematch")
                        bets = [b for b in bets if self._plausible(b)]
                        if bets:
                            asyncio.create_task(self._confirm_and_send(bets))
                    if n < BATCH or time.time() - t0 > DRAIN_MAX_S:
                        break
                    await asyncio.sleep(0)
                    continue
                changes, status = await asyncio.to_thread(self._read, True)
                if not changes:
                    break
                self.processed += len(changes)
                self.last_change_at = time.time()
                live = [c for c in changes if c.is_live]
                pre = [c for c in changes if not c.is_live]
                for part in (live, pre):
                    if not part:
                        continue
                    t_eng = time.time()
                    bets = await asyncio.to_thread(self._process_locked, part)   # detectores fuera del bucle de eventos (no bloquea Telegram)
                    dt = time.time() - t_eng
                    if dt > 2:
                        log.warning("detectores lentos: %.1fs para %d cambios (%s)", dt, len(part), "live" if part is live else "prematch")
                    bets = [b for b in bets if self._plausible(b)]
                    if bets:                                                     # confirmación + envío en segundo plano: el poll no se bloquea
                        asyncio.create_task(self._confirm_and_send(bets))
                if len(changes) < BATCH or time.time() - t0 > DRAIN_MAX_S:
                    break
                await asyncio.sleep(0)                                           # cede el turno a Telegram entre lotes
        finally:
            self._polling = False
        self._write_status(status)
        if status:
            try:
                await self._check_health(status)
            except Exception as e:                                       # noqa: BLE001
                log.debug("health: %s", e)

    # ------------------------------------------------------------------
    async def _check_health(self, status: dict):
        """Avisa a los administradores por Telegram cuando una casa se cae (y cuando vuelve).

        Solo se avisa de casas que han funcionado en esta ejecución del bot o que estaban vivas hace
        menos de 1 h (así las casas apagadas a propósito con `--only` no generan ruido).  Mientras siga
        caída se recuerda cada 6 h."""
        now = time.time()
        for c in collector_health.evaluate(status, now):
            k = c["key"]
            if c["state"] == "ok":
                self._health_seen_ok.add(k)
                if self._health_state.get(k) == "down":
                    await self._notify_admins(f"✅ <b>{c['name']}</b> vuelve a funcionar "
                                              f"({c['live'] or 0} eventos en directo).")
                self._health_state[k] = "ok"
                continue
            if c["state"] != "down":
                continue
            if k not in self._health_seen_ok and (c["age_s"] or 0) > 3600:
                continue                                                 # apagada a propósito / nunca arrancó
            last = self._health_alerted.get(k, 0)
            if self._health_state.get(k) == "down" and now - last < 6 * 3600:
                continue
            mins = int((c["age_s"] or 0) // 60)
            txt = (f"⛔ <b>{c['name']} caída</b> — sin cuotas desde hace {mins} min.\n"
                   f"Causa probable: {collector_health.CAUSE_TEXT.get(c['cause'], c['cause'])}")
            if c["error"]:
                txt += f"\nÚltimo error: <code>{c['error'][:160]}</code>"
            if c["cause"] == "structure":
                txt += ("\n\nQué hacer: comprueba que la web carga en tu navegador; si carga, apaga esa casa "
                        "(run_all.py --only con las demás) y mándame el log + un HAR de la web.")
            await self._notify_admins(txt)
            self._health_state[k] = "down"
            self._health_alerted[k] = now

    async def _notify_admins(self, text: str, reply_markup=None):
        ids = {CONFIG.admin_id} | set(CONFIG.admin_ids or ())
        admins = getattr(self.distribution, "admins", None)
        if admins is not None:
            try:
                ids |= set(admins.owners()) | set(admins.extra())
            except Exception:                                            # noqa: BLE001
                pass
        bot = getattr(self.distribution, "bot", None)
        for uid in ids:
            if not uid or bot is None:
                continue
            try:
                await bot.send_message(chat_id=uid, text=text, parse_mode="HTML", disable_web_page_preview=True,
                                       reply_markup=reply_markup)
            except Exception as e:                                       # noqa: BLE001
                log.warning("No pude avisar al admin %s: %s", uid, e)

    def _process_locked(self, changes):
        with self._engine_lock:
            return self.engine.process(changes)

    async def _confirm_and_send(self, bets: list):
        try:
            t0 = time.time()
            for b in bets:
                b._detected_at = t0
            if CONFIG.signal_confirm_seconds > 0:                         # la cuota debe aguantar unos segundos
                await asyncio.sleep(CONFIG.signal_confirm_seconds)
            bets = await asyncio.to_thread(self._verify_all, bets)
            if not bets:
                return
            self.signals += len(bets)
            # Todas las señales del lote salen A LA VEZ (antes una detrás de otra: la 3ª surebet esperaba a que la
            # 1ª y la 2ª terminaran de enviarse a todos los usuarios). Dentro de handle_bet los envíos a cada
            # usuario ya van en paralelo (MAX_PARALLEL_SENDS), así que todos reciben la señal en la misma ventana.
            results = await asyncio.gather(*(self.distribution.handle_bet(b) for b in bets), return_exceptions=True)
            for bet, r in zip(bets, results):
                if isinstance(r, Exception):
                    log.warning("No pude distribuir %s: %s", bet.game, r)
        except Exception as e:                                           # noqa: BLE001
            log.warning("confirmación de señales falló: %s", e)

    # ------------------------------------------------------------------
    # Calidad de la señal: beneficio creíble + re-verificación contra odds.db justo antes de enviar
    def _plausible(self, bet) -> bool:
        if bet.is_surebet and CONFIG.surebet_max_profit > 0 and bet.profit_pct > CONFIG.surebet_max_profit:
            log.warning("surebet descartada por beneficio inverosímil (%.1f%%): %s | %s | %s", bet.profit_pct, bet.game, bet.market,
                        "; ".join(f"{l.bookmaker_key} {l.market_code} @{l.odds}" for l in bet.lines))
            return False
        # cuotas fuera de rango en mercados de partido (p. ej. "60" por "2,60" mal leído): no se envía
        for l in bet.lines:
            mc = (l.market_code or "").split("|")[0]
            sp = (str(getattr(bet, "sport_key", "") or "") + " " + str(getattr(bet, "sport", "") or "")).lower()
            if ("tenis" in sp or "tennis" in sp) and re.match(r"POINTS(_HOME|_AWAY)?(_|$)", mc):
                log.info("señal descartada: 'puntos' en tenis es un mercado del juego en curso, no comparable entre casas: %s | %s", bet.game, bet.market)
                return False
            if "GOALS" in mc and ("balonc" in sp or "basket" in sp):
                log.warning("señal descartada: 'goles' en baloncesto (métrica mal mapeada): %s | %s", bet.game, bet.market)
                return False
            if not mc.startswith("PLAYER_") and l.odds is not None and (l.odds < 1.01 or l.odds > 50):
                log.warning("señal descartada: cuota %.2f fuera de rango en %s: %s | %s", l.odds, mc, bet.game,
                            "; ".join(f"{x.bookmaker_key} {x.market_code} @{x.odds}" for x in bet.lines))
                return False
        # líneas incoherentes con el mercado (señal de mapeo erróneo: total de equipo/cuarto tomado como total del partido)
        for l in bet.lines:
            mc = (l.market_code or "").split("|")[0]
            ln = l.line_value
            if ln is None:
                continue
            sport = (getattr(bet, "sport_key", "") or "").lower()
            bad = (("basket" in sport or "balonc" in sport) and (
                       (mc == "TOTAL" and ln < 120) or (mc in ("TOTAL_HOME", "TOTAL_AWAY") and not 50 <= ln <= 140)
                       or (mc in ("TOTAL_1H", "TOTAL_2H") and not 55 <= ln <= 130) or (mc.startswith("TOTAL_Q") and not 25 <= ln <= 75)))
            if "tenis" in sport or "tennis" in sport:
                bad = bad or ((mc == "TOTAL" and ln < 12) or (re.match(r"TOTAL_SET\d$", mc) and ln < 5.5)
                              or (mc in ("TOTAL_HOME", "TOTAL_AWAY") and ln < 5.5)
                              or (re.match(r"TOTAL_(HOME|AWAY)_SET\d$", mc) and ln < 1.5) or (mc == "SETS" and ln not in (2.5, 3.5, 4.5)))
            if bad:
                log.warning("señal descartada: línea %.1f incoherente con %s en %s: %s | %s", ln, mc, sport or "?", bet.game,
                            "; ".join(f"{x.bookmaker_key} {x.market_code} @{x.odds}" for x in bet.lines))
                return False
        return True

    def _verify_all(self, bets: list) -> list:
        if not os.path.exists(self.db_path):
            return bets
        con = self._connect()
        try:
            return [b for b in bets if self._verify(con, b)]
        except sqlite3.OperationalError as e:
            log.debug("verificación no disponible: %s", e)
            return bets
        finally:
            con.close()

    def _verify(self, con, bet) -> bool:
        """Cada pata debe seguir en odds_latest con la MISMA cuota (o mejor) y su casa debe haber refrescado el evento
        hace poco (live: ODDS_MAX_AGE_LIVE s; pre-partido: ODDS_MAX_AGE_PREMATCH s). Si la cuota bajó, se recalcula
        el beneficio de la surebet y se descarta si ya no llega al mínimo."""
        now = time.time()
        scores: list[tuple[str, str, str]] = []                 # (casa, deporte, marcador) de cada pata en directo
        # periodo más avanzado que reporta cualquiera de las casas de la señal (muchas no informan periodo;
        # si una dice "3er cuarto", los mercados de 1ª parte / 2º cuarto están muertos en todas)
        cur_max = None
        for l in bet.lines:
            if not l.event_id:
                continue
            evp = con.execute("SELECT period, is_live FROM events WHERE bookmaker=? AND event_id=?",
                              (l.bookmaker_key, l.event_id)).fetchone()
            if evp and evp[1]:
                c = self._cur_period(str(evp[0] or ""))
                if c is not None and (cur_max is None or c > cur_max):
                    cur_max = c
        key_p = (getattr(bet, "game", ""), getattr(bet, "sport", ""))
        if cur_max is not None:
            self._period_seen[key_p] = (cur_max, now)
        elif key_p in self._period_seen and now - self._period_seen[key_p][1] < 900:
            cur_max = self._period_seen[key_p][0]
        # marcador más detallado (por juegos) que tenga CUALQUIER casa de la señal: muchas solo dan sets ("1:1") y con
        # eso no se puede saber si una línea de juegos ya está decidida; con el de bwin ("3:6 7:6 4:5") sí.
        best_score = ""
        for l in bet.lines:
            if not l.event_id:
                continue
            evs = con.execute("SELECT score, is_live FROM events WHERE bookmaker=? AND event_id=?",
                              (l.bookmaker_key, l.event_id)).fetchone()
            sc = str((evs or [None])[0] or "")
            if evs and evs[1] and len(re.findall(r"\d+\s*[:\-]\s*\d+", sc)) > len(re.findall(r"\d+\s*[:\-]\s*\d+", best_score)):
                best_score = sc
        for l in bet.lines:
            if not l.event_id or not l.market_code:
                continue
            row = con.execute("SELECT price, seen_at, changed_at FROM odds_latest WHERE bookmaker=? AND event_id=? AND market_code=?",
                              (l.bookmaker_key, l.event_id, l.market_code)).fetchone()
            ev = con.execute("SELECT last_seen, is_live, score, sport, period, full_seen FROM events WHERE bookmaker=? AND event_id=?",
                             (l.bookmaker_key, l.event_id)).fetchone()
            if not row or row[0] is None or not ev:
                log.info("señal descartada: %s ya no ofrece %s en %s", l.bookmaker_key, l.market_code, bet.game)
                return False
            if ev[1] and self._settled(l, str(ev[3] or ""), str(ev[2] or ""), str(ev[4] or ""), cur_max):
                log.info("señal descartada: %s %s línea %s ya decidida/periodo terminado (marcador %s, periodo %s) en %s",
                         l.bookmaker_key, l.market_code, l.line_value, ev[2], ev[4], bet.game)
                return False
            sp_l = str(ev[3] or "")
            if ev[1] and best_score and best_score != str(ev[2] or "") and ("tenis" in sp_l or "tennis" in sp_l) \
                    and self._settled(l, sp_l, best_score, str(ev[4] or ""), cur_max):
                log.info("señal descartada: %s %s línea %s ya decidida según el marcador por juegos de otra casa (%s) en %s",
                         l.bookmaker_key, l.market_code, l.line_value, best_score, bet.game)
                return False
            max_age = CONFIG.odds_max_age_live if ev[1] else CONFIG.odds_max_age_prematch
            if ev[1] and ev[2] and not (("tenis" in str(ev[3] or "") or "tennis" in str(ev[3] or ""))
                                       and self._tennis_sets(str(ev[2])) is None):
                scores.append((l.bookmaker_key, str(ev[3] or ""), str(ev[2])))
            if now - (ev[0] or 0) > max_age:
                log.info("señal descartada: datos de %s con %.0fs de antigüedad (%s)", l.bookmaker_key, now - (ev[0] or 0), bet.game)
                return False
            # antigüedad de la PROPIA cuota (no del evento): en live una cuota que no se ha vuelto a ver en los últimos
            # segundos casi seguro ya ha cambiado cuando el usuario llega a la casa → live estricto
            # la selección sigue en odds_latest tras una pasada COMPLETA del evento (full_seen) => se vio en esa pasada
            # (las que desaparecen se retiran en la misma transacción); así el colector no tiene que reescribir seen_at
            # de cada selección en cada ciclo
            leg_age = now - max(float(row[1] or 0), float(row[2] or 0), float(ev[5] or 0))
            l._age = leg_age if ev[1] else None          # solo se muestra en live
            if ev[1] and CONFIG.surebet_live_max_leg_age > 0 and leg_age > CONFIG.surebet_live_max_leg_age:
                log.info("señal descartada: cuota live de %s vista hace %.0fs (> %.0fs) en %s", l.bookmaker_key, leg_age,
                         CONFIG.surebet_live_max_leg_age, bet.game)
                return False
            # precio congelado: en directo las cuotas se mueven continuamente (tiempo, puntos, goles); si una lleva
            # minutos sin cambiar mientras el partido avanza, la casa no está actualizando ese partido (precios
            # pre-partido con el evento ya marcado como live) y la "surebet" es contra una cuota fantasma
            frozen = now - float(row[2] or row[1] or now)
            if ev[1] and CONFIG.surebet_live_max_frozen > 0 and frozen > CONFIG.surebet_live_max_frozen:
                log.info("señal descartada: cuota live de %s sin cambiar desde hace %.0fs (> %.0fs) en %s", l.bookmaker_key,
                         frozen, CONFIG.surebet_live_max_frozen, bet.game)
                return False
            if abs(float(row[0]) - l.odds) > 1e-9:
                if bet.is_surebet:
                    l.odds = float(row[0])
                else:
                    log.info("señal descartada: cuota de %s cambió %.2f -> %.2f (%s)", l.bookmaker_key, l.odds, row[0], bet.game)
                    return False
        bet._scores = ", ".join(f"{bk} {sc}" for bk, _, sc in scores if sc)
        if not self._same_score(scores, bet):
            return False
        if not self._not_lagging(bet, scores):
            return False
        if bet.is_surebet and not self._coherent(con, bet):
            return False
        if bet.is_surebet:
            inv = sum(1.0 / l.odds for l in bet.lines if l.odds)
            if inv <= 0 or inv >= 1.0:
                log.info("señal descartada: la surebet ya no existe tras verificar (%s)", bet.game)
                return False
            profit = (1.0 / inv - 1.0) * 100.0
            if profit < CONFIG.surebet_detector_min_profit:
                return False
            bet.profit_pct = round(profit, 2)
            for l in bet.lines:
                l.provider_stake = float(round(100.0 / (l.odds * inv)))   # euros enteros
        return True

    @staticmethod
    def _cur_period(period: str) -> float | None:
        """Número de periodo en curso según el texto de la casa ('3er cuarto', 'Q2', '2ª parte', 'Set 2', 'Descanso'=1.5)."""
        per_txt = period.lower()
        if re.search(r"descanso|half ?time|medio tiempo|\bht\b|intermedio", per_txt):
            return 1.5
        mm = re.search(r"(?<![\d:.,])([1-5])(?![\d:.,])", per_txt)
        if mm and re.search(r"set|cuarto|quarter|mitad|parte|half|tiempo|periodo|period|\bq\d|\d[tph]\b|º|ª|er|nd|rd|th", per_txt):
            return float(mm.group(1))
        if re.search(r"segunda|second|2nd", per_txt):
            return 2.0
        if re.search(r"primera|first|1st", per_txt):
            return 1.0
        if re.search(r"prorroga|overtime|\bot\b", per_txt):
            return 9.0
        return None

    @staticmethod
    def _settled(l, sport: str, score: str, period: str, cur_max=None) -> bool:
        """En directo: una línea de más/menos ya superada por el marcador (Over 0.5 juegos del 1er set con 3 juegos
        jugados) o un mercado de un periodo ya terminado (total 1ª parte en la 2ª) es un mercado muerto cuya cuota
        se ha quedado colgada en alguna casa; nunca puede formar parte de una señal."""
        mc = (l.market_code or "").split("|")[0]
        m_per = re.search(r"_(1H|2H|Q[1-4]|SET[1-5])(?:_|$)", mc)
        cur = OddsSource._cur_period(period)
        if cur_max is not None and (cur is None or cur_max > cur):
            cur = cur_max
        if m_per and cur is not None:
            want = m_per.group(1)
            basket = "balon" in sport or "basket" in sport
            if want == "1H":
                n = 2 if basket else 1          # en baloncesto la 1ª parte acaba con el 2º cuarto
            elif want == "2H":
                n = 4 if basket else 2
            else:
                n = int(want[-1])
            if n < cur:
                return True                                   # periodo del mercado ya terminado (también props de jugador)
        if mc.startswith("PLAYER_"):
            return False
        ln = l.line_value
        if "tenis" in sport or "tennis" in sport:
            # Solo con marcador por sets en juegos ("6:4 4:3", "6-4, 4-3"): total de juegos de un set ya decidido.
            # 28-10 22:48: Herea-Monnet TOTAL_SET1 Under 8.5 @3.00 (betway) con el set 4-3 → el set acaba como
            # mínimo 6-3 (9 juegos): línea muerta.
            pairs = re.findall(r"(\d+)\s*[:\-]\s*(\d+)", score or "")
            if ln is None or len(pairs) < 2:
                return False
            pairs = [(int(a), int(b)) for a, b in pairs]
            m_set = re.search(r"_SET([1-5])(?:_|$)", mc)
            if m_set and mc.startswith("TOTAL"):
                n = int(m_set.group(1))
                if n > len(pairs):
                    return False
                a, b = pairs[n - 1]
                if n < len(pairs) and (a + b) > 0 and not re.search(r"-:-", score):
                    return True                               # set ya terminado (hay otro posterior en el marcador)
                lo, hi = min(a, b), max(a, b)
                if (hi >= 6 and hi - lo >= 2) or hi == 7:
                    return True                               # set terminado
                min_final = 6 + lo if lo <= 4 else 12
                return ln < min_final                         # el Over es seguro / el Under imposible
            if mc == "TOTAL":
                return ln < sum(a + b for a, b in pairs)      # juegos del partido ya por encima de la línea
            # 30-10 00:27: Shelton-Kym "3:6 7:6 4:5" → sportium TOTAL_HOME Over 12.5 @6.75 con 14 juegos ya ganados
            if mc == "TOTAL_HOME":
                return ln < sum(a for a, _ in pairs)
            if mc == "TOTAL_AWAY":
                return ln < sum(b for _, b in pairs)
            return False
        if ln is None and mc not in ("BTTS", "TTS_HOME", "TTS_AWAY"):
            return False
        if m_per:
            return False                                      # el marcador es acumulado; no sabemos el parcial del periodo
        nums = [int(x) for x in re.findall(r"\d+", score)]
        if len(nums) < 2:
            return False
        h, a = nums[0], nums[1]
        if mc == "BTTS":
            return h > 0 and a > 0
        if mc == "TTS_HOME":
            return h > 0
        if mc == "TTS_AWAY":
            return a > 0
        if mc == "TOTAL" and ln < h + a:
            return True
        if mc == "TOTAL_HOME" and ln < h:
            return True
        if mc == "TOTAL_AWAY" and ln < a:
            return True
        return False

    def _not_lagging(self, bet, scores: list) -> bool:
        """Memoria del marcador más avanzado visto para cada partido (todas las casas que han pasado por aquí).
        Si la casa de una pata va por detrás de ese marcador (p. ej. Sportium 31-31 cuando otra casa ya dio 39-38),
        su feed está retrasado y sus cuotas son viejas aunque la otra pata no traiga marcador para compararlo."""
        try:
            from services.signals import _MATCHER
        except Exception:                                                # noqa: BLE001
            return True
        ref = getattr(self, "_score_ref", None)
        if ref is None:
            ref = self._score_ref = {}
        now = time.time()
        ok = True
        for bk, sport, sc in scores:
            if "tennis" in sport or "tenis" in sport:
                continue
            nums = re.findall(r"\d+", sc)
            if len(nums) < 2:
                continue
            total = int(nums[0]) + int(nums[1])
            key = None
            for l in bet.lines:
                if l.bookmaker_key == bk:
                    key = _MATCHER._cache.get((bk, l.event_id))
                    break
            if not key:
                continue
            tol = 2 if ("basket" in sport or "balonc" in sport) else 0
            prev = ref.get(key)
            if prev and now - prev[1] < 900 and prev[0] - total > tol:
                log.info("señal descartada: %s va con retraso (marcador %s; %s ya dio %s hace %.0fs) en %s",
                         bk, sc, prev[3], prev[2], now - prev[1], bet.game)
                ok = False
            if not prev or total >= prev[0]:
                ref[key] = (total, now, sc, bk)
        if len(ref) > 5000:
            for k in [k for k, v in ref.items() if now - v[1] > 3600]:
                ref.pop(k, None)
        return ok

    @staticmethod
    def _tennis_sets(sc: str) -> tuple[int, int] | None:
        """Sets ganados (local, visitante) a partir del marcador de tenis en cualquiera de los formatos de las
        casas: "1:0" (sets), "6:4 3:2" / "2:2 -:- -:-" (juegos por set), "6-4, 3-2". Un set cuenta como ganado
        con >=6 juegos y 2 de ventaja, o 7 juegos (tie-break). Se ignora el set en curso."""
        pairs = re.findall(r"(\d+)\s*[:\-]\s*(\d+)", sc or "")
        if not pairs:
            return None
        pairs = [(int(a), int(b)) for a, b in pairs]
        st = OddsSource._tennis_state(sc, pairs)
        return st[:2] if st else None

    @staticmethod
    def _tennis_state(sc: str, pairs: list) -> tuple | None:
        """(sets_local, sets_visit, juegos_local, juegos_visit) del set en curso; los juegos van a None cuando el
        formato no los da ("1:0" = solo sets)."""
        if len(pairs) == 1:
            a, b = pairs[0]
            if a in (15, 30, 40) or b in (15, 30, 40) or re.search(r"\bA\b", sc or ""):
                return None                        # puntos del juego (40:40, 15:30, A:40): no dice nada de sets
            if re.search(r"-:-|:-|-:", sc):
                if (a >= 6 and a - b >= 2) or a == 7:
                    return (1, 0, 0, 0)            # "6:4 -:- -:-": 1er set cerrado, el 2º aún sin juegos
                if (b >= 6 and b - a >= 2) or b == 7:
                    return (0, 1, 0, 0)
                return (0, 0, a, b)                # "2:2 -:- -:-": juegos por set, solo el 1º en curso → 0:0 en sets
            if a <= 3 and b <= 3:
                return (a, b, None, None)          # formato "sets ganados" (0:0, 1:0, 2:1…)
            return (None, None, a, b)              # un único par >3 (1:4, 5:3): juegos del set en curso, sets desconocidos
        h = a_ = 0
        for a, b in pairs:
            if (a >= 6 and a - b >= 2) or a == 7:
                h += 1
            elif (b >= 6 and b - a >= 2) or b == 7:
                a_ += 1
        ga, gb = pairs[-1]
        if (ga >= 6 and ga - gb >= 2) or ga == 7 or (gb >= 6 and gb - ga >= 2) or gb == 7:
            ga = gb = 0                            # el último set ya está cerrado: el siguiente empieza 0-0
        return (h, a_, ga, gb)

    @staticmethod
    def _same_score(scores: list, bet) -> bool:
        """En directo todas las casas deben ir por el mismo marcador: si una va 1-0 y otra 1-1, la de 1-0 tiene la
        cuota congelada/suspendida (acaba de haber gol) y la "surebet" es un espejismo. Fútbol: igualdad exacta;
        baloncesto: tolerancia de 2 puntos (las casas refrescan con segundos de diferencia); tenis: sets ganados."""
        parsed = []
        games = []
        for bk, sport, sc in scores:
            if "tennis" in sport or "tenis" in sport:
                pairs = [(int(x), int(y)) for x, y in re.findall(r"(\d+)\s*[:\-]\s*(\d+)", sc or "")]
                st = OddsSource._tennis_state(sc, pairs) if pairs else None
                if not st:
                    continue
                if st[0] is not None:
                    parsed.append((bk, st[0], st[1]))
                if st[2] is not None:
                    games.append((bk, st[2], st[3]))
                continue
            nums = re.findall(r"\d+", sc)
            if len(nums) >= 2:
                parsed.append((bk, int(nums[0]), int(nums[1])))
        if len(games) >= 2:                        # tenis: juegos del set en curso (1 juego de tolerancia por el refresco)
            gh = [g[1] for g in games]
            ga = [g[2] for g in games]
            if max(gh) - min(gh) > 1 or max(ga) - min(ga) > 1:
                log.info("señal descartada: juegos del set distintos entre casas (%s) en %s",
                         ", ".join(f"{bk} {x}-{y}" for bk, x, y in games), bet.game)
                return False
        if len(parsed) < 2:
            return True
        tol = 2 if any("basket" in sp or "balonc" in sp for _, sp, _ in scores) else 0   # 3-4 puntos de retraso ya mueven la línea 5 puntos
        h = [p[1] for p in parsed]
        a = [p[2] for p in parsed]
        if max(h) - min(h) > tol or max(a) - min(a) > tol:
            log.info("señal descartada: marcadores distintos entre casas (%s) en %s",
                     ", ".join(f"{bk} {x}-{y}" for bk, x, y in parsed), bet.game)
            return False
        return True

    @staticmethod
    def _fair_prob(con, l) -> float | None:
        """Probabilidad sin margen que la propia casa asigna a la selección de la pata (normalizando con sus
        selecciones complementarias: Más/Menos de la misma línea, 1/X/2, Sí/No, hándicap espejo)."""
        try:
            market, player, line, sel = l.market_code.split("|", 3)
        except ValueError:
            return None
        rows = con.execute("SELECT market_code, price FROM odds_latest WHERE bookmaker=? AND event_id=? AND market_code LIKE ? "
                           "AND price IS NOT NULL", (l.bookmaker_key, l.event_id, f"{market}|{player}|%")).fetchall()
        mirror = ""
        if sel in ("1", "2") and line not in ("", None):
            try:
                mirror = f"{-float(line):g}"
            except ValueError:
                mirror = ""
        group = {}
        for mc, price in rows:
            try:
                _, _, ln, sl = mc.split("|", 3)
            except ValueError:
                continue
            if ln == line or (mirror and ln == mirror and sl != sel):
                group[sl] = float(price)
        group[sel] = l.odds
        inv = sum(1.0 / o for o in group.values() if o and o > 1.0)
        if len(group) < 2 or inv <= 0:
            return 1.0 / l.odds if l.odds else None            # sin complementaria (props "Anotará"): prob bruta
        return (1.0 / l.odds) / inv

    def _coherent(self, con, bet) -> bool:
        probs = [self._fair_prob(con, l) for l in bet.lines if l.event_id and l.market_code]
        if len(probs) != len(bet.lines) or any(p is None for p in probs):
            return True
        gap = abs(sum(probs) - 1.0)
        if CONFIG.surebet_max_prob_gap > 0 and gap > CONFIG.surebet_max_prob_gap:
            log.warning("surebet descartada por incoherencia (probabilidades suman %.2f): %s | %s | %s", sum(probs), bet.game, bet.market,
                        "; ".join(f"{l.bookmaker_key} {l.market_code} @{l.odds} (p={p:.2f})" for l, p in zip(bet.lines, probs)))
            return False
        return True

    def _write_status(self, scraper_status: dict):
        """Misma ruta/forma que usaba el forwarder para que la Mini App lo muestre sin cambios."""
        try:
            path = os.path.join(os.path.dirname(CONFIG.db_path) or ".", "forwarder_status.json")
            last_run = scraper_status.get("last_run")
            alive = False
            if last_run:
                try:
                    dt = datetime.fromisoformat(last_run.replace("Z", "+00:00"))
                    alive = (time.time() - dt.timestamp()) < 120
                except Exception:
                    alive = False
            data = {
                "available": True, "running": alive, "connected": alive,
                "source": "odds.db (" + "+".join(sorted(scraper_status.get("bookmakers", []) or ["winamaxes", "paston"])) + ")", "msg_count": self.processed, "signals": self.signals,
                "last_msg_at": self.last_change_at, "scraper": scraper_status,
                "sources": [f"scraper ({scraper_status.get('targets', '?')} targets, pasada {scraper_status.get('elapsed_s', '?')}s)"],
            }
            tmp = path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump(data, fh, ensure_ascii=False)
            os.replace(tmp, path)
        except Exception as e:                                           # noqa: BLE001
            log.debug("No pude escribir el estado: %s", e)
