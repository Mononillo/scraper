"""
bet777.py — colector de cuotas de Bet777 (bet777.es, plataforma Swarm de BetConstruct).

El front (Nuxt) no usa HTTP para las cuotas: abre UN websocket contra el "Swarm" de BetConstruct
    wss://eu-swarm-ws-re.betcoswarm.com/      (Origin https://www.bet777.es, sin cookies, sin WAF)
y habla JSON:
    → {"command":"request_session","params":{"language":"spa","site_id":"999999"},"rid":…}
    → {"command":"get","params":{"source":"betting","what":{sport:[…],region:[…],competition:[…],game:[…],market:[…],
                                 event:[…]},"where":{…},"subscribe":true|false},"rid":…}
    ← {"rid":…,"data":{"data":{sport:{id:{region:{id:{competition:{id:{game:{id:{market:{id:{event:{id:{price…
       y, si subscribe=true, un "subid"; a partir de ahí llegan PARCHES {"rid":"0","data":{subid:{…ruta parcial…}}}
       con solo lo que cambia (precio, base, info/marcador; null = borrado). Se mezclan sobre el estado local.
    → {"command":"unsubscribe","params":{"subid":…}}      → {"command":"ping"} (keepalive)

Directo: UNA suscripción con todos los partidos en directo de las competiciones mapeadas (3 deportes) → el estado
local está siempre al día y cada 2 s se vuelcan a odds.db solo los partidos tocados (0 peticiones).
Pre-partido: un `get` sin suscripción por deporte cada `interval_prematch` s (en hilo aparte).

Mercados: `market.type` es un identificador estable de BetConstruct (P1XP2, OverUnder, AsianHandicap, MatchTotal,
SetHandicap…), `market.sequence` el nº de periodo (cuarto/mitad/set) y `event.type`/`type_1` la selección
(P1/X/P2, Home/Away, Over/Under, Yes/No). Tabla MK más abajo; lo que no está en ella no se guarda.

Uso:  python bet777.py        (bucle)     --once     --list (competiciones)     --dump <gameId>
"""
from __future__ import annotations

import fastjson as json
import logging
import os
import re
import sys
import threading
import time
import unicodedata
from datetime import datetime
from pathlib import Path

from competitions import Competitions
from storage import OddsStore
import pace

log = logging.getLogger("bet777")
CFG_PATH = Path(os.getenv("BET777_CFG", Path(__file__).parent / "bet777.json"))

SPORTS = {1: "futbol", 3: "baloncesto", 4: "tenis"}
SPORT_SLUG = {"futbol": "futbol", "baloncesto": "baloncesto", "tenis": "tenis"}


_US_RX = re.compile(r"\b(NBA|WNBA|NCAA)\b", re.I)


def _swap_sides(row: dict) -> None:
    """Bet777 lista las ligas americanas al estilo USA (visitante - local): team1 es el VISITANTE. El resto de casas
    (y el bot) usan local - visitante, así que se da la vuelta a todo lo que depende del lado: nombres, marcador,
    selecciones 1/2 y mercados *_HOME/*_AWAY (la línea de hándicap es la propia de cada lado: no cambia).
    Visto el 15-11: 'Brooklyn Nets - Memphis Grizzlies' en Bet777 frente a 'Memphis Grizzlies - Brooklyn Nets' en las demás."""
    row["home"], row["away"] = row["away"], row["home"]
    sc = row.get("score")
    if isinstance(sc, str) and ":" in sc:
        row["score"] = " ".join(":".join(reversed(p.split(":", 1))) for p in sc.split())
    for sl in row.get("selections") or []:
        if sl.get("selection") in ("1", "2"):
            sl["selection"] = "2" if sl["selection"] == "1" else "1"
        mk = sl.get("market") or ""
        if "_HOME" in mk:
            sl["market"] = mk.replace("_HOME", "_AWAY")
        elif "_AWAY" in mk:
            sl["market"] = mk.replace("_AWAY", "_HOME")
        if sl.get("code"):
            sl.pop("code", None)          # el código se regenera a partir de mercado/selección en storage


def _slug(txt: str) -> str:
    """'UEFA Nations League' -> 'uefa-nations-league' (como las rutas de bet777.es)."""
    t = unicodedata.normalize("NFKD", str(txt or "")).encode("ascii", "ignore").decode()
    return re.sub(r"-{2,}", "-", re.sub(r"[^a-z0-9]+", "-", t.lower())).strip("-")

WHAT_LIVE = {"sport": ["id", "alias"], "region": ["id", "name"], "competition": ["id", "name"],
             "game": ["id", "team1_name", "team2_name", "start_ts", "is_live", "is_blocked", "type", "info", "stats"],
             "market": ["id", "type", "name", "base", "sequence"],
             "event": ["id", "type", "type_1", "name", "base", "price"]}
WHAT_PM = {**WHAT_LIVE, "game": ["id", "team1_name", "team2_name", "start_ts", "is_live", "is_blocked", "type"]}

# ── market.type de BetConstruct → taxonomía propia ─────────────────────────────────────────────────────────────
# (market, tipo). tipo: result (1/X/2), dc (1X/12/X2), total (base = línea; Over/Under), hcp (dos selecciones, cada
# una con su base = línea del lado), yesno, sets (total de sets 2.5). {n} = market.sequence (cuarto / mitad / set).
MK: dict[str, dict[str, tuple[str, str]]] = {
    "futbol": {
        "P1XP2": ("1X2", "result"), "HalfTimeResult": ("1X2_1H", "result"), "SecondHalfResult": ("1X2_2H", "result"),
        "1X12X2": ("DC", "dc"), "HalfTimeDoubleChance": ("DC_1H", "dc"), "DrawNoBet": ("DNB", "result"),
        "HalfTimeDrawNoBet": ("DNB_1H", "result"),
        "OverUnder": ("TOTAL", "total"), "HalfTimeOverUnder": ("TOTAL_1H", "total"),
        "2ndHalfTotalOver/Under": ("TOTAL_2H", "total"),
        "Team1OverUnder": ("TOTAL_HOME", "total"), "Team2OverUnder": ("TOTAL_AWAY", "total"),
        "HalfTimeTeam1OverUnder": ("TOTAL_HOME_1H", "total"), "HalfTimeTeam2OverUnder": ("TOTAL_AWAY_1H", "total"),
        "SecondHalfHomeTeamTotalGoalsOverUnder": ("TOTAL_HOME_2H", "total"),
        "SecondHalfAwayTeamTotalGoalsOverUnder": ("TOTAL_AWAY_2H", "total"),
        "CornersOverUnder": ("CORNERS", "total"), "HalfTimeCornersOverUnder": ("CORNERS_1H", "total"),
        "HomeTeamCornersOverUnder": ("CORNERS_HOME", "total"), "AwayTeamCornersOverUnder": ("CORNERS_AWAY", "total"),
        # Solo amarillas: NO es el mismo mercado que "Total de tarjetas" (Altenar, Codere… cuentan también las rojas).
        # Con 3 amarillas + 1 roja pierden a la vez "Más de 3.5 amarillas" y "Menos de 3.5 tarjetas".
        "YellowCardsOverUnder": ("YELLOW", "total"), "Team1YellowCardsOverUnder": ("YELLOW_HOME", "total"),
        "Team2YellowCardsOverUnder": ("YELLOW_AWAY", "total"),
        "AsianHandicap": ("HANDICAP", "hcp"), "HalfTimeAsianHandicap": ("HANDICAP_1H", "hcp"),
        "2ndHalfAsianHandicap": ("HANDICAP_2H", "hcp"), "CornerHandicap": ("HANDICAP_CORNERS", "hcp"),
        "BothTeamsToScore": ("BTTS", "yesno"), "1stHalfBothTeamsToScore": ("BTTS_1H", "yesno"),
        "2ndHalfBothTeamsToScore": ("BTTS_2H", "yesno"),
    },
    "baloncesto": {
        "P1P2": ("1X2", "result"), "MatchHandicap": ("HANDICAP", "hcp"), "MatchTotal": ("TOTAL", "total"),
        "MatchHomeTeamTotal2": ("TOTAL_HOME", "total"), "MatchAwayTeamTotal2": ("TOTAL_AWAY", "total"),
        "HalfWinner2": ("DNB_{n}H", "result"), "HalfWinner3": ("1X2_{n}H", "result"),
        "HalfHandicap": ("HANDICAP_{n}H", "hcp"), "HalfTotal": ("TOTAL_{n}H", "total"),
        "HalfHomeTeamTotal2": ("TOTAL_HOME_{n}H", "total"), "HalfAwayTeamTotal2": ("TOTAL_AWAY_{n}H", "total"),
        "QuarterWinner2": ("DNB_Q{n}", "result"), "QuarterWinner3": ("1X2_Q{n}", "result"),
        "QuarterHandicap": ("HANDICAP_Q{n}", "hcp"), "QuarterTotal": ("TOTAL_Q{n}", "total"),
        "QuarterHomeTeamTotal2": ("TOTAL_HOME_Q{n}", "total"), "QuarterAwayTeamTotal2": ("TOTAL_AWAY_Q{n}", "total"),
    },
    "tenis": {
        "P1P2": ("1X2", "result"), "Handicap": ("HANDICAP", "hcp"), "Sets Handicap": ("HANDICAP_SETS", "hcp"),
        "TotalGamesOver/Under": ("TOTAL", "total"), "TotalofSets": ("SETS", "total"),
        "Player1:Player'sTotalofWonGames": ("TOTAL_HOME", "total"), "Player2:Player'sTotalofWonGames": ("TOTAL_AWAY", "total"),
        "SetWinner": ("1X2_SET{n}", "result"), "SetOverUnder": ("TOTAL_SET{n}", "total"),
        "SetHandicap": ("HANDICAP_SET{n}", "hcp"),
        "SetPlayer1TotalGames": ("TOTAL_HOME_SET{n}", "total"), "SetPlayer2TotalGames": ("TOTAL_AWAY_SET{n}", "total"),
    },
}
# props de jugador de baloncesto: "PlayerToScore20orMorePoints" -> PLAYER_POINTS Over 19.5 por cada jugador
_PLAYER_RX = re.compile(r"^Player(?:ToScore|ToRecord|Made)(\d+)orMore(Points|Assists|Rebounds|Three-Points)$")
_PLAYER_METRIC = {"Points": "PLAYER_POINTS", "Assists": "PLAYER_ASSISTS", "Rebounds": "PLAYER_REBOUNDS",
                  "Three-Points": "PLAYER_THREES"}

_SIDE = {"p1": "1", "w1": "1", "home": "1", "team1": "1", "1": "1",
         "p2": "2", "w2": "2", "away": "2", "team2": "2", "2": "2",
         "x": "X", "draw": "X", "tie": "X"}
_OU = {"over": "Over", "under": "Under"}
_YN = {"yes": "Yes", "no": "No"}


def _num(v) -> float | None:
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def _half(v: float | None) -> bool:
    """True solo para líneas x.5 (las únicas comparables entre casas sin reembolso/asiáticas)."""
    return v is not None and abs(abs(v) % 1 - 0.5) < 1e-9


def _etype(ev: dict) -> str:
    return str(ev.get("type") or ev.get("type_1") or "").strip().lower()


def _events(m: dict) -> list[dict]:
    return [e for e in (m.get("event") or {}).values()
            if isinstance(e, dict) and _num(e.get("price")) and float(e["price"]) > 1.0]


def market_selections(m: dict, sport: str) -> list[dict]:
    """Un mercado del Swarm -> selecciones normalizadas (market, selection, line, player, price)."""
    typ = m.get("type") or ""
    rule = MK.get(sport, {}).get(typ)
    if not rule:
        pm = _PLAYER_RX.match(typ) if sport == "baloncesto" else None
        if not pm:
            return []
        line = int(pm.group(1)) - 0.5
        return [{"market": _PLAYER_METRIC[pm.group(2)], "selection": "Over", "line": line,
                 "player": (e.get("name") or "").strip(), "price": e["price"]}
                for e in _events(m) if (e.get("name") or "").strip()]
    market, kind = rule
    if "{n}" in market:
        n = m.get("sequence")
        if not isinstance(n, int) or n <= 0:
            return []
        market = market.replace("{n}", str(n))
    evs = _events(m)
    out: list[dict] = []
    if kind == "result":
        for e in evs:
            side = _SIDE.get(_etype(e))
            if side:
                out.append({"market": market, "selection": side, "line": None, "price": e["price"]})
    elif kind == "dc":
        for e in evs:
            t = _etype(e).upper()
            if t in ("1X", "12", "X2"):
                out.append({"market": market, "selection": t, "line": None, "price": e["price"]})
    elif kind == "total":
        line = _num(m.get("base"))
        if not _half(line):
            return []
        for e in evs:
            sel = _OU.get(_etype(e))
            if sel:
                out.append({"market": market, "selection": sel, "line": line, "price": e["price"]})
    elif kind == "hcp":
        if len(evs) != 2:
            return []
        for e in evs:
            side = _SIDE.get(_etype(e))
            line = _num(e.get("base"))
            if side in ("1", "2") and _half(line):
                out.append({"market": market, "selection": side, "line": line, "price": e["price"]})
        if len(out) != 2 or out[0]["line"] != -out[1]["line"]:
            return []
    elif kind == "yesno":
        for e in evs:
            sel = _YN.get(_etype(e))
            if sel:
                out.append({"market": market, "selection": sel, "line": None, "price": e["price"]})
    return out


# ──────────────────────────────────────────────────────────────────────────────
def _merge(dst: dict, patch: dict, touched: set, under_game: bool = False) -> None:
    """Mezcla un parche del Swarm sobre el estado local: null borra, dict anida, resto sustituye.
    Anota en `touched` los ids de partido afectados."""
    for k, v in patch.items():
        if v is None:
            dst.pop(k, None)
            if under_game:
                touched.add(k)
            continue
        if isinstance(v, dict):
            cur = dst.get(k)
            if not isinstance(cur, dict):
                cur = dst[k] = {}
            if under_game:
                touched.add(k)
            _merge(cur, v, touched, under_game=(k == "game"))
        else:
            dst[k] = v


class Swarm:
    """Cliente websocket del Swarm en un hilo: peticiones con respuesta (`get`) y suscripciones con estado local."""

    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.url = cfg.get("ws", "wss://eu-swarm-ws-re.betcoswarm.com/")
        self.origin = cfg.get("origin", "https://www.bet777.es")
        self._ws = None
        self._lock = threading.Lock()            # envíos + estructuras compartidas
        self._pending: dict[str, tuple[threading.Event, list]] = {}
        self._subs: dict[str, dict] = {}         # nombre -> params deseados (se resuscriben al reconectar)
        self._subid: dict[str, str] = {}         # nombre -> subid vivo
        self._state: dict[str, dict] = {}        # nombre -> árbol de datos
        self.touched: dict[str, set] = {}        # nombre -> ids de partido tocados desde el último drain
        self._rid = 0
        self._stop = False
        self.connected = False
        self.connected_at = 0.0
        self.last_msg = 0.0
        self.msgs = self.bytes = self.reconnects = 0
        self.generation = 0
        self._th = threading.Thread(target=self._loop, name="bet777-swarm", daemon=True)
        self._th.start()

    # ── API ──
    def alive(self, max_silence: float = 120.0) -> bool:
        return self.connected and time.time() - max(self.last_msg, self.connected_at) < max_silence

    def _send(self, obj: dict) -> None:
        ws = self._ws
        if ws is None:
            raise RuntimeError("Swarm desconectado")
        with self._lock:
            ws.send(json.dumps(obj))

    def request(self, command: str, params: dict, timeout: float = 40.0) -> dict:
        with self._lock:
            self._rid += 1
            rid = str(self._rid)
            ev, box = threading.Event(), []
            self._pending[rid] = (ev, box)
        try:
            self._send({"command": command, "params": params, "rid": rid})
            if not ev.wait(timeout):
                raise RuntimeError(f"{command}: sin respuesta en {timeout:.0f}s")
        finally:
            with self._lock:
                self._pending.pop(rid, None)
        d = box[0]
        if d.get("code") not in (0, None):
            raise RuntimeError(f"{command}: código {d.get('code')} {str(d.get('msg') or d.get('data'))[:120]}")
        return d.get("data") or {}

    def get(self, what: dict, where: dict) -> dict:
        return self.request("get", {"source": "betting", "what": what, "where": where, "subscribe": False}).get("data") or {}

    def subscribe(self, name: str, what: dict, where: dict) -> None:
        """(Re)suscribe `name`; sustituye la suscripción anterior del mismo nombre."""
        params = {"source": "betting", "what": what, "where": where, "subscribe": True}
        self.unsubscribe(name)
        d = self.request("get", params)
        with self._lock:
            self._subs[name] = params
            self._subid[name] = str(d.get("subid"))
            self._state[name] = d.get("data") or {}
            self.touched[name] = {"*"}           # todo el árbol es nuevo

    def unsubscribe(self, name: str) -> None:
        with self._lock:
            sid = self._subid.pop(name, None)
            self._subs.pop(name, None)
            self._state.pop(name, None)
            self.touched.pop(name, None)
        if sid and self._ws is not None:
            try:
                self.request("unsubscribe", {"subid": sid}, timeout=10)
            except Exception as e:  # noqa: BLE001
                log.debug("unsubscribe %s: %s", name, e)

    def subscribed(self, name: str) -> bool:
        return name in self._subid

    def state(self, name: str) -> dict:
        return self._state.get(name) or {}

    def drain(self, name: str) -> set:
        with self._lock:
            t = self.touched.get(name) or set()
            self.touched[name] = set()
        return t

    def stop(self):
        self._stop = True

    # ── hilo ──
    def _loop(self):
        try:
            from websockets.sync.client import connect
        except ImportError:
            log.error("falta el paquete 'websockets' (pip install websockets)")
            return
        backoff = 2
        while not self._stop:
            try:
                with connect(self.url, additional_headers={"Origin": self.origin, "User-Agent": self.cfg.get("user_agent", "Mozilla/5.0")},
                             max_size=None, open_timeout=20, close_timeout=5) as ws:
                    self._ws = ws
                    ws.send(json.dumps({"command": "request_session", "rid": "session",
                                        "params": {"language": self.cfg.get("language", "spa"),
                                                   "site_id": str(self.cfg.get("site_id", "999999"))}}))
                    first = json.loads(ws.recv(timeout=20))
                    if first.get("code") not in (0, None) or not (first.get("data") or {}).get("sid"):
                        raise RuntimeError(f"request_session: {str(first)[:160]}")
                    self.connected = True
                    self.connected_at = self.last_msg = time.time()
                    self.generation += 1
                    backoff = 2
                    log.info("Swarm conectado (site %s, %s)", self.cfg.get("site_id", "999999"), (first.get("data") or {}).get("host", "?"))
                    with self._lock:                         # las suscripciones murieron con el socket: el colector
                        self._subid.clear()                  # las rehace (subscribed() -> False) desde su hilo
                        self._state.clear()
                        self._subs.clear()
                    last_ping = time.time()
                    while not self._stop:
                        try:
                            raw = ws.recv(timeout=15)
                        except TimeoutError:
                            if time.time() - self.last_msg > 180:
                                raise RuntimeError("socket mudo 180s")
                            if time.time() - last_ping > 30:
                                ws.send(json.dumps({"command": "ping", "rid": "ping"}))
                                last_ping = time.time()
                            continue
                        self._on_msg(raw)
            except Exception as e:  # noqa: BLE001
                if self._stop:
                    break
                log.warning("Swarm caído: %s — reconexión en %ss", str(e)[:160], backoff)
                self.reconnects += 1
                time.sleep(backoff)
                backoff = min(backoff * 2, 60)
            finally:
                self.connected = False
                self._ws = None
                with self._lock:
                    for ev, box in self._pending.values():
                        box.append({"code": -1, "msg": "desconectado"})
                        ev.set()

    def _on_msg(self, raw: str) -> None:
        self.msgs += 1
        self.bytes += len(raw)
        self.last_msg = time.time()
        d = json.loads(raw)
        rid = d.get("rid")
        if rid and rid not in ("0", "ping", "session"):
            with self._lock:
                p = self._pending.get(rid)
            if p:
                p[1].append(d)
                p[0].set()
            return
        data = d.get("data")
        if not isinstance(data, dict):
            return
        with self._lock:
            by_sid = {sid: name for name, sid in self._subid.items()}
            for sid, patch in data.items():
                name = by_sid.get(sid)
                if name and isinstance(patch, dict):
                    _merge(self._state.setdefault(name, {}), patch, self.touched.setdefault(name, set()))


# ──────────────────────────────────────────────────────────────────────────────
class Collector:
    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.bk = cfg["bookmaker"]
        self.catalog = Competitions()
        self.store = OddsStore(bookmaker=self.bk)
        self.swarm = Swarm(cfg)
        self.comps: dict[int, tuple[str, str]] = {}          # competition id -> (deporte, competición canónica)
        self._comp_slug: dict[int, str] = {}                  # competition id -> 'europe-uefa-nations-league' (ruta web)
        self._all: list[tuple[str, int, str]] = []
        self._menu_at = 0.0
        self._sub_ids: tuple = ()
        self._last_prematch = 0.0
        self._pm_queue: list[int] = []
        self._cfg_mtime = CFG_PATH.stat().st_mtime
        self._bg = pace.Background(f"{self.bk}-prematch")
        self._live_present: set[str] = set()
        self._live_full_at = 0.0
        self.transport = "websocket"

    def _reload_if_changed(self):
        mt = CFG_PATH.stat().st_mtime
        if mt != self._cfg_mtime:
            self._cfg_mtime = mt
            self.cfg = pace.apply(json.loads(CFG_PATH.read_text(encoding="utf-8")))
            log.info("bet777.json recargado")
        self.catalog.reload()

    def _wait_connected(self, timeout: float = 30.0) -> None:
        t0 = time.time()
        while not self.swarm.connected:
            if time.time() - t0 > timeout:
                raise RuntimeError("Swarm sin conexión")
            time.sleep(0.2)

    # ── catálogo ──
    def refresh_menu(self, force: bool = False):
        if not force and time.time() - self._menu_at < self.cfg.get("menu_ttl", 900):
            if self._sub_ids and not self.swarm.subscribed("live"):
                self._wait_connected()
                self._subscribe_live()               # tras una reconexión del Swarm
            return
        self._wait_connected()
        d = self.swarm.get({"sport": ["id"], "region": ["id", "name", "alias"], "competition": ["id", "name"]},
                           {"sport": {"id": {"@in": list(SPORTS)}}})
        found: dict[int, tuple[str, str]] = {}
        slugs: dict[int, str] = {}
        allc: list[tuple[str, int, str]] = []
        for sid, s in (d.get("sport") or {}).items():
            sport = SPORTS.get(int(sid))
            if not sport:
                continue
            for r in (s.get("region") or {}).values():
                for c in (r.get("competition") or {}).values():
                    label = re.sub(r"\s+", " ", f"{r.get('name') or ''} - {c.get('name') or ''}").strip(" -")
                    allc.append((sport, int(c["id"]), label))
                    comp = self.catalog.match(self.bk, sport, label)
                    if comp:
                        found[int(c["id"])] = (sport, comp)
                        slugs[int(c["id"])] = _slug(f"{r.get('alias') or r.get('name') or ''} {c.get('name') or ''}")
        self.comps = found
        self._comp_slug = slugs
        self._all = allc
        self._menu_at = time.time()
        log.info("%d competiciones mapeadas en Bet777", len(found))
        ids = tuple(sorted(found))
        if ids != self._sub_ids or not self.swarm.subscribed("live"):
            self._sub_ids = ids
            self._subscribe_live()

    def _subscribe_live(self):
        if not self._sub_ids:
            return
        self.swarm.subscribe("live", WHAT_LIVE, {"sport": {"id": {"@in": list(SPORTS)}},
                                                 "competition": {"id": {"@in": list(self._sub_ids)}},
                                                 "game": {"is_live": 1}})
        self._live_full_at = 0.0

    # ── estado del partido ──
    @staticmethod
    def _state(g: dict, sport: str) -> tuple[str | None, str | None, str | None]:
        """(marcador, periodo, reloj) a partir de game.info / game.stats."""
        info = g.get("info") or {}
        stats = g.get("stats") or {}
        st = str(info.get("current_game_state") or "").lower()
        m = re.search(r"(\d+)", st)
        n = int(m.group(1)) if m else 0
        s1, s2 = info.get("score1"), info.get("score2")
        score = f"{s1}:{s2}" if s1 is not None and s2 is not None else None
        timer = str(info.get("current_game_time") or "") or None
        if sport == "tenis":
            sets = []
            for i in range(1, 6):
                sc = stats.get(f"score_set{i}")
                if isinstance(sc, dict) and sc.get("team1_value") is not None:
                    sets.append(f"{sc['team1_value']}:{sc['team2_value']}")
            if sets:
                # un solo set en juego: se añade " -:-" (formato bwin) para que "2:1" no se confunda con sets ganados
                score = " ".join(sets) + (" -:-" if len(sets) == 1 else "")
            return score, (f"Set {n}" if n else None), None
        if sport == "baloncesto":
            if "half" in st and "end" in st:
                period = "Descanso"
            elif "overtime" in st or "ot" == st or n >= 5:
                period = "Prórroga"
            elif n:
                period = f"Q{n}"
            else:
                period = None
            return score, period, timer
        if "half" in st and ("time" in st or "end" in st):
            period = "Descanso"
        elif n == 1:
            period = "1ª parte"
        elif n == 2:
            period = "2ª parte"
        elif n >= 3 or "overtime" in st or "extra" in st:
            period = "Prórroga"
        else:
            period = None
        if timer and timer.isdigit():
            timer = f"{timer}'"
        return score, period, timer

    def _row(self, g: dict, sport: str, comp: str, kind: str, cid: int = 0) -> dict | None:
        if not isinstance(g, dict) or g.get("is_blocked"):
            return None
        home, away = (g.get("team1_name") or "").strip(), (g.get("team2_name") or "").strip()
        if not home or not away:
            return None
        sels: list[dict] = []
        for m in (g.get("market") or {}).values():
            if isinstance(m, dict):
                sels.extend(market_selections(m, sport))
        if not sels:
            return None
        gid = str(g.get("id"))
        dt = datetime.fromtimestamp(g["start_ts"]) if g.get("start_ts") else None
        row = {"event_id": gid, "home": home, "away": away, "competition": comp,
               "date": dt.strftime("%Y-%m-%d") if dt else None, "start_time": dt.strftime("%H:%M") if dt else None,
               "url": self.cfg.get("event_url", "https://www.bet777.es/{sport}/{comp}/{teams}-{event}/").format(
                   event=gid, sport=SPORT_SLUG.get(sport, sport), comp=self._comp_slug.get(cid) or "evento",
                   teams=_slug(f"{home} vs {away}") or "partido"),
               "selections": sels}
        if kind == "live":
            if not g.get("is_live") and g.get("type") != 1:
                return None
            score, period, timer = self._state(g, sport)
            row.update(score=score, period=period, timer=timer)
        if sport == "baloncesto" and _US_RX.search(comp or ""):
            _swap_sides(row)
        return row

    @staticmethod
    def _games(tree: dict):
        """Recorre sport -> region -> competition -> game del árbol del Swarm."""
        for s in (tree.get("sport") or {}).values():
            if not isinstance(s, dict):
                continue
            for r in (s.get("region") or {}).values():
                if not isinstance(r, dict):
                    continue
                for cid, c in (r.get("competition") or {}).items():
                    if not isinstance(c, dict):
                        continue
                    for gid, g in (c.get("game") or {}).items():
                        yield int(cid), str(gid), g

    # ── directo ──
    def live_cycle(self) -> tuple[int, int]:
        if not self.swarm.alive():
            raise RuntimeError("Swarm sin conexión (reconectando)")
        touched = self.swarm.drain("live")
        full = "*" in touched or time.time() - self._live_full_at >= self.cfg.get("live_full_every", 30)
        rows = changed = 0
        by_sport: dict[str, list[dict]] = {}
        present: set[str] = set()
        with self.swarm._lock:                      # lectura coherente del árbol mientras el hilo mezcla parches
            for cid, gid, g in self._games(self.swarm.state("live")):
                sc = self.comps.get(cid)
                if not sc:
                    continue
                present.add(gid)
                if not full and gid not in touched:
                    continue
                r = self._row(g, sc[0], sc[1], "live", cid)
                if r:
                    by_sport.setdefault(sc[0], []).append(r)
        for sp, rs in by_sport.items():
            changed += self.store.save_rows(sp, "live", rs)
            rows += len(rs)
        if full:
            self.store.sweep(present, "live")
            self._live_full_at = time.time()
        self._live_present = present
        return len(present), changed

    # ── pre-partido ──
    def prematch_sport(self, sid: int) -> tuple[int, int]:
        sport = SPORTS[sid]
        ids = [cid for cid, (sp, _c) in self.comps.items() if sp == sport]
        if not ids:
            return 0, 0
        now = int(time.time())
        d = self.swarm.get(WHAT_PM, {"sport": {"id": sid}, "competition": {"id": {"@in": ids}},
                                     "game": {"type": {"@in": [0, 2]}, "start_ts": {"@gt": now - 600, "@lt": now + int(self.cfg.get("prematch_hours", 48) * 3600)}}})
        rows: list[dict] = []
        for cid, gid, g in self._games(d):
            sc = self.comps.get(cid)
            if not sc or gid in self._live_present or g.get("is_live") or g.get("type") == 1:
                continue
            r = self._row(g, sc[0], sc[1], "prematch", cid)
            if r:
                rows.append(r)
        self._pm_present |= {r["event_id"] for r in rows}
        changed = self.store.save_rows(sport, "prematch", rows) if rows else 0
        return len(rows), changed

    def _pm_job(self, t0: float, once: bool):
        if not self._pm_queue and t0 - self._last_prematch >= self.cfg.get("interval_prematch", 60):
            self._pm_queue = list(SPORTS)
            self._pm_present: set[str] = set()
            self._pm_rows = self._pm_changed = 0
            self._last_prematch = t0
        if not self._pm_queue:
            return None
        chunk, self._pm_queue = (self._pm_queue, []) if once else (self._pm_queue[:1], self._pm_queue[1:])

        def _run():
            for sid in chunk:
                try:
                    r, c = self.prematch_sport(sid)
                    self._pm_rows += r
                    self._pm_changed += c
                except Exception as e:  # noqa: BLE001
                    log.warning("prematch %s: %s", SPORTS[sid], e)
            if not self._pm_queue:
                self.store.sweep(self._pm_present, "prematch")
                return f"prematch {self._pm_rows} ev / {self._pm_changed} cambios (pasada completa)"
            return f"prematch {self._pm_rows} ev / {self._pm_changed} cambios ({len(self._pm_queue)} deportes pendientes)"
        return _run

    # ── bucle ──
    def run(self, once: bool = False):
        backoff = 2
        while True:
            t0 = time.time()
            try:
                self._reload_if_changed()
                self.refresh_menu()
                rows, changed = self.live_cycle()
                msg = f"live {rows} ev / {changed} cambios [push {self.swarm.msgs} msgs, {self.swarm.bytes // 1024} KB]"
                if not self._bg.busy():
                    job = self._pm_job(t0, once)
                    if job is not None:
                        r = self._bg.run(job, inline=once)
                        if r:
                            msg += " | " + r
                note = self._bg.note()
                if note:
                    msg += " | " + note
                self.store.set_status(**{f"{self.bk}_last_ok": time.time(), f"{self.bk}_live_events": rows,
                                         f"{self.bk}_transport": self.transport})
                log.info("%s [%s] (%.1fs)", msg, self.transport, time.time() - t0)
                backoff = 2
                if once:
                    return
            except Exception as e:  # noqa: BLE001
                log.warning("error de ciclo: %s — reintento en %ss", e, backoff, exc_info=log.isEnabledFor(logging.DEBUG))
                self.store.set_status(**{f"{self.bk}_last_error": f"{time.time():.0f} {e}"})
                time.sleep(backoff)
                backoff = min(backoff * 2, 60)
                continue
            time.sleep(max(0.5, self.cfg.get("interval_live", 2) - (time.time() - t0)))


def list_catalog(c: Collector):
    c.refresh_menu(force=True)
    by: dict[str, list] = {}
    for sport, cid, label in sorted(set(c._all), key=lambda x: (x[0], x[2])):
        by.setdefault(sport, []).append((cid, label))
    for sport, items in by.items():
        print(f"\n=== {sport}")
        for cid, label in items:
            comp = c.comps.get(cid)
            print(f" {'✔' if comp else ' '} {label}   [{cid}]" + (f" -> {comp[1]}" if comp else ""))
    print(f"\n{len(c.comps)} competiciones mapeadas")


def dump_game(c: Collector, gid: str):
    c._wait_connected()
    d = c.swarm.get({**WHAT_LIVE, "market": ["id", "type", "name", "base", "sequence", "name_template"]},
                    {"game": {"id": int(gid)}})
    games = list(c._games(d))
    if not games:
        print("partido no encontrado")
        return
    cid, gid, g = games[0]
    sport = next((SPORTS[int(s)] for s in (d.get("sport") or {})), "futbol")
    print(g.get("team1_name"), "-", g.get("team2_name"), "|", datetime.fromtimestamp(g.get("start_ts") or 0), "| live:", g.get("is_live"),
          "|", c._state(g, sport))
    for m in (g.get("market") or {}).values():
        sels = market_selections(m, sport)
        evs = ", ".join(f"{(e.get('name') or '').strip()}[{_etype(e)}]{'' if e.get('base') is None else ' ' + str(e.get('base'))} @{e.get('price')}"
                        for e in _events(m))
        print(f"MK {m.get('type')!s:<40} seq={m.get('sequence')} base={m.get('base')} '{(m.get('name') or '')[:50]}' :: {evs[:150]}")
        print("     -> " + (", ".join(f"{s['market']} {s.get('player') or ''} {s['selection']} {s['line'] if s.get('line') is not None else ''} @{s['price']}" for s in sels) or "(sin mapear)"))


def main():
    logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"), format="%(asctime)s %(levelname)s %(name)s: %(message)s", datefmt="%H:%M:%S")
    cfg = pace.apply(json.loads(CFG_PATH.read_text(encoding="utf-8")))
    c = Collector(cfg)
    try:
        if "--list" in sys.argv:
            list_catalog(c)
            return
        if "--dump" in sys.argv:
            dump_game(c, sys.argv[sys.argv.index("--dump") + 1])
            return
        c.run(once="--once" in sys.argv)
    finally:
        c.swarm.stop()


if __name__ == "__main__":
    main()
