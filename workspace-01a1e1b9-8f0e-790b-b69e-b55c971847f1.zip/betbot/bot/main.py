"""
Punto de entrada del bot.

Arranca en un solo comando:
    1. Bot de Telegram (python-telegram-bot)
    2. Fuente de cuotas: colectores de cuotas (odds.db) → motor de señales
    3. Servidor webhook de Stripe (en un hilo aparte)
    4. Jobs periódicos (expirar trials, avisos de expiración)

Uso:
    python main.py
"""
import logging
import signal
from datetime import time

from telegram.ext import Application, ContextTypes

from config import CONFIG, get_miniapp_url
from data.repository import (
    Database, UserRepository, StatsRepository, FreebetRepository, AdminRepository,
)
from services.subscription import SubscriptionService
from services.distribution import DistributionService
from services.stripe_gateway import StripeGateway
from services.stripe_poller import StripePoller
from services.admins import AdminService
from services.odds_source import OddsSource
from handlers.bot_handlers import BotHandlers


logging.basicConfig(
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    level=logging.INFO,
)
# Bajar el ruido de terceros
logging.getLogger("httpx").setLevel(logging.WARNING)
logging.getLogger("werkzeug").setLevel(logging.WARNING)
logging.getLogger("apscheduler").setLevel(logging.WARNING)
log = logging.getLogger("main")


# ═════════════════════════════════════════════════════════
#  ORCHESTRATOR
# ═════════════════════════════════════════════════════════

class AppOrchestrator:
    """
    Compone e inicia todos los subsistemas del bot en un solo proceso.
    """

    def __init__(self):
        self._db = Database(CONFIG.db_path)
        self._db.init_schema()

        self.users = UserRepository(self._db)
        self.stats = StatsRepository(self._db)
        self.freebets = FreebetRepository(self._db)
        self.admins = AdminService(AdminRepository(self._db))

        # App Telegram (bot)
        # Pool de conexiones HTTP hacia Telegram: por defecto python-telegram-bot usa UNA sola conexión (pool_size=1,
        # pool_timeout=1s). Con los envíos en paralelo (hasta 20 a la vez) el pool se agota y cualquier otra llamada
        # —answer_callback_query / edit_message_text del botón 🔓— falla con "Pool timeout": el botón no responde
        # mientras se están enviando señales. Pool amplio + updates concurrentes para que un 🔓 nunca espere a los envíos.
        self.app: Application = (
            Application.builder().token(CONFIG.bot_token)
            .connection_pool_size(64).pool_timeout(15.0)
            .get_updates_connection_pool_size(2).get_updates_pool_timeout(15.0)
            .connect_timeout(10.0).read_timeout(15.0).write_timeout(15.0)
            .concurrent_updates(True)
            .build()
        )

        # Servicios
        self.stripe_gw = StripeGateway()
        self.subscription = SubscriptionService(self.users)
        self.distribution = DistributionService(
            self.app.bot, self.users, self.stats, admins=self.admins,
        )
        self.stripe_poller = StripePoller(self.app.bot, self.users, self.subscription)

        # Handlers
        self.bot_handlers = BotHandlers(
            self.users, self.stats,
            self.distribution, self.subscription, self.stripe_gw,
            self.freebets, self.admins,
        )
        self.bot_handlers.register(self.app)

        # Fuente de cuotas (scraper) → señales → pipeline de distribución
        self.odds_source = OddsSource(self.distribution)
        # Jobs
        self._register_jobs()

    # ── Jobs periódicos ──────────────────────────────────
    def _register_jobs(self):
        if not self.app.job_queue:
            return
        self.app.job_queue.run_repeating(
            self._expire_trials_job, interval=3600, first=60,
        )
        self.app.job_queue.run_daily(
            self._expiring_warning_job,
            time=time(hour=10, minute=0),
        )
        # Lectura de odds.db (escrito por el scraper) → señales
        logging.getLogger("apscheduler.scheduler").setLevel(logging.ERROR)   # "skipped: maximum instances" es normal
        self.app.job_queue.run_repeating(self._loop_lag_job, interval=5, first=5, name="loop_lag")
        self.app.job_queue.run_repeating(
            self.odds_source.poll, interval=CONFIG.odds_poll_seconds, first=5,
            job_kwargs={"coalesce": True, "misfire_grace_time": 30},   # si una pasada tarda más del intervalo, encadena la siguiente
        )

        # Poller de Stripe (solo si estamos en modo polling)
        if CONFIG.stripe_mode == "polling" and CONFIG.stripe_secret_key:
            self.app.job_queue.run_repeating(
                self._stripe_poll_job,
                interval=CONFIG.stripe_poll_interval,
                first=30,
            )
            log.info("⏰ Jobs: trials 1h · expiración 10:00 · Stripe poll cada %ds",
                     CONFIG.stripe_poll_interval)
        else:
            log.info("⏰ Jobs programados: trials 1h · avisos expiración diarios 10:00")

    async def _loop_lag_job(self, ctx: ContextTypes.DEFAULT_TYPE):
        """Vigila que el bucle de eventos no se bloquee (si se bloquea, Telegram deja de responder)."""
        import time as _t
        now = _t.monotonic()
        last = getattr(self, "_lag_last", None)
        self._lag_last = now
        if last is not None and now - last - 5 > 3:
            log.warning("bucle de eventos bloqueado %.1fs: algo síncrono está tardando (ver 'detectores lentos')", now - last - 5)

    async def _stripe_poll_job(self, ctx: ContextTypes.DEFAULT_TYPE):
        await self.stripe_poller.poll()

    async def _expire_trials_job(self, ctx: ContextTypes.DEFAULT_TYPE):
        """
        Caduca suscripciones vencidas y AVISA al usuario.

        Sólo afecta a las que no dependen de Stripe (pruebas y planes
        dados a mano); las de pago las gestiona el poller.
        """
        from i18n import t as _t
        for uid in self.users.expire_finished_subscriptions():
            user = self.users.find(uid)
            lang = (user.filters.language if user and user.filters else "es") or "es"
            try:
                await ctx.bot.send_message(
                    uid,
                    f"*{_t('sub.expired', lang)}*\n\n{_t('sub.expired_body', lang)}",
                    parse_mode="Markdown",
                )
            except Exception as e:                          # noqa: BLE001
                log.warning("Aviso de caducidad a %s falló: %s", uid, e)

    async def _expiring_warning_job(self, ctx: ContextTypes.DEFAULT_TYPE):
        for u in self.users.expiring_in(3):
            try:
                await ctx.bot.send_message(
                    u.telegram_id,
                    f"⏳ *Tu suscripción expira en 3 días*\n"
                    f"({u.subscription.expires_at.strftime('%d/%m/%Y')})\n\n"
                    "Si tienes renovación automática no debes hacer nada.",
                    parse_mode="Markdown",
                )
            except Exception as e:
                log.warning("Aviso expiración %s falló: %s", u.telegram_id, e)

    # ── Stripe: solo modo polling ────────────────────────
    # El proyecto funciona sin dominio, así que el webhook no aplica:
    # el poller consulta la API de Stripe cada N segundos.
    def _log_stripe_mode(self):
        if not CONFIG.stripe_secret_key:
            log.warning("⚠️  STRIPE_SECRET_KEY vacío → los pagos no funcionarán")
        elif CONFIG.stripe_mode == "polling":
            log.info("💳 Stripe en modo POLLING (sin webhook, sin dominio)")
        else:
            log.warning("⚠️  STRIPE_MODE=%s desconocido — usa 'polling'",
                        CONFIG.stripe_mode)

    # ── Ciclo de vida ───────────────────────────────────
    async def _post_init(self, application):
        """Se ejecuta después de que python-telegram-bot esté inicializado."""
        await self._register_bot_commands()
        await self._set_menu_button()

    async def _set_menu_button(self):
        """
        Botón permanente junto al campo de texto del chat.
        Si la Mini App está configurada, abre la web app; si no, envía /panel.
        """
        from telegram import MenuButtonCommands, MenuButtonWebApp, WebAppInfo

        miniapp_url = get_miniapp_url()
        if CONFIG.miniapp_enabled and miniapp_url:
            try:
                await self.app.bot.set_chat_menu_button(
                    menu_button=MenuButtonWebApp(
                        text="⚙️ Panel",
                        web_app=WebAppInfo(url=miniapp_url),
                    )
                )
                log.info("🧩 Menú: Mini App → %s", miniapp_url)
                return
            except Exception as e:
                log.warning("No pude registrar el botón ⚙️ Panel: %s", e)
            return

        # Sin Mini App operativa: menú de comandos normal
        if CONFIG.miniapp_enabled and not CONFIG.miniapp_url:
            log.warning("⚠️  MINIAPP_ENABLED=true pero MINIAPP_URL está vacía. "
                        "El botón ⚙️ Panel no se registrará. Usa /setminiapp <url>.")
        try:
            await self.app.bot.set_chat_menu_button(menu_button=MenuButtonCommands())
        except Exception as e:
            log.warning("No pude registrar el menú de comandos: %s", e)

    async def _register_bot_commands(self):
        """
        Registra los comandos en el menú "/" de Telegram.
        Los usuarios normales ven la lista básica; los admins ven además
        los comandos de administración.
        """
        from telegram import BotCommand, BotCommandScopeDefault, BotCommandScopeChat, BotCommandScopeAllPrivateChats, BotCommandScopeAllGroupChats

        # 1) Borrar TODOS los comandos previos en todos los scopes
        #    para asegurar una lista limpia.
        for scope in (
            BotCommandScopeDefault(),
            BotCommandScopeAllPrivateChats(),
            BotCommandScopeAllGroupChats(),
        ):
            try:
                await self.app.bot.delete_my_commands(scope=scope)
            except Exception as e:
                log.warning("No pude borrar comandos previos (%s): %s",
                            type(scope).__name__, e)

        # Borrar también los específicos de cada admin
        admin_ids = list(CONFIG.admin_ids)
        if CONFIG.admin_id:
            admin_ids.append(CONFIG.admin_id)
        for aid in set(admin_ids):
            try:
                await self.app.bot.delete_my_commands(
                    scope=BotCommandScopeChat(chat_id=aid)
                )
            except Exception:
                pass

        log.info("🧹 Comandos previos borrados")

        # 2) Comandos visibles para todos los usuarios
        # Solo /start: el resto vive dentro de la Mini App.
        user_commands = [
            BotCommand("start", "🏠 Abrir"),
            BotCommand("filtros", "🎛 Filtros de señales"),
        ]
        try:
            await self.app.bot.set_my_commands(
                user_commands, scope=BotCommandScopeDefault()
            )
            log.info("✅ %d comandos registrados (usuarios)", len(user_commands))
        except Exception as e:
            log.warning("No pude registrar comandos de usuario: %s", e)

        # 3) Comandos extra para los admins
        # Sin comandos extra: la administración está en la pestaña 👑 de la app.
        admin_commands = list(user_commands)
        for aid in set(admin_ids):
            try:
                await self.app.bot.set_my_commands(
                    admin_commands, scope=BotCommandScopeChat(chat_id=aid)
                )
                log.info("✅ %d comandos registrados para admin %s",
                         len(admin_commands), aid)
            except Exception as e:
                log.warning("No pude registrar comandos para admin %s: %s", aid, e)

    async def _post_shutdown(self, application):
        proc = getattr(self.odds_source, "_proc", None)
        if proc is not None:
            proc.stop()

    def run(self):
        # Validaciones
        if not CONFIG.bot_token:
            raise SystemExit("⚠️ Configura CONFIG.bot_token en config.py antes de arrancar.")

        # Hooks del ciclo de vida
        self.app.post_init = self._post_init
        self.app.post_shutdown = self._post_shutdown

        self._log_stripe_mode()

        # Bot (bloqueante)
        stripe_status = "❌"
        if CONFIG.stripe_secret_key:
            stripe_status = f"✅ ({CONFIG.stripe_mode})"
        log.info("🚀 Bot v2 iniciado")
        log.info("   · Bot Telegram: ✅")
        log.info("   · Fuente:       scraper %s (poll %ds)", CONFIG.odds_db_path, CONFIG.odds_poll_seconds)
        log.info("   · Stripe:       %s", stripe_status)
        async def _on_error(update, context):
            err = context.error
            if "Query is too old" in str(err) or "query id is invalid" in str(err):
                log.debug("callback antiguo ignorado: %s", err)
                return
            if "terminated by other getUpdates" in str(err):
                log.error("CONFLICTO: hay OTRA instancia de este bot usando el mismo token (otro python main.py / Docker / "
                          "servidor). Ciérrala: solo puede haber una. (%s)", err)
                return
            log.error("error en handler: %s", err, exc_info=err)
        self.app.add_error_handler(_on_error)
        self.app.run_polling(stop_signals=(signal.SIGINT, signal.SIGTERM))


# ═════════════════════════════════════════════════════════
#  ENTRY POINT
# ═════════════════════════════════════════════════════════

def main():
    AppOrchestrator().run()


if __name__ == "__main__":
    main()
