"""
Catálogo de casas de apuestas (BetBurger · mercado España).

Cada casa tiene:
- key    : identificador interno (ej. "bet365") — es lo que se guarda en los filtros
- name   : nombre que se muestra al usuario
- region : ES / INT / EX
- url    : enlace genérico de la casa (solo si BetBurger no manda deep-link)

BetBurger escribe los nombres a su manera ("Bet365Direct", "WinamaxES"...).
El mapa BETBURGER_ALIASES traduce ese nombre tal cual llega a nuestra clave
interna. Si BetBurger añade una casa nueva, basta con añadirla aquí.

NO HAY CLONES: todas las casas del catálogo son casas reales que BetBurger
escanea. Cada apuesta se envía tal cual llega, con su enlace "Place Bet".
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, List, Optional


# ──────────────────────────────────────────────────────────
# REGIONES
# ──────────────────────────────────────────────────────────

REGIONS: Dict[str, str] = {
    "ES": "🇪🇸 España",
    "INT": "🌐 Internacional",
    "EX": "🔄 Exchange",
}


# ──────────────────────────────────────────────────────────
# MODELO
# ──────────────────────────────────────────────────────────

@dataclass(frozen=True)
class Bookmaker:
    key: str
    name: str
    region: str
    url: str = ""

    @property
    def region_label(self) -> str:
        return REGIONS.get(self.region, self.region)


# ──────────────────────────────────────────────────────────
# CATÁLOGO — casas de las que el scraper guarda cuotas
# ──────────────────────────────────────────────────────────

_ALL: List[Bookmaker] = [
    # Las casas que recogen los colectores (clave = columna `bookmaker` de odds.db)
    Bookmaker("winamaxes",      "Winamax",         "ES",  "https://www.winamax.es/apuestas-deportivas"),
    Bookmaker("paston",         "Pastón",          "ES",  "https://www.paston.es/apuestas-deportivas"),
    Bookmaker("betsson",        "Betsson",         "ES",  "https://www.betsson.es/apuestas-deportivas"),
    Bookmaker("leovegas",       "LeoVegas",        "ES",  "https://www.leovegas.es/apuestas-deportivas"),
    Bookmaker("casumo",         "Casumo",          "ES",  "https://www.casumo.es/sports/"),
    Bookmaker("speedybet",      "Speedybet",       "ES",  "https://www.speedybet.es/es/betting"),
    Bookmaker("paf",            "Paf",             "ES",  "https://www.paf.es/es/apuestas"),
    Bookmaker("bwines",         "bwin",            "ES",  "https://www.bwin.es/es/sports"),
    Bookmaker("888sportes",     "888sport",        "ES",  "https://www.888sport.es/"),
    Bookmaker("pokerstarses",   "PokerStars",      "ES",  "https://www.pokerstars.es/apuestas-deportivas/"),
    Bookmaker("jokerbet",       "JokerBet",        "ES",  "https://www.jokerbet.es/apuestas-deportivas"),
    Bookmaker("betwayes",       "Betway",          "ES",  "https://betway.es/es/es/sports"),
    Bookmaker("sportium",       "Sportium",        "ES",  "https://www.sportium.es/apuestas"),
    Bookmaker("marca",          "Marca Apuestas",  "ES",  "https://www.marcaapuestas.es/apuestas"),
    Bookmaker("versus",         "Versus",          "ES",  "https://www.versus.es/apuestas"),
    Bookmaker("codere",         "Codere",          "ES",  "https://m.apuestas.codere.es/deportes/"),
    Bookmaker("tonybet",        "TonyBet",         "ES",  "https://tonybet.es/prematch"),
    Bookmaker("betinia",        "Betinia",         "ES",  "https://betinia.es/es/sport"),
    Bookmaker("admiralbet",     "AdmiralBet",      "ES",  "https://www.admiralbet.es/es/apuestas"),
    Bookmaker("solcasino",      "Sol Casino",      "ES",  "https://solcasino.es/apuestas"),
    Bookmaker("yaass",          "Yaass",           "ES",  "https://www.yaasscasino.es/apuestas"),
    Bookmaker("dafabet",        "Dafabet",         "ES",  "https://www.dafabet.es/es/sports"),
    Bookmaker("interwetten",    "Interwetten",     "ES",  "https://www.interwetten.es/es/apuestas-deportivas"),
    Bookmaker("daznbet",        "DAZN Bet",        "ES",  "https://www.daznbet.es/es-es/deportes"),
    Bookmaker("bet777",         "Bet777",          "ES",  "https://www.bet777.es/sports/"),
    Bookmaker("goldenpark",     "GoldenPark",      "ES",  "https://apuestas.goldenpark.es/"),
]


# ──────────────────────────────────────────────────────────
# ALIAS (texto libre → clave interna), usados por /freebet y búsquedas por nombre
# ──────────────────────────────────────────────────────────

BETBURGER_ALIASES: Dict[str, str] = {
    "winamax": "winamaxes", "winamaxes": "winamaxes",
    "paston": "paston", "pastón": "paston",
    "betsson": "betsson", "betssones": "betsson",
    
    "leovegas": "leovegas", "leo vegas": "leovegas", "leovegases": "leovegas",
    "casumo": "casumo", "casumo.es": "casumo", "casumoes": "casumo",
    "speedybet": "speedybet", "speedybet.es": "speedybet", "speedybetes": "speedybet",
    "paf": "paf", "paf.es": "paf", "pafes": "paf",
    "bwin": "bwines", "bwines": "bwines", "bwin.es": "bwines",
    "888sport": "888sportes", "888sportes": "888sportes", "888": "888sportes", "888sport.es": "888sportes",
    "betway": "betwayes", "betwayes": "betwayes", "betway.es": "betwayes",
    "sportium": "sportium", "sportium.es": "sportium",
    "marca": "marca", "marca apuestas": "marca", "marcaapuestas": "marca", "marcaapuestas.es": "marca",
    "versus": "versus", "versus.es": "versus", "versus apuestas": "versus",
    "jokerbet": "jokerbet", "joker bet": "jokerbet", "jokerbet.es": "jokerbet",
    "codere": "codere", "codere.es": "codere",
    "tonybet": "tonybet", "tony bet": "tonybet", "tonybet.es": "tonybet",
    "betinia": "betinia", "betinia.es": "betinia",
    "admiralbet": "admiralbet", "admiralbet.es": "admiralbet", "admiral": "admiralbet",
    "solcasino": "solcasino", "solcasino.es": "solcasino", "sol casino": "solcasino", "sol": "solcasino",
    "yaass": "yaass", "yaasscasino.es": "yaass", "yaass.es": "yaass", "wanabet": "yaass",
    "dafabet": "dafabet", "dafabet.es": "dafabet", "dafabetes": "dafabet",
    "interwetten": "interwetten", "interwetten.es": "interwetten", "interwettenes": "interwetten",
    "daznbet": "daznbet", "dazn bet": "daznbet", "dazn": "daznbet", "daznbet.es": "daznbet",
    "bet777": "bet777", "bet777.es": "bet777", "bet 777": "bet777",
    "goldenpark": "goldenpark", "golden park": "goldenpark", "goldenpark.es": "goldenpark",
    
    "pokerstars": "pokerstarses", "pokerstarses": "pokerstarses", "poker stars": "pokerstarses", "pokerstars.es": "pokerstarses",
}


def normalize_name(name: str) -> str:
    """Minúsculas y sin espacios ni puntos: 'Bet365 Direct' → 'bet365direct'."""
    return (name or "").strip().lower().replace(" ", "").replace(".", "")


# ──────────────────────────────────────────────────────────
# CATÁLOGO CON API
# ──────────────────────────────────────────────────────────

class BookmakerCatalog:
    """Acceso centralizado al catálogo de casas."""

    def __init__(self, bookmakers: List[Bookmaker]):
        self._by_key: Dict[str, Bookmaker] = {b.key: b for b in bookmakers}
        self._by_norm: Dict[str, Bookmaker] = {}
        for b in bookmakers:
            self._by_norm[normalize_name(b.name)] = b
            self._by_norm[b.key] = b
        for alias, key in BETBURGER_ALIASES.items():
            b = self._by_key.get(key)
            if b:
                self._by_norm[normalize_name(alias)] = b

    # ── accesos básicos ──
    def get(self, key: str) -> Optional[Bookmaker]:
        return self._by_key.get((key or "").lower())

    def all(self) -> List[Bookmaker]:
        return list(self._by_key.values())

    def keys(self) -> List[str]:
        return list(self._by_key.keys())

    # ── traducción del nombre que manda BetBurger ──
    def resolve(self, raw_name: str) -> Optional[Bookmaker]:
        """'Bet365Direct' → Bookmaker(bet365fast). None si no se conoce."""
        return self._by_norm.get(normalize_name(raw_name))

    def resolve_key(self, raw_name: str) -> str:
        """Devuelve la clave conocida o, si no, una clave normalizada."""
        bk = self.resolve(raw_name)
        return bk.key if bk else normalize_name(raw_name)

    def label(self, key: str) -> str:
        """
        Nombre a mostrar de una clave. Si la casa no está en el catálogo
        (BetBurger manda una que no tenemos), se muestra el nombre tal cual
        llegó, con la primera letra en mayúscula: "unibet" → "Unibet".
        """
        bk = self.get(key)
        if bk:
            return bk.name
        k = (key or "").strip()
        return (k[:1].upper() + k[1:]) if k else "—"

    # ── búsqueda por texto ──
    def find_by_text(self, text: str) -> List[Bookmaker]:
        t = (text or "").lower()
        return [b for b in self._by_key.values()
                if b.name.lower() in t or b.key in t]

    # ── agrupaciones para la UI ──
    def by_region(self) -> Dict[str, List[Bookmaker]]:
        out: Dict[str, List[Bookmaker]] = {r: [] for r in REGIONS}
        for b in self._by_key.values():
            out.setdefault(b.region, []).append(b)
        return {r: sorted(bs, key=lambda x: x.name)
                for r, bs in out.items() if bs}


CATALOG = BookmakerCatalog(_ALL)
