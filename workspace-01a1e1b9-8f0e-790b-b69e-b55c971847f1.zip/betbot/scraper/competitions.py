"""
competitions.py — acceso al catálogo único de competiciones (competitions.json) para todos los colectores.

    cat = Competitions()                       # recarga sola si el fichero cambia
    name = cat.match("paston", "futbol", "Europa - UEFA Champions League")   -> "Champions League" | None
    cat.patterns("winamaxes", "futbol")       -> lista de regex de esa casa
"""
from __future__ import annotations

import fastjson as json
import os
import re
import unicodedata
from pathlib import Path

CATALOG_PATH = Path(os.getenv("COMPETITIONS_FILE", Path(__file__).parent / "competitions.json"))


def _fold(s: str) -> str:
    s = unicodedata.normalize("NFKD", s or "").encode("ascii", "ignore").decode()
    return re.sub(r"\s+", " ", s.lower()).strip()


class Competitions:
    def __init__(self, path: Path = CATALOG_PATH):
        self.path = path
        self._mtime = 0.0
        self._rx: dict[tuple[str, str], list[tuple[re.Pattern, str, bool, "re.Pattern | None"]]] = {}
        self.sports: list[str] = []
        self.items: list[dict] = []
        self.reload()

    def reload(self) -> bool:
        mt = self.path.stat().st_mtime
        if mt == self._mtime:
            return False
        data = json.loads(self.path.read_text(encoding="utf-8"))
        self._mtime = mt
        self.sports = data.get("sports", [])
        self.items = data.get("competitions", [])
        self._rx.clear()
        return True

    # casas que comparten plataforma (y por tanto nombres de competición) con otra ya configurada
    ALIAS = {"jokerbet": "paston", "betinia": "paston", "admiralbet": "paston", "solcasino": "paston"}

    def _rules(self, bookmaker: str, sport: str):
        self.reload()
        bookmaker = self.ALIAS.get(bookmaker, bookmaker)
        key = (bookmaker, sport)
        if key not in self._rx:
            rules = []
            for c in self.items:
                if c["sport"] != sport:
                    continue
                pats = c.get("patterns", {})
                ex = re.compile(c["exclude"], re.I) if c.get("exclude") else None   # p.ej. Eurobasket femenino / sub-20
                if bookmaker in pats:        # patrón propio: se compara tal cual (case-insensitive)
                    rules.append((re.compile(pats[bookmaker], re.I), c["name"], False, ex))
                elif "*" in pats:            # patrón genérico: se compara sobre texto sin acentos/minúsculas
                    rules.append((re.compile(pats["*"], re.I), c["name"], True, ex))
            self._rx[key] = rules
        return self._rx[key]

    def match(self, bookmaker: str, sport: str, label: str) -> str | None:
        """Nombre canónico de la competición si `label` es una competición principal; si no, None."""
        if not label:
            return None
        folded = _fold(label)
        for rx, name, generic, ex in self._rules(bookmaker, sport):
            if rx.search(folded if generic else label):
                if ex and ex.search(folded):
                    return None          # variante excluida de la competición (femenina, sub-20…)
                return name
        return None

    def patterns(self, bookmaker: str, sport: str) -> list[str]:
        return [rx.pattern for rx, _, _, _ in self._rules(bookmaker, sport)]

    def names(self, sport: str | None = None) -> list[str]:
        return [c["name"] for c in self.items if sport is None or c["sport"] == sport]
