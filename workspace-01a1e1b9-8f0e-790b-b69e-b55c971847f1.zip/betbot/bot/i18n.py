"""
Internacionalización mínima (ES / EN).
Uso:  t("home.welcome", lang, name="Carlos")
"""
from __future__ import annotations
from typing import Any


STRINGS = {
    "es": {
        # Común
        "back":            "⬅️ Volver",
        "close":           "❎ Cerrar",
        "save":            "💾 Guardar",
        "skip":            "⏭ Saltar",
        "next":            "Siguiente ➡️",
        "prev":            "⬅️ Atrás",
        "finish":          "🎉 Terminar",
        "refresh":         "🔄 Actualizar",

        # Home
        "home.welcome":       "👋 Hola *{name}*",
        "home.no_sub":        "❌ Sin suscripción activa",
        "home.active_sub":    "✅ *{plan}* activa · {days} días restantes",
        "home.trial_name":    "🎁 Prueba gratis",
        "home.trial_intro":   "🎁 *¡Prueba gratuita activada!*\n"
                              "Tienes {days} día(s) de acceso completo, sin tarjeta.",
        "home.bookmakers_sure":  "🏦 Casas surebets",
        "home.sports":           "🏟 Deportes",
        "home.profit":           "📊 Profit mínimo",
        "home.types":            "🎯 Tipos activos",
        "home.mute":             "🔕 Silencio",
        "home.schedule":         "🕐 Horario",
        "home.language":         "🌐 Idioma",
        "home.subscription":     "💼 Suscripción",
        "home.stats":            "📊 Estadísticas",

        # Estados
        "status.enabled":  "✅ Activo",
        "status.disabled": "⛔ Desactivado",
        "status.all":      "Todas",
        "status.none":     "Ninguna",
        "status.selected": "{n} seleccionadas",

        # Lanzador de la Mini App (/start)
        "launch.greet":    "👋 Hola *{name}*",
        "launch.help":     "Desde aquí configuras tus filtros, gestionas tu "
                           "suscripción y consultas tus estadísticas.",
        "launch.open":     "⚙️ Abrir configuración",
        "launch.active":   "✅ *{plan}* · {days} días restantes",
        "launch.trial":    "🎁 *{days} días de prueba gratis* activados.",
        "launch.no_sub":   "❌ Sin suscripción activa",
        "launch.admin":   "👑 *Administrador* · acceso total",
        "sub.expired":     "Tu suscripción ha caducado",
        "sub.expired_body":"Tu acceso ha terminado. Renueva cuando quieras desde el bot.",
        "sub.cancelled":   "Suscripción cancelada",
        "sub.cancelled_body": "Tu acceso ha quedado desactivado. Puedes renovar cuando quieras.",
        "sub.cancelled_side": "Se ha cancelado una suscripción secundaria de tu cuenta. "
                              "Tu plan actual sigue activo.",
        "launch.nodispo":  "⚠️ La configuración no está disponible ahora mismo. "
                           "Escríbele al administrador.",

        # Bets
        "bet.middle_tag":  "🎯 MIDDLEBET",
        "bet.surebet":     "SUREBET",
        "bet.roi":         "ROI",
        "bet.game":        "Partido",
        "bet.market":      "Mercado",
        "bet.stake":       "Stake",
        "bet.place_bet":   "Apostar",
        "bet.with":        "Con {amount}",
        "bet.per":         "por cada {amount}",
        "bet.profit":      "Beneficio",
    },
    "en": {
        "back":            "⬅️ Back",
        "close":           "❎ Close",
        "save":            "💾 Save",
        "skip":            "⏭ Skip",
        "next":            "Next ➡️",
        "prev":            "⬅️ Back",
        "finish":          "🎉 Finish",
        "refresh":         "🔄 Refresh",

        "home.welcome":       "👋 Hi *{name}*",
        "home.no_sub":        "❌ No active subscription",
        "home.active_sub":    "✅ *{plan}* active · {days} days left",
        "home.trial_name":    "🎁 Free trial",
        "home.trial_intro":   "🎁 *Free trial activated!*\n"
                              "You've got {days} day(s) of full access, no card required.",
        "home.bookmakers_sure":  "🏦 Surebet bookmakers",
        "home.sports":           "🏟 Sports",
        "home.profit":           "📊 Min profit",
        "home.types":            "🎯 Active types",
        "home.mute":             "🔕 Mute",
        "home.schedule":         "🕐 Schedule",
        "home.language":         "🌐 Language",
        "home.subscription":     "💼 Subscription",
        "home.stats":            "📊 Statistics",

        "status.enabled":  "✅ On",
        "status.disabled": "⛔ Off",
        "status.all":      "All",
        "status.none":     "None",
        "status.selected": "{n} selected",

        # Mini App launcher (/start)
        "launch.greet":    "👋 Hi *{name}*",
        "launch.help":     "From here you set your filters, manage your "
                           "subscription and check your statistics.",
        "launch.open":     "⚙️ Open settings",
        "launch.active":   "✅ *{plan}* · {days} days left",
        "launch.trial":    "🎁 *{days}-day free trial* activated.",
        "launch.no_sub":   "❌ No active subscription",
        "launch.admin":   "👑 *Administrator* · full access",
        "sub.expired":     "Your subscription has expired",
        "sub.expired_body":"Your access has ended. Renew whenever you like from the bot.",
        "sub.cancelled":   "Subscription cancelled",
        "sub.cancelled_body": "Your access has been deactivated. You can renew whenever you like.",
        "sub.cancelled_side": "A secondary subscription on your account was cancelled. "
                              "Your current plan is still active.",
        "launch.nodispo":  "⚠️ Settings are unavailable right now. "
                           "Please contact the administrator.",

        "bet.middle_tag":  "🎯 MIDDLEBET",
        "bet.surebet":     "SUREBET",
        "bet.roi":         "ROI",
        "bet.game":        "Game",
        "bet.market":      "Market",
        "bet.stake":       "Stake",
        "bet.place_bet":   "Bet",
        "bet.with":        "With {amount}",
        "bet.per":         "per {amount}",
        "bet.profit":      "Profit",
    },
}


def t(key: str, lang: str = "es", **kwargs: Any) -> str:
    tbl = STRINGS.get(lang) or STRINGS["es"]
    val = tbl.get(key) or STRINGS["es"].get(key) or key
    return val.format(**kwargs) if kwargs else val
