"""
Catálogo de deportes: solo los que recogen los colectores (fútbol, baloncesto, tenis).
Las claves (soccer/basketball/tennis) son las que se guardan en los filtros de usuario.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, List, Optional


@dataclass(frozen=True)
class Sport:
    key: str
    name_en: str
    name_es: str
    emoji: str
    aliases: tuple = ()

    def label(self, lang: str = "es") -> str:
        name = self.name_es if lang == "es" else self.name_en
        return f"{self.emoji} {name}"


_ALL: List[Sport] = [
    Sport("soccer",       "Soccer",            "Fútbol",            "⚽",
          aliases=("football", "futbol", "fútbol")),
    Sport("basketball",   "Basketball",        "Baloncesto",        "🏀",
          aliases=("baloncesto",)),
    Sport("tennis",       "Tennis",            "Tenis",             "🎾",
          aliases=("tenis",)),
]


class SportCatalog:
    def __init__(self, sports: List[Sport]):
        self._by_key: Dict[str, Sport] = {s.key: s for s in sports}
        # índice para resolver el texto exacto de la línea "Sport:"
        self._by_name: Dict[str, Sport] = {}
        for s in sports:
            for term in (s.name_en, s.name_es, s.key, *s.aliases):
                self._by_name[term.strip().lower()] = s

    def get(self, key: str) -> Optional[Sport]:
        return self._by_key.get((key or "").lower())

    def all(self) -> List[Sport]:
        return list(self._by_key.values())

    def keys(self) -> List[str]:
        return list(self._by_key.keys())

    def by_name(self, name: str) -> Optional[Sport]:
        """'Table Tennis' → Sport(tabletennis). None si no se reconoce."""
        if not name:
            return None
        return self._by_name.get(name.strip().lower())

    def find_by_text(self, text: str) -> List[Sport]:
        t = (text or "").lower()
        found = []
        for s in self._by_key.values():
            terms = [s.name_en.lower(), s.name_es.lower(), s.key] + list(s.aliases)
            if any(term in t for term in terms):
                found.append(s)
        return found


CATALOG = SportCatalog(_ALL)
