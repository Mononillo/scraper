"""
dafabet.py — colector de cuotas de Dafabet España (dafabet.es).

API REST JSON pública en el propio dominio (sin cookies ni captcha; solo cabeceras `x-sb-brand: DAFASPAIN`):
    GET {api}/eventpathtree?periodType=PRE_MATCH&…&sportCode=FOOT|BASK|TENN   -> árbol deporte > país > liga (ids)
    GET {api}/events?periodType=IN_RUNNING&liveOnly=true&eventPathIds=<sport>&includeMarkets=true…   -> directos con
                                           TODOS sus mercados (una petición por deporte)
    GET {api}/eventpaths/<ligaId>/events?periodType=PRE_MATCH&includeMarkets=true…                 -> pre-partido de una
                                           liga con todos los mercados (una petición por liga)
    GET {api}/events/<id>?includeMarkets=true…                                                     -> detalle (--dump)
Cada mercado trae `marketTypeId` (id fijo del tipo), `opponentId` (equipo al que se refiere, si es de equipo),
`period.fullAbbreviation` (FT/M/RT/1H/2H/Q1..Q4/S1..) y en cada resultado `extraKey1` (la línea) y el precio decimal.
Se normaliza por tabla de marketTypeId; lo que no está en la tabla pasa por markets.classify() con la descripción
(sin el sufijo " - Equipo/Jugador") y se le añade lado y periodo a partir de los campos estructurados.

IMPORTANTE: dafabet.es redirige a dafabet.com desde IPs no españolas: solo funciona desde España.

Uso:  python dafabet.py            (bucle)     --once     --list (competiciones)     --dump <eventId>
"""
from __future__ import annotations

import fastjson as json
import logging
import os
import re
import sys
import time
from datetime import datetime, timedelta
from pathlib import Path

import requests

from competitions import Competitions
from markets import _fold, _team_in, classify
from storage import OddsStore
import pace

log = logging.getLogger("dafabet")
CFG_PATH = Path(os.getenv("DAFABET_CFG", Path(__file__).parent / "dafabet.json"))
NONE = -1234567890000000000          # "sin valor" en esta API (ids) ; floats: -1.23456789e+18

# ── marketTypeId -> (mercado base, tipo).  tipo: result (1/X/2 por opponentId del resultado), dc, total, hcp, yesno.
MT: dict[str, dict[int, tuple[str, str]]] = {
    "futbol": {1: ("1X2", "result"), 3021: ("HANDICAP", "hcp"), 3007: ("TOTAL", "total"), 605: ("DC", "dc"),
               571: ("DNB", "result"), 350: ("BTTS", "yesno")},
    "baloncesto": {16: ("1X2", "result"), 3061: ("HANDICAP", "hcp"), 3060: ("TOTAL", "total")},
    "tenis": {16: ("1X2", "result"), 3061: ("HANDICAP", "hcp"), 3060: ("TOTAL", "total")},
}
# tipos que NO se guardan nunca (3 vías en baloncesto, exactos, combinadas…)
MT_SKIP = {3056, 3001, 296, 27, 13810, 26, 180, 20670004, 20670006, 20670008, 10670008, 10670009, 20670010, 10242017, 10241999, 110125,
           20670013, 135096, 13510, 13540, 135097, 1259, 13920, 110091, 10311933, 2101}
# marketTypeId de props de jugador (baloncesto) -> texto canónico para markets.classify
PLAYER_PROP_TYPES = {10670001: "Puntos", 10670002: "Asistencias", 10670003: "Rebotes", 10670004: "Robos",
                     10670005: "Pérdidas de balón", 10670010: "Puntos + Asistencias", 10670011: "Puntos + Rebotes",
                     10670012: "Asistencias + Rebotes", 10670013: "Puntos + Rebotes + Asistencias", 10670014: "Robos + Tapones"}
# abreviatura de periodo -> sufijo propio ('' = partido completo)
PERIOD = {"FT": "", "M": "", "RT": "_REG", "1H": "_1H", "2H": "_2H", "Q1": "_Q1", "Q2": "_Q2", "Q3": "_Q3", "Q4": "_Q4",
          "ET": "_OT", "OT": "_OT"}


_PERIOD_TXT = {"primer tiempo": "1ª parte", "segundo tiempo": "2ª parte", "descanso": "Descanso", "medio tiempo": "Descanso",
               "prórroga": "Prórroga", "tiempo extra": "Prórroga", "penaltis": "Penaltis", "penales": "Penaltis",
               "1er cuarto": "Q1", "2do cuarto": "Q2", "3er cuarto": "Q3", "4to cuarto": "Q4", "primer set": "Set 1",
               "segundo set": "Set 2", "tercer set": "Set 3", "cuarto set": "Set 4", "quinto set": "Set 5"}


def _period(abbr: str | None, sport: str) -> str | None:
    if abbr is None:
        return ""
    a = abbr.upper()
    if a in PERIOD:
        if a == "M" and sport == "futbol":                 # fútbol: M = con prórroga/penaltis (clasificación) -> fuera
            return None
        suf = PERIOD[a]
        if suf == "_REG" and sport != "baloncesto":
            suf = ""
        return suf
    m = re.fullmatch(r"(?:S|SET)?(\d)(?:S|SET)?", a)
    if m and sport == "tenis":
        return f"_SET{m.group(1)}"
    return None                                                # periodo desconocido: no se guarda


_INTERVAL = re.compile(r"intervalo|interval|\bmin\.?\s*\d{1,3}\s*-\s*\d{1,3}\b|\d{1,3}\s*-\s*\d{1,3}\s*min|\bminutos?\b|"
                       r"\b(proxim|siguiente|next|ultim|primer|first|last)\w*\b|\bresto\b|rest of")


def _price(o: dict) -> float | None:
    cp = (o.get("consolidatedPrice") or {}).get("currentPrice") or {}
    p = cp.get("decimal")
    return float(p) if p and p > 1.0 else None


def _line(o: dict) -> float | None:
    # líneas asiáticas cuarto ("Más 2.5,3", "Oviedo 0,-0.5"): extraKey1 solo trae la primera parte -> se descartan
    if re.search(r"\d\s*,\s*[+-]?\d", o.get("description") or ""):
        return None
    v = o.get("extraKey1")
    if v is None or v < -1e17:
        m = re.search(r"([+-]?\d+(?:\.\d+)?)\s*$", o.get("description") or "")
        return float(m.group(1)) if m else None
    return float(v)


def _half(v: float | None) -> bool:
    return v is not None and abs(abs(v) % 1 - 0.5) < 1e-9


def _side_suffix(opp: int | None, home_id: int, away_id: int) -> str | None:
    if opp in (None, NONE):
        return ""
    return "_HOME" if opp == home_id else "_AWAY" if opp == away_id else None


def _rebase_live_handicaps(sels: list[dict], score: str | None) -> list[dict]:
    """Dafabet cotiza el hándicap asiático en directo sobre los goles QUE QUEDAN (marcador 0:0 desde ahora), no sobre
    el resultado final como el resto de casas.  Se convierte restando la diferencia actual del marcador
    (3:0 y 'local -1.5 desde ahora' == 'local -4.5' al final; 'visitante +1.5 desde ahora' == 'visitante +4.5').  Sin marcador fiable, los hándicaps en directo se descartan."""
    m = re.fullmatch(r"\s*(\d+)\s*:\s*(\d+)\s*", score or "")
    diff = int(m.group(1)) - int(m.group(2)) if m else None
    out = []
    for s in sels:
        mk = s["market"]
        if mk in ("HANDICAP", "HANDICAP_1H") and s.get("line") is not None:
            if diff is None:
                continue
            # la línea guardada es la PROPIA de cada selección (local -0.5 empareja con visitante +0.5)
            s = dict(s, line=round(s["line"] - diff if s["selection"] == "1" else s["line"] + diff, 2))
        out.append(s)
    return out


def market_selections(m: dict, sport: str, home: str, away: str, home_id: int, away_id: int) -> list[dict]:
    if (m.get("status") or "open").lower() != "open":
        return []
    mt = m.get("marketTypeId")
    if mt in MT_SKIP:
        return []
    per = _period((m.get("period") or {}).get("fullAbbreviation"), sport)
    if per is None:
        return []
    outs = [o for o in m.get("outcomes") or [] if not o.get("hidden") and not o.get("withdrawn") and _price(o)]
    if not outs:
        return []
    side = _side_suffix(m.get("opponentId"), home_id, away_id)
    if side is None:
        return []
    desc = (m.get("description") or "").strip()
    # mercados por tramo de minutos ("Bookings totales en el intervalo de 10 min. 61-70"), siguiente/último…:
    # el marketTypeId es el mismo que el del total del partido, así que se filtran por la descripción
    if _INTERVAL.search(_fold(desc)):
        return []
    rule = MT.get(sport, {}).get(mt)
    out: list[dict] = []
    if rule:
        base, typ = rule
        if typ == "total":
            if side == "":
                # sin opponentId pero con el equipo en la descripción ("Tarjetas - Augsburgo"): total por equipo
                tl = desc.rpartition(" - ")[2].strip() if " - " in desc else ""
                team = _team_in(_fold(tl), home, away) if tl else None
                if team:
                    side = f"_{team}"
            market = f"{base}{side}{per}"
            for o in outs:
                ln = _line(o)
                d = (o.get("description") or "").lower()
                sel = "Over" if d.startswith(("más", "mas", "over")) else "Under" if d.startswith(("menos", "under")) else None
                if sel and _half(ln):
                    out.append({"market": market, "selection": sel, "line": ln, "player": None, "price": _price(o)})
        elif typ == "hcp":
            market = f"{base}{per}"
            if len(outs) != 2:
                return []
            for o in outs:
                ln = _line(o)
                oid = o.get("opponentId")
                sel = "1" if oid == home_id else "2" if oid == away_id else None
                if sel and _half(ln):
                    out.append({"market": market, "selection": sel, "line": ln, "player": None, "price": _price(o)})
        elif typ == "result":
            market = f"{base}{per}"
            for o in outs:
                oid = o.get("opponentId")
                d = (o.get("description") or "").strip().lower()
                sel = "1" if oid == home_id else "2" if oid == away_id else "X" if d in ("empate", "x", "draw") else None
                if sel:
                    out.append({"market": market, "selection": sel, "line": None, "player": None, "price": _price(o)})
        elif typ == "dc":
            market = f"{base}{per}"
            for o in outs:
                d = (o.get("description") or "").lower()
                a, _, b = d.partition("/")
                parts = {("X" if "empate" in x else "1" if x.strip() and x.strip() in home.lower() else "2" if x.strip() and x.strip() in away.lower() else "?") for x in (a, b)}
                sel = {frozenset("1X"): "1X", frozenset("12"): "12", frozenset("X2"): "X2"}.get(frozenset(parts))
                if sel:
                    out.append({"market": market, "selection": sel, "line": None, "player": None, "price": _price(o)})
        elif typ == "yesno":
            market = f"{base}{per}"
            for o in outs:
                d = (o.get("description") or "").strip().lower()
                sel = {"sí": "Yes", "si": "Yes", "yes": "Yes", "no": "No"}.get(d)
                if sel:
                    out.append({"market": market, "selection": sel, "line": None, "player": None, "price": _price(o)})
        return _dedup(out)
    # ── desconocido: más/menos de equipo/jugador por descripción ("Puntos - James Harden", "Tiros de esquina - Oviedo")
    if not all(re.match(r"^(más|mas|menos|over|under)\b", (o.get("description") or "").lower()) for o in outs):
        return []
    base_desc, _, tail = desc.rpartition(" - ")
    player = None
    if tail and not base_desc:
        base_desc = desc
    elif tail and side == "":
        tl = tail.strip()
        if tl.lower() in (home.lower(), away.lower()) or (home and tl in home) or (away and tl in away):
            side = "_HOME" if (tl.lower() == home.lower() or tl in home) else "_AWAY"
        else:
            player = tl
    # props de jugador: el marketTypeId manda sobre el texto (p.ej. "Puntos de 3" NO son puntos)
    base_desc = PLAYER_PROP_TYPES.get(mt, base_desc.strip())
    if re.search(r"\bdobles?\b|double", base_desc, re.I):      # "Doble doble", "Triple doble": no son totales
        return []
    if player and re.search(r"\b(3|tres)\b.*\bpuntos\b|\bpuntos de (3|tres)\b|\btriples?\b|\b3 ?p(ts?|m)?\b", base_desc, re.I):
        base_desc = "Triples"
    info = classify(base_desc, sport, home, away, kind="total", player=player)
    if not info:
        return []
    market = info.market
    if side and not market.startswith("PLAYER_") and "_HOME" not in market and "_AWAY" not in market:
        market = f"{market}{side}"
    market = f"{market}{per}"
    for o in outs:
        ln = _line(o)
        d = (o.get("description") or "").lower()
        sel = "Over" if d.startswith(("más", "mas", "over")) else "Under" if d.startswith(("menos", "under")) else None
        if sel and _half(ln):
            out.append({"market": market, "selection": sel, "line": ln, "player": info.player, "price": _price(o)})
    return _dedup(out)


def _dedup(out: list[dict]) -> list[dict]:
    """Dos selecciones con la misma clave (mercado, lado, línea, jugador) = algo no identificado (equipo/periodo
    que no se ha podido distinguir): mejor no guardar nada que guardar una cuota mal etiquetada."""
    keys = [(o["market"], o["selection"], o["line"], o.get("player")) for o in out]
    return out if len(keys) == len(set(keys)) else []


# ──────────────────────────────────────────────────────────────────────────────
class Collector:
    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.bk = cfg["bookmaker"]
        self.api = cfg["api"].rstrip("/")
        self.sess = requests.Session()
        self.sess.headers.update({"Origin": cfg["origin"], "Referer": cfg["origin"] + "/es/sports/240-FOOT",
                                  **(cfg.get("headers") or {})})
        self.catalog = Competitions()
        self.store = OddsStore(bookmaker=self.bk)
        self.sports = {int(k): v for k, v in cfg["sports"].items()}
        self.leagues: dict[int, tuple[str, str]] = {}            # eventPathId liga -> (deporte, competición canónica)
        self._all: list[tuple[str, int, str]] = []
        self._menu_at = 0.0
        self._last_prematch = 0.0
        self._pm_queue: list[int] = []
        self._cfg_mtime = CFG_PATH.stat().st_mtime
        self._bg = pace.Background(f"{self.bk}-prematch")
        self._last_req = 0.0
        self.transport = "requests"

    # ── HTTP ──
    def get(self, path: str, **params):
        gap = self.cfg.get("request_gap", 0.4) - (time.time() - self._last_req)
        if gap > 0:
            time.sleep(gap)
        params.setdefault("l", "es-ES")
        r = self.sess.get(f"{self.api}/{path.lstrip('/')}", params=params, timeout=getattr(self, "timeout", 25), allow_redirects=False)
        self._last_req = time.time()
        if r.status_code in (301, 302, 303, 307, 308):
            raise RuntimeError(f"{path} -> redirección a {r.headers.get('Location')} (¿IP no española?)")
        if r.status_code in (403, 429):
            raise RuntimeError(f"{path} -> HTTP {r.status_code} (bloqueo/ritmo): pausa")
        if r.status_code != 200:
            raise RuntimeError(f"{path} -> HTTP {r.status_code}")
        return json.loads(r.content)

    def _reload_if_changed(self):
        mt = CFG_PATH.stat().st_mtime
        if mt != self._cfg_mtime:
            self._cfg_mtime = mt
            self.cfg = pace.apply(json.loads(CFG_PATH.read_text(encoding="utf-8")))
            log.info("dafabet.json recargado")
        self.catalog.reload()

    # ── catálogo ──
    def refresh_menu(self, force: bool = False):
        if not force and time.time() - self._menu_at < self.cfg.get("menu_ttl", 900):
            return
        found: dict[int, tuple[str, str]] = {}
        allt: list[tuple[str, int, str]] = []
        ok = True
        try:
            tree = self.get("eventpathtree", periodType="PRE_MATCH", includeUnpricedMarkets="false", includeMarketTypes="false",
                            lightWeightResponse="true", eventTypeFilter="GAMEEVENT", sportGroups="REGULAR")
            for s in tree if isinstance(tree, list) else tree.get("eventPaths") or []:
                sport = self.sports.get(s.get("id"))
                if not sport:
                    continue
                for c in s.get("children") or []:
                    for lg in c.get("children") or []:
                        label = re.sub(r"\s+", " ", f"{c.get('name') or ''} - {lg.get('name') or ''}").strip(" -")
                        allt.append((sport, lg["id"], label))
                        comp = self.catalog.match(self.bk, sport, label)
                        if comp:
                            found[lg["id"]] = (sport, comp)
        except Exception as e:  # noqa: BLE001
            ok = False
            log.warning("catálogo: %s", e)
        if found or (force and ok):
            self.leagues = found
            self._all = allt
        self._menu_at = time.time()
        log.info("%d competiciones mapeadas en Dafabet", len(self.leagues))

    # ── eventos ──
    @staticmethod
    def _state(ev: dict, sport: str) -> tuple[str | None, str | None, str | None, bool]:
        sc = ev.get("scores") or {}
        pts = {s.get("opponentId"): s.get("points") for s in sc.get("score") or []}
        ha, hb = ev.get("opponentAId"), ev.get("opponentBId")
        opp = ev.get("opponents") or []
        if (not ha or ha == NONE) and len(opp) >= 2:
            ha, hb = opp[0]["id"], opp[1]["id"]
        score = None
        if sport == "tenis":
            sets = ((ev.get("sets") or {}).get("gameSet") or [])
            parts = []
            for st in sets:
                g = {s.get("opponentId"): s.get("points") for s in st.get("score") or st.get("scores") or []} if isinstance(st, dict) else {}
                if g:
                    parts.append(f"{g.get(ha, 0)}:{g.get(hb, 0)}")
            score = " ".join(parts) or None
        elif pts:
            score = f"{pts.get(ha, '0')}:{pts.get(hb, '0')}"
        period = ev.get("currentPeriod")
        ab = (ev.get("currentPeriodAbbreviation") or "").upper()
        period = {"1H": "1ª parte", "2H": "2ª parte", "HT": "Descanso", "ET": "Prórroga", "OT": "Prórroga", "PEN": "Penaltis",
                  "Q1": "Q1", "Q2": "Q2", "Q3": "Q3", "Q4": "Q4"}.get(ab) or _PERIOD_TXT.get((period or "").lower(), period)
        n = ev.get("currentPeriodNumber") or 0
        if sport == "baloncesto" and n:
            period = f"Q{n}" if n <= 4 else "Prórroga"
        elif sport == "tenis" and n:
            period = f"Set {n}"
        clk = ev.get("clock") or {}
        timer = f"{clk['minutes']}:{clk.get('seconds', 0):02d}" if clk.get("minutes") is not None else None
        playing = bool(ev.get("liveOpenMarketCount")) or bool(clk) or bool(pts)
        return score, period, timer, playing

    def _row(self, ev: dict, kind: str) -> tuple[str, dict] | None:
        paths = ev.get("eventPaths") or []
        lg = next((self.leagues.get(p.get("id")) for p in reversed(paths) if self.leagues.get(p.get("id"))), None)
        if not lg or ev.get("eventType") not in (None, "GAMEEVENT"):
            return None
        sport, comp = lg
        opp = ev.get("opponents") or []
        if len(opp) < 2:
            return None
        home, away = opp[0]["description"], opp[1]["description"]
        home_id, away_id = opp[0]["id"], opp[1]["id"]
        if ev.get("opponentAId") not in (None, 0, NONE) and ev.get("opponentAId") == away_id:
            home, away, home_id, away_id = away, home, away_id, home_id
        score, period, timer, playing = self._state(ev, sport)
        if kind == "live" and not playing:
            return None
        dt = None
        try:
            dt = datetime.fromisoformat(ev["eventDate"].replace("Z", "+00:00")).astimezone()
        except Exception:  # noqa: BLE001
            pass
        if kind != "live" and dt and dt - datetime.now(dt.tzinfo) > timedelta(hours=self.cfg.get("prematch_hours", 48)):
            return None
        sels: list[dict] = []
        for m in ev.get("markets") or []:
            sels.extend(market_selections(m, sport, home, away, home_id, away_id))
        if kind == "live" and sport == "futbol":
            sels = _rebase_live_handicaps(sels, score)
        if not sels:
            return None
        row = {"event_id": str(ev["id"]), "home": home, "away": away, "competition": comp,
               "date": dt.strftime("%Y-%m-%d") if dt else None, "start_time": dt.strftime("%H:%M") if dt else None,
               "url": self.cfg.get("event_url", "").format(slug=ev.get("slug") or ev["id"]), "selections": sels}
        if kind == "live":
            row.update(score=score, period=period, timer=timer)
        return sport, row

    _COMMON = dict(allBettableEvents="true", bettable="true", includeHiddenOutcomes="false", includeMarkets="true",
                   lightWeightResponse="true", marketFilter="GAME", sportGroups="REGULAR", eventType="GAME",
                   maxMarketPerEvent="1000", eventsPerPage="100")

    def live_cycle(self) -> tuple[int, int]:
        old, self.timeout = getattr(self, "timeout", 25), self.cfg.get("timeout_live", 8)   # fallar rápido en directo
        try:
            return self._live_cycle()
        finally:
            self.timeout = old

    def _live_cycle(self) -> tuple[int, int]:
        rows = changed = 0
        present: set[str] = set()
        for sid, sport in self.sports.items():
            if not any(sp == sport for sp, _c in self.leagues.values()):
                continue
            data = self.get("events", periodType="IN_RUNNING", liveOnly="true", includeLiveEvents="true",
                            liveMarketStatus="OPEN", marketStatus="OPEN", eventPathIds=str(sid), **self._COMMON)
            by_sport: dict[str, list[dict]] = {}
            for ev in data if isinstance(data, list) else data.get("events") or []:
                r = self._row(ev, "live")
                if r:
                    by_sport.setdefault(r[0], []).append(r[1])
            for sp, rs in by_sport.items():
                present |= {r["event_id"] for r in rs}
                changed += self.store.save_rows(sp, "live", rs)
                rows += len(rs)
        self.store.sweep(present, "live")
        return rows, changed

    def prematch_league(self, lid: int) -> tuple[int, int]:
        data = self.get(f"eventpaths/{lid}/events", periodType="PRE_MATCH", marketStatus="OPEN", includeHiddenMarkets="false",
                        excludeLongTermSuspended="true", **self._COMMON)
        by_sport: dict[str, list[dict]] = {}
        for ev in data if isinstance(data, list) else data.get("events") or []:
            r = self._row(ev, "prematch")
            if r:
                by_sport.setdefault(r[0], []).append(r[1])
        rows = changed = 0
        for sp, rs in by_sport.items():
            self._pm_present |= {r["event_id"] for r in rs}
            changed += self.store.save_rows(sp, "prematch", rs)
            rows += len(rs)
        return rows, changed

    def _pm_job(self, t0: float, once: bool):
        if not self._pm_queue and t0 - self._last_prematch >= self.cfg.get("interval_prematch", 240):
            self._pm_queue = list(self.leagues)
            self._pm_present: set[str] = set()
            self._pm_rows = self._pm_changed = 0
            self._last_prematch = t0
        if not self._pm_queue:
            return None
        batch = len(self._pm_queue) if once else max(1, self.cfg.get("prematch_batch", 2))
        chunk, self._pm_queue = self._pm_queue[:batch], self._pm_queue[batch:]

        def _run():
            for lid in chunk:
                try:
                    r, c = self.prematch_league(lid)
                    self._pm_rows += r
                    self._pm_changed += c
                except Exception as e:  # noqa: BLE001
                    log.warning("prematch liga %s: %s", lid, e)
                    if "bloqueo" in str(e):
                        time.sleep(20)
            if not self._pm_queue:
                self.store.sweep(self._pm_present, "prematch")
                return f"prematch {self._pm_rows} ev / {self._pm_changed} cambios (pasada completa)"
            return f"prematch {self._pm_rows} ev / {self._pm_changed} cambios ({len(self._pm_queue)} ligas pendientes)"
        return _run

    def run(self, once: bool = False):
        backoff = 2
        while True:
            t0 = time.time()
            try:
                self._reload_if_changed()
                self.refresh_menu()
                rows, changed = self.live_cycle()
                msg = f"live {rows} ev / {changed} cambios"
                if not self._bg.busy():
                    job = self._pm_job(t0, once)
                    if job is not None:
                        r = self._bg.run(job, inline=once)
                        if r:
                            msg += " | " + r
                note = self._bg.note()
                if note:
                    msg += " | " + note
                self.store.set_status(**{f"{self.bk}_last_ok": time.time(), f"{self.bk}_live_events": rows,
                                         f"{self.bk}_transport": self.transport})
                log.info("%s [%s] (%.1fs)", msg, self.transport, time.time() - t0)
                backoff = 2
                if once:
                    return
            except Exception as e:  # noqa: BLE001
                if "bloqueo" in str(e):
                    backoff = max(backoff, 30)
                log.warning("error de ciclo: %s — reintento en %ss", e, backoff, exc_info=log.isEnabledFor(logging.DEBUG))
                self.store.set_status(**{f"{self.bk}_last_error": f"{time.time():.0f} {e}"})
                time.sleep(backoff)
                backoff = min(backoff * 2, 120)
                continue
            time.sleep(max(0.5, self.cfg.get("interval_live", 3) - (time.time() - t0)))


def list_catalog(c: Collector):
    c.refresh_menu(force=True)
    by: dict[str, list] = {}
    for sport, lid, label in sorted(set(c._all), key=lambda x: (x[0], x[2])):
        by.setdefault(sport, []).append((lid, label))
    for sport, items in by.items():
        print(f"\n=== {sport}")
        for lid, label in items:
            comp = c.leagues.get(lid)
            print(f" {'✔' if comp else ' '} {label}   [{lid}]" + (f" -> {comp[1]}" if comp else ""))
    print(f"\n{len(c.leagues)} ligas mapeadas")


def dump_event(c: Collector, eid: str):
    c.refresh_menu(force=True)
    ev = c.get(f"events/{eid}", bettable="true", marketStatus="OPEN", includeMarkets="true", lightWeightResponse="true")
    if isinstance(ev, list):
        ev = ev[0] if ev else {}
    if not ev.get("id"):
        print("evento no encontrado")
        return
    sport = next((sp for sid, sp in c.sports.items() if any(p.get("id") == sid for p in ev.get("eventPaths") or [])), "futbol")
    for p in ev.get("eventPaths") or []:
        c.leagues.setdefault(p["id"], (sport, "?"))
    opp = ev.get("opponents") or [{}, {}]
    home, away = opp[0].get("description", ""), opp[1].get("description", "")
    print(ev.get("description"), "|", ev.get("eventDate"), "| periodo:", ev.get("currentPeriod"), "| score:", c._state(ev, sport))
    for m in ev.get("markets") or []:
        sels = market_selections(m, sport, home, away, opp[0].get("id"), opp[1].get("id"))
        print(f"MT {m.get('marketTypeId')!s:>9} {(m.get('period') or {}).get('fullAbbreviation') or '':<3} {m.get('description')[:48]:<48} -> "
              + (", ".join(f"{s['market']} {s.get('player') or ''} {s['selection']} {s.get('line') if s.get('line') is not None else ''} @{s['price']}" for s in sels) or "(sin mapear)"))
        if m.get("marketTypeId") in (3021, 3061):     # hándicaps: enseñar los outcomes tal cual llegan (línea por lado)
            for o in m.get("outcomes") or []:
                print(f"            raw: desc={o.get('description')!r} line={_line(o)} opponentId={o.get('opponentId')} "
                      f"(home={opp[0].get('id')}, away={opp[1].get('id')}) price={_price(o)}")
    r = c._row(ev, "prematch")
    if r:
        print(f"\n{r[0]}: {len(r[1]['selections'])} selecciones | {r[1]['url']}")


def main():
    logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"), format="%(asctime)s %(levelname)s %(name)s: %(message)s", datefmt="%H:%M:%S")
    cfg = pace.apply(json.loads(CFG_PATH.read_text(encoding="utf-8")))
    c = Collector(cfg)
    if "--list" in sys.argv:
        list_catalog(c)
        return
    if "--dump" in sys.argv:
        dump_event(c, sys.argv[sys.argv.index("--dump") + 1])
        return
    c.run(once="--once" in sys.argv)


if __name__ == "__main__":
    main()
