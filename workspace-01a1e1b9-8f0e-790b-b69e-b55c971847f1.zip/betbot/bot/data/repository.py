"""
Repositorios: capa de persistencia sobre SQLite.

Convierte filas de la BD ↔ objetos de dominio (User, UserFilters, Subscription…).
No expone SQL fuera de esta clase; los servicios usan la API pública.
"""
from __future__ import annotations
import json
import os
import sqlite3
import time
from contextlib import contextmanager
from datetime import datetime, timedelta
from typing import List, Optional

from domain.models import (
    User, UserFilters, Subscription, SubscriptionPlan, BetKind
)
from domain.bookmakers import CATALOG as BOOKMAKERS
from domain.sports import CATALOG as SPORTS


# ──────────────────────────────────────────────────────────
#  LIMPIEZA DE FILTROS ANTIGUOS
# ──────────────────────────────────────────────────────────
# Al cambiar el catálogo (ahora son las casas de BetBurger) las claves
# guardadas en la BD pueden quedarse obsoletas. Si no se limpian, el usuario
# tiene seleccionada una casa/deporte que ya no llega NUNCA y deja de recibir
# apuestas sin saber por qué. Regla: lo que no existe hoy, se descarta; lo que
# se ha renombrado, se traduce.

_LEGACY_SPORTS = {
    "football": "soccer", "futbol": "soccer", "fútbol": "soccer",
    "baloncesto": "basketball", "tenis": "tennis",
}

# Catálogo viejo → catálogo nuevo (BetBurger). Lo que no esté en la lista
# nueva se descarta: si no, el usuario tendría seleccionada una casa que ya
# no llega nunca y dejaría de recibir apuestas sin saber por qué.
_LEGACY_BOOKS = {
    # renombradas
    "bet365":        "bet365es",
    "bet365direct":  "bet365fast",
    "bet365 fast":   "bet365fast",
    "pokerstars":    "pokerstarses",
    "bwin":          "bwines",
    "888sport":      "888sportes",
    "betway":        "betwayes",
    "winamax":       "winamaxes",
    "marathonbet":   "marathon",
    "teapuesto":     "teapuesto",       # fuera del catálogo nuevo → se descarta
    "goldenpalace":  "goldenpalace",    # fuera del catálogo nuevo → se descarta
    "unibet":        "unibet",          # fuera del catálogo nuevo → se descarta
    "zamba":         "zamba",           # fuera del catálogo nuevo → se descarta
}


def _clean_keys(values, valid: set, legacy: dict) -> list:
    out = []
    for v in values or []:
        k = str(v).strip().lower()
        k = legacy.get(k, k)
        if k in valid and k not in out:
            out.append(k)
    return out


def _as_list(raw) -> list:
    """json.loads tolerante: si la columna está corrupta devuelve []."""
    try:
        v = json.loads(raw or "[]")
    except (TypeError, ValueError):
        return []
    return v if isinstance(v, list) else []


def _clean_books(values) -> list:
    return _clean_keys(values, {b.key for b in BOOKMAKERS.all()}, _LEGACY_BOOKS)


def _clean_sports(values) -> list:
    return _clean_keys(values, {s.key for s in SPORTS.all()}, _LEGACY_SPORTS)


# ──────────────────────────────────────────────────────────
# DB CONNECTION HELPER
# ──────────────────────────────────────────────────────────

class Database:
    """Wrapper mínimo sobre sqlite3 con contexto y esquema."""

    def __init__(self, path: str):
        self.path = path
        # Si el directorio no existe lo creamos: así la app también arranca
        # fuera de Docker en vez de morir con "unable to open database file".
        parent = os.path.dirname(os.path.abspath(path))
        if parent:
            os.makedirs(parent, exist_ok=True)

    @contextmanager
    def connect(self):
        conn = sqlite3.connect(self.path, timeout=10)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        # WAL permite que el bot y la mini app lean/escriban a la vez sin
        # bloqueos ("database is locked"). Imprescindible con 2 procesos.
        conn.execute("PRAGMA journal_mode = WAL")
        conn.execute("PRAGMA busy_timeout = 10000")
        try:
            yield conn
            conn.commit()
        finally:
            conn.close()

    def init_schema(self):
        with self.connect() as c:
            c.executescript(SCHEMA_SQL)
            # columnas añadidas después de la primera versión (migración suave)
            cols = {r[1] for r in c.execute("PRAGMA table_info(users)").fetchall()}
            for col, ddl in (("live_enabled", "INTEGER DEFAULT 1"), ("prematch_enabled", "INTEGER DEFAULT 1")):
                if col not in cols:
                    c.execute(f"ALTER TABLE users ADD COLUMN {col} {ddl}")


SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS users (
    telegram_id            INTEGER PRIMARY KEY,
    username               TEXT,
    first_name             TEXT,

    -- Filtros (JSON)
    surebet_bookmakers     TEXT DEFAULT '[]',
    sports                 TEXT DEFAULT '[]',
    surebet_min_profit     REAL DEFAULT 0,
    surebets_enabled       INTEGER DEFAULT 1,
    middlebets_marked      INTEGER DEFAULT 1,
    live_enabled           INTEGER DEFAULT 1,
    prematch_enabled       INTEGER DEFAULT 1,
    language               TEXT DEFAULT 'es',
    mute_until             TEXT,
    hour_start             INTEGER DEFAULT 0,
    hour_end               INTEGER DEFAULT 24,

    -- Suscripción
    sub_active             INTEGER DEFAULT 0,
    sub_plan               TEXT,
    sub_expires_at         TEXT,
    stripe_customer        TEXT,
    stripe_subscription    TEXT,
    trial_used             INTEGER DEFAULT 0,

    created_at             TEXT,
    updated_at             TEXT
);

CREATE TABLE IF NOT EXISTS bet_log (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER,
    ts          TEXT,
    kind        TEXT,           -- 'surebet' | 'middlebet'
    is_middle   INTEGER DEFAULT 0,
    sport       TEXT,
    profit      REAL,
    bookmakers  TEXT,            -- JSON list
    game        TEXT,
    market      TEXT
);
CREATE INDEX IF NOT EXISTS idx_bet_log_user_ts ON bet_log(user_id, ts);

CREATE TABLE IF NOT EXISTS freebets (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    bookmaker   TEXT NOT NULL,          -- clave del catálogo (o texto libre)
    title       TEXT NOT NULL,          -- "Apuesta gratis de 10 €"
    description TEXT DEFAULT '',        -- condiciones / letra pequeña
    value_eur   REAL DEFAULT 0,         -- valor nominal en euros
    url         TEXT DEFAULT '',        -- enlace a la promoción
    kind        TEXT DEFAULT 'freebet', -- 'freebet' | 'bonus'
    expires_at  TEXT,                   -- ISO, opcional
    active      INTEGER DEFAULT 1,
    created_at  TEXT
);
CREATE INDEX IF NOT EXISTS idx_freebets_active ON freebets(active);

-- Avisos ya enviados: para no repetir el mismo aviso en cada sondeo.
-- Un aviso se identifica por (usuario, clave). La clave incluye el id de
-- suscripción y, si aplica, el periodo, así un aviso se manda una vez por
-- cada hecho real, no cada 5 minutos.
CREATE TABLE IF NOT EXISTS notices (
    id       INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id  INTEGER NOT NULL,
    key      TEXT NOT NULL,
    ts       TEXT,
    UNIQUE(user_id, key)
);

-- Auditoría de cambios de suscripción: para saber QUÉ suma días y cuándo
CREATE TABLE IF NOT EXISTS sub_events (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id      INTEGER NOT NULL,
    ts           TEXT NOT NULL,
    action       TEXT NOT NULL,
    days_before  INTEGER,
    days_after   INTEGER,
    detail       TEXT DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_sub_events_user ON sub_events(user_id, id);

-- Administradores adicionales (los del .env son los "dueños" y no se borran)
CREATE TABLE IF NOT EXISTS admins (
    telegram_id  INTEGER PRIMARY KEY,
    note         TEXT DEFAULT '',
    added_by     INTEGER,
    created_at   TEXT
);

"""


# ──────────────────────────────────────────────────────────
# USER REPOSITORY
# ──────────────────────────────────────────────────────────

class SubscriptionAuditMixin:
    """Se añade a UserRepository: registrar y leer cambios de suscripción."""

    def log_sub_event(self, user_id: int, action: str,
                      days_before, days_after, detail: str = "") -> None:
        """
        Registra un cambio de suscripción, incluyendo QUÉ código lo provocó.
        Así, si los días crecen solos, el historial dice de dónde viene.
        """
        try:
            import inspect
            caller = "?"
            for fr in inspect.stack()[1:6]:
                fn = fr.filename.replace("\\", "/")
                if "/data/repository.py" not in fn:
                    caller = f"{fn.split('/')[-1]}:{fr.lineno}"
                    if fr.function and fr.function != "<module>":
                        caller += f" {fr.function}()"
                    break
            with self.db.connect() as c:
                c.execute("""
                    INSERT INTO sub_events
                        (user_id, ts, action, days_before, days_after, detail)
                    VALUES (?, ?, ?, ?, ?, ?)
                """, (user_id, datetime.now().isoformat(), action,
                      days_before, days_after, f"[{caller}] {detail}"))
        except Exception:                                   # noqa: BLE001
            pass      # la auditoría nunca debe romper el bot

    def clear_sub_events(self) -> int:
        """Vacía el historial de cambios de suscripción. Devuelve las filas borradas."""
        try:
            with self.db.connect() as c:
                n = c.execute("SELECT COUNT(*) FROM sub_events").fetchone()[0]
                c.execute("DELETE FROM sub_events")
            return int(n or 0)
        except Exception:                                   # noqa: BLE001
            return 0

    def sub_events(self, user_id: int, limit: int = 25) -> List[dict]:
        try:
            with self.db.connect() as c:
                rows = c.execute("""
                    SELECT * FROM sub_events WHERE user_id = ?
                    ORDER BY id DESC LIMIT ?
                """, (user_id, limit)).fetchall()
            return [dict(r) for r in rows]
        except Exception:                                   # noqa: BLE001
            return []

class UserRepository(SubscriptionAuditMixin):
    def __init__(self, db: Database):
        self.db = db

    # ── mapping row → domain ──
    @staticmethod
    def _row_to_user(row: sqlite3.Row) -> User:
        filters = UserFilters(
            surebet_bookmakers  = _clean_books(
                _as_list(row["surebet_bookmakers"])),
            sports              = _clean_sports(_as_list(row["sports"])),
            surebet_min_profit  = row["surebet_min_profit"] or 0.0,
            surebets_enabled    = bool(row["surebets_enabled"]),
            middlebets_marked   = bool(row["middlebets_marked"]),
            live_enabled        = bool(row["live_enabled"]) if "live_enabled" in row.keys() and row["live_enabled"] is not None else True,
            prematch_enabled    = bool(row["prematch_enabled"]) if "prematch_enabled" in row.keys() and row["prematch_enabled"] is not None else True,
            language            = row["language"] or "es",
            mute_until          = _parse_dt(row["mute_until"]),
            hour_start          = row["hour_start"] if row["hour_start"] is not None else 0,
            hour_end            = row["hour_end"] if row["hour_end"] is not None else 24,
        )
        sub = Subscription(
            is_active              = bool(row["sub_active"]),
            plan                   = SubscriptionPlan(row["sub_plan"]) if row["sub_plan"] else None,
            expires_at             = _parse_dt(row["sub_expires_at"]),
            stripe_customer_id     = row["stripe_customer"],
            stripe_subscription_id = row["stripe_subscription"],
            trial_used             = bool(row["trial_used"]),
        )
        return User(
            telegram_id  = row["telegram_id"],
            username     = row["username"] or "",
            first_name   = row["first_name"] or "",
            filters      = filters,
            subscription = sub,
            created_at   = _parse_dt(row["created_at"]) or datetime.now(),
            updated_at   = _parse_dt(row["updated_at"]) or datetime.now(),
        )

    # ── operaciones ──
    def find(self, telegram_id: int) -> Optional[User]:
        with self.db.connect() as c:
            row = c.execute(
                "SELECT * FROM users WHERE telegram_id = ?", (telegram_id,)
            ).fetchone()
        return self._row_to_user(row) if row else None

    def get_or_create(self, telegram_id: int, username: str = "", first_name: str = "") -> User:
        user = self.find(telegram_id)
        if user:
            return user
        now = datetime.now().isoformat()
        with self.db.connect() as c:
            c.execute("""
                INSERT INTO users (telegram_id, username, first_name, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?)
            """, (telegram_id, username, first_name, now, now))
        return self.find(telegram_id)

    def save(self, user: User):
        user.updated_at = datetime.now()
        f, s = user.filters, user.subscription
        with self.db.connect() as c:
            c.execute("""
                INSERT INTO users (
                    telegram_id, username, first_name,
                    surebet_bookmakers, sports,
                    surebet_min_profit,
                    surebets_enabled, middlebets_marked,
                    live_enabled, prematch_enabled,
                    language, mute_until, hour_start, hour_end,
                    sub_active, sub_plan, sub_expires_at,
                    stripe_customer, stripe_subscription, trial_used,
                    created_at, updated_at
                ) VALUES (
                    ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
                )
                ON CONFLICT(telegram_id) DO UPDATE SET
                    username=excluded.username,
                    first_name=excluded.first_name,
                    surebet_bookmakers=excluded.surebet_bookmakers,
                    sports=excluded.sports,
                    surebet_min_profit=excluded.surebet_min_profit,
                    surebets_enabled=excluded.surebets_enabled,
                    middlebets_marked=excluded.middlebets_marked,
                    live_enabled=excluded.live_enabled,
                    prematch_enabled=excluded.prematch_enabled,
                    language=excluded.language,
                    mute_until=excluded.mute_until,
                    hour_start=excluded.hour_start,
                    hour_end=excluded.hour_end,
                    sub_active=excluded.sub_active,
                    sub_plan=excluded.sub_plan,
                    sub_expires_at=excluded.sub_expires_at,
                    stripe_customer=COALESCE(excluded.stripe_customer, users.stripe_customer),
                    stripe_subscription=COALESCE(excluded.stripe_subscription, users.stripe_subscription),
                    trial_used=excluded.trial_used,
                    updated_at=excluded.updated_at
            """, (
                user.telegram_id, user.username, user.first_name,
                json.dumps(f.surebet_bookmakers),
                json.dumps(f.sports),
                f.surebet_min_profit,
                int(f.surebets_enabled), int(f.middlebets_marked),
                int(f.live_enabled), int(f.prematch_enabled),
                f.language,
                f.mute_until.isoformat() if f.mute_until else None,
                f.hour_start, f.hour_end,
                int(s.is_active), s.plan.value if s.plan else None,
                s.expires_at.isoformat() if s.expires_at else None,
                s.stripe_customer_id, s.stripe_subscription_id, int(s.trial_used),
                user.created_at.isoformat(), user.updated_at.isoformat(),
            ))

    def all_active(self) -> List[User]:
        with self.db.connect() as c:
            rows = c.execute("SELECT * FROM users WHERE sub_active = 1").fetchall()
        return [self._row_to_user(r) for r in rows]

    def all(self) -> List[User]:
        with self.db.connect() as c:
            rows = c.execute("SELECT * FROM users ORDER BY created_at DESC").fetchall()
        return [self._row_to_user(r) for r in rows]

    def expiring_in(self, days: int) -> List[User]:
        target = (datetime.now() + timedelta(days=days)).date().isoformat()
        with self.db.connect() as c:
            rows = c.execute("""
                SELECT * FROM users
                WHERE sub_active = 1
                  AND substr(sub_expires_at, 1, 10) = ?
            """, (target,)).fetchall()
        return [self._row_to_user(r) for r in rows]

    # ── avisos ya enviados ───────────────────────────────
    def notice_sent(self, user_id: int, key: str) -> bool:
        """True si ya le mandamos este aviso. Evita el spam del poller."""
        try:
            with self.db.connect() as c:
                r = c.execute(
                    "SELECT 1 FROM notices WHERE user_id=? AND key=?",
                    (user_id, key)).fetchone()
            return r is not None
        except Exception:                                   # noqa: BLE001
            return False

    def mark_notice(self, user_id: int, key: str) -> bool:
        """Registra el aviso como enviado. True si era nuevo."""
        try:
            with self.db.connect() as c:
                c.execute(
                    "INSERT INTO notices (user_id, key, ts) VALUES (?, ?, ?) "
                    "ON CONFLICT(user_id, key) DO NOTHING",
                    (user_id, key, datetime.now().isoformat()))
            return True
        except Exception:                                   # noqa: BLE001
            return False

    def clear_stripe_ids(self, telegram_id: int) -> bool:
        """
        Desvincula al usuario de su suscripción de Stripe.

        Hace falta un UPDATE explícito porque save() usa COALESCE para no
        perder estos datos por descuido... lo que también impedía borrarlos
        asignándoles None.
        """
        with self.db.connect() as c:
            cur = c.execute(
                "UPDATE users SET stripe_customer=NULL, "
                "stripe_subscription=NULL, updated_at=? WHERE telegram_id=?",
                (datetime.now().isoformat(), telegram_id),
            )
        return cur.rowcount > 0

    def expire_finished_subscriptions(self) -> List[int]:
        """
        Desactiva las suscripciones VENCIDAS que no dependen de Stripe
        (pruebas y planes dados a mano). Las que tienen suscripción de
        Stripe las controla el poller: aquí no se tocan.

        Se ejecuta una vez por hora; como tras caducar quedan inactivas,
        el aviso se manda una sola vez.
        """
        now = datetime.now().isoformat()
        with self.db.connect() as c:
            rows = c.execute("""
                SELECT telegram_id FROM users
                WHERE sub_active = 1
                  AND sub_expires_at IS NOT NULL AND sub_expires_at < ?
                  AND (stripe_subscription IS NULL OR stripe_subscription = '')
            """, (now,)).fetchall()
            ids = [r["telegram_id"] for r in rows]
            if ids:
                placeholders = ",".join("?" * len(ids))
                c.execute(
                    f"UPDATE users SET sub_active=0, updated_at=? "
                    f"WHERE telegram_id IN ({placeholders})",
                    (now, *ids),
                )
        return ids

    def expire_finished_trials(self) -> List[int]:
        """Desactiva trials caducados sin suscripción Stripe. Devuelve IDs afectados."""
        now = datetime.now().isoformat()
        with self.db.connect() as c:
            rows = c.execute("""
                SELECT telegram_id FROM users
                WHERE sub_active = 1 AND sub_plan = 'trial'
                  AND sub_expires_at IS NOT NULL AND sub_expires_at < ?
                  AND (stripe_subscription IS NULL OR stripe_subscription = '')
            """, (now,)).fetchall()
            ids = [r["telegram_id"] for r in rows]
            if ids:
                placeholders = ",".join("?" * len(ids))
                c.execute(
                    f"UPDATE users SET sub_active=0, updated_at=? "
                    f"WHERE telegram_id IN ({placeholders})",
                    (now, *ids),
                )
        return ids


# ──────────────────────────────────────────────────────────
# STATS REPOSITORY
# ──────────────────────────────────────────────────────────

class StatsRepository:
    def __init__(self, db: Database):
        self.db = db

    def log_bet(self, user_id: int, kind: BetKind, is_middle: bool,
                sport: str, profit: float, bookmakers: List[str],
                game: str = "", market: str = ""):
        with self.db.connect() as c:
            c.execute("""
                INSERT INTO bet_log (user_id, ts, kind, is_middle, sport, profit, bookmakers, game, market)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (user_id, datetime.now().isoformat(), kind.value, int(is_middle),
                  sport, profit, json.dumps(bookmakers), game, market))

    def log_bet_many(self, records: List[dict]) -> int:
        """
        Inserta muchas apuestas en UNA sola transacción.

        Antes se llamaba a log_bet() por usuario, y cada llamada abría y
        cerraba su propia conexión SQLite: con 100 usuarios eran 100
        transacciones por cada apuesta. Ahora es una sola.
        """
        if not records:
            return 0
        now = datetime.now().isoformat()
        rows = []
        for r in records:
            kind = r.get("kind")
            kind_val = kind.value if hasattr(kind, "value") else str(kind or "")
            rows.append((
                r.get("user_id"),
                now,
                kind_val,
                int(bool(r.get("is_middle"))),
                r.get("sport", ""),
                r.get("profit", 0) or 0,
                json.dumps(r.get("bookmakers", [])),
                r.get("game", ""),
                r.get("market", ""),
            ))
        with self.db.connect() as c:
            c.executemany("""
                INSERT INTO bet_log
                    (user_id, ts, kind, is_middle, sport, profit, bookmakers, game, market)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, rows)
        return len(rows)

    def user_stats(self, user_id: int) -> dict:
        with self.db.connect() as c:
            total = c.execute("""
                SELECT COUNT(*) c, AVG(profit) a, MAX(profit) m
                FROM bet_log WHERE user_id = ?
            """, (user_id,)).fetchone()

            last24 = c.execute(
                "SELECT COUNT(*) FROM bet_log WHERE user_id=? AND ts>=?",
                (user_id, (datetime.now() - timedelta(hours=24)).isoformat())
            ).fetchone()[0]

            last7 = c.execute(
                "SELECT COUNT(*) FROM bet_log WHERE user_id=? AND ts>=?",
                (user_id, (datetime.now() - timedelta(days=7)).isoformat())
            ).fetchone()[0]

            middles = c.execute(
                "SELECT COUNT(*) FROM bet_log WHERE user_id=? AND is_middle=1",
                (user_id,)
            ).fetchone()[0]

        return {
            "total":      total["c"] or 0,
            "avg_profit": total["a"] or 0,
            "max_profit": total["m"] or 0,
            "last24h":    last24,
            "last7d":     last7,
            "middles":    middles,
        }

    def admin_stats(self) -> dict:
        with self.db.connect() as c:
            total = c.execute("SELECT COUNT(*) FROM users").fetchone()[0]
            paid  = c.execute("SELECT COUNT(*) FROM users WHERE sub_active=1").fetchone()[0]
            new_this_month = c.execute("""
                SELECT COUNT(*) FROM users
                WHERE sub_active=1 AND COALESCE(updated_at, created_at) >= ?
            """, (datetime.now().replace(day=1, hour=0, minute=0, second=0).isoformat(),)).fetchone()[0]
            bets_today = c.execute(
                "SELECT COUNT(*) FROM bet_log WHERE ts >= ?",
                (datetime.now().replace(hour=0, minute=0, second=0).isoformat(),)
            ).fetchone()[0]
            by_plan = dict(c.execute("""
                SELECT COALESCE(sub_plan,'none'), COUNT(*)
                FROM users WHERE sub_active=1 GROUP BY sub_plan
            """).fetchall())
        return {
            "total_users":    total,
            "paid_users":     paid,
            "free_users":     total - paid,
            "new_this_month": new_this_month,
            "bets_today":     bets_today,
            "by_plan":        by_plan,
        }


# ──────────────────────────────────────────────────────────
# HELPERS
# ──────────────────────────────────────────────────────────

def _parse_dt(v) -> Optional[datetime]:
    if not v:
        return None
    try:
        return datetime.fromisoformat(v)
    except Exception:
        return None


# ──────────────────────────────────────────────────────────
# FREEBET REPOSITORY  (promociones publicadas por el admin)
# ──────────────────────────────────────────────────────────

class FreebetRepository:
    """Promociones / apuestas gratis que el admin publica a los usuarios."""

    def __init__(self, db: Database):
        self.db = db

    # ── lectura ──────────────────────────────────────────
    def list_active(self, limit: int = 100) -> List[dict]:
        with self.db.connect() as c:
            rows = c.execute("""
                SELECT * FROM freebets
                WHERE active = 1
                ORDER BY
                    CASE WHEN expires_at IS NULL OR expires_at = '' THEN 1 ELSE 0 END,
                    expires_at ASC,
                    id DESC
                LIMIT ?
            """, (limit,)).fetchall()
        return [dict(r) for r in rows]

    def list_all(self, limit: int = 100) -> List[dict]:
        with self.db.connect() as c:
            rows = c.execute(
                "SELECT * FROM freebets ORDER BY id DESC LIMIT ?", (limit,)
            ).fetchall()
        return [dict(r) for r in rows]

    def get(self, fb_id: int) -> Optional[dict]:
        with self.db.connect() as c:
            row = c.execute(
                "SELECT * FROM freebets WHERE id = ?", (fb_id,)
            ).fetchone()
        return dict(row) if row else None

    # ── escritura ────────────────────────────────────────
    def add(self, bookmaker: str, title: str, value_eur: float = 0,
            url: str = "", description: str = "", kind: str = "freebet",
            expires_at: str = "") -> int:
        with self.db.connect() as c:
            cur = c.execute("""
                INSERT INTO freebets
                    (bookmaker, title, description, value_eur, url,
                     kind, expires_at, active, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?)
            """, (bookmaker, title, description, value_eur, url,
                  kind, expires_at, datetime.now().isoformat()))
            return cur.lastrowid

    def deactivate(self, fb_id: int) -> bool:
        with self.db.connect() as c:
            cur = c.execute(
                "UPDATE freebets SET active = 0 WHERE id = ?", (fb_id,)
            )
            return cur.rowcount > 0

    def delete(self, fb_id: int) -> bool:
        with self.db.connect() as c:
            cur = c.execute("DELETE FROM freebets WHERE id = ?", (fb_id,))
            return cur.rowcount > 0

    def purge_expired(self) -> int:
        """Desactiva las caducadas (se llama desde un job diario)."""
        with self.db.connect() as c:
            cur = c.execute("""
                UPDATE freebets SET active = 0
                WHERE active = 1
                  AND expires_at IS NOT NULL AND expires_at != ''
                  AND expires_at < ?
            """, (datetime.now().isoformat(),))
            return cur.rowcount


# ──────────────────────────────────────────────────────────
# ADMIN REPOSITORY  (admins gestionados desde la Mini App)
# ──────────────────────────────────────────────────────────

class AdminRepository:
    """
    Administradores extra, guardados en la BD para poder añadirlos y
    quitarlos desde la Mini App sin tocar el .env ni reiniciar.

    Los IDs de ADMIN_ID / ADMIN_IDS del .env son los "dueños": siempre
    lo son y no se pueden quitar desde la app.
    """

    TTL_DEFAULT = 30      # segundos de caché

    def __init__(self, db: Database):
        self.db = db
        self._cache: dict[int, tuple[bool, float]] = {}

    # ── lectura ──────────────────────────────────────────
    def all(self) -> List[int]:
        with self.db.connect() as c:
            rows = c.execute(
                "SELECT telegram_id FROM admins ORDER BY telegram_id"
            ).fetchall()
        return [r[0] for r in rows]

    def all_detailed(self) -> List[dict]:
        with self.db.connect() as c:
            rows = c.execute(
                "SELECT * FROM admins ORDER BY created_at DESC"
            ).fetchall()
        return [dict(r) for r in rows]

    def exists(self, uid: int) -> bool:
        try:
            with self.db.connect() as c:
                r = c.execute(
                    "SELECT 1 FROM admins WHERE telegram_id = ?", (uid,)
                ).fetchone()
            return r is not None
        except Exception:                                   # noqa: BLE001
            # Tabla aún no creada: no es un error, simplemente no es admin.
            return False

    def is_admin(self, uid: int, ttl: int = TTL_DEFAULT) -> bool:
        """Con caché corto: se llama en cada envío de apuesta."""
        now = time.time()
        hit = self._cache.get(uid)
        if hit and (now - hit[1]) < ttl:
            return hit[0]
        val = self.exists(uid)
        self._cache[uid] = (val, now)
        return val

    # ── escritura ────────────────────────────────────────
    def add(self, uid: int, note: str = "", added_by: int = 0) -> bool:
        with self.db.connect() as c:
            c.execute("""
                INSERT INTO admins (telegram_id, note, added_by, created_at)
                VALUES (?, ?, ?, ?)
                ON CONFLICT(telegram_id) DO UPDATE SET note = excluded.note
            """, (uid, note, added_by, datetime.now().isoformat()))
        self._cache.pop(uid, None)
        return True

    def remove(self, uid: int) -> bool:
        with self.db.connect() as c:
            cur = c.execute("DELETE FROM admins WHERE telegram_id = ?", (uid,))
        self._cache.pop(uid, None)
        return cur.rowcount > 0

    def invalidate(self):
        self._cache.clear()


