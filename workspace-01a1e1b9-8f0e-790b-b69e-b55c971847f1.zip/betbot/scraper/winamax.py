"""
winamax.py — colector de cuotas de Winamax (winamax.es) sin navegador.

Winamax sirve las cuotas por Socket.IO (Engine.IO v3) desde
`sports-eu-west-3.winamax.es/uof-sports-server`. Protocolo (ingeniería inversa del bundle
main.*.js, ver README):

    cliente -> 42["m", {"menu": true, "route": "live", ...}]      catálogo (menu solo responde junto a una route): sports/categories/tournaments
    cliente -> 42["m", {"route": "live", "requestId": "x"}]       partidos en vivo + apuesta principal
    cliente -> 42["m", {"route": "sport:1", "requestId": "x"}]    todos los partidos del deporte (apuesta principal)
    cliente -> 42["m", {"route": "match:ID", "requestId": "x"}]   todos los mercados de un partido
    servidor -> 42["m", {...}]   respuesta (lleva requestId) o delta sin requestId (cambios de cuotas,
                                 marcador, minuto). Ambos se fusionan igual sobre el estado local;
                                 un valor null borra la clave.

Solo se piden detalles (route match:ID) de los partidos de las competiciones principales
(competitions.json, común a todas las casas). Todos los mercados se normalizan con markets.py
(totales de partido/equipo/periodo, hándicaps, BTTS, player props…) y se escriben en odds.db con
bookmaker `winamaxes`.

Uso:  python winamax.py            (bucle)
      python winamax.py --list     (vuelca el catálogo de competiciones de fútbol/baloncesto/tenis)
      python winamax.py --once     (una pasada y sale; útil para probar)
"""
from __future__ import annotations

import asyncio
import fastjson as json
import logging
import os
import re
import sys
import time
from datetime import datetime
from pathlib import Path

import websockets

from competitions import Competitions
from markets import MarketInfo, classify, implied_line, parse_ou_label
from storage import OddsStore

log = logging.getLogger("winamax")
CFG_PATH = Path(os.getenv("WINAMAX_CFG", Path(__file__).parent / "winamax.json"))
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
      "Chrome/130.0.0.0 Safari/537.36")


def load_cfg() -> dict:
    import pace
    return pace.apply(json.loads(CFG_PATH.read_text(encoding="utf-8")))


# ──────────────────────────────────────────────────────────────────────────────
# Estado local fusionado (matches / bets / outcomes / odds / catálogo)
# ──────────────────────────────────────────────────────────────────────────────
class State:
    TABLES = ("sports", "categories", "tournaments", "matches", "bets", "outcomes", "odds")

    def __init__(self):
        self.t: dict[str, dict] = {k: {} for k in self.TABLES}
        self.dirty_matches: set[str] = set()

    def merge(self, msg: dict) -> None:
        for table in self.TABLES:
            part = msg.get(table)
            if not isinstance(part, dict):
                continue
            store = self.t[table]
            for k, v in part.items():
                if v is None:
                    store.pop(k, None)
                elif table == "odds":
                    if not isinstance(v, (int, float)):           # formato inesperado: no lo guardamos, lo anotamos
                        log.warning("odds con formato raro para %s: %r", k, v)
                        continue
                    store[k] = v
                    o = self.t["outcomes"].get(k)
                    if o:
                        b = self.t["bets"].get(str(o.get("betId")))
                        if b:
                            self.dirty_matches.add(str(b.get("matchId")))
                elif isinstance(v, dict) and isinstance(store.get(k), dict):
                    store[k].update(v)
                else:
                    if table == "matches" and isinstance(v, dict):
                        # delta parcial de un partido que aún no teníamos (p. ej. tras reconectar): sin matchId
                        # dentro, y match_row/_details hacían m["matchId"] → KeyError → «error de ciclo: 'matchId'»
                        v.setdefault("matchId", int(k) if str(k).isdigit() else k)
                    store[k] = v
                if table == "matches":
                    self.dirty_matches.add(k)
                elif table == "bets" and isinstance(v, dict) and v.get("matchId"):
                    self.dirty_matches.add(str(v["matchId"]))


# ──────────────────────────────────────────────────────────────────────────────
# Cliente Engine.IO v3 / Socket.IO mínimo
# ──────────────────────────────────────────────────────────────────────────────
class WinamaxSocket:
    def __init__(self, cfg: dict, state: State):
        self.cfg, self.state = cfg, state
        self.ws = None
        self._pending: dict[str, asyncio.Future] = {}
        self._rid = 0
        self._reader: asyncio.Task | None = None
        self._pinger: asyncio.Task | None = None
        self.ping_interval = 25.0

    async def connect(self) -> None:
        self.ws = await websockets.connect(
            self.cfg["socket_url"], max_size=64 * 1024 * 1024, open_timeout=20,
            additional_headers={"Origin": self.cfg["origin"], "User-Agent": UA})
        hello = await asyncio.wait_for(self.ws.recv(), 20)          # 0{"sid":...,"pingInterval":25000}
        if hello.startswith("0"):
            try:
                self.ping_interval = json.loads(hello[1:]).get("pingInterval", 25000) / 1000
            except ValueError:
                pass
        await asyncio.wait_for(self.ws.recv(), 20)                  # 40 (namespace conectado)
        self._reader = asyncio.create_task(self._read_loop())
        self._pinger = asyncio.create_task(self._ping_loop())
        log.info("socket conectado (pingInterval=%.0fs)", self.ping_interval)

    async def close(self) -> None:
        for t in (self._reader, self._pinger):
            if t:
                t.cancel()
        if self.ws:
            await self.ws.close()
        for f in self._pending.values():
            if not f.done():
                f.cancel()
        self._pending.clear()

    async def _ping_loop(self):
        while True:
            await asyncio.sleep(self.ping_interval)
            await self.ws.send("2")

    async def _read_loop(self):
        try:
            async for raw in self.ws:
                if raw == "2":                       # ping del servidor
                    await self.ws.send("3")
                    continue
                if raw == "3" or not raw.startswith("42"):
                    continue
                try:
                    ev, payload = json.loads(raw[2:])
                except (ValueError, TypeError):
                    continue
                if ev != "m" or not isinstance(payload, dict):
                    continue
                self.state.merge(payload)
                rid = payload.get("requestId")
                if rid and rid in self._pending:
                    fut = self._pending.pop(rid)
                    if not fut.done():
                        fut.set_result(payload)
        except Exception as e:                        # conexión caída: despierta a los que esperan
            for f in self._pending.values():
                if not f.done():
                    f.set_exception(e)
            self._pending.clear()

    async def request(self, body: dict, timeout: float = 20) -> dict:
        self._rid += 1
        rid = f"r{self._rid}"
        body = dict(body, requestId=rid)
        fut = asyncio.get_running_loop().create_future()
        self._pending[rid] = fut
        await self.ws.send("42" + json.dumps(["m", body], separators=(",", ":")))
        try:
            return await asyncio.wait_for(fut, timeout)
        finally:
            self._pending.pop(rid, None)

    async def route(self, route: str, timeout: float = 20) -> dict:
        return await self.request({"route": route}, timeout)

    @property
    def alive(self) -> bool:
        return bool(self.ws) and self._reader is not None and not self._reader.done()


# ──────────────────────────────────────────────────────────────────────────────
# Catálogo -> competiciones principales
# ──────────────────────────────────────────────────────────────────────────────
def select_tournaments(state: State, cfg: dict, catalog: Competitions) -> dict[int, tuple[str, str]]:
    """{tournamentId: (sport, nombre canónico)} de los torneos que están en competitions.json."""
    out: dict[int, tuple[str, str]] = {}
    bm = cfg.get("bookmaker", "winamaxes")
    for sid, sport in cfg["sports"].items():
        s = state.t["sports"].get(str(sid))
        if not s:
            continue
        for cid in s.get("categories", []):
            c = state.t["categories"].get(str(cid))
            if not c:
                continue
            for tid in c.get("tournaments", []):
                t = state.t["tournaments"].get(str(tid))
                if not t:
                    continue
                label = f"{c.get('categoryName', '')} - {t.get('tournamentName', '')}".strip()
                name = catalog.match(bm, sport, label)
                if name:
                    out[int(tid)] = (sport, name)
    return out


# ──────────────────────────────────────────────────────────────────────────────
# Partido -> fila para OddsStore (formato común de OddsStore)
# ──────────────────────────────────────────────────────────────────────────────
def _sbv(bet: dict, key: str) -> str | None:
    """specialBetValue 'player=sr:player:1|total=2.5' / 'hcp=-1.5' -> valor de `key`."""
    for part in (bet.get("specialBetValue") or "").split("|"):
        if part.startswith(key + "="):
            return part[len(key) + 1:]
    return None


def _num(v) -> float | None:
    try:
        return float(str(v).replace(",", "."))
    except (TypeError, ValueError):
        return None


def _sel_url(b: dict, o: dict) -> str | None:
    """Enlace directo que deja la selección en la cesta (formato verificado: ?bet=<betId>&outcome=<outcomeId>)."""
    mid, bid, oid = b.get("matchId"), b.get("betId"), o.get("_oid")
    if not (mid and bid and oid):
        return None
    return f"https://www.winamax.es/apuestas-deportivas/match/{mid}?bet={bid}&outcome={oid}"


def bet_selections(state: State, b: dict, sport: str, home: str, away: str) -> list[dict]:
    """Convierte una apuesta de Winamax (bet + outcomes + odds) en selecciones normalizadas (markets.py)."""
    title = b.get("betTitle") or ""
    tpl = b.get("template") or ""
    outs = []
    for oid in b.get("outcomes") or []:
        o = state.t["outcomes"].get(str(oid))
        price = state.t["odds"].get(str(oid))
        if o and price and 1.0 < float(price) <= 1000 and o.get("available", True):
            o["_oid"] = oid
            outs.append((o, price))
    if not outs:
        return []
    sels: list[dict] = []
    has_player_sbv = _sbv(b, "player") is not None
    if _sbv(b, "from") is not None or _sbv(b, "to") is not None or _sbv(b, "goalnr") is not None \
            or _sbv(b, "cornernr") is not None or _sbv(b, "scorenr") is not None:
        return []                      # mercados de intervalo ("Goles del 41 al 50") o de "enésimo gol/córner": no son totales del partido

    if tpl in ("OverUnder", "dynamic") and _sbv(b, "total") is not None:
        info = classify(title, sport, home, away, kind="total")
        if not info or (has_player_sbv and not info.player):
            return []
        # claves extra en specialBetValue (competitor=1|2, player=…, set=…) → el total NO es del partido
        extra = {part.split("=", 1)[0] for part in (b.get("specialBetValue") or "").split("|") if "=" in part} - {"total"}
        comp = _sbv(b, "competitor")
        if comp in ("1", "2") and not info.team and not info.player:
            side = "HOME" if comp == "1" else "AWAY"
            base = info.market[: -len(info.period) - 1] if info.period and info.market.endswith("_" + info.period) else info.market
            info = MarketInfo(base + "_" + side + ("_" + info.period if info.period else ""), None, side, info.period)
        elif extra - {"competitor"} and not info.player and not info.period:
            return []                  # p. ej. set=2 o player=… que el título no refleja: no lo mezclamos con el total del partido
        line = _num(_sbv(b, "total"))
        for o, price in outs:
            code = str(o.get("code", "")).lower()
            lab = o.get("label") or ""
            sel = "Over" if code == "over" else "Under" if code == "under" else parse_ou_label(lab)[0]
            if sel and (info.team or info.player or not re.search(r"[A-Za-zÁ-ú]{3,}\s+[A-Za-zÁ-ú]{2,}", re.sub(r"(?i)m[áa]s de|menos de", "", lab))):
                sels.append({"market": info.market, "selection": sel, "line": line, "player": info.player, "price": price, "url": _sel_url(b, o)})
    elif tpl == "asian_handicap" and _sbv(b, "hcp") is not None:
        info = classify(title, sport, home, away, kind="handicap")
        if not info:
            return []
        h = _num(_sbv(b, "hcp"))
        # outcomes[0] = local, outcomes[1] = visitante; la línea de cada uno va en su etiqueta ("Como -0.5")
        for idx, (o, price) in enumerate(outs[:2]):
            mm = re.search(r"([+-]?\d+(?:[.,]\d+)?)\s*$", o.get("label") or "")
            line = _num(mm.group(1)) if mm else (h if idx == 0 else (-h if h is not None else None))
            sels.append({"market": info.market, "selection": "1" if idx == 0 else "2", "line": line, "price": price, "url": _sel_url(b, o)})
    elif tpl in ("3way", "2way"):
        if tpl == "3way" and sport != "futbol":
            return []                      # baloncesto/tenis: "Resultado" con empate (sin prórroga) no es el ganador
        t = title.lower()
        if "ambos equipos marcan" in t:
            info = classify(title, sport, home, away, kind="btts")
            for o, price in outs:
                lab = (o.get("label") or "").lower()
                sels.append({"market": info.market, "selection": "Yes" if lab.startswith("s") else "No", "price": price, "url": _sel_url(b, o)})
        elif "sin empate" in t:
            info = classify(title, sport, home, away, kind="dnb")
            for o, price in outs:
                code = str(o.get("code", ""))
                if code in ("1", "2"):
                    sels.append({"market": info.market, "selection": code, "price": price, "url": _sel_url(b, o)})
        else:
            info = classify(title, sport, home, away)
            if not info or not info.market.startswith("1X2"):
                return []
            for o, price in outs:
                code = str(o.get("code", "")).lower()
                sel = {"1": "1", "x": "X", "2": "2"}.get(code)
                if sel:
                    sels.append({"market": info.market, "selection": sel, "price": price, "url": _sel_url(b, o)})
    elif tpl in ("ListOdd", "List") and (b.get("betTypeCategory") or "").strip() in ("Goleadores", "Estad. jugadores", "Anotadores"):
        # mercados de jugador con una fila por jugador: "Goleador", "Marca 2 goles o más", "Realiza 3 o más remates"
        line = implied_line(title)
        if line is None:
            return []
        for o, price in outs:
            player = (o.get("label") or "").strip()
            info = classify(title, sport, home, away, player=player)
            if info and info.player:
                sels.append({"market": info.market, "selection": "Over", "line": line, "player": info.player, "price": price, "url": _sel_url(b, o)})
    # cuotas imposibles en mercados de partido (p. ej. 60 donde debería ser 2,60): se descartan y se deja rastro
    ok = []
    for x in sels:
        if not x.get("player") and (x["price"] is None or float(x["price"]) > 50):
            continue                   # líneas extremas de totales por equipo (Over 4.5 @100 / Under @1.00): reales pero inútiles
        ok.append(x)
    return ok


def match_row(state: State, m: dict, sport: str, competition: str, cfg: dict) -> dict | None:
    if not m.get("available", True) or not m.get("competitor1Name") or not m.get("competitor2Name"):
        return None
    mid = str(m["matchId"])
    home, away = m["competitor1Name"], m["competitor2Name"]
    selections: list[dict] = []
    for b in state.t["bets"].values():
        if str(b.get("matchId")) != mid or not b.get("available", True):
            continue
        selections.extend(bet_selections(state, b, sport, home, away))
    if not selections:
        return None
    start = m.get("matchStart")
    dt = datetime.fromtimestamp(start) if start else None
    live = m.get("status") == "LIVE"
    score = m.get("score")
    return {
        "event_id": mid, "home": home, "away": away, "competition": competition,
        "date": dt.strftime("%Y-%m-%d") if dt else None,
        "start_time": dt.strftime("%H:%M") if dt else None,
        "url": cfg["match_url"].format(matchId=mid),
        "score": score if live and score else None,
        "period": m.get("periodName") if live else None,
        "timer": (m.get("matchtimeExtended") or m.get("remainingTime")
                  or (f"{m['matchtime']}'" if m.get("matchtime") else None)) if live else None,
        "selections": selections,
    }


# ──────────────────────────────────────────────────────────────────────────────
# Bucle principal
# ──────────────────────────────────────────────────────────────────────────────
class Collector:
    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.state = State()
        self.store = OddsStore(bookmaker=cfg.get("bookmaker", "winamaxes"))
        self.catalog = Competitions()
        self._prematch_done = asyncio.Event()
        self.tournaments: dict[int, tuple[str, str]] = {}
        self.sock: WinamaxSocket | None = None
        self._cfg_mtime = CFG_PATH.stat().st_mtime
        self._last_prematch = 0.0
        self._last_catalog = 0.0

    def _reload_cfg_if_changed(self):
        mt = CFG_PATH.stat().st_mtime
        changed = self.catalog.reload()
        if mt != self._cfg_mtime:
            self.cfg = load_cfg()
            self._cfg_mtime = mt
            changed = True
        if changed:
            self.tournaments = select_tournaments(self.state, self.cfg, self.catalog)
            log.info("configuración recargada: %d torneos seleccionados", len(self.tournaments))

    async def ensure_socket(self):
        if self.sock and self.sock.alive:
            return
        if self.sock:
            await self.sock.close()
        self.sock = WinamaxSocket(self.cfg, self.state)
        await self.sock.connect()
        for _ in range(3):                      # a veces la 1ª respuesta llega sin catálogo
            await self.sock.request({"menu": True, "route": "live", "clientTime": int(time.time() * 1000)}, timeout=40)
            if self.state.t["tournaments"]:
                break
            await asyncio.sleep(1)
        if not self.state.t["tournaments"]:
            raise RuntimeError("Winamax no ha devuelto el catálogo (menu)")
        self.tournaments = select_tournaments(self.state, self.cfg, self.catalog)
        self._last_catalog = time.time()
        self._last_prematch = 0.0
        log.info("catálogo: %d deportes, %d torneos; seleccionados %d",
                 len(self.state.t["sports"]), len(self.state.t["tournaments"]), len(self.tournaments))

    def _selected_matches(self, live_only: bool, max_hours: float | None = None) -> list[tuple[dict, str, str]]:
        now = time.time()
        out = []
        for m in self.state.t["matches"].values():
            sel = self.tournaments.get(m.get("tournamentId") or -1)
            if not sel or not m.get("competitor1Name"):
                continue
            sport, comp = sel
            is_live = m.get("status") == "LIVE"
            if live_only and not is_live:
                continue
            if not live_only and not is_live:
                if m.get("status") not in (None, "PREMATCH"):
                    continue
                st = m.get("matchStart") or 0
                if st < now - 300 or (max_hours and st > now + max_hours * 3600):
                    continue
            out.append((m, sport, comp))
        return out

    async def _details(self, matches: list, budget: int):
        """route match:ID en paralelo (lotes pequeños) para traer todos los mercados."""
        ids = [str(m["matchId"]) for m, *_ in matches][:budget]
        ok = 0
        for i in range(0, len(ids), 10):
            chunk = ids[i:i + 10]
            res = await asyncio.gather(*(self.sock.route(f"match:{x}", timeout=15) for x in chunk),
                                       return_exceptions=True)
            for x, r in zip(chunk, res):
                if isinstance(r, Exception):
                    log.debug("match:%s sin respuesta: %s", x, r)
                else:
                    ok += 1
        return ok

    def _rows(self, matches: list) -> dict[str, list[dict]]:
        """Filas a guardar (se construyen en el bucle de eventos: el estado lo muta el lector del socket)."""
        by_sport: dict[str, list[dict]] = {}
        for m, sport, comp in matches:
            row = match_row(self.state, m, sport, comp, self.cfg)
            if row:
                by_sport.setdefault(sport, []).append(row)
        return by_sport

    def _save(self, by_sport: dict[str, list[dict]], kind: str) -> tuple[int, int]:
        changed = rows = 0
        for sport, rs in by_sport.items():
            changed += self.store.save_rows(sport, kind, rs)
            rows += len(rs)
        return rows, changed

    def _flush(self, matches: list, kind: str) -> tuple[int, int]:
        return self._save(self._rows(matches), kind)

    async def _flush_async(self, matches: list, kind: str, batch: int = 2) -> tuple[int, int]:
        """Como _flush pero en lotes pequeños cediendo el bucle entre lote y lote.
        El volcado prematch (≈100 ev / 15-30k cambios) tardaba 60-90 s en SQLite de forma SÍNCRONA: bloqueaba
        el lector del websocket (sin pong → cierre 1005) y el ciclo live, y al terminar se procesaban en bloque
        los mensajes encolados con seen_at=ahora, es decir, cuotas viejas con aspecto de frescas."""
        changed = rows = 0
        for i in range(0, len(matches), batch):
            r, c = await asyncio.to_thread(self._save, self._rows(matches[i:i + batch]), kind)   # SQLite fuera del bucle
            rows += r; changed += c
            await asyncio.sleep(0.02)
        return rows, changed

    async def cycle(self):
        """Ciclo rápido (interval_live): lista live + detalle de los partidos en vivo seleccionados."""
        cfg = self.cfg
        now = time.time()
        await self.sock.route("live", timeout=20)
        live = self._selected_matches(live_only=True)
        await self._details(live, cfg.get("max_detail_per_cycle", 80))
        rows, changed = self._flush(live, "live")
        if now - self._last_catalog > 3600:                       # catálogo cada hora + limpieza
            await self.sock.request({"menu": True, "route": "live", "clientTime": int(now * 1000)}, timeout=40)
            self.tournaments = select_tournaments(self.state, self.cfg, self.catalog)
            self._last_catalog = now
            self.store.prune()
        self.store.set_status(winamax_last_ok=now, winamax_live_events=rows,
                              winamax_tournaments=len(self.tournaments))
        log.info("live %d ev / %d cambios (%.1fs)", rows, changed, time.time() - now)

    async def prematch_loop(self):
        """Ciclo lento (interval_prematch) en paralelo: no frena al ciclo live."""
        while True:
            t0 = time.time()
            try:
                for sid in self.cfg["sports"]:
                    await self.sock.route(f"sport:{sid}", timeout=40)
                pre = self._selected_matches(live_only=False, max_hours=self.cfg.get("prematch_hours", 48))
                pre = pre[: self.cfg.get("max_detail_per_cycle", 80) * 3]
                # Detalle + volcado POR LOTES: antes se pedían los ~100 partidos y luego se volcaban todos al final,
                # así que con el socket lento (route match: con timeout) la pasada tardaba 130-300 s y los eventos
                # pre-partido de Winamax llevaban casi siempre más de ODDS_MAX_AGE_PREMATCH sin refrescar → el bot
                # no sacaba ninguna señal con Winamax. Ahora cada lote de 10 se guarda nada más llegar y, si el
                # socket deja de contestar (dos lotes seguidos sin respuesta), se corta la pasada y se reintenta.
                rows = changed = 0
                dead = 0
                for i in range(0, len(pre), 10):
                    chunk = pre[i:i + 10]
                    ok = await self._details(chunk, len(chunk))
                    if ok == 0 and len(chunk) >= 3:
                        dead += 1
                        if dead >= 2:
                            log.warning("prematch: el socket no contesta a los detalles (%d/%d partidos hechos); corto la pasada", i, len(pre))
                            break
                    else:
                        dead = 0
                    r, c = await self._flush_async(chunk, "prematch")
                    rows += r; changed += c
                log.info("prematch %d ev / %d cambios (%.1fs)", rows, changed, time.time() - t0)
                self._prematch_done.set()
            except asyncio.CancelledError:
                raise
            except Exception as e:
                log.warning("prematch falló: %s", e)
            await asyncio.sleep(max(5.0, self.cfg.get("interval_prematch", 60) - (time.time() - t0)))

    async def run(self, once: bool = False):
        backoff = 2
        pre_task: asyncio.Task | None = None
        while True:
            t0 = time.time()
            try:
                self._reload_cfg_if_changed()
                await self.ensure_socket()
                if pre_task is None or pre_task.done():
                    pre_task = asyncio.create_task(self.prematch_loop())
                await self.cycle()
                backoff = 2
                if once:
                    # en --once esperamos a que termine una pasada completa de prematch
                    try:
                        await asyncio.wait_for(self._prematch_done.wait(), 150)
                    except asyncio.TimeoutError:
                        log.warning("prematch no terminó en 150 s")
                    pre_task.cancel()
                    return
            except Exception as e:
                log.warning("error de ciclo: %s — reconectando en %ss", e, backoff)
                self.store.set_status(winamax_last_error=f"{time.time():.0f} {e}")
                if pre_task:
                    pre_task.cancel()
                    pre_task = None
                if self.sock:
                    await self.sock.close()
                    self.sock = None
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2, 60)
                continue
            await asyncio.sleep(max(0.5, self.cfg.get("interval_live", 5) - (time.time() - t0)))


async def list_catalog(cfg: dict):
    st = State()
    s = WinamaxSocket(cfg, st)
    await s.connect()
    await s.request({"menu": True, "route": "live", "clientTime": int(time.time() * 1000)}, timeout=40)
    sel = select_tournaments(st, cfg, Competitions())
    for sid, sport in cfg["sports"].items():
        print(f"\n=== {sport} (sportId {sid})")
        for cid in st.t["sports"].get(sid, {}).get("categories", []):
            c = st.t["categories"].get(str(cid), {})
            for tid in c.get("tournaments", []):
                t = st.t["tournaments"].get(str(tid), {})
                mark = "✔" if int(tid) in sel else " "
                print(f" {mark} {c.get('categoryName')} - {t.get('tournamentName')}   "
                      f"[{tid}] pre={t.get('mainMatchCount')} live={t.get('liveMatchCount')}")
    await s.close()


async def dump_live(cfg: dict, n: int = 3):
    """Mercados en bruto de los primeros `n` directos (deporte opcional en argv: futbol|baloncesto|tenis): título Winamax -> código nuestro."""
    st = State()
    s = WinamaxSocket(cfg, st)
    await s.connect()
    await s.request({"menu": True, "route": "live", "clientTime": int(time.time() * 1000)}, timeout=40)
    sel = select_tournaments(st, cfg, Competitions())
    matches = [(m, *sel[m["tournamentId"]]) for m in st.t["matches"].values()
               if m.get("tournamentId") in sel and m.get("status") == "LIVE" and m.get("competitor1Name")]
    want = next((a for a in sys.argv if a in ("futbol", "baloncesto", "tenis")), "futbol")
    matches = [x for x in matches if x[1] == want][:n] or matches[:n]
    for m, sport, comp in matches:
        await s.route(f"match:{m['matchId']}", timeout=15)
        home, away = m["competitor1Name"], m["competitor2Name"]
        print(f"\n=== {home} - {away} [{m['matchId']}] {sport} {comp} score={m.get('score')} "
              f"periodo={m.get('periodName')} min={m.get('matchtime')}")
        for b in st.t["bets"].values():
            if str(b.get("matchId")) != str(m["matchId"]) or not b.get("available", True):
                continue
            outs = " | ".join(f"{st.t['outcomes'].get(str(o), {}).get('label')} @{st.t['odds'].get(str(o))}"
                              for o in b.get("outcomes") or [])
            mapped = bet_selections(st, b, sport, home, away)
            codes = ", ".join(f"{x['market']}|{x['selection']}|{x.get('line')}" for x in mapped) or "-"
            print(f"  [{b.get('template')}/{(b.get('betTypeCategory') or '').strip()}] {b.get('betTitle')!r} "
                  f"sbv={b.get('specialBetValue')!r} {' '.join(f'{k}={b[k]!r}' for k in ('periodName', 'period', 'betType', 'marketId', 'specifiers') if b.get(k))}"
                  f": {outs}\n        -> {codes}")
    await s.close()


async def dump_links(cfg: dict):
    """Imprime URLs candidatas de enlace directo a una apuesta (para probarlas en el navegador)."""
    st = State()
    s = WinamaxSocket(cfg, st)
    await s.connect()
    await s.request({"menu": True, "route": "live", "clientTime": int(time.time() * 1000)}, timeout=40)
    sel = select_tournaments(st, cfg, Competitions())
    ms = [m for m in st.t["matches"].values() if m.get("tournamentId") in sel and m.get("competitor1Name")]
    ms.sort(key=lambda m: (m.get("status") != "LIVE", m.get("matchStart") or 0))
    if not ms:
        print("sin partidos"); await s.close(); return
    m = ms[0]
    mid = m["matchId"]
    await s.route(f"match:{mid}", timeout=15)
    bet = next((b for b in st.t["bets"].values() if str(b.get("matchId")) == str(mid)
                and b.get("available", True) and b.get("outcomes")), None)
    await s.close()
    if not bet:
        print("sin apuestas"); return
    bid, oid = bet.get("betId"), bet["outcomes"][0]
    lab = st.t["outcomes"].get(str(oid), {}).get("label")
    base = f"https://www.winamax.es/apuestas-deportivas/match/{mid}"
    print(f"Partido: {m['competitor1Name']} - {m['competitor2Name']}  ({m.get('status')})")
    print(f"Apuesta: {bet.get('betTitle')!r} -> selección {lab!r}  betId={bid} outcomeId={oid}\n")
    print("Abre cada URL en incógnito y dime cuál deja la selección ya marcada en la cesta:")
    for i, u in enumerate([
        f"{base}?betId={bid}&outcomeId={oid}",
        f"{base}?outcomeId={oid}",
        f"{base}#bet-{bid}",
        f"{base}/{bid}/{oid}",
        f"{base}?bet={bid}&outcome={oid}",
        f"https://www.winamax.es/apuestas-deportivas/cesta?outcomes={oid}",
        f"https://www.winamax.es/apuestas-deportivas/match/{mid}?add={oid}",
    ], 1):
        print(f"  {i}. {u}")


def main():
    logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"),
                        format="%(asctime)s %(levelname)s %(name)s: %(message)s", datefmt="%H:%M:%S")
    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    cfg = load_cfg()
    if "--links" in sys.argv:
        asyncio.run(dump_links(cfg)); return
    if "--list" in sys.argv:
        asyncio.run(list_catalog(cfg))
        return
    if "--dump" in sys.argv:
        asyncio.run(dump_live(cfg))
        return
    asyncio.run(Collector(cfg).run(once="--once" in sys.argv))


if __name__ == "__main__":
    main()
