"""
goldenpark.py — colector de cuotas de GoldenPark (apuestas.goldenpark.es, sportsbook SportnCo / Gaming1).

Sin cookies, token ni captcha; solo `requests`:
  * Catálogo y pre-partido:  POST https://ws.goldenpark.es/component/datatree  {"context":{"url_key": <ruta de la web>,…}}
      /es/deporte/<id>-slug        -> sport_page_all.a_z.categories[].links[]  (país + competición, id, url)
      /es/competicion/<id>-slug    -> prematch_event_list.events[]             (eventos con mercados principales)
      /es/evento/<id>-slug         -> event_market_list.event.markets[].bets[] (todos los mercados de un evento)
      /es/en-vivo                  -> live_event_list.events[]                 (partidos en directo: ids, match_id)
    Cada árbol pesa ~300 KB (plantilla incluida) y el host va detrás de F5 que devuelve 429 si se encadenan
    peticiones muy seguidas → `request_gap` entre peticiones y pausa larga al primer 429.
  * Directo: Server-Sent Events  GET https://events.goldenpark.es/live?mode=v2&partner=870&id=<match_id|match_id…>
      Una sola conexión para todos los partidos: cada 1-2 s por partido llega `event: match` (marcador, periodo,
      minuto), `event: odds` (TODOS los mercados del partido: snapshot completo) y `event: status`.

Mercados: por título (markets.classify) + `cid` de cada selección (SNC_ACTOR_HOME/DRAW/AWAY, ls:over/under, ls:yes/no,
ls:1x/12/x2); la línea va en la etiqueta de la selección ("Más de 2.5", "Italia (-1.5)").

Uso:  python goldenpark.py          (bucle)      --once      --list (competiciones)      --dump <match_id|eventId>
"""
from __future__ import annotations

import fastjson as json
import logging
import os
import re
import sys
import threading
import time
import unicodedata
from datetime import datetime
from pathlib import Path

import requests

from competitions import Competitions
from markets import classify, parse_ou_label
import storage
from storage import OddsStore
import pace

log = logging.getLogger("goldenpark")
CFG_PATH = Path(os.getenv("GOLDENPARK_CFG", Path(__file__).parent / "goldenpark.json"))

# títulos que nunca son comparables (juego/punto concreto, exactos, combinadas, par/impar…)
_SKIP_TITLE = re.compile(r"juego \d|punto \d|tie-?break|iguales|resultado (correcto|exacto)|exact|impar|\bpar\b|descanso ?/ ?final|"
                         r"goleador|marca y|marca o|asist|ambas mitades|a cero|al menos|y ambos|y m[aá]s|y menos|ambos equipos marcar[aá]n y|"
                         r"apuestas divertidas|momento del|primer equipo|[uú]ltimo equipo|apuesta nula|n[uú]mero de sets|"
                         r"propia puerta|penalti|se clasifica|gana ambas|gana al menos|minuto|m[uú]ltiple|ventaja\)|(^|- )n[uú]mero de (goles|c[oó]rneres)\s*$|n[uú]mero de goles (en|marcados)|saques de banda", re.I)
# selection_order_type (pre-partido) que no modelamos
_SKIP_SOT = {"correct_score_3way", "correct_score", "mlt_correct_score", "goalscorer", "ht_ft", "result_btts", "btts_over_under",
             "odds_asc", "alphabetical_asc", "next_goal", "home_no_bet", "away_no_bet", "precanned2legs", "precanned3legs",
             "precanned4legs", "precanned5legs", "odd_even", "numerical_asc_nb_goals", "corner_bands"}
_CID = {"SNC_ACTOR_HOME": "1", "SNC_ACTOR_DRAW": "X", "SNC_ACTOR_AWAY": "2", "ls:over": "Over", "ls:under": "Under",
        "30": "Over", "31": "Under", "ls:yes": "Yes", "ls:no": "No", "39": "Yes", "40": "No",
        "ls:1x": "1X", "ls:12": "12", "ls:x2": "X2", "7": "1X", "8": "12", "9": "X2"}


def _fold(s: str) -> str:
    return re.sub(r"\s+", " ", unicodedata.normalize("NFKD", s or "").encode("ascii", "ignore").decode().lower()).strip()


def _num(s) -> float | None:
    if s is None:
        return None
    m = re.search(r"([+-]?\d+(?:[.,]\d+)?)", str(s))
    return float(m.group(1).replace(",", ".")) if m else None


def _hcp_from_label(name: str) -> float | None:
    """'Italia (-1.5)' / '(-1.5) Italia' / 'Georgia Sub-19 (+3)' -> ±línea de ESA selección."""
    m = re.search(r"\(([+-]?\d+(?:[.,]\d+)?)\)", name or "")
    return float(m.group(1).replace(",", ".")) if m else None


def _side_by_label(label: str, home: str, away: str) -> str | None:
    t = _fold(re.sub(r"\([^)]*\)", "", label or ""))
    if t in ("empate", "x", "draw"):
        return "X"
    h, a = _fold(home), _fold(away)
    if t and (t == h or h in t or t in h):
        return "1"
    if t and (t == a or a in t or t in a):
        return "2"
    return None


def _sel_from(cid: str | None, label: str, home: str, away: str) -> str | None:
    s = _CID.get(cid or "")
    if s:
        return s
    t = _fold(label)
    if re.match(r"(mas de|over)", t):
        return "Over"
    if re.match(r"(menos de|under)", t):
        return "Under"
    if t in ("si", "yes"):
        return "Yes"
    if t == "no":
        return "No"
    m = re.fullmatch(r"(.+?) o (.+)", t)
    if m:                                              # doble oportunidad por texto: "Italia o Empate"
        a_, b_ = _side_by_label(m.group(1), home, away), _side_by_label(m.group(2), home, away)
        if a_ and b_ and a_ != b_:
            return "".join(sorted(a_ + b_, key="1X2".index))
        return None
    return _side_by_label(label, home, away)


def _kind(title: str) -> str | None:
    t = _fold(title)
    if re.search(r"handicap", t):
        return "handicap"
    if re.search(r"empate anula|sin empate|draw no bet", t):
        return "dnb"
    if re.search(r"doble oportunidad", t):
        return "dc"
    if re.search(r"ambos equipos marca", t):
        return "btts"
    if re.search(r"quien ganara el partido|^resultado$|- resultado$|- ganador$|^ganador$|set \d - ganador", t):
        return "result"
    if re.search(r"total|mas ?(de)? ?/ ?menos|cuantos|numero de|mas o menos", t):
        return "total"
    return None


def market_selections(title: str, sels: list[tuple[str | None, str, float]], sport: str, home: str, away: str) -> list[dict]:
    """Un mercado (título + [(cid, etiqueta, cuota)]) -> selecciones normalizadas."""
    if not title or _SKIP_TITLE.search(title):
        return []
    kind = _kind(title)
    if kind is None:
        return []
    t = re.sub(r"\s*\((?:[+-]?\d+(?:[.,]\d+)?)\)\s*-\s*resultado\s*$", "", title, flags=re.I)   # "Hándicap (-1.5) - Resultado del partido"
    t = re.sub(r"\s*\((?:[+-]?\d+(?:[.,]\d+)?)\)", "", t)                                       # "Hándicap (0:2)" se descarta más abajo
    if kind == "handicap" and re.search(r"\(\d+:\d+\)", title):
        return []                                                                                # hándicap "(0:2)" europeo por resultado
    t = re.sub(r"\bhandicaps\b", "Hándicap", t, flags=re.I)
    t = re.sub(r"h[aá]ndicaps\b", "Hándicap", t, flags=re.I)
    t = re.sub(r"^\s*¿|\?\s*$", "", t)
    t = re.sub(r"^qui[eé]n ganar[aá] el partido\s*\??", "Resultado", t, flags=re.I)                  # "¿Quién ganará el partido? (Prórroga incluida)"
    if kind == "handicap" and re.search(r"3 opciones", title, re.I):
        return []                                                                                # hándicap europeo (con empate): no comparable
    if sport == "tenis":
        t = re.sub(r"^set (\d) - ", lambda m: f"{m.group(1)}º set - ", t, flags=re.I)
    if sport == "baloncesto" and kind == "result" and any(c == "SNC_ACTOR_DRAW" or _fold(l) == "empate" for c, l, _p in sels) \
            and not re.search(r"cuarto|mitad|parte", t, re.I):
        return []                                                                                # partido completo a 3 vías = tiempo reglamentario; el 1X2
                                                                                                 # del partido es a 2 vías (con prórroga). Por cuarto/mitad las
                                                                                                 # demás casas también son a 3 vías -> se guardan (1X2_Q2, 1X2_1H…)
    # "¿Más o menos de 2.5 goles?", "Más de/Menos de 8.5 córneres", "Más/Menos de 22.5 juegos", "… 12.5 remates para Italia"
    mo = re.match(r"^(?P<pre>.*?)m[aá]s ?(?:o|/|de ?/) ?menos de [\d.,]+ (?P<met>[^()]+?)(?: para (?P<team>[^()]+?))?\s*(?P<ot>\(.*\))?\s*$", t, re.I)
    if mo:
        t = f"{mo.group('pre')}{(mo.group('team') + ' - ') if mo.group('team') else ''}Total de {mo.group('met')} {mo.group('ot') or ''}".strip()
    info = classify(t, sport, home, away, kind=kind)
    if not info:
        return []
    out: list[dict] = []
    for cid, label, price in sels:
        if not price or price <= 1.0:
            continue
        sel = _sel_from(cid, label, home, away)
        if not sel:
            continue
        line = None
        if kind == "handicap":
            line = _hcp_from_label(label)
            if line is None or sel not in ("1", "X", "2"):
                continue
        elif kind == "total" or info.market.startswith(("TOTAL", "SETS", "CORNERS", "CARDS")):
            ou, line = parse_ou_label(label)
            if ou not in ("Over", "Under") or line is None:
                continue
            sel = ou
        elif kind in ("result", "dnb") and sel not in ("1", "X", "2"):
            continue
        elif kind == "dc" and sel not in ("1X", "12", "X2"):
            continue
        elif kind == "btts" and sel not in ("Yes", "No"):
            continue
        out.append({"market": info.market, "selection": sel, "line": line, "player": info.player, "price": float(price), "ot": info.ot})
    return out


def sse_market_selections(odds: list[dict], sport: str, home: str, away: str) -> list[dict]:
    out: list[dict] = []
    for o in odds or []:
        title = o.get("qt") or ""
        sels: list[tuple[str | None, str, float]] = []
        for b in o.get("bets") or []:
            for c in (b.get("tch") or {}).values():
                if not isinstance(c, dict) or c.get("ct") in (None, -1, 0):
                    continue
                sels.append((c.get("cid"), c.get("act") or "", float(c["ct"])))
        out.extend(market_selections(title, sels, sport, home, away))
    return out


def tree_market_selections(markets: list[dict], sport: str, home: str, away: str) -> list[dict]:
    out: list[dict] = []
    for m in markets or []:
        if m.get("selection_order_type") in _SKIP_SOT:
            continue
        for b in m.get("bets") or []:
            sels = [(None, s.get("label") or "", float(s["odds"])) for s in b.get("selections") or [] if s.get("odds")]
            out.extend(market_selections(b.get("label") or "", sels, sport, home, away))
    return out


def _find(c, key: str):
    if isinstance(c, dict):
        if c.get("tree_compo_key") == key:
            return c
        for x in c.get("components") or []:
            r = _find(x, key)
            if r:
                return r
    return None


# ──────────────────────────────────────────────────────────────────────────────
class Stream(threading.Thread):
    """Conexión SSE única con todos los match_id de interés; guarda el último snapshot de cada partido."""

    def __init__(self, cfg: dict, headers: dict):
        super().__init__(daemon=True, name="goldenpark-sse")
        self.cfg, self.headers = cfg, {**headers, "Accept": "text/event-stream"}
        self.ids: list[str] = []
        self._gen = 0
        self._cur_gen = -1
        self.snap: dict[str, dict] = {}            # match_id -> {"match":…, "odds":…, "ts":…}
        self.lock = threading.Lock()
        self.msgs = self.bytes = 0
        self.last_msg = 0.0
        self.connected = False
        self._resp = None

    def set_ids(self, ids: list[str]):
        ids = sorted(set(ids))
        if ids != self.ids:
            self.ids = ids
            self._gen += 1
            r = self._resp
            if r is not None:
                try:
                    r.close()                      # fuerza la reconexión con la lista nueva
                except Exception:  # noqa: BLE001
                    pass

    def alive(self) -> bool:
        return self.connected and time.time() - self.last_msg < self.cfg.get("sse_silence", 120)

    def run(self):
        backoff = 2
        while True:
            if not self.ids:
                self.connected = False
                time.sleep(1)
                continue
            gen, ids = self._gen, list(self.ids)
            url = self.cfg["sse"].format(ids="|".join(ids), partner=self.cfg.get("partner", 870))
            try:
                with requests.get(url, headers=self.headers, stream=True, timeout=(15, self.cfg.get("sse_silence", 120))) as r:
                    self._resp = r
                    if r.status_code != 200:
                        raise RuntimeError(f"HTTP {r.status_code}")
                    r.encoding = "utf-8"                   # el servidor no declara charset → requests asumía Latin-1 y
                    self.connected, self.last_msg = True, time.time()   # «2º Cuarto»/«1ª mitad»/«Hándicaps» llegaban rotos (sin mapear)
                    self._cur_gen = gen
                    backoff = 2
                    ev, data = None, []
                    for raw in r.iter_lines(decode_unicode=True):
                        if gen != self._gen:
                            break
                        if raw is None:
                            continue
                        self.bytes += len(raw) + 1
                        if raw == "":
                            if ev and data:
                                self._on(ev, "\n".join(data))
                            ev, data = None, []
                        elif raw.startswith("event:"):
                            ev = raw[6:].strip()
                        elif raw.startswith("data:"):
                            data.append(raw[5:].lstrip())
                        self.last_msg = time.time()
            except Exception as e:  # noqa: BLE001
                if gen == self._gen:
                    log.warning("sse: %s — reconexión en %ss", e, backoff)
                    time.sleep(backoff)
                    backoff = min(backoff * 2, 60)
            finally:
                self.connected = False
                self._resp = None

    def _on(self, ev: str, data: str):
        try:
            d = json.loads(data)
        except ValueError:
            return
        mid = str(d.get("match_id") or "")
        if not mid:
            return
        self.msgs += 1
        with self.lock:
            s = self.snap.setdefault(mid, {})
            if ev == "match":
                s["match"] = d
            elif ev == "odds":
                s["odds"] = d.get("odds") or []
                s["ts"] = time.time()
            elif ev == "status":
                s["active"] = d.get("active")

    def drop(self, keep: set[str]):
        with self.lock:
            for k in [k for k in self.snap if k not in keep]:
                del self.snap[k]


# ──────────────────────────────────────────────────────────────────────────────
class Collector:
    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.bk = cfg["bookmaker"]
        origin = cfg.get("origin", "https://apuestas.goldenpark.es")
        self.headers = {"Accept": "*/*", "Content-Type": "application/json", "Origin": origin, "Referer": origin + "/",
                        "Accept-Language": "es-ES,es;q=0.9", **(cfg.get("headers") or {})}
        self.sess = requests.Session()
        self.sess.headers.update(self.headers)
        self.catalog = Competitions()
        self.store = OddsStore(bookmaker=self.bk)
        self.sports = {int(k): v for k, v in cfg["sports"].items()}
        self.comps: dict[int, tuple[str, str, str]] = {}        # competition id -> (deporte, nombre canónico, url)
        self._all: list[tuple[str, str, int, str, int]] = []
        self._menu_at = 0.0
        self._cfg_mtime = CFG_PATH.stat().st_mtime
        self._bg = pace.Background(f"{self.bk}-prematch")
        self._last_req = 0.0
        self._blocked_until = 0.0
        self._req_lock = threading.Lock()
        self.transport = "requests"
        self.stream = Stream(cfg, self.headers) if cfg.get("push", True) else None
        if self.stream:
            self.stream.start()
        self.live_meta: dict[str, dict] = {}                    # match_id -> evento (de /es/en-vivo)
        self._live_list_at = 0.0
        self._last_prematch = 0.0
        self._pm_queue: list[int] = []
        self._pm_present: set[str] = set()
        self._pm_rows = self._pm_changed = 0

    # ── HTTP ──
    def tree(self, url_key: str, params: dict | None = None) -> dict:
        with self._req_lock:
            wait = max(self.cfg.get("request_gap", 2.0) - (time.time() - self._last_req), self._blocked_until - time.time())
            if wait > 0:
                time.sleep(wait)
            body = {"context": {"url_key": url_key, "version": "1.0.1", "device": "web_vuejs_desktop", "lang": "es",
                                "timezone": "Europe/Madrid", "url_params": params or {}}}
            r = self.sess.post(self.cfg["api"], data=json.dumps(body), timeout=40)
            self._last_req = time.time()
        if r.status_code == 429 or (r.status_code == 200 and b"Too Many Requests" in r.content[:600]):
            self._blocked_until = time.time() + self.cfg.get("block_pause", 90)
            raise RuntimeError("bloqueo 429 (F5): pausa")
        if r.status_code != 200:
            raise RuntimeError(f"HTTP {r.status_code} {url_key}")
        j = r.json()
        if j.get("error_message"):
            raise RuntimeError(f"datatree {url_key}: {j['error_message'][:80]}")
        return j

    def _reload_if_changed(self):
        try:
            mt = CFG_PATH.stat().st_mtime
        except OSError:
            return
        if mt != self._cfg_mtime:
            self._cfg_mtime = mt
            self.cfg.update(pace.apply(json.loads(CFG_PATH.read_text(encoding="utf-8"))))
            log.info("config recargada")

    # ── catálogo ──
    def refresh_menu(self, force: bool = False):
        if not force and time.time() - self._menu_at < self.cfg.get("menu_ttl", 900):
            return
        comps: dict[int, tuple[str, str, str]] = {}
        allc = []
        for sid, sport in self.sports.items():
            url = self.cfg["sport_urls"].get(str(sid)) or f"/es/deporte/{sid}"
            j = self.tree(url)
            a = (_find(j.get("tree"), "sport_page_all") or {}).get("data") or {}
            for cat in (a.get("a_z") or {}).get("categories") or []:
                for l in cat.get("links") or []:
                    label = f"{cat.get('name') or ''} - {l.get('label') or ''}"
                    name = self.catalog.match(self.bk, sport, label)
                    allc.append((sport, label, l.get("id"), name, l.get("nb_events") or 0))
                    if name and l.get("id") and l.get("url"):
                        comps[int(l["id"])] = (sport, name, l["url"])
        if comps or force:
            self.comps = comps
            self._all = allc
        self._menu_at = time.time()
        log.info("%d competiciones mapeadas (%d en el menú)", len(comps), len(allc))

    # ── filas ──
    def _teams(self, ev: dict) -> tuple[str, str]:
        acts = {a.get("type"): a.get("label") for a in ev.get("actors") or []}
        h, a = acts.get("home"), acts.get("away")
        if not h or not a:
            parts = (ev.get("label") or "").split(" / ", 1)
            if len(parts) == 2:
                h, a = parts
        return (h or "").strip(), (a or "").strip()

    @staticmethod
    def _state(m: dict, sport: str) -> tuple[str | None, str | None, str | None]:
        """(marcador, periodo, minuto) del bloque `match` del SSE."""
        sc, st = m.get("sc") or None, (m.get("st") or "").strip()
        if sport == "tenis":
            cur = re.findall(r"\d+", sc or "")                 # sc "1:0" = sets ganados; ssc "6:2 - 3:0" = juegos por set
            n = sum(int(x) for x in cur) + 1 if len(cur) == 2 else None
            games = " ".join(x.strip() for x in (m.get("ssc") or "").split(" - ") if x.strip()) or None
            return games or sc, (f"Set {n}" if n else None), None
        if sport == "baloncesto":
            per = {"Q1": "Q1", "Q2": "Q2", "Q3": "Q3", "Q4": "Q4"}.get(st.upper()) or ("Prórroga" if re.search(r"pr[oó]rroga|ot", st, re.I) else
                                                                                    "Descanso" if re.search(r"descanso|half", st, re.I) else st or None)
            return sc, per, m.get("mtm") or None
        per = {"1T": "1ª parte", "2T": "2ª parte", "MT": "Descanso", "HT": "Descanso"}.get(st.upper()) or \
            ("Descanso" if re.search(r"descanso", st, re.I) else "Prórroga" if re.search(r"pr[oó]rroga", st, re.I) else st or None)
        return sc, per, m.get("tm") or None

    def _live_row(self, mid: str, meta: dict, snap: dict) -> tuple[str, dict] | None:
        sport, comp = meta["sport"], meta["comp"]
        home, away = meta["home"], meta["away"]
        m = snap.get("match") or {}
        if snap.get("active") == 0 or not snap.get("odds"):
            return None
        score, period, timer = self._state(m, sport)
        sels = sse_market_selections(snap["odds"], sport, home, away)
        if not sels:
            return None
        return sport, {"event_id": str(meta["id"]), "home": home, "away": away, "competition": comp,
                       "date": meta.get("date"), "start_time": meta.get("start_time"), "url": meta["url"], "selections": sels,
                       "score": score, "period": period, "timer": timer}

    def _meta(self, ev: dict, sport: str, comp: str) -> dict:
        home, away = self._teams(ev)
        dt = datetime.fromtimestamp(ev["ts_start"]) if ev.get("ts_start") else None
        return {"id": ev["id"], "match_id": str(ev.get("match_id") or ""), "sport": sport, "comp": comp, "home": home, "away": away,
                "url": self.cfg["origin"].rstrip("/") + (ev.get("url") or ""), "date": dt.strftime("%Y-%m-%d") if dt else None,
                "start_time": dt.strftime("%H:%M") if dt else None, "ts_start": ev.get("ts_start")}

    # ── directo ──
    def refresh_live_list(self, force: bool = False):
        if not force and time.time() - self._live_list_at < self.cfg.get("live_list_refresh", 60):
            return
        j = self.tree("/es/en-vivo")
        evs = ((_find(j.get("tree"), "live_event_list") or {}).get("data") or {}).get("events") or []
        meta: dict[str, dict] = {}
        for ev in evs:
            sid = (ev.get("sport") or {}).get("id")
            cid = (ev.get("competition") or {}).get("id")
            if sid not in self.sports or ev.get("is_canceled"):
                continue
            c = self.comps.get(int(cid)) if cid else None
            if not c:
                continue
            m = self._meta(ev, c[0], c[1])
            if m["match_id"] and m["home"] and m["away"]:
                meta[m["match_id"]] = m
        self.live_meta = meta
        self._live_list_at = time.time()
        if self.stream:
            self.stream.set_ids(list(meta))
            self.stream.drop(set(meta))

    def live_cycle(self) -> tuple[int, int]:
        self.refresh_live_list()
        if not self.stream:
            return 0, 0
        alive = self.stream.alive()
        self.transport = "push" if alive else "requests"
        # Las cuotas llegan por push (snapshot completo sólo cuando algo cambia): mientras el stream esté vivo son
        # vigentes aunque lleven un rato sin cambiar. La tanda empieza ahora, no en la última petición REST del menú
        # (si esa no guardó nada, su fetch_t0 sellaría estas cuotas con decenas de segundos de antigüedad).
        storage.end_fetch()
        storage.note_fetch()
        with self.stream.lock:
            snaps = {k: dict(v) for k, v in self.stream.snap.items()}
        by_sport: dict[str, list[dict]] = {}
        max_age = self.cfg.get("sse_max_age", 20)          # sólo si el stream se ha caído: no revivir snapshots viejos
        for mid, meta in self.live_meta.items():
            s = snaps.get(mid)
            if not s or not s.get("odds"):
                continue
            if not alive and time.time() - s.get("ts", 0) > max_age:
                continue
            r = self._live_row(mid, meta, s)
            if r:
                by_sport.setdefault(r[0], []).append(r[1])
        present: set[str] = set()
        rows = changed = 0
        for sp, rs in by_sport.items():
            present |= {r["event_id"] for r in rs}
            changed += self.store.save_rows(sp, "live", rs)
            rows += len(rs)
        self.store.sweep(present, "live")
        return rows, changed

    # ── pre-partido ──
    def prematch_competition(self, cid: int) -> tuple[int, int]:
        sport, comp, url = self.comps[cid]
        j = self.tree(url)
        pl = ((_find(j.get("tree"), "prematch_event_list") or {}).get("data") or {}).get("events") or []
        horizon = time.time() + self.cfg.get("prematch_hours", 48) * 3600
        rows: list[dict] = []
        detail_max = self.cfg.get("detail_per_competition", 30)
        for ev in pl:
            if ev.get("type") != "pm" or ev.get("is_canceled") or not ev.get("ts_start") or ev["ts_start"] > horizon:
                continue
            m = self._meta(ev, sport, comp)
            if not m["home"] or not m["away"]:
                continue
            markets = ev.get("markets") or []
            if detail_max > 0 and ev.get("url"):
                try:
                    jd = self.tree(ev["url"])
                    full = ((_find(jd.get("tree"), "event_market_list") or {}).get("data") or {}).get("event") or {}
                    if full.get("markets"):
                        markets = full["markets"]
                    detail_max -= 1
                except Exception as e:  # noqa: BLE001
                    log.debug("detalle %s: %s", ev.get("id"), e)
                    if "bloqueo" in str(e):
                        raise
            sels = tree_market_selections(markets, sport, m["home"], m["away"])
            if sels:
                rows.append({"event_id": str(m["id"]), "home": m["home"], "away": m["away"], "competition": comp, "date": m["date"],
                             "start_time": m["start_time"], "url": m["url"], "selections": sels})
        if not rows:
            return 0, 0
        self._pm_present |= {r["event_id"] for r in rows}
        return len(rows), self.store.save_rows(sport, "prematch", rows)

    def _pm_job(self, t0: float, once: bool):
        if not self._pm_queue and t0 - self._last_prematch >= self.cfg.get("interval_prematch", 300):
            self._pm_queue = list(self.comps)
            self._pm_present = set()
            self._pm_rows = self._pm_changed = 0
            self._last_prematch = t0
        if not self._pm_queue:
            return None
        batch = len(self._pm_queue) if once else max(1, self.cfg.get("prematch_batch", 1))
        chunk, self._pm_queue = self._pm_queue[:batch], self._pm_queue[batch:]

        def _run():
            for cid in chunk:
                try:
                    r, c = self.prematch_competition(cid)
                    self._pm_rows += r
                    self._pm_changed += c
                except Exception as e:  # noqa: BLE001
                    log.warning("prematch %s: %s", self.comps.get(cid, ("?", "?"))[1], e)
            if not self._pm_queue:
                self.store.sweep(self._pm_present, "prematch")
                return f"prematch {self._pm_rows} ev / {self._pm_changed} cambios (pasada completa)"
            return f"prematch {self._pm_rows} ev / {self._pm_changed} cambios ({len(self._pm_queue)} competiciones pendientes)"
        return _run

    def run(self, once: bool = False):
        backoff = 2
        while True:
            t0 = time.time()
            try:
                self._reload_if_changed()
                self.refresh_menu()
                rows, changed = self.live_cycle()
                msg = f"live {rows} ev / {changed} cambios"
                if self.stream:
                    msg += f" [sse {len(self.live_meta)} partidos, {self.stream.msgs} msgs, {self.stream.bytes // 1024} KB]"
                if not self._bg.busy():
                    job = self._pm_job(t0, once)
                    if job is not None:
                        r = self._bg.run(job, inline=once)
                        if r:
                            msg += " | " + r
                note = self._bg.note()
                if note:
                    msg += " | " + note
                self.store.set_status(**{f"{self.bk}_last_ok": time.time(), f"{self.bk}_live_events": rows,
                                         f"{self.bk}_transport": self.transport})
                log.info("%s [%s] (%.1fs)", msg, self.transport, time.time() - t0)
                backoff = 2
                if once:
                    return
            except Exception as e:  # noqa: BLE001
                if "bloqueo" in str(e):
                    backoff = max(backoff, 30)
                log.warning("error de ciclo: %s — reintento en %ss", e, backoff, exc_info=log.isEnabledFor(logging.DEBUG))
                self.store.set_status(**{f"{self.bk}_last_error": f"{time.time():.0f} {e}"})
                time.sleep(backoff)
                backoff = min(backoff * 2, 120)
                continue
            time.sleep(max(0.5, self.cfg.get("interval_live", 2) - (time.time() - t0)))


def list_catalog(c: Collector):
    c.refresh_menu(force=True)
    for sport, label, cid, name, n in sorted(c._all, key=lambda x: (x[0], x[1])):
        print(f"{'✔' if name else ' '} {sport:10s} {cid!s:>6s}  {label:60s} {n:4d} ev  -> {name or ''}")
    print(f"\n{len(c.comps)} competiciones seleccionadas")


def dump_event(c: Collector, ident: str):
    c.refresh_menu(force=True)
    c.refresh_live_list(force=True)
    meta = c.live_meta.get(ident) or next((m for m in c.live_meta.values() if str(m["id"]) == ident), None)
    if meta and c.stream:
        print(f"LIVE {meta['home']} - {meta['away']} ({meta['comp']}) match_id={meta['match_id']}; esperando SSE…")
        for _ in range(30):
            time.sleep(1)
            with c.stream.lock:
                s = dict(c.stream.snap.get(meta["match_id"]) or {})
            if s.get("odds"):
                break
        print(json.dumps(s.get("match"), ensure_ascii=False))
        for o in s.get("odds") or []:
            print(f"  {o.get('qt')!r}: " + "; ".join(f"{cc.get('cid')}|{cc.get('act')}@{cc.get('ct')}" for b in o.get('bets') or []
                                                   for cc in (b.get('tch') or {}).values()))
        print("\n-> selecciones:")
        for s_ in sse_market_selections(s.get("odds") or [], meta["sport"], meta["home"], meta["away"]):
            print("  ", s_)
        return
    # pre-partido: buscar el evento por id en las competiciones
    for cid, (sport, comp, url) in c.comps.items():
        j = c.tree(url)
        for ev in ((_find(j.get("tree"), "prematch_event_list") or {}).get("data") or {}).get("events") or []:
            if str(ev.get("id")) == ident or str(ev.get("match_id")) == ident:
                jd = c.tree(ev["url"])
                full = ((_find(jd.get("tree"), "event_market_list") or {}).get("data") or {}).get("event") or ev
                home, away = c._teams(ev)
                print(f"PRE {home} - {away} ({comp})")
                for m in full.get("markets") or []:
                    for b in m.get("bets") or []:
                        print(f"  [{m.get('selection_order_type')}] {b.get('label')!r}: " +
                              "; ".join(f"{s.get('label')}@{s.get('odds')}" for s in b.get("selections") or []))
                print("\n-> selecciones:")
                for s_ in tree_market_selections(full.get("markets") or [], sport, home, away):
                    print("  ", s_)
                return
    print("evento no encontrado (ni en directo ni en las competiciones seleccionadas)")


def main():
    try:
        sys.stdout.reconfigure(encoding="utf-8")                # consola de Windows: evita "HÃ¡ndicap" en --list/--dump
    except Exception:  # noqa: BLE001
        pass
    logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"), format="%(asctime)s %(levelname)s %(name)s: %(message)s", datefmt="%H:%M:%S")
    cfg = pace.apply(json.loads(CFG_PATH.read_text(encoding="utf-8")))
    c = Collector(cfg)
    if "--list" in sys.argv:
        list_catalog(c)
        return
    if "--dump" in sys.argv:
        dump_event(c, sys.argv[sys.argv.index("--dump") + 1])
        return
    c.run(once="--once" in sys.argv)


if __name__ == "__main__":
    main()
