"""Limpieza periódica de odds.db para que no engorde.

Qué se borra (configurable por .env):
  DB_CLEAN_EVERY_MIN    (5)  cada cuántos minutos se limpia
  DB_HISTORY_MIN       (20)  odds_history: solo se guardan los últimos N minutos (el bot lee ~15 min)
  DB_STALE_HOURS        (6)  odds_latest / events que ninguna casa ha vuelto a ver en N horas
  DB_VACUUM_HOURS      (24)  cada cuántas horas se compacta el fichero (VACUUM) para devolver el espacio al disco;
                             0 = nunca. Entre VACUUMs el espacio borrado se reutiliza (el fichero no crece).
  DB_CKPT_EVERY_S       (5)  cada cuántos segundos se hace checkpoint PASIVO del -wal (no bloquea; los colectores no lo hacen)
  WAL_RESTART_MB      (256)  MB de WAL EN USO a partir de los cuales se fuerza su reinicio (RESTART bloquea escritores: raro)
Se ejecuta como un servicio más (run_all.py / docker compose). No toca market_map (pequeña y útil para depurar).

    python housekeeping.py            # bucle
    python housekeeping.py --once     # una pasada y sale
"""
from __future__ import annotations

import os
import sqlite3
import sys
import time
from pathlib import Path

DB = Path(os.getenv("ODDS_DB") or Path(__file__).resolve().parent.parent / "data" / "odds.db")
EVERY = max(1, int(os.getenv("DB_CLEAN_EVERY_MIN", "5") or 5)) * 60
HISTORY_MIN = max(5, int(os.getenv("DB_HISTORY_MIN", "20") or 20))
STALE_H = max(1.0, float(os.getenv("DB_STALE_HOURS", "6") or 6))
VACUUM_H = max(0.0, float(os.getenv("DB_VACUUM_HOURS", "24") or 24))
_last_vacuum = 0.0
VACUUM_WINDOW = os.getenv("DB_VACUUM_WINDOW", "4-10")   # franja horaria local "HH-HH" en la que se permite el VACUUM


def _quiet_hour() -> bool:
    try:
        a, b = (int(x) for x in VACUUM_WINDOW.split("-"))
    except ValueError:
        return True
    h = time.localtime().tm_hour
    return a <= h < b if a <= b else (h >= a or h < b)
CKPT_EVERY = max(3, int(os.getenv("DB_CKPT_EVERY_S", "5") or 5))
WAL_RESTART_MB = float(os.getenv("WAL_RESTART_MB", "256") or 256)


def _size_mb() -> float:
    tot = 0
    for suf in ("", "-wal", "-shm"):
        p = Path(str(DB) + suf)
        if p.exists():
            tot += p.stat().st_size
    return tot / 1e6


def _log(msg: str) -> None:
    print(time.strftime("%H:%M:%S"), msg, flush=True)


def clean(vacuum: bool) -> None:
    global _last_vacuum
    if not DB.exists():
        _log(f"odds.db aún no existe ({DB})")
        return
    before = _size_mb()
    con = sqlite3.connect(DB, timeout=60)
    con.execute("PRAGMA busy_timeout=60000")
    now = time.time()
    try:
        # el histórico se borra por lotes cortos: un DELETE de cientos de miles de filas bloquea la BD varios
        # segundos y todas las casas (y el bot) se quedan esperando a la vez
        h = 0
        while True:
            n = con.execute("DELETE FROM odds_history WHERE id IN (SELECT id FROM odds_history WHERE ts < ? LIMIT 20000)",
                            (now - HISTORY_MIN * 60,)).rowcount
            con.commit()
            h += n
            if n < 20000:
                break
            time.sleep(0.2)
        l = con.execute("DELETE FROM odds_latest WHERE seen_at < ?", (now - STALE_H * 3600,)).rowcount
        e = con.execute("DELETE FROM events WHERE last_seen < ?", (now - STALE_H * 3600,)).rowcount
        con.commit()
        con.execute("PRAGMA busy_timeout=3000")
        con.execute("PRAGMA wal_checkpoint(TRUNCATE)")       # con journal_size_limit (storage.py) el -wal queda <= 64 MB
        con.execute("PRAGMA busy_timeout=60000")
        info = f"borradas {h} filas de histórico, {l} cuotas y {e} eventos viejos"
        if vacuum:
            t0 = time.time()
            con.execute("VACUUM")
            _last_vacuum = time.time()
            info += f" · VACUUM en {time.time() - t0:.1f}s"
    except sqlite3.OperationalError as ex:
        _log(f"⚠️ limpieza aplazada: {ex}")
        con.close()
        return
    con.close()
    _log(f"🧹 {info} · {before:.1f} MB → {_size_mb():.1f} MB")


def main() -> None:
    global _last_vacuum
    once = "--once" in sys.argv
    _log(f"limpieza de {DB}: cada {EVERY // 60} min · histórico {HISTORY_MIN} min · eventos {STALE_H:g} h · "
         f"VACUUM cada {VACUUM_H:g} h")
    while True:
        due = VACUUM_H > 0 and (time.time() - _last_vacuum) >= VACUUM_H * 3600 and _last_vacuum > 0
        if _last_vacuum == 0:          # primer arranque: compactar ya si el fichero es grande
            _last_vacuum = time.time()
            due = VACUUM_H > 0 and _size_mb() > 200
        if due and not _quiet_hour():  # VACUUM bloquea a TODOS los colectores unos segundos: solo en horas sin partidos
            due = False
            _last_vacuum = time.time() - VACUUM_H * 3600 + 600   # reintentar dentro de 10 min
        try:
            clean(vacuum=due or once)
        except Exception as ex:  # noqa: BLE001
            _log(f"⚠️ error en limpieza: {ex}")
        if once:
            return
        # Entre limpiezas, checkpoint cada CKPT_EVERY s. Los colectores tienen wal_autocheckpoint=0 (storage.py):
        # este proceso es el único que copia el -wal al fichero principal, fuera del camino crítico de las casas.
        # PASSIVE no molesta a nadie; si aun así el -wal pasa de WAL_RESTART_MB (nunca pilla un instante sin
        # lectores), RESTART espera como mucho 1,5 s a que terminen las lecturas en curso y reinicia el WAL.
        # OJO: el tamaño del fichero -wal NO sirve para decidir (journal_size_limit lo deja fijo en 64 MB aunque esté
        # vacío): se usa el nº de frames en uso que devuelve el propio PASSIVE. RESTART bloquea a TODOS los escritores
        # mientras copia, así que solo se fuerza si los frames pendientes de verdad pasan de WAL_RESTART_MB.
        for _ in range(max(1, EVERY // CKPT_EVERY)):
            time.sleep(CKPT_EVERY)
            try:
                c = sqlite3.connect(DB, timeout=5)
                c.execute("PRAGMA busy_timeout=1500")
                r = c.execute("PRAGMA wal_checkpoint(PASSIVE)").fetchone() or (0, 0, 0)
                page = c.execute("PRAGMA page_size").fetchone()[0]
                # r = (busy, frames en el WAL, frames ya copiados). Lo que de verdad retiene el WAL son los frames
                # PENDIENTES (r[1]-r[2]: un lector antiguo impide copiarlos); r[1] solo es el tamaño del fichero.
                wal_mb = max(0, r[1]) * page / 1e6
                pend_mb = max(0, r[1] - r[2]) * page / 1e6
                if wal_mb > WAL_RESTART_MB:
                    r2 = c.execute("PRAGMA wal_checkpoint(RESTART)").fetchone()
                    if r2 and r2[0] == 0:
                        _log(f"🔁 WAL reiniciado ({wal_mb:.0f} MB, {pend_mb:.0f} MB pendientes de copiar)")
                    elif pend_mb > WAL_RESTART_MB / 2:
                        _log(f"⚠️ WAL {wal_mb:.0f} MB con {pend_mb:.0f} MB pendientes: algún proceso mantiene una lectura abierta")
                c.close()
            except Exception:  # noqa: BLE001
                pass


if __name__ == "__main__":
    main()
