"""
bwin.py — colector de cuotas de bwin (bwin.es), plataforma Entain ("cds-api").

API JSON en el mismo dominio, con geobloqueo (IP española) pero sin WAF agresivo: responde a `requests`
(transport.py en modo `auto` pasa a Chrome real si empezara a bloquear). Todas las llamadas llevan
`x-bwin-accessid` (identificador público de la web, en bwin.json) y `lang=es&country=ES&userCountry=ES`.

Endpoints (verificados desde España):
    bettingoffer/counts?...&tagTypes=Sport,Region,Competition&sportIds=4   -> catálogo región > competición (ids)
    bettingoffer/fixtures?...&state=Live&sportIds=4,5,7&take=200            -> TODOS los directos (marcador, reloj)
    bettingoffer/fixtures?...&state=Latest&competitionIds=a,b,c&take=100     -> pre-partido por competiciones
                                                                            (mercados principales incluidos)
    bettingoffer/fixture-view?...&fixtureIds=2:7892670&offerMapping=All     -> todos los mercados de un partido
Los mercados vienen en dos formatos: `optionMarkets` (V2, con `parameters` MarketType/Happening/Period/
DecimalValue/FixtureParticipant) y `games` (legado: nombre + results con attr/sourceName). Se tratan ambos.
Sport ids: 4 fútbol, 5 tenis, 7 baloncesto.

Uso:  python bwin.py          (bucle)      python bwin.py --once      python bwin.py --list      python bwin.py --dump
"""
from __future__ import annotations

import fastjson as json
import logging
import os
import re
import sys
import time
import unicodedata
from datetime import datetime, timezone, timedelta
from pathlib import Path
from urllib.parse import urlencode

sys.path.insert(0, str(Path(__file__).resolve().parent))   # permite `python -m scraper.bwin` desde la raíz

from competitions import Competitions
from markets import classify, parse_ou_label, period_of
from storage import OddsStore
from demand import Demand
from transport import Http

log = logging.getLogger("bwin")
CFG_PATH = Path(os.getenv("BWIN_CFG", Path(__file__).parent / "bwin.json"))

_PERIOD = {"RegularTime": None, "FullTime": None, "Match": None, "FirstHalf": "1H", "SecondHalf": "2H",
           "FirstQuarter": "Q1", "SecondQuarter": "Q2", "ThirdQuarter": "Q3", "FourthQuarter": "Q4",
           "FirstSet": "SET1", "SecondSet": "SET2", "ThirdSet": "SET3", "FourthSet": "SET4", "FifthSet": "SET5"}
_KIND = {"3way": "result", "2way": "result", "Over/Under": "total", "Handicap": "handicap", "AsianHandicap": "handicap",
         "Spread": "handicap", "BTTS": "btts", "DrawNoBet": "dnb"}
_SKIP_TYPES = {"CorrectScore", "Odd/Even", "XthHappening", "ThreeWayAndBTTS", "ThreeWayAndOverUnder", "DoubleChance",
               "HalfTimeFullTime", "WinningMargin", "ScoreCast", "Multi", "TeamToScoreFirst", "AnytimeAndResult"}
_SKIP_TITLE = re.compile(r"par o impar|impar o par|exacto|equipo en marcar|se clasifica|quién ganará el \d|juego \d|margen|"
                         r"\(\+\d\)|\bVA\b|combinad|y ambos|y total|y multigol|minuto|primer[oa]? |último|al descanso y|"
                         r"gana ambas|sin encajar|pierde|carrera a|habrá|1ª estadística|primer intento|ambos equipos anotan|"
                         r"\d+\+ puntos en|descanso/final|o menos\b|\bcanasta\b", re.I)
_STRIP = re.compile(r"\s*\((solo|sólo)[^)]*\)|\s*-\s*pr[oó]rroga( incluida)?$|\s*\(incl\.? pr[oó]rroga\)", re.I)


def load_cfg() -> dict:
    import pace
    return pace.apply(json.loads(CFG_PATH.read_text(encoding="utf-8")))


def _fold(s: str) -> str:
    return unicodedata.normalize("NFKD", s or "").encode("ascii", "ignore").decode().lower()


def _num(s) -> float | None:
    if s is None:
        return None
    m = re.search(r"([+-]?\d+(?:[.,]\d+)?)", str(s))
    return float(m.group(1).replace(",", ".")) if m else None


def _hcp_from_name(name: str) -> float | None:
    m = re.search(r"\(([+-]?\d+(?:[.,]\d+)?)\)\s*$", name or "") or re.search(r"([+-]\d+(?:[.,]\d+)?)\s*$", name or "")
    return float(m.group(1).replace(",", ".")) if m else None


# ──────────────────────────────────────────────────────────────────────────────
# Happening (parámetro V2) -> métrica en castellano que entiende markets.classify
_HAPPENING = {"Goal": "goles", "NonOwnGoal": "goles", "Corner": "córners", "Card": "tarjetas", "CombinedCards": "tarjetas",
              "YellowCard": "tarjetas", "Shot": "tiros", "ShotOnTarget": "tiros a puerta", "Foul": "faltas", "Offside": "fueras de juego",
              "Assist": "asistencias", "Tackle": "entradas", "Save": "paradas", "Point": "puntos", "Rebound": "rebotes",
              "ThreePointer": "triples", "Steal": "robos", "Block": "tapones", "Game": "juegos", "Set": "sets",
              "CombinedPointsAssists": "puntos + asistencias", "CombinedPointsRebounds": "puntos + rebotes",
              "CombinedReboundsAssists": "rebotes + asistencias", "CombinedPointsReboundsAssists": "puntos + rebotes + asistencias"}
_SKIP_SUBTYPE = {"2Up", "ResultAfter", "MostGoals"}
_HCP_UNKNOWN: set = set()


class Ctx:
    """Participantes de un fixture: lado de cada equipo y nombres de jugadores."""

    def __init__(self, fx: dict, home: str, away: str):
        self.home, self.away = home, away
        # formato US ("Visitante en casa de Local"): bwin lista primero al visitante → la posición 1 / sourceName "1" es el VISITANTE
        self.us = " en casa de " in ((fx.get("name") or {}).get("value") or "")
        self.sides: dict = {}
        self.players: dict = {}
        for pt in fx.get("participants") or []:
            t = (pt.get("properties") or {}).get("type")
            nm = (pt.get("name") or {}).get("value") or ""
            for key in (pt.get("id"), pt.get("participantId")):
                if key is None:
                    continue
                if t in ("HomeTeam", "AwayTeam"):
                    self.sides[str(key)] = "HOME" if t == "HomeTeam" else "AWAY"
                elif t == "Player":
                    self.players[str(key)] = (pt.get("name") or {}).get("short") or re.sub(r"\s*\([A-Za-z]{2,4}\)$", "", nm)
        self.player_names = sorted(set(self.players.values()), key=len, reverse=True)

    def side(self, fp) -> str | None:
        return self.sides.get(str(fp)) if fp is not None else None

    def player(self, fp, title: str) -> str | None:
        if fp is not None and str(fp) in self.players:
            return self.players[str(fp)]
        tf = _fold(title)
        for n in self.player_names:                       # "Desmond Bane registra 3+ rebotes"
            if tf.startswith(_fold(n)):
                return n
        return None

    def side_by_name(self, name: str, idx: int, n: int) -> str | None:
        t = _fold(re.sub(r"\s*\(?[+-]\d+(?:[.,]\d+)?\)?\s*$", "", name)).strip()
        if t in ("1", "x", "2"):
            if self.us and t in ("1", "2"):
                return "2" if t == "1" else "1"
            return t.upper()
        if t in ("empate", "draw"):
            return "X"
        h, a = _fold(self.home), _fold(self.away)
        if t and (t == h or t in h or h in t):
            return "1"
        if t and (t == a or t in a or a in t):
            return "2"
        if n == 2:
            first = "2" if self.us else "1"
            return first if idx == 0 else ("1" if first == "2" else "2")
        if n == 3:
            return ("2", "X", "1")[idx] if self.us else ("1", "X", "2")[idx]
        return None


def _period_fix(info, period: str | None):
    if period in _PERIOD and _PERIOD[period] != info.period:
        base = re.sub(r"_(1H|2H|Q[1-4]|SET[1-5]|OT)$", "", info.market)
        info.market = base + (f"_{_PERIOD[period]}" if _PERIOD[period] else "")
    return info


def _generic(title: str, cat: str, results: list[tuple], sport: str, ctx: Ctx) -> list[dict]:
    """Mercados sin parámetros (games legado o V2 con solo CategoryId/TemplateId): por título.
    results = [(nombre, cuota, attr, sourceName)]"""
    if _SKIP_TITLE.search(title):
        return []
    tc = _fold(cat + " " + title)
    kind = "handicap" if re.search(r"handicap|spread", tc) else "total" if re.search(r"mas/menos|total|numero de|cuantos", tc) \
        else "result" if re.search(r"ganador|resultado|1x2|1 2", tc) else None
    if kind == "result" and re.search(r"juego", _fold(title)):
        return []
    mq = re.search(r"quien ganara mas (juegos|puntos|sets)", _fold(title))   # "¿Quién ganará más juegos? (hándicap jugador)"
    if mq:
        kind = "handicap"
        per = period_of(title)                          # "… en el 2° set? (hándicap jugador)" → SET2 (antes se perdía: hándicap del set guardado como del partido)
        if per is None and not re.search(r"\bpartido\b", _fold(title)) and re.search(r"\bjuego\b", _fold(title)):
            return []                                   # "en el 6º juego": hándicap de un juego concreto, no modelado
        title = {"juegos": "Hándicap de juegos", "sets": "Hándicap de sets"}.get(mq.group(1), "Hándicap")
        if per:
            title += " - " + {"1H": "1ª mitad", "2H": "2ª mitad", "Q1": "1er cuarto", "Q2": "2do cuarto", "Q3": "3er cuarto", "Q4": "4to cuarto",
                              "SET1": "1er set", "SET2": "2do set", "SET3": "3er set", "SET4": "4to set", "SET5": "5to set", "OT": "prórroga"}.get(per, "")
    elif sport == "tenis" and _fold(title).strip() == "handicap":
        return []                                       # "Hándicap" a secas en tenis: ¿sets o juegos? no comparable
    t2 = re.sub(r"^¿?cu[aá]ntos puntos se anotar[aá]n en el partido", "Total de puntos", title, flags=re.I)
    t2 = re.sub(r"^¿?cu[aá]ntos puntos anotar[aá]n? (los |el )?", "Total de puntos ", t2, flags=re.I)   # "¿Cuántos puntos anotará Atlanta Hawks?"
    t2 = re.sub(r"\s*\(tiempo reglamentario\)|\s*\(solo el tiempo reglamentario\)|\?$", "", t2)
    t2 = re.sub(r"1er medio tiempo", "1ª mitad", t2, flags=re.I)
    player = ctx.player(None, t2)
    if player and re.match(rf"{re.escape(_fold(player))}\s*-\s*", _fold(t2)):
        t2 = t2.split(" - ", 1)[1]
    info = classify(t2, sport, ctx.home, ctx.away, kind=kind, player=player)
    if not info:
        return []
    out = []
    for i, (name, odds, attr, src, *rest) in enumerate(results):
        oid = rest[0] if rest else None
        if not odds:
            continue
        if info.market.startswith(("1X2", "DNB")):
            sel = ctx.side_by_name(name, i, len(results))
            if sel is None and src in ("1", "X", "2", "x"):
                sel = src.upper()
                if ctx.us and sel in ("1", "2"):
                    sel = "2" if sel == "1" else "1"
            if sel:
                out.append({"market": info.market, "selection": sel, "line": None, "price": odds, "oid": oid})
        elif info.market.startswith("HANDICAP"):
            sel = ctx.side_by_name(name, i, len(results))
            ln = _hcp_from_name(name)                       # la línea del nombre ("Lakers +7,5") es la de ESA selección
            if ln is None and attr is not None:
                ln = _num(attr)                             # `attr` suele ser la línea del local: para el visitante se invierte
                if ln is not None and sel == "2" and len(results) == 2:
                    other = results[1 - i] if i < 2 else None
                    oattr = _num(other.get("attr")) if other and other.get("attr") is not None else None
                    if oattr is not None and abs(oattr - ln) < 1e-9:
                        ln = -ln
            if ln is not None and sel in ("1", "2"):
                out.append({"market": info.market, "selection": sel, "line": ln, "price": odds, "oid": oid})
        elif info.market.startswith("BTTS"):
            out.append({"market": info.market, "selection": "Yes" if _fold(name).startswith("s") else "No", "line": None, "price": odds, "oid": oid})
        else:
            sel, ln = parse_ou_label(name)
            if ln is None:
                ln = _num(attr)
            if sel and ln is not None:
                out.append({"market": info.market, "selection": sel, "line": ln, "player": info.player, "price": odds, "oid": oid})
    return out


def parse_option_market(m: dict, sport: str, ctx: Ctx) -> list[dict]:
    """Mercado V2 (`optionMarkets`) -> selecciones normalizadas."""
    if m.get("status") not in (None, "Visible"):
        return []
    p = {x.get("key"): x.get("value") for x in m.get("parameters") or []}
    mtype, hap, period = p.get("MarketType"), p.get("Happening"), p.get("Period")
    title = _STRIP.sub("", (m.get("name") or {}).get("value") or "")
    opts = [o for o in m.get("options") or [] if o.get("status") in (None, "Visible") and (o.get("price") or {}).get("odds")]
    if not opts:
        return []
    if mtype is None:                                   # plantilla clásica dentro de V2: por título
        return _generic(title, "", [((o.get("name") or {}).get("value") or "", o["price"]["odds"], None, None, o.get("id")) for o in opts], sport, ctx)
    if (period and period not in _PERIOD) or "RangeValue" in p or p.get("MarketSubType") in _SKIP_SUBTYPE or _SKIP_TITLE.search(title):
        return []
    if not period:                                      # sin parámetro Period: el set/parte puede venir solo en el nombre
        tp = period_of(title)                           # ("Hándicap de juegos - 2.º set")
        if tp:
            period = next((k for k, v in _PERIOD.items() if v == tp), None)
            if period is None:
                return []                               # periodo que no modelamos (p. ej. juego concreto)
    fp = p.get("FixtureParticipant")
    line = _num(p.get("DecimalValue"))
    out: list[dict] = []

    def sel_side(o, i):
        types = (o.get("parameters") or {}).get("optionTypes") or []
        if "Draw" in types:
            return "X"
        side = ctx.side((o.get("parameters") or {}).get("fixtureParticipant"))
        return {"HOME": "1", "AWAY": "2"}.get(side) or ctx.side_by_name((o.get("name") or {}).get("value") or "", i, len(opts))

    if mtype in ("3way", "2way", "DrawNoBet"):
        if hap not in (None, "Goal", "Point", "Game", "Set"):
            return []                                   # "Más córners" (3 vías de córners) no es 1X2
        if sport != "futbol" and (mtype == "3way" or any("Draw" in ((o.get("parameters") or {}).get("optionTypes") or []) for o in opts)):
            return []                                   # baloncesto/tenis: "1X2" a 3 vías es tiempo reglamentario con empate; la clave 1X2 es el ganador a 2 vías
        info = classify(title, sport, ctx.home, ctx.away, kind="dnb" if mtype == "DrawNoBet" else "result")
        if not info or not info.market.startswith(("1X2", "DNB")):
            return []
        _period_fix(info, period)
        for i, o in enumerate(opts):
            sel = sel_side(o, i)
            if sel:
                out.append({"market": info.market, "selection": sel, "line": None, "price": o["price"]["odds"], "oid": o.get("id")})
        return out
    if mtype == "BTTS":
        info = _period_fix(classify("Ambos equipos marcan", sport, kind="btts"), period)
        for o in opts:
            types = (o.get("parameters") or {}).get("optionTypes") or []
            sel = "Yes" if ("Yes" in types or _fold((o.get("name") or {}).get("value") or "").startswith("s")) else "No"
            out.append({"market": info.market, "selection": sel, "line": None, "price": o["price"]["odds"], "oid": o.get("id")})
        return out
    if mtype in ("Handicap", "AsianHandicap", "Spread"):
        if any("Draw" in ((o.get("parameters") or {}).get("optionTypes") or []) for o in opts):
            return []                                   # "Hándicap 1X2" (3 vías) no es comparable con un hándicap 2 vías
        metric = _HAPPENING.get(hap, "")
        if sport == "tenis" and not metric:
            # sin Happening conocido el título es un simple "Hándicap": puede ser de sets o de juegos (mismas líneas ±1.5/±2.5,
            # cuotas distintas) → se infiere del título y, si no se puede, se descarta (antes creaba surebets falsos)
            tl = _fold(title)
            metric = "sets" if re.search(r"\bsets?\b", tl) else ("juegos" if re.search(r"\bjuegos?\b", tl) else "")
            if not metric:
                key = (hap, title)
                if key not in _HCP_UNKNOWN:
                    _HCP_UNKNOWN.add(key)
                    log.info("tenis: hándicap sin métrica (Happening=%r título=%r): descartado", hap, title)
                return []
        info = classify(f"Hándicap {metric}", sport, ctx.home, ctx.away, kind="handicap")
        if not info:
            return []
        _period_fix(info, period)
        for i, o in enumerate(opts):
            name = (o.get("name") or {}).get("value") or ""
            sel = sel_side(o, i)
            ln = _hcp_from_name(name)
            if ln is None and line is not None:
                ln = line if sel == "1" else -line
            if sel in ("1", "2") and ln is not None:
                out.append({"market": info.market, "selection": sel, "line": ln, "price": o["price"]["odds"], "oid": o.get("id")})
        return out
    if mtype == "Over/Under":
        if hap and hap not in _HAPPENING:
            return []                                   # FantasyPoints, DoubleDouble…
        side = ctx.side(fp)
        player = None if side else ctx.player(fp, title)
        if fp is not None and not side and not player:
            return []                                   # participante desconocido: no es el total del partido
        if hap:
            metric = _HAPPENING[hap]
            if hap == "Shot" and p.get("Outcome") == "OnTarget":
                metric = "tiros a puerta"
            if not side and not player:                 # sin FixtureParticipant: el equipo puede venir solo en el título
                probe = classify(title, sport, ctx.home, ctx.away, kind="total")
                if probe and probe.team:
                    side = probe.team
            syn = f"Total de {metric}" + (f" {ctx.home if side == 'HOME' else ctx.away}" if side else "")
        else:
            syn = title
        info = classify(syn, sport, ctx.home, ctx.away, kind="total", player=player)
        if not info:
            return []
        _period_fix(info, period)
        yesno = p.get("MarketSubType") == "YesNo"
        for o in opts:
            name = (o.get("name") or {}).get("value") or ""
            types = (o.get("parameters") or {}).get("optionTypes") or []
            sel = "Over" if "Over" in types else "Under" if "Under" in types else parse_ou_label(name)[0]
            ln = line if line is not None else parse_ou_label(name)[1]
            if yesno and ln is not None:
                ln = ln - 0.5                          # "registra 3+ rebotes" (DecimalValue 3) -> Más de 2.5
            if sel in ("Over", "Under") and ln is not None:
                out.append({"market": info.market, "selection": sel, "line": ln, "player": info.player, "price": o["price"]["odds"], "oid": o.get("id")})
        return out
    if mtype == "Scorer" and p.get("Position") == "Any" and hap in _HAPPENING:
        metric = "tiros a puerta" if (hap == "Shot" and p.get("Outcome") == "OnTarget") else _HAPPENING[hap]
        places = _num(p.get("Places")) or 1
        for o in opts:
            player = (o.get("name") or {}).get("value") or ""
            if ", " in player:                          # "Silva, Thiago" -> "Thiago Silva"
                last, first = player.split(", ", 1)
                player = f"{first} {last}"
            info = classify(f"Total de {metric}", sport, player=player)
            if info:
                _period_fix(info, period)
                out.append({"market": info.market, "selection": "Over", "line": places - 0.5, "player": player, "price": o["price"]["odds"], "oid": o.get("id")})
        return out
    return []


def parse_game(g: dict, sport: str, ctx: Ctx) -> list[dict]:
    """Mercado legado (`games`) -> selecciones normalizadas."""
    if g.get("visibility") not in (None, "Visible"):
        return []
    title = _STRIP.sub("", (g.get("name") or {}).get("value") or "")
    cat = ((g.get("templateCategory") or {}).get("name") or {}).get("value") or ""
    res = [((r.get("name") or {}).get("value") or "", r.get("odds"), r.get("attr"), (r.get("sourceName") or {}).get("value"), r.get("id"))
           for r in g.get("results") or [] if r.get("visibility") in (None, "Visible")]
    out = _generic(title, cat, res, sport, ctx)
    for sl in out:
        sl["mid"] = g.get("id")
    return out


def fixture_selections(fx: dict, sport: str, home: str, away: str) -> list[dict]:
    ctx = Ctx(fx, home, away)
    out: list[dict] = []
    for m in fx.get("optionMarkets") or []:
        for sl in parse_option_market(m, sport, ctx):
            sl["mid"] = m.get("id")
            out.append(sl)
    for g in fx.get("games") or []:
        out += parse_game(g, sport, ctx)
    # enlace directo verificado: <evento>?options=<fixtureId>-<marketId>-<optionId>  (deja la selección en la cesta)
    for sl in out:
        mid, oid = sl.pop("mid", None), sl.pop("oid", None)
        if mid and oid:
            sl["url"] = f"?options={fx.get('id')}-{mid}-{oid}"
    return out


def _scoreboard(sb: dict | None) -> dict:
    if not sb:
        return {}
    score = sb.get("score")
    sets = sb.get("setsValues") or {}
    if sets:
        p1, p2 = sets.get("player1") or [], sets.get("player2") or []
        full = " ".join(f"{a}:{b}" for a, b in zip(p1, p2))
        if full:
            score = full                           # tenis: juegos de cada set ("6:4 1:4") en vez del "1:4" suelto
    tm = sb.get("timer") or {}
    timer = None
    if isinstance(tm, dict) and tm.get("seconds") is not None:
        secs = int(tm["seconds"])
        if tm.get("running") and tm.get("base"):
            try:
                secs += int(time.time() - datetime.fromisoformat(tm["base"].replace("Z", "+00:00")).timestamp())
            except ValueError:
                pass
        timer = f"{secs // 60:02d}:{secs % 60:02d}"
    return {"score": score or None, "period": sb.get("period"), "timer": timer}


# ──────────────────────────────────────────────────────────────────────────────
class Collector:
    def __init__(self, cfg: dict):
        self.cfg = cfg
        self._cfg_mtime = CFG_PATH.stat().st_mtime
        self.bk = cfg.get("bookmaker", "bwines")
        self.http = Http(cfg["origin"], cfg.get("transport", "auto"), cfg.get("headers"), cfg.get("start_url"),
                         cfg.get("workers", 3), gap=cfg.get("request_gap"), api_hint="/cds-api/", headless=cfg.get("headless"))
        self.store = OddsStore(bookmaker=self.bk)
        self.catalog = Competitions()
        self.demand = Demand(self.bk)
        self.comps: dict[int, tuple[str, str]] = {}       # competitionId -> (sport, competición canónica)
        self._comps_at = 0.0
        self._last_prematch = 0.0
        self._pm_queue: list = []
        self._live_off = 0
        self._skipped = 0

    def url(self, path: str, **params) -> str:
        q = {"x-bwin-accessid": self.cfg["access_id"], "lang": "es", "country": "ES", "userCountry": "ES"}
        q.update({k: v for k, v in params.items() if v is not None})
        return f"{self.cfg['api_base'].rstrip('/')}/{path}?{urlencode(q, safe=',:')}"

    def get(self, path: str, **params):
        st, js = self.http.get(self.url(path, **params))
        if st != 200 or js is None:
            raise RuntimeError(f"{path} -> HTTP {st}")
        return js

    def _reload_if_changed(self):
        self.catalog.reload()
        mt = CFG_PATH.stat().st_mtime
        if mt != self._cfg_mtime:
            self.cfg, self._cfg_mtime = load_cfg(), mt
            log.info("bwin.json recargado")

    # ── catálogo ──
    def refresh_comps(self, force: bool = False):
        if not force and time.time() - self._comps_at < self.cfg.get("catalog_ttl", 900):
            return
        comps: dict[int, tuple[str, str]] = {}
        for sid, sport in self.cfg["sports"].items():
            tags = self.get("bettingoffer/counts", state="Latest", tagTypes="Sport,Region,Competition", sortBy="Tags",
                            sportIds=sid, fixtureTypes="Standard,PairGame")
            regions = {t["tag"]["id"]: t["tag"]["name"]["value"] for t in tags if t["tag"].get("type") == "Region"}
            for t in tags:
                tg = t["tag"]
                if tg.get("type") != "Competition":
                    continue
                label = f"{regions.get(tg.get('parentId'), '')} - {tg['name']['value']}".strip(" -")
                comp = self.catalog.match(self.bk, sport, label)
                if comp:
                    comps[int(tg["id"])] = (sport, comp)
        for cid, (sport, comp) in (self.cfg.get("extra_competitions") or {}).items():
            comps[int(cid)] = (sport, comp)
        self.comps, self._comps_at = comps, time.time()
        log.info("%d competiciones mapeadas en bwin", len(comps))

    # ── eventos ──
    def _names(self, fx: dict) -> tuple[str, str]:
        home = away = ""
        for pt in fx.get("participants") or []:
            t = (pt.get("properties") or {}).get("type")
            nm = (pt.get("name") or {}).get("value") or ""
            if t == "HomeTeam":
                home = nm
            elif t == "AwayTeam":
                away = nm
        if not home or not away:
            nm = (fx.get("name") or {}).get("value") or ""
            if " en casa de " in nm:                      # formato US: "Visitante en casa de Local"
                away, home = nm.split(" en casa de ", 1)
            elif " - " in nm:
                home, away = nm.split(" - ", 1)
        return re.sub(r"\s*\([A-Z]{3}\)$", "", home), re.sub(r"\s*\([A-Z]{3}\)$", "", away)

    def _comp_of(self, fx: dict) -> tuple[str, str] | None:
        c = fx.get("competition") or {}
        g = self.comps.get(int(c.get("id") or 0))
        if g:
            return g
        sport = self.cfg["sports"].get(str((fx.get("sport") or {}).get("id")))
        if not sport:
            return None
        label = f"{((fx.get('region') or {}).get('name') or {}).get('value', '')} - {(c.get('name') or {}).get('value', '')}".strip(" -")
        comp = self.catalog.match(self.bk, sport, label)
        if comp:
            self.comps[int(c.get("id") or 0)] = (sport, comp)
            return sport, comp
        return None

    def _row(self, fx: dict, sport: str, comp: str, live: bool) -> dict:
        home, away = self._names(fx)
        dt = None
        try:
            dt = datetime.fromisoformat(fx["startDate"].replace("Z", "+00:00")).astimezone()
        except Exception:  # noqa: BLE001
            pass
        slug = re.sub(r"[^a-z0-9]+", "-", _fold((fx.get("name") or {}).get("value") or "")).strip("-")
        row = {"event_id": str(fx["id"]), "home": home, "away": away, "competition": comp,
               "date": dt.strftime("%Y-%m-%d") if dt else None, "start_time": dt.strftime("%H:%M") if dt else None,
               "url": self.cfg["event_url"].format(slug=slug, id=fx["id"]),
               "selections": fixture_selections(fx, sport, home, away)}
        for sl in row["selections"]:
            if sl.get("url", "").startswith("?"):
                sl["url"] = row["url"] + sl["url"]
        if live:
            sb = _scoreboard(fx.get("scoreboard"))
            if sb.get("score") and " en casa de " in ((fx.get("name") or {}).get("value") or ""):
                # fixtures "A en casa de B": el marcador viene visitante:local -> lo damos como local:visitante
                sb["score"] = " ".join(":".join(reversed(p.split(":"))) if ":" in p else p for p in sb["score"].split())
            row.update(sb)
        return row

    def live_fixtures(self) -> list[tuple[dict, str, str]]:
        js = self.get("bettingoffer/fixtures", fixtureTypes="Standard,PairGame", state="Live", offerMapping="Filtered",
                      offerCategories="Gridable", sportIds=",".join(self.cfg["sports"]), skip=0,
                      take=self.cfg.get("live_take", 200), sortBy="Tags", scoreboardMode="Full")
        out = []
        for fx in js.get("fixtures") or []:
            if fx.get("fixtureType") == "Tournament" or len(fx.get("participants") or []) < 2:
                continue
            g = self._comp_of(fx)
            if g:
                out.append((fx, g[0], g[1]))
        return out

    def prematch_fixtures(self) -> list[tuple[dict, str, str]]:
        horizon = datetime.now(timezone.utc) + timedelta(hours=self.cfg.get("prematch_hours", 48))
        by_sport: dict[str, list[str]] = {}
        for cid, (sport, _) in self.comps.items():
            by_sport.setdefault(sport, []).append(str(cid))
        urls = []
        n = self.cfg.get("competitions_per_call", 12)
        for sport, ids in by_sport.items():
            for i in range(0, len(ids), n):
                urls.append(self.url("bettingoffer/fixtures", fixtureTypes="Standard,PairGame", state="Latest",
                                     offerMapping="Filtered", offerCategories="Gridable", competitionIds=",".join(ids[i:i + n]),
                                     skip=0, take=self.cfg.get("prematch_take", 100), sortBy="StartDate"))
        out = []
        for st, js in self.http.get_many(urls):
            if st != 200 or not isinstance(js, dict):
                continue
            for fx in js.get("fixtures") or []:
                if fx.get("stage") == "Live" or fx.get("fixtureType") == "Tournament" or len(fx.get("participants") or []) < 2:
                    continue
                try:
                    if datetime.fromisoformat(fx["startDate"].replace("Z", "+00:00")) > horizon:
                        continue
                except Exception:  # noqa: BLE001
                    pass
                g = self._comp_of(fx)
                if g:
                    out.append((fx, g[0], g[1]))
        return out

    def _demand(self, evs: list) -> list:
        if not self.cfg.get("demand_only", True):
            return evs
        out = self.demand.filter(evs, lambda it: (it[1], *self._names(it[0])))
        self._skipped = len(evs) - len(out)
        return out

    def details(self, evs: list, kind: str) -> dict[str, list[dict]]:
        urls = [self.url("bettingoffer/fixture-view", fixtureIds=fx["id"], state="Latest", offerMapping="All",
                         scoreboardMode="Full", includePrecreatedBetBuilder="false", supportVirtual="false",
                         useRegionalisedConfiguration="true", includeRelatedFixtures="false", statisticsModes="None")
                for fx, *_ in evs]
        by_sport: dict[str, list[dict]] = {}
        for (fx, sport, comp), (st, js) in zip(evs, self.http.get_many(urls)):
            full = (js or {}).get("fixture") if st == 200 and isinstance(js, dict) else None
            if not full:
                full = fx                                  # sin detalle: al menos los mercados principales de la lista
            if not full.get("scoreboard") and fx.get("scoreboard"):
                full["scoreboard"] = fx["scoreboard"]
            by_sport.setdefault(sport, []).append(self._row(full, sport, comp, kind == "live"))
        return by_sport

    def _save(self, by_sport: dict[str, list[dict]], kind: str) -> tuple[int, int]:
        rows = changed = 0
        for sport, rs in by_sport.items():
            changed += self.store.save_rows(sport, kind, rs)
            rows += len(rs)
        return rows, changed

    # ── ciclos ──
    def live_cycle(self) -> tuple[int, int]:
        # timeout corto en directo: una API colgada no debe dejar la casa ciega 60-100 s (ver Http.timeout_scope)
        with self.http.timeout_scope(self.cfg.get("timeout_live", 8)):
            return self._live_cycle()

    def _live_cycle(self) -> tuple[int, int]:
        evs = self.live_fixtures()
        self.store.sweep({str(fx["id"]) for fx, *_ in evs}, "live")
        evs = self._demand(evs)
        n = self.cfg.get("max_detail_per_cycle", 30)
        if len(evs) > n:
            off = self._live_off % len(evs)
            evs = (evs + evs)[off: off + n]
            self._live_off = off + n
        return self._save(self.details(evs, "live"), "live")


    # ── pre-partido en segundo plano (pace.Background): el bucle live no espera por listas ni fichas pre-partido ──
    def _pm_inline(self, once: bool) -> bool:
        http = getattr(self, "http", None) or getattr(getattr(self, "api", None), "http", None)
        name = getattr(http, "name", None) or getattr(http, "mode", "") or ""
        return once or "browser" in str(name) or "chrome" in str(name)   # el navegador no se comparte entre hilos

    def _pm_schedule(self, t0: float, once: bool, msg: str) -> str:
        bg = self.__dict__.setdefault("_bg", __import__("pace").Background(f"{getattr(self, 'bk', 'prematch')}-prematch"))
        if not bg.busy():
            job = self._pm_job(t0, once)
            if job is not None:
                r = bg.run(job, inline=self._pm_inline(once))
                if r:
                    msg += " | " + r
        note = bg.note()
        if note:
            msg += " | " + note
        return msg

    def _pm_job(self, t0: float, once: bool):
        if not self._pm_queue and t0 - self._last_prematch >= self.cfg.get("interval_prematch", 30):
            def _list():
                evs = self.prematch_fixtures()
                out = ""
                if evs:
                    self.store.sweep({str(fx["id"]) for fx, *_ in evs}, "prematch")
                    by_sport: dict[str, list[dict]] = {}
                    for fx, sport, comp in evs:                      # mercados principales de la lista (baratos)
                        r = self._row(fx, sport, comp, False)
                        r["partial"] = True
                        by_sport.setdefault(sport, []).append(r)
                    prow, pchg = self._save(by_sport, "prematch")
                    out = f"prematch lista {prow} ev / {pchg} cambios"
                self._pm_queue = self._demand(evs)[: self.cfg.get("max_prematch_detail", 300)]
                self._last_prematch = time.time()
                if once and self._pm_queue:
                    out += " | " + self._pm_job(time.time(), once)()
                return out
            return _list
        if self._pm_queue:
            batch = len(self._pm_queue) if once else max(1, self.cfg.get("prematch_batch", 4))
            chunk, self._pm_queue = self._pm_queue[:batch], self._pm_queue[batch:]
            def _detail():
                prow, pchg = self._save(self.details(chunk, "prematch"), "prematch")
                return f"prematch detalle {prow} ev / {pchg} cambios ({len(self._pm_queue)} pendientes)"
            return _detail
        return None

    def run(self, once: bool = False):
        backoff = 2
        while True:
            t0 = time.time()
            try:
                self._reload_if_changed()
                self.refresh_comps()
                rows, changed = self.live_cycle()
                msg = f"live {rows} ev / {changed} cambios"
                if self._skipped:
                    msg += f" ({self._skipped} sin pareja en otras casas, no detallados)"
                msg = self._pm_schedule(t0, once, msg)
                self.store.set_status(bwin_last_ok=time.time(), bwin_live_events=rows, bwin_transport=self.http.name)
                log.info("%s [%s] (%.1fs)", msg, self.http.name, time.time() - t0)
                backoff = 2
                if once:
                    return
            except Exception as e:  # noqa: BLE001
                log.warning("error de ciclo: %s — reintento en %ss", e, backoff, exc_info=log.isEnabledFor(logging.DEBUG))
                self.store.set_status(bwin_last_error=f"{time.time():.0f} {e}")
                time.sleep(backoff)
                backoff = min(backoff * 2, 60)
                continue
            time.sleep(max(0.5, self.cfg.get("interval_live", 5) - (time.time() - t0)))


def list_catalog(c: Collector):
    for sid, sport in c.cfg["sports"].items():
        tags = c.get("bettingoffer/counts", state="Latest", tagTypes="Sport,Region,Competition", sortBy="Tags",
                     sportIds=sid, fixtureTypes="Standard,PairGame")
        regions = {t["tag"]["id"]: t["tag"]["name"]["value"] for t in tags if t["tag"].get("type") == "Region"}
        print(f"\n=== {sport}")
        for t in tags:
            tg = t["tag"]
            if tg.get("type") != "Competition":
                continue
            label = f"{regions.get(tg.get('parentId'), '')} - {tg['name']['value']}"
            comp = c.catalog.match(c.bk, sport, label)
            if comp or t.get("preMatch", 0) + t.get("live", 0) >= 6:
                print(f" {'✔' if comp else ' '} {label}   [{tg['id']}] pre={t.get('preMatch')} live={t.get('live')}" + (f"  -> {comp}" if comp else ""))


def dump(c: Collector, n: int = 2):
    """Vuelca fixture-view crudo + selecciones mapeadas de n partidos por deporte a snapshots/dump_bwin_*.json."""
    c.refresh_comps(True)
    evs = c.live_fixtures() + c.prematch_fixtures()
    pick, per = [], {}
    for fx, sport, comp in evs:
        if per.get(sport, 0) < n:
            per[sport] = per.get(sport, 0) + 1
            pick.append((fx, sport, comp))
    out = []
    for fx, sport, comp in pick:
        js = c.get("bettingoffer/fixture-view", fixtureIds=fx["id"], state="Latest", offerMapping="All", scoreboardMode="Full",
                   includePrecreatedBetBuilder="false", supportVirtual="false", useRegionalisedConfiguration="true",
                   includeRelatedFixtures="false", statisticsModes="None")
        full = js.get("fixture") or fx
        home, away = c._names(full)
        sels = fixture_selections(full, sport, home, away)
        out.append({"sport": sport, "competition": comp, "fixture_view": js, "parsed": sels})
        log.info("%s %s - %s: %d optionMarkets + %d games -> %d selecciones", sport, home, away,
                 len(full.get("optionMarkets") or []), len(full.get("games") or []), len(sels))
    p = Path(os.getenv("SNAP_DIR", Path(__file__).parent / "snapshots")) / f"dump_bwin_{int(time.time())}.json"
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")
    log.info("volcado -> %s", p)


def dump_links(c: "Collector"):
    """URLs candidatas de enlace directo a una selección (bwin), para probarlas en el navegador."""
    c.refresh_comps(force=True)
    evs = (c.live_fixtures() or []) + (c.prematch_fixtures() or [])
    print(f"{len(evs)} eventos candidatos")
    for fx, sport, comp in evs[:10]:
        try:
            js = c.get("bettingoffer/fixture-view", fixtureIds=fx["id"], state="Latest", offerMapping="All")
        except RuntimeError as e:
            print(f"  {fx['id']}: {e}")
            js = {}
        fxf = (js or {}).get("fixture") or fx
        found = None                               # (título, nombre selección, cuota, marketId, optionId)
        for m in fxf.get("optionMarkets") or []:
            o = next((o for o in m.get("options") or [] if (o.get("price") or {}).get("odds")), None)
            if o:
                found = ((m.get("name") or {}).get("value"), (o.get("name") or {}).get("value"), o["price"]["odds"], m.get("id"), o.get("id"))
                break
        if not found:
            for g in fxf.get("games") or []:
                r = next((r for r in g.get("results") or [] if r.get("odds")), None)
                if r:
                    found = ((g.get("name") or {}).get("value"), (r.get("name") or {}).get("value"), r["odds"], g.get("id"), r.get("id"))
                    break
        if not found:
            print(f"  {(fx.get('name') or {}).get('value')}: {len(fxf.get('optionMarkets') or [])} optionMarkets, "
                  f"{len(fxf.get('games') or [])} games, sin cuotas")
            continue
        title, oname, odds, mid, oid = found
        fid = fx["id"]
        slug = re.sub(r"[^a-z0-9]+", "-", _fold((fx.get("name") or {}).get("value") or "")).strip("-")
        base = c.cfg["event_url"].format(slug=slug, id=fid)
        print(f"\nPartido: {(fx.get('name') or {}).get('value')}  fixtureId={fid}")
        print(f"Apuesta: {title!r} -> selección {oname!r} @{odds}  marketId={mid} optionId={oid}\n")
        print("Abre cada URL en incógnito y dime cuál deja la selección ya marcada en la cesta:")
        for i, u in enumerate([
            f"{base}?options={fid}-{mid}-{oid}",
            f"{base}?options={mid}-{oid}",
            f"{base}?options={oid}",
            f"{base}?market={mid}&option={oid}",
            f"{base}?betslip={fid}-{mid}-{oid}",
            f"https://www.bwin.es/es/sports?options={fid}-{mid}-{oid}",
            f"https://www.bwin.es/es/sports/betslip?options={fid}-{mid}-{oid}",
            f"{base}?optionIds={oid}",
        ], 1):
            print(f"  {i}. {u}")
        return
    print("sin selecciones")


def main():
    logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"),
                        format="%(asctime)s %(levelname)s %(name)s: %(message)s", datefmt="%H:%M:%S")
    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    c = Collector(load_cfg())
    if "--list" in sys.argv:
        list_catalog(c)
    elif "--dump" in sys.argv:
        dump(c)
    elif "--links" in sys.argv:
        dump_links(c)
    else:
        c.run(once="--once" in sys.argv)
    c.http.close()


if __name__ == "__main__":
    main()
