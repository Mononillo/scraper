"""
pokerstars.py — colector de cuotas de PokerStars Sports España (www.pokerstars.es), plataforma Sisal (desde 11-2025).

API JSON pública (GET, sin cookies ni captcha; solo Origin/Referer) en `betting.pokerstars.es/api/lettura-palinsesto-sport/`:
    palinsesto/live/alberatura                                  -> árbol de TODO el directo (62 KB): países, competiciones
                                                                   (`codiceManifestazione`) y eventos en juego
    palinsesto/live/v1/eventDetail/1-<id>                       -> un evento en directo con todos sus mercados (~45 KB)
    palinsesto/prematch/v1/schedaManifestazione/0/<sport>-<manif> -> eventos de una competición (pre-partido) + principales
    palinsesto/prematch/v1/eventDetail/1-<id>                   -> todos los mercados de un evento pre-partido (NBA ~2 MB)
    shortcuts, shortcuts/<sport>, prematch/hot-bets/<sport>     -> accesos directos: de ahí se sacan códigos de competición
No se ha visto ningún endpoint con el árbol pre-partido completo: el catálogo se construye con las fuentes de arriba
(+ `catalog_paths` candidatos y `extra_competitions` fijos en pokerstars.json).  `--probe` enseña qué responde.

Modelo: `scommessaMap` (familia de mercado, texto con comodines "CUARTO Z - EQUIPO Y - TOTAL …") +
`infoAggiuntivaMap` (mercado concreto: `descrizione`, `soglia` línea, `teamIds`, `esitoList[{descrizione, quota×100, stato}]`).
El tipo se deduce de las etiquetas de los resultados (MÁS DE/MENOS DE, 1/2, 1/X/2, SÍ/NO, 1X/X2/12) y la métrica/periodo
con markets.classify() sobre el texto.  Hándicap principal: `soglia` se aplica al equipo 2 (comprobado con las cuotas:
"(-10.5)" 1@1.20 con partido igualado); se verifica la tendencia de precios por evento y se descartan los de periodo.

Geobloqueada fuera de España (desde el sandbox HTTP 0).  Uso:
    python pokerstars.py            (bucle)    --once    --list    --probe    --dump <eventId> [--live]    --raw <ruta>
"""
from __future__ import annotations

import fastjson as json
import logging
import os
import re
import sys
import time
import unicodedata
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone
from pathlib import Path

import requests

from competitions import Competitions
from markets import _fold, classify, demote_plain_ot
from storage import OddsStore
import pace

log = logging.getLogger("pokerstars")
CFG_PATH = Path(os.getenv("POKERSTARS_CFG", Path(__file__).parent / "pokerstars.json"))

_OVER = {"más de", "mas de", "over", "più"}
_UNDER = {"menos de", "under", "meno"}
_YES = {"sí", "si", "yes"}
_NO = {"no"}
# familias/mercados que nunca se guardan (combinadas, exactos, par/impar, carreras, márgenes, "al menos", dobles…)
_SKIP_RX = re.compile(r"par/impar|impar/par|carrera a|margen de|descanso/final|doble doble|triple doble|al menos|consigue|"
                      r"\+ ?(under|over|m[áa]s de|menos de)|exactamente|primer equipo|1\.er equipo|lidera|anota (el|un) gol|"
                      r"3 opciones\) h[áa]ndicap|h[áa]ndicap: comienza|pr[óo]ximo|siguiente|intervalo|minuto|"
                      r"\bgol \d|marcador|resultado exacto|n[úu]mero de goles|ganador del set y|set y partido|"
                      r"tie ?break|\bpuntos? del (juego|set)\b|\bjuego \d|gana el (set|juego)|\bbreaks?\b|\bsaque|"
                      r"cometidas y recibidas|entre cometidas|puntos por tarjetas|\bpalos?\b|larguero|\bposte\b|\bmax\.? \d", re.I)
_PERIOD_IN_TEXT = re.compile(r"\b(cuarto|mitad|set|periodo) ?[1-5]\b|\b[1-5]\.[ao] (mitad|cuarto|set|parte|tiempo)\b|"
                             r"\bpr[óo]rroga\b|descanso", re.I)
_PLACEHOLDER = re.compile(r"\b(CUARTO|PERIODO|MITAD|JUGADOR|EQUIPO|SET|PARTE)\s+[XYZ]\b|\b[XYZ]\.[ao]\s+(MITAD|CUARTO|SET|PARTE)\b|"
                          r"\bM[ÁA]S/MENOS DE [XYZ]\b|\b[XYZ]\b(?= PUNTOS| ASISTENCIAS| REBOTES| GOLES)")


def _slug(s: str) -> str:
    s = unicodedata.normalize("NFKD", s or "").encode("ascii", "ignore").decode().lower()
    s = re.sub(r"[^a-z0-9]+", "-", s).strip("-")
    return s


def _player_name(raw: str) -> str:
    """'Bridges, Miles' -> 'Miles Bridges'; 'CARTER Jr. Wendell' -> 'Wendell Carter Jr.'; 'Devin Booker' igual."""
    raw = re.sub(r"\s+", " ", raw or "").strip()
    if "," in raw:
        a, _, b = raw.partition(",")
        return f"{b.strip()} {a.strip()}".strip()
    toks = raw.split()
    suf = [t for t in toks if re.fullmatch(r"(Jr|Sr)\.?|I{2,3}|IV", t)]
    toks = [t for t in toks if t not in suf]
    caps = [t for t in toks if t.isupper() and len(t) > 1]
    if caps and toks and toks[0].isupper():
        rest = [t for t in toks if t not in caps]
        sur = " ".join(t.title() for t in caps)
        return " ".join([*rest, sur, *suf]).strip()
    return " ".join([*toks, *suf]).strip()


def _half(v) -> bool:
    try:
        return abs(float(v) * 2 - round(float(v) * 2)) < 1e-6
    except (TypeError, ValueError):
        return False


def _num(s) -> float | None:
    try:
        return float(str(s).replace(",", "."))
    except (TypeError, ValueError):
        return None


def _cleanup_title(fam: str, ia: str) -> tuple[str, str | None, str | None]:
    """Compone el título para markets.classify a partir de la familia (con comodines) y el mercado concreto.
    Devuelve (título, jugador, lado) con lado ∈ {'1','2',None} cuando el texto dice EQUIPO 1/2."""
    fam = fam or ""
    ia = ia or ""
    # abreviaturas de Sisal: "MIT 1: MÁS/MENOS DE 0.5 EQ 2" -> "MITAD 1 … EQUIPO 2"
    ia = re.sub(r"\bMIT\.? ?(\d)\b", r"MITAD \1", ia)
    ia = re.sub(r"\bEQ\.? ?([12])\b", r"EQUIPO \1", ia)
    ia = re.sub(r"\bCUA\.? ?(\d)\b", r"CUARTO \1", ia)
    player = None
    side = None
    if re.search(r"\bJUGADOR\b", fam) or re.search(r"\bJUGADOR\b", ia):
        parts = re.split(r"\s+-\s+", ia.strip(), maxsplit=1)      # el nombre puede llevar guion (Calvert-Lewin, Miller-McIntyre)
        if len(parts) == 2 and 3 <= len(parts[0]) <= 60 and not re.match(r"^(CUARTO|MITAD|SET|PERIODO|TOTAL|M[ÁA]S|MENOS|ENFRENTAMIENTO)\b", parts[0], re.I):
            player = _player_name(parts[0])
            ia = parts[1]
        else:
            return "", None, None          # familia de jugador sin jugador identificable: fuera
    m = re.search(r"\bEQUIPO ([12AB])\b|\b(LOCAL|VISITANTE)\b", ia)
    if m:
        tok = (m.group(1) or m.group(2)).upper()
        side = "1" if tok in ("1", "A", "LOCAL") else "2"
        ia = re.sub(r"[-:]?\s*\bEQUIPO [12AB]\b|\b(LOCAL|VISITANTE)\b", " ", ia)
    fam_c = _PLACEHOLDER.sub(" ", fam)
    fam_c = re.sub(r"\(\d+ OPCIONES\)|\(SIN MARGEN\)|\(SIN H[ÁA]NDICAP\)|\bSIN H[ÁA]NDICAP\b|\bSIN MARGEN\b|\(EXCL\. ABANDONOS\)|\(INCL\. ABANDONOS\)", " ", fam_c)
    if side:
        fam_c = re.sub(r"\b(TOTAL )?(DEL |DE LA |DE )?EQUIPOS?\b", " ", fam_c)
    # si el concreto ya trae el periodo, la familia no debe aportar palabras de periodo (sin número -> classify devuelve None)
    if _PERIOD_IN_TEXT.search(ia):
        fam_c = re.sub(r"\b\d\.[ao]\s+(MITAD|CUARTO|SET|PARTE)\b|\b(CUARTO|MITAD|PERIODO|PARTE|TIEMPO|SET)S?\s*\d?\b", " ", fam_c, flags=re.I)
    # línea: fuera del título (classify no la necesita y "MÁS/MENOS DE 2.5" no molesta, pero "6 PUNTOS" sí podría)
    ia_c = re.sub(r"M[ÁA]S/MENOS DE\s*-?\d+(?:[.,]\d+)?", "MÁS/MENOS DE", ia)
    ia_c = re.sub(r"\(\s*-?\d+(?:[.,]\d+)?\s*\)|H[ÁA]NDICAP\s+-?\d+(?:[.,]\d+)?", "HÁNDICAP", ia_c)
    ia_c = re.sub(r"\(\d+ OPCIONES\)|\(SIN MARGEN\)|\(SIN H[ÁA]NDICAP\)|\bSIN H[ÁA]NDICAP\b|\bSIN MARGEN\b|\(EXCL\. ABANDONOS\)|\(INCL\. ABANDONOS\)", " ", ia_c)
    # "CUARTO 1:" / "MITAD 1:" / "1.a MITAD" -> formas que entiende classify
    txt = f"{ia_c} - {fam_c}"
    txt = re.sub(r"\b(\d)\.a\s+(MITAD|PARTE)", r"\1a \2", txt)
    txt = re.sub(r"\b(\d)\.(?:o|er)\s+(CUARTO|SET)", r"\2 \1", txt)
    txt = txt.replace("+", " + ")
    txt = re.sub(r"\s+", " ", txt).strip(" -:").lower()     # en minúsculas: markets.classify toma MAYÚSCULAS por siglas de equipo
    return txt, player, side


def market_selections(fam: str, ia: dict, sport: str, home: str, away: str) -> list[dict]:
    if ia.get("stato") not in (None, 1):
        return []
    desc = (ia.get("descrizione") or "").strip()
    esiti = [e for e in ia.get("esitoList") or [] if e.get("stato", 1) == 1 and (e.get("quota") or 0) > 100]
    if not esiti:
        return []
    joined = f"{fam} | {desc}"
    if _SKIP_RX.search(_fold(joined)):
        return []
    labels = [_fold(e.get("descrizione") or "") for e in esiti]
    lset = {_fold(e.get("descrizione") or "") for e in ia.get("esitoList") or []}     # TODAS las opciones (también cerradas)
    if re.search(r"\d+ opciones", _fold(joined)) and lset != {"1", "x", "2"}:
        return []                      # "Más/menos de 6 (3 opciones)" con EXACTAMENTE: no es un más/menos normal
    title, player, side = _cleanup_title(fam, desc)
    if not title:
        return []
    soglia = _num(ia.get("soglia"))
    if soglia is None:
        m = re.search(r"m[áa]s/menos de\s*(-?\d+(?:[.,]\d+)?)|\((-?\d+(?:[.,]\d+)?)\)|h[áa]ndicap\s+(-?\d+(?:[.,]\d+)?)", desc, re.I)
        if m:
            soglia = _num(m.group(1) or m.group(2) or m.group(3))
    tids = ia.get("teamIds") or []
    if side is None and len(tids) == 1 and str(tids[0]) in ("1", "2"):
        side = str(tids[0])
    out: list[dict] = []

    if lset <= (_OVER | _UNDER):
        # (una sola pata abierta también vale: PokerStars suele cerrar el "MENOS DE" de las líneas alternativas)
        if soglia is None or not _half(soglia):
            return []
        info = classify(title, sport, home, away, kind="total", player=player)
        if not info:
            return []
        market = info.market
        if side and not market.startswith("PLAYER_") and "_HOME" not in market and "_AWAY" not in market:
            per = ""
            m = re.match(r"^(.*?)(_(1H|2H|Q[1-4]|SET[1-5]|OT|REG))?$", market)
            base, per = m.group(1), m.group(2) or ""
            market = f"{base}_{'HOME' if side == '1' else 'AWAY'}{per}"
        for e, lab in zip(esiti, labels):
            sel = "Over" if lab in _OVER else "Under"
            out.append({"market": market, "selection": sel, "line": soglia, "player": info.player, "price": e["quota"] / 100, "ot": info.ot})
        return _dedup(out)

    if len(esiti) < 2:
        return []
    if re.search(r"h[áa]ndicap", title):
        if lset != {"1", "2"} or soglia is None or not _half(soglia) or side:
            return []
        if _PERIOD_IN_TEXT.search(desc) or _PERIOD_IN_TEXT.search(fam) or re.search(r"\b(CUARTO|MITAD|SET|PERIODO)\b", fam):
            return []                      # hándicaps de periodo: convención de signo no verificada
        info = classify(title, sport, home, away, kind="handicap")
        if not info or info.period:
            return []
        for e, lab in zip(esiti, labels):
            ln = -soglia if lab == "1" else soglia      # soglia se aplica al equipo 2 (ver cabecera); _fix_hcp_sign lo verifica
            out.append({"market": info.market, "selection": lab, "line": ln, "player": None, "price": e["quota"] / 100, "ot": info.ot, "_soglia": soglia})
        return _dedup(out)

    if lset in ({"1", "x", "2"}, {"1", "2"}):
        if side or player:
            return []
        if "x" in lset and sport != "futbol":
            return []                  # baloncesto/tenis a 3 vías (empate al final del tiempo reglamentario): no comparable
        info = classify(title, sport, home, away, kind="result")
        if not info:
            return []
        if lset == {"1", "2"} and sport == "futbol" and not re.search(r"sin empate|dnb|draw no bet|empate no", _fold(title)):
            return []                      # fútbol a 2 vías sin decir DNB: no sabemos qué pasa con el empate
        for e, lab in zip(esiti, labels):
            out.append({"market": info.market, "selection": lab.upper(), "line": None, "player": None, "price": e["quota"] / 100, "ot": info.ot})
        return _dedup(out)

    if lset == {"1x", "x2", "12"}:
        info = classify(title, sport, home, away, kind="dc")
        if not info:
            return []
        for e, lab in zip(esiti, labels):
            out.append({"market": info.market, "selection": lab.upper(), "line": None, "player": None, "price": e["quota"] / 100, "ot": info.ot})
        return _dedup(out)

    if lset <= (_YES | _NO) and lset & _YES and lset & _NO:
        if player or side:
            return []
        if not re.search(r"ambos (equipos )?(marcan|anotan)|both teams", _fold(title)):
            return []
        info = classify(title, sport, home, away, kind="btts")
        if not info:
            return []
        for e, lab in zip(esiti, labels):
            out.append({"market": info.market, "selection": "Yes" if lab in _YES else "No", "line": None, "player": None, "price": e["quota"] / 100, "ot": info.ot})
        return _dedup(out)
    return []


def _dedup(out: list[dict]) -> list[dict]:
    keys = [(o["market"], o["selection"], o["line"], o.get("player")) for o in out]
    return out if len(keys) == len(set(keys)) else []


def _fix_hcp_sign(sels: list[dict]) -> None:
    """Con ≥3 líneas de hándicap del mismo mercado, la cuota del '1' debe BAJAR cuando su línea sube (más ventaja).
    Si la tendencia observada es la contraria, la convención de signo de esta casa/deporte es la otra: se invierte."""
    by: dict[str, list[dict]] = {}
    for s in sels:
        if "_soglia" in s and s["selection"] == "1":
            by.setdefault(s["market"], []).append(s)
    flip: set[str] = set()
    for mk, rows in by.items():
        if len(rows) < 3:
            continue
        rows.sort(key=lambda r: r["line"])
        up = sum(1 for a, b in zip(rows, rows[1:]) if b["price"] > a["price"])
        down = sum(1 for a, b in zip(rows, rows[1:]) if b["price"] < a["price"])
        if up > down:
            flip.add(mk)
    for s in sels:
        if "_soglia" in s:
            if s["market"] in flip:
                s["line"] = -s["line"]
            del s["_soglia"]


# ──────────────────────────────────────────────────────────────────────────────
class Collector:
    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.bk = cfg["bookmaker"]
        self.api = cfg["api"].rstrip("/")
        hdrs = {"Origin": cfg["origin"], "Referer": cfg["origin"] + "/apuestas-deportivas/", **(cfg.get("headers") or {})}
        # La API responde al navegador pero deja colgadas (read timeout) las peticiones con huella TLS de `requests`:
        # curl_cffi es una librería HTTP normal que imita la huella de Chrome (sin abrir navegador), como en Interwetten.
        self._hdrs = hdrs
        self._h1 = False              # tras varios "HTTP/2 stream reset" seguidos se pasa a HTTP/1.1
        self._resets = 0
        self._new_session()
        self.catalog = Competitions()
        self.store = OddsStore(bookmaker=self.bk)
        self.sports = {int(k): v for k, v in cfg["sports"].items()}
        self.leagues: dict[str, tuple[str, str, str]] = {}      # "sport-manif" -> (deporte, competición canónica, etiqueta)
        self._all: dict[str, tuple[str, str]] = {}               # "sport-manif" -> (deporte, etiqueta)  (todo lo visto)
        self._menu_at = 0.0
        self._last_prematch = 0.0
        self._pm_queue: list = []
        self._pm_present: set[str] = set()
        self._pm_rows = self._pm_changed = 0
        self._cfg_mtime = CFG_PATH.stat().st_mtime
        self._bg = pace.Background(f"{self.bk}-prematch")
        self._last_req = 0.0
        self._live_rr = 0
        self._found_paths: list[str] = []
        self.transport = self.http_lib

    # ── HTTP ──
    def _new_session(self):
        hdrs = dict(self._hdrs)
        try:
            from curl_cffi import requests as _cffi
            kw = {"impersonate": self.cfg.get("impersonate", "chrome")}
            if self._h1:
                from curl_cffi import CurlHttpVersion
                kw["http_version"] = CurlHttpVersion.V1_1
            self.sess = _cffi.Session(**kw)
            hdrs.pop("User-Agent", None)              # la UA la pone curl_cffi coherente con la huella TLS
            self.http_lib = "curl_cffi"
        except ImportError:
            self.sess = requests.Session()
            self.http_lib = "requests"
            log.warning("curl_cffi no instalado (pip install curl_cffi): la API de PokerStars suele no contestar al HTTP normal")
        self.sess.headers.update(hdrs)

    def get(self, path: str, **params):
        gap = self.cfg.get("request_gap", 0.1) - (time.time() - self._last_req)
        if gap > 0:
            time.sleep(gap)
        params.setdefault("offerId", 0)
        url = f"{self.api}/{path.lstrip('/')}"
        timeout = self.cfg.get("timeout", 15)
        try:
            r = self.sess.get(url, params=params, timeout=timeout, allow_redirects=False)
            self._resets = 0
        except Exception as e:  # noqa: BLE001  (curl 92 "HTTP/2 stream reset", conexión cerrada, etc.)
            self._last_req = time.time()
            msg = str(e)
            if "stream" in msg or "HTTP/2" in msg or "reset" in msg.lower() or "Connection" in msg:
                self._resets += 1
                if self._resets >= 3 and not self._h1:
                    self._h1 = True
                    log.warning("HTTP/2 reseteado %d veces seguidas: paso a HTTP/1.1", self._resets)
                self._new_session()                   # conexión nueva y un único reintento
                time.sleep(0.5)
                r = self.sess.get(url, params=params, timeout=timeout, allow_redirects=False)
            else:
                raise
        self._last_req = time.time()
        if r.status_code in (301, 302, 303, 307, 308):
            raise RuntimeError(f"{path} -> redirección a {r.headers.get('Location')} (¿IP no española?)")
        if r.status_code in (403, 429):
            raise RuntimeError(f"{path} -> HTTP {r.status_code} (bloqueo/ritmo): pausa")
        if r.status_code != 200:
            raise RuntimeError(f"{path} -> HTTP {r.status_code}")
        return json.loads(r.content)

    def _reload_if_changed(self):
        mt = CFG_PATH.stat().st_mtime
        if mt != self._cfg_mtime:
            self._cfg_mtime = mt
            self.cfg = pace.apply(json.loads(CFG_PATH.read_text(encoding="utf-8")))
            log.info("pokerstars.json recargado")
        self.catalog.reload()

    # ── catálogo ──
    @staticmethod
    def _walk_manifs(obj, out: dict[str, str], sport_hint: int | None = None):
        """Recorre cualquier JSON recogiendo objetos con codiceManifestazione/key + descripción -> {"sport-manif": label}."""
        if isinstance(obj, dict):
            d = obj.get("descrizioneManifestazione") or obj.get("descrizione") or obj.get("description") or obj.get("label")
            sp = obj.get("codiceDisciplina") or obj.get("sportId") or sport_hint
            code = obj.get("codiceManifestazione")
            key = obj.get("key") if isinstance(obj.get("key"), str) else None
            if isinstance(d, str):
                d = re.sub(r"\s+", " ", d.replace("\xa0", " ")).strip()
            if code is not None and d and sp and not obj.get("codiceAvvenimento") and not obj.get("firstCompetitor"):
                out.setdefault(f"{int(sp)}-{int(code)}", str(d))
            elif key and re.fullmatch(r"\d+-\d+", key) and d and "codiceAvvenimento" not in obj and not obj.get("firstCompetitor") \
                    and ("manifestazione" in json.dumps(list(obj.keys())).lower() or "sigla" in obj or obj.get("codiceManifestazione") is not None):
                out.setdefault(key, str(d))
            hint = obj.get("codiceDisciplina") or obj.get("sportId") or sport_hint
            for k, v in obj.items():
                if isinstance(v, (dict, list)):
                    if k in ("manifestazioneMap",) and isinstance(v, dict):
                        for mk, mv in v.items():
                            if isinstance(mv, dict) and re.fullmatch(r"\d+-\d+", str(mk)) and (mv.get("descrizione") or mv.get("description")):
                                out.setdefault(str(mk), str(mv.get("descrizione") or mv.get("description")))
                    if k == "classificationMap" and isinstance(v, dict):
                        for cv in v.values():
                            if isinstance(cv, dict):
                                csp = cv.get("sportId") or cv.get("codiceDisciplina")
                                country = cv.get("description") or cv.get("descrizione") or ""
                                for mk in cv.get("manifestazioneKeyDataList") or []:
                                    if isinstance(mk, dict) and mk.get("descrizione") and (mk.get("codiceManifestazione") is not None or mk.get("key")):
                                        kk = mk.get("key") if isinstance(mk.get("key"), str) and re.fullmatch(r"\d+-\d+", mk["key"]) else f"{csp}-{mk.get('codiceManifestazione')}"
                                        d0 = re.sub(r"\s+", " ", mk["descrizione"].replace("\xa0", " "))
                                        same = re.sub(r"[^a-z0-9]", "", _fold(d0)).startswith(re.sub(r"[^a-z0-9]", "", _fold(country)))
                                        lab = d0 if (same or not country) else f"{country.title()} - {d0}"
                                        out[kk] = lab
                        continue
                    Collector._walk_manifs(v, out, hint)
        elif isinstance(obj, list):
            for v in obj:
                Collector._walk_manifs(v, out, sport_hint)

    def _catalog_sources(self, probe: bool = False) -> dict[str, str]:
        found: dict[str, str] = {}
        paths = ["shortcuts"] + [f"shortcuts/{s}" for s in self.sports] + [f"palinsesto/prematch/hot-bets/{s}" for s in self.sports] \
                + [f"palinsesto/prematch/top-match/{s}" for s in self.sports] + ["palinsesto/live/alberatura"]
        for p in list(self.cfg.get("catalog_paths") or []):
            for s in self.sports:
                paths.append(p.replace("{sport}", str(s)))
        seen = set()
        for p in paths:
            if p in seen:
                continue
            seen.add(p)
            try:
                data = self.get(p)
                before = len(found)
                self._walk_manifs(data, found)
                n = len(found) - before
                if n and p not in self._found_paths:
                    self._found_paths.append(p)
                if probe:
                    print(f" 200 {p}  (+{n} competiciones)")
            except Exception as e:  # noqa: BLE001
                if probe:
                    print(f" --- {p}: {e}")
                elif "bloqueo" in str(e):
                    raise
        for k, v in (self.cfg.get("extra_competitions") or {}).items():
            found.setdefault(str(k), str(v))
        return found

    def refresh_menu(self, force: bool = False):
        if not force and time.time() - self._menu_at < self.cfg.get("menu_ttl", 900):
            return
        try:
            found = self._catalog_sources()
        except Exception as e:  # noqa: BLE001
            log.warning("catálogo: %s", e)
            self._menu_at = time.time()
            return
        leagues: dict[str, tuple[str, str, str]] = {}
        allt: dict[str, tuple[str, str]] = {}
        for key, label in found.items():
            sid = int(key.split("-")[0])
            sport = self.sports.get(sid)
            if not sport:
                continue
            allt[key] = (sport, label)
            comp = self.catalog.match(self.bk, sport, label)
            if comp:
                leagues[key] = (sport, comp, label)
        if leagues or force:
            self.leagues = leagues
            self._all = allt
        self._menu_at = time.time()
        log.info("%d competiciones mapeadas en PokerStars (%d vistas)", len(self.leagues), len(self._all))

    # ── eventos ──
    @staticmethod
    def _state(ev: dict, sport: str) -> tuple[str | None, str | None, str | None]:
        ls = ev.get("livescore") or {}
        scores = ls.get("scoreList") or []
        score = None
        if sport == "tenis":
            sets = [s for s in scores if str(s.get("type", "")).startswith("Period") and s.get("type") != "PeriodGame"]
            sets.sort(key=lambda s: str(s.get("type")))
            score = " ".join(f"{s.get('team1', 0)}:{s.get('team2', 0)}" for s in sets) or None
        else:
            cur = next((s for s in scores if s.get("type") == "Current"), None)
            if cur:
                score = f"{cur.get('team1', 0)}:{cur.get('team2', 0)}"
        period = ls.get("statusDescription") or None
        if period and period.lower() in ("iniziata", "in corso", "started"):
            period = "En juego"
        if sport == "tenis" and scores:
            n = len([s for s in scores if str(s.get("type", "")).startswith("Period") and s.get("type") != "PeriodGame"])
            if n:
                period = f"Set {n}"
        timer = None
        pt = ls.get("playTimeMs")
        if ls.get("showTimer") and pt and not ls.get("stopTimer"):
            try:
                secs = max(0, int(time.time() - pt / 1000) + int((ls.get("addPlayTimeMs") or 0) / 1000))
                timer = f"{secs // 60}:{secs % 60:02d}"
            except Exception:  # noqa: BLE001
                pass
        return score, period, timer

    def _event_url(self, sport: str, label: str, home: str, away: str, live: bool) -> str:
        tpl = self.cfg.get("event_url_live" if live else "event_url", "")
        sport_slug = (self.cfg.get("sport_slugs") or {}).get(sport, sport)
        # La etiqueta de la API puede llevar país ("EE. UU. - NBA", "España - La Liga"); en la URL real sólo va la
        # competición (comprobado 2026-11-15: …/eventos-deportivos/baloncesto/nba/boston-celtics-dallas-mavericks).
        comp_label = label.rsplit(" - ", 1)[-1] if " - " in label else label
        return tpl.format(sport=sport_slug, comp=_slug(comp_label), event=_slug(f"{home} {away}"))

    def _row(self, ev: dict, detail: dict, kind: str) -> tuple[str, dict] | None:
        key = f"{ev.get('codiceDisciplina')}-{ev.get('codiceManifestazione')}"
        lg = self.leagues.get(key)
        if not lg:
            return None
        sport, comp, label = lg
        home = ((ev.get("firstCompetitor") or {}).get("description") or "").strip()
        away = ((ev.get("secondCompetitor") or {}).get("description") or "").strip()
        if not home or not away:
            d = ev.get("descrizione") or ""
            if " - " not in d:
                return None
            home, away = [x.strip() for x in d.split(" - ", 1)]
        dt = None
        try:
            dt = datetime.fromisoformat(ev["data"].replace("Z", "+00:00")).astimezone()
        except Exception:  # noqa: BLE001
            pass
        if kind != "live" and dt and dt - datetime.now(dt.tzinfo) > timedelta(hours=self.cfg.get("prematch_hours", 48)):
            return None
        sc_map = detail.get("scommessaMap") or {}
        sels: list[dict] = []
        for k, ia in (detail.get("infoAggiuntivaMap") or {}).items():
            parts = str(k).split("-")
            if len(parts) < 3 or parts[1] != str(ev.get("codiceAvvenimento")):
                continue
            fam = (sc_map.get("-".join(parts[:3])) or {}).get("descrizione") or ""
            got = market_selections(fam, ia, sport, home, away)
            for s_ in got:
                s_["_src"] = f"{fam} | {ia.get('descrizione')}"
            sels.extend(got)
        sels = self._drop_collisions(sels, f"{home} - {away}")
        _fix_hcp_sign(sels)
        if sport == "baloncesto":
            demote_plain_ot(sels)
        for s in sels:
            s.pop("ot", None)
            s.pop("_src", None)
        if not sels:
            return None
        row = {"event_id": str(ev.get("codiceAvvenimento") or ev.get("eventId")), "home": home, "away": away, "competition": comp,
               "date": dt.strftime("%Y-%m-%d") if dt else None, "start_time": dt.strftime("%H:%M") if dt else None,
               "url": self._event_url(sport, label, home, away, kind == "live"), "selections": sels}
        if kind == "live":
            score, period, timer = self._state(ev, sport)
            row.update(score=score, period=period, timer=timer)
        return sport, row

    _collision_log: set = set()

    def _drop_collisions(self, sels: list[dict], ev_label: str) -> list[dict]:
        """Misma clave (mercado, lado, línea, jugador) desde DOS mercados distintos de la casa con distinta cuota = algo
        que el mapeo no distingue (periodo, variante…). Se descartan ambos y se registra el par de textos para corregirlo."""
        first: dict[tuple, dict] = {}
        bad: set[tuple] = set()
        for s_ in sels:
            k = (s_["market"], s_["selection"], s_.get("line"), s_.get("player"))
            o = first.get(k)
            if o is None:
                first[k] = s_
            elif o.get("_src") != s_.get("_src") and o["price"] != s_["price"]:
                bad.add(k)
                fams = (o.get("_src", "").split(" | ")[0], s_.get("_src", "").split(" | ")[0])
                if fams not in self._collision_log and len(self._collision_log) < 40:
                    self._collision_log.add(fams)
                    log.warning("colisión de mapeo (%s): %s %s ← [%s] @%s  vs  [%s] @%s", ev_label, k[0], k[3] or "", o.get("_src"), o["price"], s_.get("_src"), s_["price"])
        if not bad:
            return sels
        return [s_ for s_ in sels if (s_["market"], s_["selection"], s_.get("line"), s_.get("player")) not in bad]

    @staticmethod
    def _events_in(data) -> list[dict]:
        """Lista de avvenimenti de una respuesta (alberatura, schedaManifestazione, live-ora…)."""
        out: list[dict] = []

        def walk(o):
            if isinstance(o, dict):
                if o.get("codiceAvvenimento") is not None and o.get("codiceManifestazione") is not None and "codiceScommessa" not in o \
                        and (o.get("data") or o.get("firstCompetitor") or o.get("eventId") is not None):
                    out.append(o)
                    return
                for v in o.values():
                    if isinstance(v, (dict, list)):
                        walk(v)
            elif isinstance(o, list):
                for v in o:
                    walk(v)
        walk(data)
        return out

    def _fetch_detail(self, ev: dict, kind: str) -> tuple[dict, dict] | None:
        path = f"palinsesto/{'live' if kind == 'live' else 'prematch'}/v1/eventDetail/{ev.get('codicePalinsesto', 1)}-{ev['codiceAvvenimento']}"
        try:
            d = self.get(path, metaTplEnabled="true")
        except Exception as e:  # noqa: BLE001
            if "bloqueo" in str(e):
                raise
            log.debug("detalle %s: %s", path, e)
            return None
        av = d.get("avvenimentoFe") or ev
        if kind == "live" and not av.get("livescore"):
            av = {**av, "livescore": ev.get("livescore")}
        return av, d

    def live_cycle(self) -> tuple[int, int]:
        tree = self.get("palinsesto/live/alberatura")
        events = [e for e in self._events_in(tree) if e.get("live", True) and f"{e.get('codiceDisciplina')}-{e.get('codiceManifestazione')}" in self.leagues]
        in_tree = {str(e.get("codiceAvvenimento")) for e in events}
        # el árbol no trae marcador: lo da el eventDetail. Limita detalles por ciclo y rota.
        cap = int(self.cfg.get("live_detail_per_cycle", 12))
        if len(events) > cap:
            self._live_rr = (self._live_rr + cap) % len(events)
            events = (events + events)[self._live_rr:self._live_rr + cap]
        by_sport: dict[str, list[dict]] = {}
        present: set[str] = set()
        workers = max(1, int(self.cfg.get("workers", 4)))
        with ThreadPoolExecutor(max_workers=workers) as ex:
            for res in ex.map(lambda e: self._fetch_detail(e, "live"), events):
                if not res:
                    continue
                av, d = res
                r = self._row(av, d, "live")
                if r:
                    by_sport.setdefault(r[0], []).append(r[1])
        rows = changed = 0
        for sp, rs in by_sport.items():
            present |= {r["event_id"] for r in rs}
            changed += self.store.save_rows(sp, "live", rs)
            rows += len(rs)
        self.store.sweep(present | in_tree, "live")      # lo que sigue en el árbol pero no se ha refrescado este ciclo se mantiene
        return rows, changed

    def prematch_league(self, key: str) -> tuple[int, int]:
        data = self.get(f"palinsesto/prematch/v1/schedaManifestazione/0/{key}", metaTplEnabled="true", deep="true")
        evs = [e for e in self._events_in(data) if not e.get("live")]
        hours = self.cfg.get("prematch_hours", 48)
        now = datetime.now(timezone.utc)
        todo = []
        for e in evs:
            try:
                dt = datetime.fromisoformat(e["data"].replace("Z", "+00:00"))
            except Exception:  # noqa: BLE001
                continue
            if timedelta(minutes=-5) <= dt - now <= timedelta(hours=hours):
                todo.append(e)
        by_sport: dict[str, list[dict]] = {}
        for e in todo:
            res = self._fetch_detail(e, "prematch")
            if not res:
                continue
            av, d = res
            r = self._row({**e, **{k: v for k, v in av.items() if v is not None}}, d, "prematch")
            if r:
                by_sport.setdefault(r[0], []).append(r[1])
        rows = changed = 0
        for sp, rs in by_sport.items():
            self._pm_present |= {r["event_id"] for r in rs}
            changed += self.store.save_rows(sp, "prematch", rs)
            rows += len(rs)
        return rows, changed

    def _pm_job(self, t0: float, once: bool):
        if not self._pm_queue and t0 - self._last_prematch >= self.cfg.get("interval_prematch", 60):
            self._pm_queue = list(self.leagues)
            self._pm_present = set()
            self._pm_rows = self._pm_changed = 0
            self._last_prematch = t0
        if not self._pm_queue:
            return None
        batch = len(self._pm_queue) if once else max(1, self.cfg.get("prematch_batch", 1))
        chunk, self._pm_queue = self._pm_queue[:batch], self._pm_queue[batch:]

        def _run():
            for key in chunk:
                try:
                    r, c = self.prematch_league(key)
                    self._pm_rows += r
                    self._pm_changed += c
                except Exception as e:  # noqa: BLE001
                    log.warning("prematch %s (%s): %s", key, self.leagues.get(key, ("", "", "?"))[2], e)
                    if "bloqueo" in str(e):
                        time.sleep(20)
            if not self._pm_queue:
                self.store.sweep(self._pm_present, "prematch")
                return f"prematch {self._pm_rows} ev / {self._pm_changed} cambios (pasada completa)"
            return f"prematch {self._pm_rows} ev / {self._pm_changed} cambios ({len(self._pm_queue)} ligas pendientes)"
        return _run

    def run(self, once: bool = False):
        backoff = 2
        while True:
            t0 = time.time()
            try:
                self._reload_if_changed()
                self.refresh_menu()
                rows, changed = self.live_cycle()
                msg = f"live {rows} ev / {changed} cambios"
                if not self._bg.busy():
                    job = self._pm_job(t0, once)
                    if job is not None:
                        r = self._bg.run(job, inline=once)
                        if r:
                            msg += " | " + r
                note = self._bg.note()
                if note:
                    msg += " | " + note
                self.store.set_status(**{f"{self.bk}_last_ok": time.time(), f"{self.bk}_live_events": rows,
                                         f"{self.bk}_transport": self.transport})
                log.info("%s [%s] (%.1fs)", msg, self.transport, time.time() - t0)
                backoff = 2
                if once:
                    return
            except Exception as e:  # noqa: BLE001
                if "bloqueo" in str(e):
                    backoff = max(backoff, 30)
                log.warning("error de ciclo: %s — reintento en %ss", e, backoff, exc_info=log.isEnabledFor(logging.DEBUG))
                self.store.set_status(**{f"{self.bk}_last_error": f"{time.time():.0f} {e}"})
                time.sleep(backoff)
                backoff = min(backoff * 2, 120)
                continue
            time.sleep(max(0.5, self.cfg.get("interval_live", 2) - (time.time() - t0)))


def list_catalog(c: Collector):
    c.refresh_menu(force=True)
    by: dict[str, list] = {}
    for key, (sport, label) in c._all.items():
        by.setdefault(sport, []).append((key, label))
    for sport, items in by.items():
        print(f"\n=== {sport}")
        for key, label in sorted(items, key=lambda x: x[1]):
            comp = c.leagues.get(key)
            print(f" {'✔' if comp else ' '} {label}   [{key}]" + (f" -> {comp[1]}" if comp else ""))
    print(f"\n{len(c.leagues)} competiciones mapeadas de {len(c._all)} vistas; fuentes útiles: {c._found_paths}")
    missing = [n for n in c.catalog.names() if n not in {v[1] for v in c.leagues.values()}]
    if missing:
        print("sin código todavía (añádelos en pokerstars.json → extra_competitions cuando los veas en la web):", ", ".join(missing))


def probe(c: Collector):
    print("API:", c.api, "| HTTP:", c.http_lib)
    found = c._catalog_sources(probe=True)
    print(f"\n{len(found)} competiciones encontradas en total")
    for k, v in sorted(found.items(), key=lambda x: (int(x[0].split('-')[0]), x[1])):
        if int(k.split("-")[0]) in c.sports:
            print(f"  {k:>10}  {v}")


def dump_event(c: Collector, eid: str, live: bool):
    c.refresh_menu(force=True)
    kind = "live" if live else "prematch"
    d = c.get(f"palinsesto/{kind}/v1/eventDetail/1-{eid}", metaTplEnabled="true")
    av = d.get("avvenimentoFe") or {}
    key = f"{av.get('codiceDisciplina')}-{av.get('codiceManifestazione')}"
    sport = c.sports.get(av.get("codiceDisciplina"), "futbol")
    c.leagues.setdefault(key, (sport, "?", "?"))
    home = ((av.get("firstCompetitor") or {}).get("description") or av.get("descrizione", " - ").split(" - ")[0]).strip()
    away = ((av.get("secondCompetitor") or {}).get("description") or av.get("descrizione", " - ").split(" - ")[-1]).strip()
    print(av.get("descrizione"), "|", av.get("data"), "| manif", key, "|", c._state(av, sport))
    sc_map = d.get("scommessaMap") or {}
    for k, ia in (d.get("infoAggiuntivaMap") or {}).items():
        fam = (sc_map.get("-".join(str(k).split("-")[:3])) or {}).get("descrizione") or ""
        sels = market_selections(fam, ia, sport, home, away)
        print(f"{fam[:40]:<40} | {ia.get('descrizione', '')[:55]:<55} -> "
              + (", ".join(f"{s['market']} {s.get('player') or ''} {s['selection']} {s.get('line') if s.get('line') is not None else ''} @{s['price']}" for s in sels) or "(sin mapear)"))
    r = c._row(av, d, kind)
    if r:
        print(f"\n{r[0]}: {len(r[1]['selections'])} selecciones | {r[1]['url']}")


def raw_path(c: Collector, path: str):
    """Inspección de una ruta de la API: claves de primer nivel, tamaño y muestra (para descubrir estructuras nuevas)."""
    d = c.get(path, metaTplEnabled="true")
    txt = json.dumps(d, ensure_ascii=False)
    print(f"{path}: {len(txt)} bytes")

    def shape(o, depth=0, key="root"):
        pad = "  " * depth
        if isinstance(o, dict):
            print(f"{pad}{key}: dict[{len(o)}] keys={list(o)[:12]}")
            if depth < 3:
                for k, v in list(o.items())[:6]:
                    shape(v, depth + 1, str(k))
        elif isinstance(o, list):
            print(f"{pad}{key}: list[{len(o)}]")
            if o and depth < 3:
                shape(o[0], depth + 1, key + "[0]")
        else:
            print(f"{pad}{key}: {str(o)[:80]!r}")
    shape(d)
    found: dict[str, str] = {}
    c._walk_manifs(d, found)
    print(f"competiciones detectadas por el walker: {len(found)}")
    print("muestra:", txt[:2500])


def main():
    logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"), format="%(asctime)s %(levelname)s %(name)s: %(message)s", datefmt="%H:%M:%S")
    cfg = pace.apply(json.loads(CFG_PATH.read_text(encoding="utf-8")))
    c = Collector(cfg)
    if "--probe" in sys.argv:
        probe(c)
        return
    if "--list" in sys.argv:
        list_catalog(c)
        return
    if "--raw" in sys.argv:
        raw_path(c, sys.argv[sys.argv.index("--raw") + 1])
        return
    if "--dump" in sys.argv:
        dump_event(c, sys.argv[sys.argv.index("--dump") + 1], "--live" in sys.argv)
        return
    c.run(once="--once" in sys.argv)


if __name__ == "__main__":
    main()
