"""
ptslice.py — decodificador del formato binario de "slices" de Playtech Vision/Nexus (sportswidget).

Lo usan Sportium y Marca Apuestas (sportswidget-cdn.<casa>.es/v2/getslice/...). Cada slice es LZMA
(formato .lzma "alone") que envuelve una memoria columnar:

    201 ... 202                        cabecera (fecha de creación en +7, nº tablas u16 en +11, offsets u32 desde +18)
    tabla: 203 @t, 204 @t+9            total u32 @t+1, header u16 @t+5, nº columnas u16 @t+7, offsets u32 @t+10, nombre tras ellos
    columna: 206 @c, 207 @c+20         total u32 @c+1, header u16 @c+5, max u32 @c+7, count u32 @c+11, tipo u8 @c+15, nombre @c+21
    tipos: 0 byte · 1 bool(bitset) · 2 int16 · 3 uint16 · 4 int32 · 5 uint32 · 6 fecha(u32 s) · 7 int64 · 10 string (u32 offset → u16 len + utf8)

Portado de la lógica del service-worker de la web (funciones Bu/xu/Uu/pu). `decode(blob)` devuelve
{tabla: {columna: [valores]}} (usa rows() para iterar filas).
"""
from __future__ import annotations

import lzma
import struct
from datetime import datetime, timezone


def _u16(b: bytes, o: int) -> int:
    return b[o] | (b[o + 1] << 8)


def _u32(b: bytes, o: int) -> int:
    return struct.unpack_from("<I", b, o)[0]


def _str(b: bytes, o: int) -> str:
    n = _u16(b, o)
    return b[o + 2:o + 2 + n].decode("utf-8", "replace") if n else ""


def _column(b: bytes, c: int) -> tuple[str, list]:
    if b[c] != 206 or b[c + 20] != 207:
        raise ValueError(f"etiqueta de columna inválida en {c}")
    header = _u16(b, c + 5)
    count = _u32(b, c + 11)
    typ = b[c + 15]
    name = _str(b, c + 21)
    items = c + header
    if typ == 0:
        vals = list(b[items:items + count])
    elif typ == 1:
        vals = [bool((b[items + (i >> 3)] >> (i & 7)) & 1) for i in range(count)]
    elif typ == 2:
        vals = list(struct.unpack_from(f"<{count}h", b, items))
    elif typ == 3:
        vals = list(struct.unpack_from(f"<{count}H", b, items))
    elif typ == 4:
        vals = list(struct.unpack_from(f"<{count}i", b, items))
    elif typ == 5:
        vals = list(struct.unpack_from(f"<{count}I", b, items))
    elif typ == 6:
        vals = [datetime.fromtimestamp(v, tz=timezone.utc) for v in struct.unpack_from(f"<{count}I", b, items)]
    elif typ == 7:
        vals = list(struct.unpack_from(f"<{count}q", b, items))
    elif typ == 10:
        offs = struct.unpack_from(f"<{count}I", b, items)
        vals = [_str(b, o) for o in offs]
    else:
        raise ValueError(f"tipo de columna desconocido {typ}")
    return name, vals


def _table(b: bytes, t: int) -> tuple[str, list[dict]]:
    if b[t] != 203 or b[t + 9] != 204:
        raise ValueError(f"etiqueta de tabla inválida en {t}")
    ncols = _u16(b, t + 7)
    name = _str(b, t + 10 + 4 * ncols)
    cols = {}
    for i in range(ncols):
        cn, vals = _column(b, _u32(b, t + 10 + 4 * i))
        cols[cn] = vals
    return name, cols


def _table_name(b: bytes, t: int) -> str:
    return _str(b, t + 10 + 4 * _u16(b, t + 7))


def decode_memory(b: bytes, tables: set[str] | None = None) -> dict[str, dict[str, list]]:
    """Memoria descomprimida -> {tabla: {columna: [valores]}} (columnar, barato en memoria)."""
    if b[0] != 201 or b[17] != 202:
        raise ValueError("cabecera de memoria inválida")
    ntab = _u16(b, 11)
    out: dict[str, dict[str, list]] = {}
    for s in range(ntab):
        off = _u32(b, 18 + 4 * s)
        if off == 0:
            break
        name = _table_name(b, off)
        if name == "BinBag" or (tables is not None and name not in tables):
            continue
        out[name] = _table(b, off)[1]
    return out


def decompress(blob: bytes, max_len: int = 200_000_000) -> bytes:
    """LZMA "alone" (cabecera de 13 bytes: props, dict_size u32, tamaño u64). Los slices de Playtech llevan
    tamaño conocido *y* marcador de fin; algunas liblzma (p.ej. la del Python 3.12 de Windows) rechazan esa
    combinación con "Corrupt input data", así que se descomprime en modo RAW con los parámetros de la cabecera
    y se corta al tamaño declarado."""
    if len(blob) < 13:
        raise ValueError("slice demasiado corto")
    props = blob[0]
    dict_size = struct.unpack_from("<I", blob, 1)[0]
    size = struct.unpack_from("<Q", blob, 5)[0]
    if props >= 225:
        raise ValueError("cabecera LZMA inválida")
    filters = [{"id": lzma.FILTER_LZMA1, "dict_size": max(dict_size, 4096), "lc": props % 9, "lp": (props // 9) % 5, "pb": props // 45}]
    d = lzma.LZMADecompressor(format=lzma.FORMAT_RAW, filters=filters)
    limit = min(size, max_len) if size != 0xFFFFFFFFFFFFFFFF else max_len
    out = d.decompress(blob[13:], max_length=limit)
    if size != 0xFFFFFFFFFFFFFFFF and len(out) != size:
        raise ValueError(f"tamaño descomprimido {len(out)} != declarado {size}")
    return out


def decode(blob: bytes, tables: set[str] | None = None) -> dict[str, dict[str, list]]:
    """Slice comprimido (.bin) -> tablas columnares. `tables` limita qué tablas se materializan."""
    return decode_memory(decompress(blob), tables)


def rows(table: dict[str, list]):
    """Itera una tabla columnar como dicts fila a fila."""
    if not table:
        return
    keys = list(table)
    n = len(table[keys[0]])
    for i in range(n):
        yield {k: table[k][i] for k in keys}


if __name__ == "__main__":
    import sys
    tabs = decode(open(sys.argv[1], "rb").read())
    for k, tab in tabs.items():
        n = len(next(iter(tab.values()))) if tab else 0
        print(f"== {k} ({n})")
        for i, r in enumerate(rows(tab)):
            if i >= 3:
                break
            print("   ", {a: (str(v)[:60]) for a, v in r.items()})
