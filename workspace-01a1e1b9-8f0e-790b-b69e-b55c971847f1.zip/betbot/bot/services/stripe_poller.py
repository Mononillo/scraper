"""
StripePoller: consulta Stripe periódicamente y sincroniza las suscripciones
con la base de datos local.

Se usa como alternativa al webhook cuando NO hay dominio HTTPS público
(imprescindible para el webhook).

Cómo funciona:
- Cada N minutos pide a Stripe la lista de suscripciones activas.
- Compara con la BD local:
    · Suscripción nueva/renovada → activa al usuario y le notifica.
    · Suscripción cancelada     → desactiva al usuario y le notifica.
    · Cambio de plan            → actualiza el plan.
- Guarda el `stripe_customer_id` en el usuario para poder abrir el portal.

Ventajas:
    · Sin dominio, sin HTTPS, sin puertos abiertos.
Contras:
    · Delay de N minutos entre pago y activación.
    · Consume llamadas a la API de Stripe (dentro de los límites gratuitos).
"""
from __future__ import annotations
import logging
from datetime import datetime
from typing import Optional

import stripe
from telegram import Bot

from config import CONFIG
from data.repository import UserRepository
from services.subscription import SubscriptionService

log = logging.getLogger(__name__)


class StripePoller:

    def __init__(self, bot: Bot, users: UserRepository,
                 subs: SubscriptionService):
        self.bot = bot
        self.users = users
        self.subs = subs
        stripe.api_key = CONFIG.stripe_secret_key

        # Mapa inverso: price_id → plan_key
        self._price_to_plan = {
            plan["price_id"]: key
            for key, plan in CONFIG.plans.items()
            if plan.get("price_id")
        }

        # Event loop principal (se captura al primer poll)
        self._main_loop = None

    # ══════════════════════════════════════════════════════
    #  ENTRY POINT — llamado por el JobQueue del bot
    # ══════════════════════════════════════════════════════
    async def poll(self):
        if not CONFIG.stripe_secret_key:
            return
        # Capturamos el event loop del bot para poder programar corutinas
        # desde el thread pool donde corre la llamada a Stripe
        import asyncio
        if self._main_loop is None:
            self._main_loop = asyncio.get_running_loop()
        try:
            await asyncio.wait_for(
                asyncio.to_thread(self._sync_subscriptions_blocking),
                timeout=60,
            )
        except asyncio.TimeoutError:
            log.warning("⏱ Stripe poll timeout (60s) — se saltó este ciclo")
        except Exception as e:
            log.error("Poll Stripe falló: %s", e)

    def _sync_subscriptions_blocking(self):
        """Versión síncrona que corre en un thread pool para no bloquear asyncio."""
        seen_users: set[int] = set()
        notifications = []  # (user_id, texto) para enviar al final

        # ══════════════════════════════════════════════════
        #  1) Una sola suscripción por usuario.
        #     Si alguien compró dos veces (dos planes activos a la vez),
        #     procesar las DOS hacía que el plan "cambiara" en cada vuelta
        #     y se acumularan días sin parar. Nos quedamos con la más nueva.
        # ══════════════════════════════════════════════════
        por_usuario: dict[int, list] = {}

        for sub in stripe.Subscription.list(
                status="all", limit=100, expand=["data.customer"]
        ).auto_paging_iter():
            uid = self._extract_telegram_id(sub)
            if not uid:
                continue
            por_usuario.setdefault(uid, []).append(sub)

        # De cada usuario usamos la suscripción activa más reciente; el resto
        # sólo genera avisos informativos (si se cancelan).
        by_user: dict[int, object] = {}
        for uid, subs in por_usuario.items():
            activas = [x for x in subs if x.status in ("active", "trialing")]
            pool = activas or subs
            by_user[uid] = max(pool, key=self._sub_start)
            if len(activas) > 1:
                log.warning(
                    "⚠️ El usuario %s tiene %d suscripciones ACTIVAS en Stripe (%s). "
                    "Sólo uso la más reciente. Cancela el resto en el panel de "
                    "Stripe para que no se le siga cobrando.", uid, len(activas),
                    ", ".join(x.id for x in activas[1:]))

        for user_id, sub in by_user.items():
            seen_users.add(user_id)

            # Avisos por las demás suscripciones canceladas (duplicados)
            user = self.users.find(user_id)
            if user and user.subscription.is_active:
                for otro in por_usuario.get(user_id, []):
                    if otro is sub or otro.status not in (
                            "canceled", "incomplete_expired", "unpaid"):
                        continue
                    self._avisar_una_vez(notifications, user_id,
                        f"cancel:{otro.id}",
                        f"*{self._txt(user_id, 'sub.cancelled')}*\n\n"
                        f"{self._txt(user_id, 'sub.cancelled_side')}")
                    break        # uno solo, para no spampear

            plan_key = self._extract_plan(sub)
            customer_id = sub.customer if isinstance(sub.customer, str) else sub.customer.id
            expires_at = self._extract_expires_at(sub)

            user = self.users.find(user_id)
            if not user:
                user = self.users.get_or_create(user_id)

            was_active = user.subscription.is_active
            was_plan   = user.subscription.plan.value if user.subscription.plan else None

            if sub.status in ("active", "trialing"):
                # El poller se ejecuta cada pocos minutos: DEBE ser
                # idempotente. Si no ha cambiado nada, no tocamos nada.
                # (Antes esto llamaba a activate() en cada vuelta y, al
                # acumular días, las suscripciones crecían sin parar.)
                # La suscripción que ya teníamos guardada, ¿es la misma?
                prev_sub = user.subscription.stripe_subscription_id
                same_sub = bool(prev_sub and prev_sub == sub.id)

                # Sólo acumulamos si es OTRA suscripción: si es la misma,
                # ver el plan "distinto" significa que hay duplicados, y
                # acumular ahí inflaría los días en cada sondeo.
                plan_changed = bool(
                    was_active and was_plan and was_plan != plan_key
                    and not same_sub
                )

                # sync_stripe ya es idempotente: sólo escribe si hace falta,
                # nunca acorta la fecha y deja rastro en el historial.
                self.subs.sync_stripe(
                    user, plan_key,
                    expires_at=expires_at,
                    customer_id=customer_id,
                    subscription_id=sub.id,
                    plan_changed=plan_changed,
                )
                # Sólo avisamos si el ESTADO ha cambiado de verdad. Comparamos
                # contra el valor POSTERIOR a la sincronización: así un
                # sondeo repetido nunca manda nada.
                ahora_activo = user.subscription.is_active
                ahora_plan   = (user.subscription.plan.value
                                if user.subscription.plan else None)

                if not was_active and ahora_activo:
                    notifications.append((user_id,
                        f"✅ *¡Pago confirmado!*\n\n"
                        f"Plan *{plan_key}* activo hasta el "
                        f"{expires_at.strftime('%d/%m/%Y') if expires_at else '—'}."
                    ))
                elif (was_active and was_plan != plan_key
                        and ahora_plan == plan_key):
                    notifications.append((user_id,
                        f"🔄 *Plan actualizado*\n\nAhora estás en el plan *{plan_key}*."
                    ))
            elif sub.status in ("canceled", "incomplete_expired", "unpaid"):
                if was_active:
                    es_actual = (
                        user.subscription.stripe_subscription_id == sub.id
                    )
                    if es_actual:
                        # Era la suscripción que estaba usando: se queda sin acceso
                        self.subs.deactivate(user)
                        self._avisar_una_vez(notifications, user_id,
                            f"cancel:{sub.id}",
                            f"*{self._txt(user_id, 'sub.cancelled')}*\n\n"
                            f"{self._txt(user_id, 'sub.cancelled_body')}")
                    else:
                        # Suscripción duplicada cancelada: su plan sigue activo
                        self._avisar_una_vez(notifications, user_id,
                            f"cancel:{sub.id}",
                            f"*{self._txt(user_id, 'sub.cancelled')}*\n\n"
                            f"{self._txt(user_id, 'sub.cancelled_side')}")
            elif sub.status == "past_due":
                periodo = getattr(sub, "current_period_end", None) or 0
                self._avisar_una_vez(notifications, user_id,
                    f"pastdue:{sub.id}:{periodo}",
                    "⚠️ *No hemos podido cobrar tu suscripción*")

        # Programar las notificaciones asincrónicamente en el loop del bot
        import asyncio
        loop = self._main_loop
        if loop and notifications:
            for uid, text in notifications:
                asyncio.run_coroutine_threadsafe(self._notify(uid, text), loop)
        elif notifications:
            log.warning("No hay event loop capturado, %d notificaciones perdidas",
                        len(notifications))

    # Mantengo el método async por compatibilidad, pero ya no se usa
    async def _sync_subscriptions(self):
        self._sync_subscriptions_blocking()

    # ══════════════════════════════════════════════════════
    #  HELPERS
    # ══════════════════════════════════════════════════════
    @staticmethod
    def _sub_start(sub) -> int:
        """Inicio del periodo actual, para quedarnos con la suscripción más nueva."""
        val = getattr(sub, "current_period_start", None)
        if not val:
            val = getattr(sub, "created", None) or 0
        try:
            return int(val)
        except (TypeError, ValueError):
            return 0

    @staticmethod
    def _meta_get(sub, key: str) -> Optional[str]:
        """
        Acceso robusto a metadata: los objetos Stripe modernos no siempre
        soportan .get() ni las funciones habituales de dict.
        """
        try:
            meta = sub.metadata
            # Intentar como dict
            if hasattr(meta, "get"):
                v = meta.get(key)
                if v:
                    return v
            # Intentar como atributo
            v = getattr(meta, key, None)
            if v:
                return v
            # Intentar como getitem
            try:
                return meta[key]
            except (KeyError, TypeError):
                pass
        except Exception:
            pass
        return None

    def _extract_telegram_id(self, sub) -> Optional[int]:
        raw = self._meta_get(sub, "telegram_user_id")
        if not raw:
            return None
        try:
            return int(raw)
        except ValueError:
            return None

    def _extract_plan(self, sub) -> str:
        # 1) Preferir el que viene en metadata (más fiable)
        raw = self._meta_get(sub, "plan")
        if raw and raw in CONFIG.plans:
            return raw
        # 2) Fallback: mapear por price_id
        try:
            price_id = sub["items"]["data"][0]["price"]["id"]
        except Exception:
            price_id = None
        return self._price_to_plan.get(price_id, "monthly")

    def _extract_expires_at(self, sub) -> Optional[datetime]:
        # Usamos current_period_end (timestamp Unix)
        try:
            ts = sub.current_period_end
            if ts:
                return datetime.fromtimestamp(ts)
        except Exception:
            pass
        return None

    def _avisar_una_vez(self, lista, user_id: int, clave: str, texto: str):
        """
        Añade el aviso SÓLO si no se lo hemos mandado ya.

        Sin esto, hechos permanentes (una suscripción cancelada lo está para
        siempre) generarían un aviso en cada sondeo, cada 5 minutos.
        """
        if self.users.notice_sent(user_id, clave):
            return False
        self.users.mark_notice(user_id, clave)
        lista.append((user_id, texto))
        return True

    def _txt(self, user_id: int, key: str) -> str:
        """
        Texto del aviso en el idioma del usuario.

        Usa el repositorio del propio poller: abrir una conexión nueva a
        CONFIG.db_path crearía el fichero de la BD si aún no existe.
        """
        try:
            from i18n import t as _t
            u = self.users.find(user_id) if self.users else None
            lang = (u.filters.language if u and u.filters else "es") or "es"
            return _t(key, lang)
        except Exception:                                   # noqa: BLE001
            from i18n import t as _t
            return _t(key, "es")

    async def _notify(self, user_id: int, text: str):
        try:
            await self.bot.send_message(
                chat_id=user_id, text=text, parse_mode="Markdown"
            )
        except Exception as e:
            log.warning("No pude notificar a %s: %s", user_id, e)
