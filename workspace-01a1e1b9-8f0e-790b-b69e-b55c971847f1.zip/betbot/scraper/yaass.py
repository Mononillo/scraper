"""
yaass.py — colector de cuotas de Yaass (yaasscasino.es, Grupo Orenes, antes Wanabet).

Sportsbook propio de Orenes (feed Sportradar/UOF) con API GraphQL pública, sin cookies ni WAF; solo hace falta la
cabecera `x-api-key` fija que lleva el front y Origin/Referer de online-sportsbook.orenes.tech:
    POST https://online-sportsbook.orenes.tech/offermanager/graphql   {operationName, variables, query}
      categories(sportKeys,…)          -> categorías con sus torneos (tournamentId uuid)            (catálogo)
      currentOffer(status:"Live"|"Prematch", sportKeys, tournamentsId, to, first/after)  -> eventos con TODOS
                                           los mercados (marketHeaders) ya incluidos: una petición por deporte en
                                           directo y una por torneo en pre-partido, sin detalle por evento.
Las consultas de abajo son versiones reducidas de las del front (solo los campos que usamos: ~20x menos bytes).

Mercados: `marketKey` es un id propio de Orenes (estable por deporte; NO es el id UOF) y la línea viene en
`marketSpecialSelectionsValues` (total=, hcp=, setnr=, quarternr=, player=). Se normalizan con la tabla MK de
abajo (determinista, sin depender de textos); lo que no está en la tabla no se guarda.

Uso:  python yaass.py            (bucle)     --once     --list (competiciones)     --dump <eventId>
"""
from __future__ import annotations

import fastjson as json
import logging
import os
import re
import sys
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

import requests

from competitions import Competitions
from storage import OddsStore
import pace

log = logging.getLogger("yaass")
CFG_PATH = Path(os.getenv("YAASS_CFG", Path(__file__).parent / "yaass.json"))

SPORTS = {1: "futbol", 2: "baloncesto", 5: "tenis"}

Q_CATS = """query categories($sportKeys:[Short!],$first:Int,$after:String){
 categories(tenantId:"{T}",sportKeys:$sportKeys,minNumOfEvents:1,first:$first,after:$after){
  pageInfo{endCursor hasNextPage}
  nodes{name categoryId tournamentCorrelations(sportKeys:$sportKeys,minNumOfEvents:1){
   tournaments{tournamentId tournamentName numberOfEvents}}}}}"""

# campos de evento comunes a currentOffer / eventsById / suscripción eventsChanged (yaass_push.py)
FIELDS = """eventId sportKey isLive eventName offerActive utcStartDate
   tournament{tournamentId tournamentName mainCategory{categoryId name}}
   ... on Fixture{ competitors{competitorName} minute isPaused score summary
    marketHeaders(onlyMainMarkets:false,isActive:true){marketKey markets{marketId marketKey marketName active marketTags
     marketSpecialSelectionsValues{key value}
     selectionHeaders{selectionKey selectionName selections{selectionId selectionName price offerStatus}}}}}"""

Q_OFFER = """query currentOffer($first:Int,$after:String,$status:EventFilterEnum,$sportKeys:[Short!],$to:DateTime,$tournamentsId:[String],$types:[EventTypeEnum!]!){
 currentOffer(first:$first,after:$after,filter:{tenantId:"{T}",types:$types,sportKeys:$sportKeys,status:$status,to:$to,tournamentsId:$tournamentsId,onlyMainMarkets:false}){
  pageInfo{endCursor hasNextPage}
  nodes{{F}}}}"""

Q_EVENT = """query eventsById($eventsId:[Uuid!]!){
 eventsById(tenantId:"{T}",eventsId:$eventsId){{F}}}"""

# ── marketKey de Orenes → taxonomía propia ───────────────────────────────────────────────────────────────────
# (market, tipo). tipo: "result" (1/X/2 por nombre de equipo), "dc" (1X/12/X2), "total" (línea total=, más/menos
# por signo +/- del nombre), "hcp" (dos selecciones, hcp= es la línea del LOCAL), "yesno" (Sí/No), "sets"
# (nº de sets 2/3 -> SETS Over/Under 2.5), "scorer" (cada selección es un jugador -> PLAYER_GOALS Over 0.5),
# "pplus" (prop de jugador 'Apellido, Nombre - N+' -> Over N-0.5), "ptotal" (prop de jugador con total=).
# {n} = nº de periodo (quarternr / setnr).  Se omiten a propósito los mercados a 3 bandas de baloncesto
# (ganador 1ª parte / cuarto con X) para no mezclarlos con los 2-way del resto de casas.
MK: dict[str, dict[int, tuple[str, str]]] = {
    "futbol": {
        1: ("1X2", "result"), 13: ("DC", "dc"), 14: ("DNB", "result"), 22: ("1X2_1H", "result"), 44: ("1X2_2H", "result"),
        344: ("DC_1H", "dc"), 5: ("TOTAL", "total"), 6: ("TOTAL_1H", "total"), 45: ("TOTAL_2H", "total"),
        59: ("TOTAL_HOME", "total"), 60: ("TOTAL_AWAY", "total"), 20035: ("TOTAL_HOME_1H", "total"),
        20036: ("TOTAL_AWAY_1H", "total"), 111: ("CORNERS", "total"), 25: ("BTTS", "yesno"), 40: ("BTTS_1H", "yesno"),
        83: ("BTTS_2H", "yesno"), 106: ("HANDICAP", "hcp"),
        81: ("PLAYER_GOALS", "scorer"), 20085: ("PLAYER_GOALS", "pplus"), 20086: ("PLAYER_SHOTS", "pplus"),
        20087: ("PLAYER_SHOTS_OT", "pplus"), 20088: ("PLAYER_PASSES", "pplus"),
    },
    "baloncesto": {
        29: ("1X2", "result"), 5: ("TOTAL", "total"), 106: ("HANDICAP", "hcp"), 6: ("TOTAL_1H", "total"),
        20034: ("HANDICAP_1H", "hcp"), 59: ("TOTAL_HOME", "total"), 60: ("TOTAL_AWAY", "total"),
        355: ("1X2_Q{n}", "result"), 356: ("HANDICAP_Q{n}", "hcp"), 357: ("TOTAL_Q{n}", "total"),
        20079: ("PLAYER_POINTS", "ptotal"), 20080: ("PLAYER_ASSISTS", "ptotal"), 20081: ("PLAYER_REBOUNDS", "ptotal"),
        20082: ("PLAYER_THREES", "ptotal"),
    },
    "tenis": {
        29: ("1X2", "result"), 16: ("1X2_SET{n}", "result"), 34: ("TOTAL", "total"), 37: ("TOTAL_SET{n}", "total"),
        114: ("HANDICAP", "hcp"), 20: ("SETS", "sets"),
    },
}


def _num(v) -> float | None:
    try:
        return float(str(v).replace(",", "."))
    except (TypeError, ValueError):
        return None


def _half(v: float | None) -> bool:
    """True solo para líneas x.5 (las únicas comparables entre casas sin reembolso/asiáticas)."""
    return v is not None and abs(abs(v) % 1 - 0.5) < 1e-9


def _player_name(raw: str) -> str:
    """'Moreno, Gerard' -> 'Gerard Moreno' (como el resto de casas)."""
    raw = (raw or "").strip()
    if "," in raw and "/" not in raw:
        a, b = raw.split(",", 1)
        return f"{b.strip()} {a.strip()}".strip()
    return raw


def _fold(s: str) -> str:
    return re.sub(r"\s+", " ", (s or "").strip().lower())


def _side(name: str, home: str, away: str) -> str | None:
    """Nombre de selección -> '1' / 'X' / '2' (por nombre de equipo, 'Local'/'Visitante' o 1/X/2 literales)."""
    n = _fold(name)
    if n in ("x", "empate", "draw"):
        return "X"
    if n in ("1", "local", "home") or (home and n == _fold(home)):
        return "1"
    if n in ("2", "visitante", "away") or (away and n == _fold(away)):
        return "2"
    return None


def _ou(name: str, header: str) -> str | None:
    """'+2.5' / '- 2.5' / 'Más de' / 'Menos' -> Over / Under."""
    for s in (name, header):
        s = (s or "").strip().lower()
        if s.startswith("+") or s.startswith("más") or s.startswith("mas") or s.startswith("over"):
            return "Over"
        if s.startswith("-") or s.startswith("menos") or s.startswith("under"):
            return "Under"
    return None


def market_selections(m: dict, sport: str, home: str, away: str) -> list[dict]:
    """Un mercado del feed -> selecciones normalizadas (market, selection, line, player, price)."""
    rule = MK.get(sport, {}).get(m.get("marketKey") or -1)
    if not rule or m.get("active") is False:
        return []
    market, typ = rule
    ssv = {s["key"]: s["value"] for s in m.get("marketSpecialSelectionsValues") or [] if s.get("key")}
    if "{n}" in market:
        n = ssv.get("quarternr") or ssv.get("setnr") or ""
        if not str(n).isdigit():
            return []
        market = market.replace("{n}", str(n))
    sels = [(h.get("selectionName") or "", s) for h in m.get("selectionHeaders") or []
            for s in h.get("selections") or []
            if s.get("price") and (s.get("offerStatus") or "Active") == "Active" and float(s["price"]) > 1.0]
    out: list[dict] = []
    if typ == "result":
        for hdr, s in sels:
            side = _side(s.get("selectionName") or hdr, home, away)
            if side:
                out.append({"market": market, "selection": side, "line": None, "price": s["price"]})
    elif typ == "dc":
        for hdr, s in sels:
            n = (s.get("selectionName") or hdr or "").replace(" ", "").upper()
            if n in ("1X", "12", "X2"):
                out.append({"market": market, "selection": n, "line": None, "price": s["price"]})
    elif typ == "total":
        line = _num(ssv.get("total"))
        if not _half(line):
            return []
        for hdr, s in sels:
            sel = _ou(s.get("selectionName") or "", hdr)
            if sel:
                out.append({"market": market, "selection": sel, "line": line, "price": s["price"]})
    elif typ == "hcp":
        h = _num(ssv.get("hcp", ssv.get("handicap")))
        if not _half(h) or len(sels) != 2:
            return []
        for i, (hdr, s) in enumerate(sels):
            side = _side(s.get("selectionName") or hdr, home, away) or ("1" if i == 0 else "2")
            if side == "1":
                out.append({"market": market, "selection": "1", "line": h, "price": s["price"]})
            elif side == "2":
                out.append({"market": market, "selection": "2", "line": -h, "price": s["price"]})
    elif typ == "yesno":
        for hdr, s in sels:
            n = _fold(s.get("selectionName") or hdr)
            sel = {"sí": "Yes", "si": "Yes", "yes": "Yes", "no": "No"}.get(n)
            if sel:
                out.append({"market": market, "selection": sel, "line": None, "price": s["price"]})
    elif typ == "sets":                                    # "2 sets" / "3 sets" (al mejor de 3) -> SETS 2.5
        names = {re.sub(r"\D", "", s.get("selectionName") or ""): s["price"] for _h, s in sels}
        if set(names) == {"2", "3"}:
            out.append({"market": market, "selection": "Under", "line": 2.5, "price": names["2"]})
            out.append({"market": market, "selection": "Over", "line": 2.5, "price": names["3"]})
    elif typ == "scorer":
        for _h, s in sels:
            name = _player_name(s.get("selectionName") or "")
            if name and _fold(name) not in ("ninguno", "no goal", "sin gol"):
                out.append({"market": market, "selection": "Over", "line": 0.5, "player": name, "price": s["price"]})
    elif typ == "pplus":                                   # 'Maguire, Harry - 2+' -> Over 1.5
        player = _player_name(ssv.get("player") or "")
        for _h, s in sels:
            mm = re.search(r"-\s*(\d+)\+\s*$", s.get("selectionName") or "")
            if not mm:
                continue
            name = player or _player_name((s.get("selectionName") or "").rsplit("-", 1)[0])
            if name and not (market == "PLAYER_GOALS" and mm.group(1) == "1"):   # 'Goles 1+' ya va por 'Marca algún gol' (81)
                out.append({"market": market, "selection": "Over", "line": int(mm.group(1)) - 0.5, "player": name,
                            "price": s["price"]})
    elif typ == "ptotal":
        player = _player_name(ssv.get("player") or "")
        line = _num(ssv.get("total"))
        if not player or not _half(line):
            return []
        for hdr, s in sels:
            sel = _ou(s.get("selectionName") or "", hdr)
            if sel:
                out.append({"market": market, "selection": sel, "line": line, "player": player, "price": s["price"]})
    return out


# ──────────────────────────────────────────────────────────────────────────────
class Collector:
    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.bk = cfg["bookmaker"]
        self.api = cfg["api"]
        self.tenant = cfg["tenant"]
        origin = cfg.get("origin", "https://online-sportsbook.orenes.tech")
        self.sess = requests.Session()
        self.sess.headers.update({"Accept": "*/*", "Content-Type": "application/json", "Origin": origin,
                                  "Referer": origin + "/", "x-api-key": cfg["api_key"], **(cfg.get("headers") or {})})
        self.catalog = Competitions()
        self.store = OddsStore(bookmaker=self.bk)
        self.tournaments: dict[str, tuple[str, str]] = {}        # tournamentId -> (deporte, competición canónica)
        self._all: list[tuple[str, str, str]] = []
        self._menu_at = 0.0
        self._last_prematch = 0.0
        self._pm_queue: list[str] = []
        self._cfg_mtime = CFG_PATH.stat().st_mtime
        self._bg = pace.Background(f"{self.bk}-prematch")
        self._last_req = 0.0
        self.transport = "requests"
        # push: suscripción websocket (yaass_push.py); el HTTP queda para sembrar/limpiar cada `push_refresh` s
        self.push = None
        if cfg.get("push", True):
            from yaass_push import Push
            self.push = Push(cfg, FIELDS, list(SPORTS))
        self._live_present: set[str] = set()       # ids en directo guardados (para el sweep en modo push)
        self._live_refresh_at = 0.0
        self._push_gen = -1

    # ── HTTP ──
    def gql(self, op: str, query: str, variables: dict) -> dict:
        gap = self.cfg.get("request_gap", 0.5) - (time.time() - self._last_req)
        if gap > 0:
            time.sleep(gap)
        body = {"operationName": op, "variables": variables, "query": query.replace("{F}", FIELDS).replace("{T}", self.tenant)}
        r = self.sess.post(self.api, json=body, timeout=30)
        self._last_req = time.time()
        if r.status_code in (403, 429):
            raise RuntimeError(f"{op} -> HTTP {r.status_code} (bloqueo/ritmo): pausa")
        if r.status_code != 200:
            raise RuntimeError(f"{op} -> HTTP {r.status_code}")
        data = json.loads(r.content)
        if data.get("errors"):
            raise RuntimeError(f"{op} -> {data['errors'][0].get('message')}")
        return data.get("data") or {}

    def _reload_if_changed(self):
        mt = CFG_PATH.stat().st_mtime
        if mt != self._cfg_mtime:
            self._cfg_mtime = mt
            self.cfg = pace.apply(json.loads(CFG_PATH.read_text(encoding="utf-8")))
            log.info("yaass.json recargado")
        self.catalog.reload()

    # ── catálogo ──
    def refresh_menu(self, force: bool = False):
        if not force and time.time() - self._menu_at < self.cfg.get("menu_ttl", 900):
            return
        found: dict[str, tuple[str, str]] = {}
        allt: list[tuple[str, str, str]] = []
        ok = True
        for sk, sport in SPORTS.items():
            after = None
            try:
                while True:
                    d = self.gql("categories", Q_CATS, {"sportKeys": [sk], "first": 100, "after": after})
                    page = d.get("categories") or {}
                    for c in page.get("nodes") or []:
                        for tc in c.get("tournamentCorrelations") or []:
                            for t in tc.get("tournaments") or []:
                                label = re.sub(r"\s+", " ", f"{c.get('name') or ''} - {t.get('tournamentName') or ''}").strip(" -")
                                allt.append((sport, t["tournamentId"], label))
                                if t["tournamentId"] in found:
                                    continue                   # el mismo torneo cuelga de varias categorías
                                comp = self.catalog.match(self.bk, sport, label)
                                if comp:
                                    found[t["tournamentId"]] = (sport, comp)
                    pi = page.get("pageInfo") or {}
                    if not pi.get("hasNextPage"):
                        break
                    after = pi.get("endCursor")
            except Exception as e:  # noqa: BLE001
                ok = False
                log.warning("catálogo %s: %s", sport, e)
        if found or (force and ok):
            self.tournaments = found
            self._all = allt
        self._menu_at = time.time()
        log.info("%d competiciones mapeadas en Yaass", len(self.tournaments))

    # ── eventos ──
    @staticmethod
    def _state(ev: dict, sport: str) -> tuple[str | None, str | None, str | None, bool]:
        """(score, period, timer, en_juego) a partir de minute/score/summary."""
        summ = ev.get("summary") or {}
        if isinstance(summ, str):
            try:
                summ = json.loads(summ)
            except ValueError:
                summ = {}
        pers = [p for p in summ.get("periodScores") or [] if isinstance(p, dict)]
        n = len(pers)
        minute = ev.get("minute")
        score = ev.get("score")
        if sport == "tenis":
            score = " ".join(f"{p.get('homeScore', 0)}:{p.get('awayScore', 0)}" for p in pers) or score
            period = f"Set {n}" if n else None
            timer = None
        elif sport == "baloncesto":
            period = (f"Q{n}" if n <= 4 else "Prórroga") if n else None
            timer = str(minute) if minute else None
        else:
            if n >= 3:
                period = "Prórroga"
            elif n == 2:
                period = "Descanso" if (not minute and ev.get("isPaused")) else "2ª parte"
            elif n == 1:
                period = "1ª parte"
            else:
                period = None
            timer = str(minute) if minute else None
        playing = bool(ev.get("isLive")) and (n > 0 or bool(minute))
        return score, period, timer, playing

    def _row(self, ev: dict, kind: str) -> tuple[str, dict] | None:
        t = self.tournaments.get((ev.get("tournament") or {}).get("tournamentId"))
        if not t or ev.get("offerActive") is False:
            return None
        sport, comp = t
        comps = [c.get("competitorName") or "" for c in ev.get("competitors") or []]
        if len(comps) < 2:
            parts = (ev.get("eventName") or "").split(" - ", 1)
            comps = parts if len(parts) == 2 else []
        if len(comps) < 2 or not comps[0] or not comps[1]:
            return None
        home, away = comps[0], comps[1]
        if sport == "tenis":
            home, away = _player_name(home), _player_name(away)
        score, period, timer, playing = self._state(ev, sport)
        if kind == "live" and not playing:
            return None
        dt = None
        try:
            dt = datetime.fromisoformat(ev["utcStartDate"].replace("Z", "+00:00")).astimezone()
        except Exception:  # noqa: BLE001
            pass
        if kind != "live" and dt and dt - datetime.now(dt.tzinfo) > timedelta(hours=self.cfg.get("prematch_hours", 48)):
            return None
        sels: list[dict] = []
        for h in ev.get("marketHeaders") or []:
            for m in h.get("markets") or []:
                sels.extend(market_selections(m, sport, comps[0], comps[1]))
        if not sels:
            return None
        row = {"event_id": ev["eventId"], "home": home, "away": away, "competition": comp,
               "date": dt.strftime("%Y-%m-%d") if dt else None, "start_time": dt.strftime("%H:%M") if dt else None,
               "url": self.cfg.get("event_url", "").format(event=ev["eventId"]), "selections": sels}
        if kind == "live":
            row.update(score=score, period=period, timer=timer)
        return sport, row

    def offer(self, status: str, sport_keys: list[int], tournaments: list[str] | None, hours: float | None = None) -> list[dict]:
        nodes: list[dict] = []
        after = None
        var = {"first": self.cfg.get("page_size", 50), "types": ["Fixture"], "status": status, "sportKeys": sport_keys,
               "tournamentsId": tournaments}
        if hours:
            var["to"] = (datetime.now(timezone.utc) + timedelta(hours=hours)).strftime("%Y-%m-%dT%H:%M:%S.000Z")
        for _ in range(10):
            d = self.gql("currentOffer", Q_OFFER, {**var, "after": after})
            page = d.get("currentOffer") or {}
            nodes.extend(page.get("nodes") or [])
            pi = page.get("pageInfo") or {}
            if not pi.get("hasNextPage"):
                break
            after = pi.get("endCursor")
        return nodes

    def live_cycle(self) -> tuple[int, int]:
        if self.push is not None and self.push.alive():
            self.transport = "push"
            refresh = self.cfg.get("push_refresh", 30)
            if self.push.generation != self._push_gen or time.time() - self._live_refresh_at >= refresh:
                self._push_gen = self.push.generation
                self.push.drain()                  # lo que llegó antes de la siembra ya viene en el HTTP
                return self._live_full()
            return self._live_push()
        self.transport = "requests"
        return self._live_full()

    def _live_push(self) -> tuple[int, int]:
        """Solo los eventos que han cambiado desde el ciclo anterior (0 peticiones HTTP)."""
        rows = changed = 0
        by_sport: dict[str, list[dict]] = {}
        for ev in self.push.drain():
            r = self._row(ev, "live")
            if r:
                by_sport.setdefault(r[0], []).append(r[1])
            elif ev.get("eventId") in self._live_present and (not ev.get("isLive") or ev.get("offerActive") is False):
                self._live_present.discard(ev["eventId"])     # terminado / retirado: fuera del sweep
        for sp, rs in by_sport.items():
            self._live_present |= {r["event_id"] for r in rs}
            changed += self.store.save_rows(sp, "live", rs)
            rows += len(rs)
        self.store.sweep(self._live_present, "live")
        return len(self._live_present), changed

    def _live_full(self) -> tuple[int, int]:
        rows = changed = 0
        present: set[str] = set()
        for sk, sport in SPORTS.items():
            tids = [tid for tid, (sp, _c) in self.tournaments.items() if sp == sport]
            if not tids:
                continue
            by_sport: dict[str, list[dict]] = {}
            for ev in self.offer("Live", [sk], tids):
                r = self._row(ev, "live")
                if r:
                    by_sport.setdefault(r[0], []).append(r[1])
            for sp, rs in by_sport.items():
                present |= {r["event_id"] for r in rs}
                changed += self.store.save_rows(sp, "live", rs)
                rows += len(rs)
        self.store.sweep(present, "live")
        self._live_present = present
        self._live_refresh_at = time.time()
        return rows, changed

    def prematch_tournament(self, tid: str) -> tuple[int, int]:
        sport, _c = self.tournaments[tid]
        sk = next(k for k, v in SPORTS.items() if v == sport)
        by_sport: dict[str, list[dict]] = {}
        for ev in self.offer("Prematch", [sk], [tid], hours=self.cfg.get("prematch_hours", 48)):
            r = self._row(ev, "prematch")
            if r:
                by_sport.setdefault(r[0], []).append(r[1])
        rows = changed = 0
        for sp, rs in by_sport.items():
            self._pm_present |= {r["event_id"] for r in rs}
            changed += self.store.save_rows(sp, "prematch", rs)
            rows += len(rs)
        return rows, changed

    def _pm_job(self, t0: float, once: bool):
        if not self._pm_queue and t0 - self._last_prematch >= self.cfg.get("interval_prematch", 240):
            self._pm_queue = list(self.tournaments)
            self._pm_present: set[str] = set()
            self._pm_rows = self._pm_changed = 0
            self._last_prematch = t0
        if not self._pm_queue:
            return None
        batch = len(self._pm_queue) if once else max(1, self.cfg.get("prematch_batch", 2))
        chunk, self._pm_queue = self._pm_queue[:batch], self._pm_queue[batch:]

        def _run():
            for tid in chunk:
                try:
                    r, c = self.prematch_tournament(tid)
                    self._pm_rows += r
                    self._pm_changed += c
                except Exception as e:  # noqa: BLE001
                    log.warning("prematch torneo %s: %s", tid[:8], e)
                    if "bloqueo" in str(e):
                        time.sleep(20)
            if not self._pm_queue:
                self.store.sweep(self._pm_present, "prematch")
                return f"prematch {self._pm_rows} ev / {self._pm_changed} cambios (pasada completa)"
            return f"prematch {self._pm_rows} ev / {self._pm_changed} cambios ({len(self._pm_queue)} torneos pendientes)"
        return _run

    def run(self, once: bool = False):
        backoff = 2
        while True:
            t0 = time.time()
            try:
                self._reload_if_changed()
                self.refresh_menu()
                rows, changed = self.live_cycle()
                msg = f"live {rows} ev / {changed} cambios"
                if self.transport == "push":
                    msg += f" [push {self.push.msgs} msgs, {self.push.bytes // 1024} KB]"
                if not self._bg.busy():
                    job = self._pm_job(t0, once)
                    if job is not None:
                        r = self._bg.run(job, inline=once)
                        if r:
                            msg += " | " + r
                note = self._bg.note()
                if note:
                    msg += " | " + note
                self.store.set_status(**{f"{self.bk}_last_ok": time.time(), f"{self.bk}_live_events": rows,
                                         f"{self.bk}_transport": self.transport})
                log.info("%s [%s] (%.1fs)", msg, self.transport, time.time() - t0)
                backoff = 2
                if once:
                    return
            except Exception as e:  # noqa: BLE001
                if "bloqueo" in str(e):
                    backoff = max(backoff, 30)
                log.warning("error de ciclo: %s — reintento en %ss", e, backoff, exc_info=log.isEnabledFor(logging.DEBUG))
                self.store.set_status(**{f"{self.bk}_last_error": f"{time.time():.0f} {e}"})
                time.sleep(backoff)
                backoff = min(backoff * 2, 120)
                continue
            interval = self.cfg.get("interval_live_push", 2) if self.transport == "push" else self.cfg.get("interval_live", 3)
            time.sleep(max(0.5, interval - (time.time() - t0)))


def list_catalog(c: Collector):
    c.refresh_menu(force=True)
    by: dict[str, list] = {}
    for sport, tid, label in sorted(set(c._all), key=lambda x: (x[0], x[2])):
        by.setdefault(sport, []).append((tid, label))
    for sport, items in by.items():
        print(f"\n=== {sport}")
        for tid, label in items:
            comp = c.tournaments.get(tid)
            print(f" {'✔' if comp else ' '} {label}   [{tid[:8]}]" + (f" -> {comp[1]}" if comp else ""))
    print(f"\n{len(c.tournaments)} torneos mapeados")


def dump_event(c: Collector, eid: str):
    c.refresh_menu(force=True)
    evs = c.gql("eventsById", Q_EVENT, {"eventsId": [eid]}).get("eventsById") or []
    if not evs:
        print("evento no encontrado")
        return
    ev = evs[0]
    sport = SPORTS.get(ev.get("sportKey"), "futbol")
    tid = (ev.get("tournament") or {}).get("tournamentId")
    c.tournaments.setdefault(tid, (sport, "?"))
    comps = [x.get("competitorName") or "" for x in ev.get("competitors") or []] or ["", ""]
    print(ev.get("eventName"), "|", ev.get("utcStartDate"), "| live:", ev.get("isLive"), "|", c._state(ev, sport))
    for h in ev.get("marketHeaders") or []:
        for m in h.get("markets") or []:
            ssv = " ".join(f"{s['key']}={s['value']}" for s in m.get("marketSpecialSelectionsValues") or [])
            sels = market_selections(m, sport, comps[0], comps[1])
            print(f"MK {m.get('marketKey')!s:>6} {m.get('marketName')[:45]:<45} {ssv:<28} -> "
                  + (", ".join(f"{s['market']} {s.get('player') or ''} {s['selection']} {s.get('line') if s.get('line') is not None else ''} @{s['price']}" for s in sels) or "(sin mapear)"))
    r = c._row(ev, "live" if ev.get("isLive") else "prematch")
    if r:
        print(f"\n{r[0]}: {len(r[1]['selections'])} selecciones | {r[1]['url']}")


def main():
    logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"), format="%(asctime)s %(levelname)s %(name)s: %(message)s", datefmt="%H:%M:%S")
    cfg = pace.apply(json.loads(CFG_PATH.read_text(encoding="utf-8")))
    c = Collector(cfg)
    if "--list" in sys.argv:
        list_catalog(c)
        return
    if "--dump" in sys.argv:
        dump_event(c, sys.argv[sys.argv.index("--dump") + 1])
        return
    c.run(once="--once" in sys.argv)


if __name__ == "__main__":
    main()
